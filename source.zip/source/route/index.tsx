import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import React from "react";
import { NAVIGATION } from "../navigation";
import BookMarkSignUp from "../screens/Authentication/BookmarkSignUp";
import FinishSignUp from "../screens/Authentication/FinishSignUp";
import Forgot from "../screens/Authentication/ForgotPassword";
import GeoLocation from "../screens/Authentication/GeoLocation";
import HabitsAndInterests from "../screens/Authentication/HabitsSignUp";
import Login from "../screens/Authentication/Login";
import LoginSignUp from "../screens/Authentication/LoginSignup";
import ReceivingHabitsSignUp from "../screens/Authentication/ReceivingHabitsSignUp";
import SignUp from "../screens/Authentication/Register";
import RegisterOtpScreen from "../screens/Authentication/RegisterOtp";
import Reset from "../screens/Authentication/ResetPassword";
import EditBookMarkerAccount from "../screens/Dashboard/Profile/EditBookmarkerAccount";
import EditNotification from "../screens/Dashboard/Profile/EditNotification";
import EditPassword from "../screens/Dashboard/Profile/EditPassword";
import EditSports from "../screens/Dashboard/Profile/EditSports";
import EditUserDetails from "../screens/Dashboard/Profile/EditUserDetail";
import ProfileScreen from "../screens/Dashboard/Profile/ProfileWireframe";
import StatisticsProfileTab from "../screens/Dashboard/Statistics/JockeyStatesTab/StatisticsProfileTab";
import TrackNews from "../screens/Dashboard/Statistics/TrackNews";
import TrackProfiles from "../screens/Dashboard/Statistics/TrackProfiles";
import TrainerProfileTab from "../screens/Dashboard/Statistics/TrainerStatesTab/TrainerProfileTab";
import TabStack from "../screens/Dashboard/TabStack";
import AdvertisingScreen from "../screens/Dashboard/TabStack/Advertising";
import SportMatchupsScreen from "../screens/Dashboard/TabStack/TabScreen/Sports/SportsMatchups/SportMatchupsScreen";
import SportTeam from "../screens/Dashboard/TabStack/TabScreen/Sports/SportsMatchups/SportTeam";
import TennisMarkets from "../screens/Dashboard/TopStack/TennisMarkets";

import HorsesTab from "../screens/Dashboard/Statistics/HorsesProfileTab/HorsesTab";
import TrainerStatsTab from "../screens/Dashboard/Statistics/TainerDetailsProfile/TrainerStatsTab";
import TrackProfileDetails from "../screens/Dashboard/Statistics/TrackProfileDetails";
import SplashScreen from "../screens/Splash";
import { ScreenOptions } from "../utils/constant";

const Stack = createNativeStackNavigator();

export default function Route() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={NAVIGATION.SPLASH}>
        <Stack.Screen
          name={NAVIGATION.SPLASH}
          component={SplashScreen}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.LOGIN}
          component={Login}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.REGISTER}
          component={SignUp}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.NEXT2SIGN_UP}
          component={LoginSignUp}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.NEXT3SIGN_UP}
          component={BookMarkSignUp}
          options={ScreenOptions}
        />

        <Stack.Screen
          name={NAVIGATION.NEXT4SIGN_UP}
          component={HabitsAndInterests}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.NEXT5SIGN_UP}
          component={ReceivingHabitsSignUp}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.NEXT6SIGN_UP}
          component={FinishSignUp}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.REGISTER_OTP}
          component={RegisterOtpScreen}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.FORGOT}
          component={Forgot}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.RESET}
          component={Reset}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.TAB_STACK}
          component={TabStack}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.PROFILE}
          component={ProfileScreen}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.USER_DETAILS}
          component={EditUserDetails}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.EDIT_PASSWORD}
          component={EditPassword}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.BOOK_MARKER}
          component={EditBookMarkerAccount}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.EDIT_SPORTS}
          component={EditSports}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.EDIT_NOTIFICATION}
          component={EditNotification}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.TRACK_PROFILES}
          component={TrackProfiles}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.TRACK_NEWS}
          component={TrackNews}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.JOCKEY_STATES}
          component={StatisticsProfileTab}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.TRAINER_TAB}
          component={TrainerProfileTab}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.ADVERTISING}
          component={AdvertisingScreen}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.GEOLOCATION}
          component={GeoLocation}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.SPORT_MATCHUPS}
          component={SportMatchupsScreen}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.SPORT_TEAM}
          component={SportTeam}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.TENNIS_MARKET}
          component={TennisMarkets}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.TRACK_PROFILE_DETAILS}
          component={TrackProfileDetails}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.TAINER_STATS_PROFILETAB}
          component={TrainerStatsTab}
          options={ScreenOptions}
        />
        <Stack.Screen
          name={NAVIGATION.HORSES_TAB}
          component={HorsesTab}
          options={ScreenOptions}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
