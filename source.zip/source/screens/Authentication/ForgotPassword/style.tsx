import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  mainLoginView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  signInText: {
    marginTop: Metrics.rfv(40),
  },
  svgIconStyle: {
    marginTop: Metrics.rfv(20),
    width: Metrics.rfv(71),
    height: Metrics.rfv(22),
    resizeMode: "contain",
  },
  signInTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(23),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(25),
  },
  horizontalContainerView: {
    alignItems: "center",
  },
  signUpTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Bold,
    lineHeight: Metrics.rfv(16),
    textDecorationLine: "underline",
    textDecorationColor: Colors.white,
    marginTop: Metrics.rfv(5),
    textAlign: "center",
  },
  emailTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    alignSelf: "flex-start",
    marginBottom: Metrics.rfv(5),
  },
  inputTextStyle: {
    marginHorizontal: Metrics.rfv(20),
  },
  width: {
    width: "100%",
  },
  height: {
    height: Metrics.rfv(40),
  },

  errorText: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
    color: Colors.red,
    marginTop: Metrics.rfv(5),
  },
  arrowContainerStyle: {
    width: Metrics.rfv(50),
    paddingVertical: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
  },
  backArrowStyle: {
    width: Metrics.rfv(16),
    height: Metrics.rfv(16),
  },
});
