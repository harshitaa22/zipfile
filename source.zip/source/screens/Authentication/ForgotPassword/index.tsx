import React, { useState } from "react";
import {
  Image,
  Keyboard,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import Button from "../../../component/Button/index";
import { NAVIGATION } from "../../../navigation";
import { Colors, CommonStyle, Images, Metrics } from "../../../theme/index";
import { BackArrow, SmartBAppSmallIcon } from "../../../theme/svg";
import styles from "./style";
import commonStyles from "../../../theme/commonStyle";
import CustomTextInput from "../../../component/TextInput/index";
import ErrorText from "../../../component/ErrorText";
import Loader from "../../../component/ProgressBar";
import { useNavigation } from "@react-navigation/native";
import KeyboardSpacer from "react-native-keyboard-spacer";
import {
  isConnectionAvailable,
  showToast,
} from "../../../utils/commonFunction";
import { APP_CONSTANT } from "../../../utils/appConstant";
import { translate } from "../../../utils/Localize";
import API_CONFIG from "../../../api/api_url";
import { callApi } from "../../../api";
import { print_data } from "../../../utils/Logs";

export default function Forgot() {
  const navigation = useNavigation();
  const [email, setEmail] = useState("");
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [isShowEmailError, showEmailError] = useState(false);
  const [emailErrorText, setEmailErrorText] = useState("");
  const [userNotFound, setUserNotFound] = useState("");

  const onSubmitPress = async () => {
    Keyboard.dismiss();
    let is_validate = true;
    if (await isConnectionAvailable()) {
      if (email?.length == 0) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("EmptyError"));
      } else if (!APP_CONSTANT.EMAIL_PATTERN.test(email)) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("EmailNotValidError"));
      }
      if (is_validate) {
        setIsLoaderVisible(true);
        callForgotPasswordAPi();
      }
    } else {
      showToast(translate("InternetConnection"));
    }
  };

  const redirectVerify = () => {
    showEmailError(false);
    setEmailErrorText("");
    setUserNotFound("");
    setEmail("");
    navigation.navigate(NAVIGATION.RESET, {
      userEmail: email,
    });
  };

  const callForgotPasswordAPi = async () => {
    try {
      var param_data = {
        email: email,
      };
      const response = await callApi(
        API_CONFIG.FORGOT_PASSWORD + email,
        param_data,
        API_CONFIG.FORGOT_DATA,
        null
      );
      print_data(response);
      if (response.body != null) {
        if (response.body?.status === 200) {
          setIsLoaderVisible(false);
          redirectVerify();
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.success == false) {
            setTimeout(() => {
              setUserNotFound(response?.body?.data?.message);
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <Pressable
          style={styles.arrowContainerStyle}
          onPress={() => navigation.goBack()}
        >
          <BackArrow style={styles.backArrowStyle} color={Colors.white} />
        </Pressable>
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
        >
          <View style={styles.horizontalContainerView}>
            {/* <SmartBAppSmallIcon style={styles.svgIconStyle} /> */}
            <Image source={Images.registerLogo} style={styles.svgIconStyle} />
            <View style={styles.signInText}>
              <Text style={styles.signInTextStyle}>
                {translate("ForgotPassword")}
              </Text>
              <Pressable onPress={() => navigation.navigate(NAVIGATION.LOGIN)}>
                <Text style={styles.signUpTextStyle}>
                  {translate("BackToSignIn")}
                </Text>
              </Pressable>
            </View>
          </View>
          <View style={styles.height} />
          <View style={styles.inputTextStyle}>
            <CustomTextInput
              textInputStyle={commonStyles.textInputStyle}
              placeholderText={translate("Email")}
              placeholderTextColor={Colors.white}
              containerStyle={commonStyles.inputTextContainerStyle}
              lableTextStyle={commonStyles.labelTextStyle}
              inputTextStyle={commonStyles.inputTextStyle}
              value={email}
              keyboardType="email-address"
              onChangeText={(text) => {
                setEmail(text);
                showEmailError(false);
              }}
              lableText={translate("Email")}
            />
            <View style={styles.width}>
              <ErrorText
                errorText={emailErrorText}
                is_visible={isShowEmailError}
              />
            </View>
            <View style={styles.width}>
              <Text style={styles.errorText}>{userNotFound}</Text>
            </View>
            <View style={styles.width}>
              <Button
                disabled={false}
                onPress={onSubmitPress}
                title={translate("Continue")}
                color={Colors.black}
                fontSize={Metrics.rfv(14)}
                backgroundColor={Colors.white}
              />
            </View>
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </LinearGradient>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
}
