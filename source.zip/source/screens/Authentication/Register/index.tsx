import moment from "moment";
import React, { createRef, useEffect, useState } from "react";
import {
  Keyboard,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import KeyboardSpacer from "react-native-keyboard-spacer";
import DatePicker from "react-native-date-picker";
import DropDownPicker from "react-native-dropdown-picker";
import LinearGradient from "react-native-linear-gradient";
import Modal from "react-native-modal";
import { useNavigation } from "@react-navigation/native";
import _ from "lodash";
//component
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import Button from "../../../component/Button/index";
import CustomTextInput from "../../../component/TextInput/index";
import ErrorText from "../../../component/ErrorText";
import CommonHeader from "../../../component/CommonHeader";
import Loader from "../../../component/ProgressBar";
//theme
import commonStyles from "../../../theme/commonStyle";
import { Colors, CommonStyle, Metrics } from "../../../theme/index";
import { BackArrow, DownArrow, UpArrow } from "../../../theme/svg";
//navigation
import { NAVIGATION } from "../../../navigation";
//style
import styles from "./style";
//utils
import {
  isConnectionAvailable,
  showToast,
} from "../../../utils/commonFunction";
import { APP_CONSTANT } from "../../../utils/appConstant";
//utils
import { translate } from "../../../utils/Localize";
import { print_data } from "../../../utils/Logs";
//api
import API_CONFIG from "../../../api/api_url";
import { callApi } from "../../../api";

export default function SignUp(props: any) {
  const navigation = useNavigation();
  const userNameRef = createRef();
  const userLastNameRef = createRef();
  const useMobileRef = createRef();
  const [titleList, setTitleList] = useState([
    { label: "- Select -", value: "- Select -" },
    { label: "Mr", value: "Mr" },
    { label: "Mrs", value: "Mrs" },
    { label: "Ms", value: "Ms" },
    { label: "Miss", value: "Miss" },
    { label: "Dr", value: "Dr" },
  ]);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [titleOpen, setTitleOpen] = useState(false);
  const [selectedTitle, setSelectedTitle] = useState("");
  const [userName, setUserName] = useState("");
  const [userLastName, setUserLastName] = useState("");
  const [userPhoneNumber, setUserPhoneNumber] = useState("");
  const [isDropDownBorder, setIsDropDownBorder] = useState(false);
  const [countryOpen, setCountryOpen] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState("");
  const [isCountryBorder, setIsCountryBorder] = useState(false);
  const [stateOpen, setStateOpen] = useState(false);
  const [selectedState, setSelectedState] = useState("");
  const [isStateBorder, setIsStateBorder] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [getUTCDate, setGetUTCDate] = useState(new Date());
  const [isDateBirth, setIsDateBirth] = useState(false);
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [isShowNameError, showNameError] = useState(false);
  const [isShowLastNameError, showLastNameError] = useState(false);
  const [isTitleErrorShow, setIsTitleErrorShow] = useState(false);
  const [isDateOfBirthValid, setIsDateOfBirthValid] = useState(false);
  const [isCountryErrorShow, setIsCountryErrorShow] = useState(false);
  // const [isStateErrorShow, setIsStateErrorShow] = useState(false);
  const [isShowMobileError, showMobileError] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [countryId, setCountryId] = useState("");
  const [stateId, setStateId] = useState(null);
  const [checkYear, setCheckYear] = useState(false);
  const [userYear, setUserYear] = useState("");
  const [mobileError, setMobileError] = useState(false);
  const [numericError, setNumericError] = useState(false);
  const [countryOffset, setCountryOffset] = useState(0);
  const [counryCount, setCountryCount] = useState(0);
  const [stateCount, setStateCount] = useState(0);
  const [stateOffset, setStateOffset] = useState(0);
  const [isLoadMore, setIsLoadMore] = useState(false);

  useEffect(() => {
    setIsLoaderVisible(true);
    callCountryAPi(countryOffset);
  }, []);

  const onNextPress = async () => {
    Keyboard.dismiss();
    let is_validate = true;
    if (await isConnectionAvailable()) {
      if (selectedTitle?.length == 0 || selectedTitle == "- Select -") {
        is_validate = false;
        setIsTitleErrorShow(true);
      }
      if (userName?.trim().length == 0) {
        is_validate = false;
        showNameError(true);
      }
      if (userLastName?.trim().length == 0) {
        is_validate = false;
        showLastNameError(true);
      }
      if (userPhoneNumber?.trim().length == 0) {
        is_validate = false;
        showMobileError(true);
      } else if (userPhoneNumber?.length > 12 || userPhoneNumber?.length < 10) {
        is_validate = false;
        setMobileError(true);
      } else if (!APP_CONSTANT.PHONE_PATTERN.test(userPhoneNumber)) {
        is_validate = false;
        setNumericError(true);
      }

      if (dateOfBirth?.length == 0) {
        is_validate = false;
        setIsDateOfBirthValid(true);
      } else if (moment(getUTCDate) >= moment().subtract(18, "years")) {
        is_validate = false;
        setCheckYear(true);
        setIsDateOfBirthValid(false);
        setUserYear(translate("GraterThanYear"));
      }

      if (selectedCountry?.length == 0 || selectedCountry == "- Select -") {
        is_validate = false;
        setIsCountryErrorShow(true);
      }

      // if (selectedState == "- Select -") {
      //   is_validate = false;
      //   setIsStateErrorShow(true);
      // }
      if (is_validate) {
        const registerData = {
          selectedTitle: selectedTitle,
          userName: userName,
          userLastName: userLastName,
          userPhoneNumber: userPhoneNumber,
          dateOfBirth: moment(getUTCDate).format("YYYY-MM-DD"),
          selectedCountry: countryId,
          selectedState: stateId?.length > 0 ? stateId : null,
        };

        navigation.navigate(NAVIGATION.NEXT2SIGN_UP, {
          registerData,
        });
      }
    } else {
      showToast(translate("InternetConnection"));
    }
  };

  const callCountryAPi = async (countryOffset) => {
    try {
      const response = await callApi(
        API_CONFIG.COUNTRY + countryOffset,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let countryAPIList = response?.body?.data?.result?.rows;
          const itemData: any = [];
          countryAPIList.map((item: any, index) => {
            itemData.push({
              label: item?.country,
              value: item?.id,
              key: index,
            });
          });
          const finalList = [...countryList, ...itemData];
          setCountryList(finalList);
          setCountryCount(Math.ceil(response?.body?.data?.result?.count / 20));
          setIsLoadMore(false);
          setIsLoaderVisible(false);
        } else {
          setIsLoadMore(false);
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoadMore(false);
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoadMore(false);
      setIsLoaderVisible(false);
      print_data("=====exception=====" + error);
    }
  };

  const callStateAPi = async (selectedCountry, page, type) => {
    try {
      const response = await callApi(
        API_CONFIG.STATE + `/${selectedCountry}?limit=20&offset=${page}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let stateAPIList = response?.body?.data?.result?.rows;
          let itemData = [];
          for (let i = 0; i < stateAPIList.length; i++) {
            itemData.push({
              label: stateAPIList[i].state,
              value: stateAPIList[i].id,
            });
          }

          setStateCount(Math.ceil(response?.body?.data?.result?.count / 20));

          if (type) {
            setStateList(itemData);
          } else {
            const finalList = [...stateList, ...itemData];
            setStateList(finalList);
          }

          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <Modal
          isVisible={isModalVisible}
          onBackButtonPress={() => isModalVisible}
          testID={"modal"}
          style={styles.modal}
          onBackdropPress={() => {
            setIsModalVisible(false);
          }}
        >
          <View style={styles.dateView}>
            <Pressable
              onPress={() => {
                setIsModalVisible(false);
              }}
            >
              <Text style={[styles.dialogCancelStyle]}>
                {translate("Cancel")}
              </Text>
            </Pressable>

            <Pressable
              onPress={() => {
                if (getUTCDate) {
                  setDateOfBirth(moment(getUTCDate).format("DD/MM/YYYY"));
                  setIsDateBirth(false);

                  setIsModalVisible(false);
                } else {
                  setIsModalVisible(false);
                }
              }}
            >
              <Text style={[styles.dialogDoneStyle]}>{translate("Done")}</Text>
            </Pressable>
          </View>
          <View>
            <DatePicker
              style={styles.dataPicker}
              mode={"date"}
              maximumDate={new Date()}
              textColor={Colors.black}
              date={getUTCDate ? getUTCDate : new Date()}
              onDateChange={(date) => {
                setGetUTCDate(date);
                setIsDateOfBirthValid(false);
                setCheckYear(false);
              }}
            />
          </View>
        </Modal>
        <Pressable
          style={styles.arrowContainerStyle}
          onPress={() => navigation.goBack()}
        >
          <BackArrow style={styles.backArrowStyle} color={Colors.white} />
        </Pressable>
        <ScrollView
          nestedScrollEnabled={true}
          contentContainerStyle={styles.scrollViewStyle}
          overScrollMode="never"
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
        >
          <CommonHeader
            iconStyle={styles.svgIconStyle}
            title={translate("StepFirst")}
            subTitle={translate("SignUpInfo")}
          />
          <View style={styles.horizontalView}>
            <View style={styles.dropDownView}>
              <Text style={styles.titleTextStyle}>{translate("Title")}</Text>
              <DropDownPicker
                textStyle={styles.labelSelectStyle}
                open={titleOpen}
                value={selectedTitle}
                labelExtractor={({ label }) => label}
                valueExtractor={({ selectedTitle }) => selectedTitle}
                items={titleList}
                scrollViewProps={{
                  nestedScrollEnabled: true,
                  showsVerticalScrollIndicator: false,
                  showsHorizontalScrollIndicator: false,
                }}
                setOpen={(isOpen) => {
                  setTitleOpen(isOpen);
                  setCountryOpen(false);
                  setStateOpen(false);
                }}
                listMode="SCROLLVIEW"
                dropDownContainerStyle={styles.dropDownContainerStyle}
                setValue={setSelectedTitle}
                onChangeValue={(selectedTitle) => {
                  setIsDropDownBorder(false);
                  setIsTitleErrorShow(false);
                }}
                setItems={setTitleList}
                dropDownDirection="BOTTOM"
                autoScroll={true}
                style={
                  isDropDownBorder
                    ? styles.dropDownStyleRed
                    : styles.dropDownStyleWhite
                }
                placeholder={translate("PlaceHolder")}
                ArrowUpIconComponent={({}) => (
                  <UpArrow
                    width={Metrics.rfv(11)}
                    height={Metrics.rfv(6)}
                    fill={Colors.white}
                  />
                )}
                ArrowDownIconComponent={({}) => (
                  <DownArrow
                    width={Metrics.rfv(11)}
                    height={Metrics.rfv(6)}
                    fill={Colors.white}
                  />
                )}
                selectedItemContainerStyle={styles.selectedItemContainerStyle}
                placeholderStyle={styles.dropDownPlaceholder}
              />
            </View>
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("EmptyError")}
                is_visible={isTitleErrorShow}
              />
            </View>
            <CustomTextInput
              ref={userNameRef}
              textInputStyle={commonStyles.textInputStyle}
              placeholderText={translate("FirstName")}
              placeholderTextColor={Colors.lightGrayBoxGray}
              containerStyle={commonStyles.inputTextContainerStyle}
              lableText={translate("FirstName")}
              lableTextStyle={commonStyles.labelTextStyle}
              inputTextStyle={commonStyles.inputTextStyle}
              value={userName}
              returnKeyType={"next"}
              onChangeText={(text: string) => {
                setUserName(text);
                showNameError(false);
              }}
              onSubmitEditing={() => {
                if (userLastNameRef) {
                  userLastNameRef.current?.focus();
                }
              }}
            />
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("EmptyError")}
                is_visible={isShowNameError}
              />
            </View>
            <CustomTextInput
              ref={userLastNameRef}
              textInputStyle={commonStyles.textInputStyle}
              placeholderText={translate("LastName")}
              placeholderTextColor={Colors.lightGrayBoxGray}
              containerStyle={commonStyles.inputTextContainerStyle}
              lableText={translate("LastName")}
              lableTextStyle={commonStyles.labelTextStyle}
              inputTextStyle={commonStyles.inputTextStyle}
              value={userLastName}
              returnKeyType={"next"}
              onChangeText={(text: string) => {
                setUserLastName(text);
                showLastNameError(false);
              }}
            />
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("EmptyError")}
                is_visible={isShowLastNameError}
              />
            </View>
            <Text style={styles.dobStyle}>{translate("Dob")}</Text>
            <View style={styles.bottomView}>
              <CustomTextInput
                editable={false}
                textInputStyle={commonStyles.textInputStyle}
                backgroundColor={Colors.lightblue}
                placeholderText={translate("DatePickerPlaceHolder")}
                width={Metrics.rfp(45)}
                borderColor={
                  isDateBirth ? Colors.textRed : Colors.validationBorder
                }
                inputTextStyle={commonStyles.inputTextStyle}
                keyboardType="email-address"
                placeholderTextColor={Colors.lightGrayBoxGray}
                onChangeText={(text: string) => {
                  setDateOfBirth(text);
                }}
                value={dateOfBirth}
                datePickerVisible={true}
                onPressDatePicker={() => {
                  Keyboard.dismiss();
                  setIsModalVisible(true);
                }}
                returnKeyType="next"
                placeholder={translate("DatePickerPlaceHolder")}
                activeOpacity={1}
              />
              <Text style={styles.signUpAgeStyle}>
                {translate("SingnUpAge")}
              </Text>
              {checkYear ? (
                <Text style={styles.errorTextStyle}>{userYear}</Text>
              ) : null}
              <View style={styles.fullWidthStyle}>
                <ErrorText
                  errorText={translate("EmptyError")}
                  is_visible={isDateOfBirthValid}
                />
              </View>
            </View>
            <View style={styles.countryIndex}>
              <Text style={styles.emailTextStyle}>
                {translate("CountryOfResidence")}
              </Text>

              <DropDownPicker
                autoScroll={true}
                textStyle={styles.labelSelectStyle}
                open={countryOpen}
                value={selectedCountry}
                scrollViewProps={{
                  nestedScrollEnabled: true,
                  showsVerticalScrollIndicator: false,
                  showsHorizontalScrollIndicator: false,

                  onMomentumScrollEnd(event) {
                    if (
                      !isLoadMore &&
                      counryCount !== Math.ceil(countryOffset / 20)
                    ) {
                      setIsLoadMore(true);
                      // setIsLoaderVisible(true);
                      callCountryAPi(countryOffset + 20);
                      setCountryOffset(countryOffset + 20);
                    }
                  },
                }}
                labelExtractor={({ country }) => country}
                valueExtractor={({ selectedCountry }) => selectedCountry}
                items={countryList}
                setOpen={(isOpen) => {
                  setCountryOpen(isOpen);
                  setStateOpen(false);
                  setTitleOpen(false);
                }}
                listMode="SCROLLVIEW"
                dropDownContainerStyle={styles.dropDownContainerStyle}
                setValue={setSelectedCountry}
                onChangeValue={(selectedCountry) => {
                  setIsCountryBorder(false);
                  setIsCountryErrorShow(false);
                  setCountryId(selectedCountry);
                  setIsLoaderVisible(true);
                  setTimeout(() => {
                    if (selectedCountry?.toString().length > 0) {
                      setStateList([]);
                      setStateCount(0);
                      setSelectedState("");
                      callStateAPi(selectedCountry, 0, true);
                      // setStateId("");
                    }
                  }, 100);
                }}
                setItems={setCountryList}
                dropDownDirection="BOTTOM"
                style={
                  isCountryBorder
                    ? styles.dropDownStyleRed
                    : styles.dropDownStyleWhite
                }
                placeholder={translate("PlaceHolder")}
                ArrowUpIconComponent={({}) => (
                  <UpArrow
                    width={Metrics.rfv(11)}
                    height={Metrics.rfv(6)}
                    fill={Colors.white}
                  />
                )}
                ArrowDownIconComponent={({}) => (
                  <DownArrow
                    width={Metrics.rfv(11)}
                    height={Metrics.rfv(6)}
                    fill={Colors.white}
                  />
                )}
                selectedItemContainerStyle={styles.selectedItemContainerStyle}
                placeholderStyle={styles.dropDownPlaceholder}
              />
            </View>
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("EmptyError")}
                is_visible={isCountryErrorShow}
              />
            </View>
            <View style={styles.dropDownView}>
              <Text style={styles.stateTextStyle}>{translate("State")}</Text>

              <DropDownPicker
                textStyle={styles.labelSelectStyle}
                zIndex={3000}
                open={stateOpen}
                autoScroll={true}
                scrollViewProps={{
                  showsVerticalScrollIndicator: false,
                  showsHorizontalScrollIndicator: false,

                  onMomentumScrollEnd(event) {
                    if (stateCount !== Math.ceil(stateOffset / 20)) {
                      callStateAPi(countryId, stateOffset + 20, false);
                      setStateOffset(stateOffset + 20);
                    }
                  },
                }}
                value={selectedState}
                labelExtractor={({ label }) => label}
                valueExtractor={({ selectedState }) => selectedState}
                items={stateList}
                setOpen={(isOpen) => {
                  setStateOpen(isOpen);
                  setCountryOpen(false);
                  setTitleOpen(false);
                }}
                listMode="SCROLLVIEW"
                dropDownContainerStyle={styles.dropDownContainerStyle}
                setValue={setSelectedState}
                onChangeValue={(selectedState) => {
                  // setIsLoaderVisible(true);

                  setStateId(selectedState);
                  setIsStateBorder(false);
                  // setIsStateErrorShow(false);
                }}
                setItems={setStateList}
                dropDownDirection="BOTTOM"
                style={
                  isStateBorder
                    ? styles.dropDownStyleRed
                    : styles.dropDownStyleWhite
                }
                placeholder={translate("PlaceHolder")}
                ArrowUpIconComponent={({}) => (
                  <UpArrow
                    width={Metrics.rfv(11)}
                    height={Metrics.rfv(6)}
                    fill={Colors.white}
                  />
                )}
                ArrowDownIconComponent={({}) => (
                  <DownArrow
                    width={Metrics.rfv(11)}
                    height={Metrics.rfv(6)}
                    fill={Colors.white}
                  />
                )}
                selectedItemContainerStyle={styles.selectedItemContainerStyle}
                placeholderStyle={styles.dropDownPlaceholder}
              />
            </View>
            {/* <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("EmptyError")}
                is_visible={isStateErrorShow}
              />
            </View> */}
            <View style={styles.phoneNumberContainer}>
              <CustomTextInput
                textInputStyle={commonStyles.textInputStyle}
                ref={useMobileRef}
                containerStyle={commonStyles.inputTextContainerStyle}
                placeholderTextColor={Colors.white}
                lableText={translate("Mobile")}
                lableTextStyle={commonStyles.labelTextStyle}
                inputTextStyle={commonStyles.inputTextStyle}
                value={userPhoneNumber}
                maxLength={12}
                keyboardType={"number-pad"}
                returnKeyType={"done"}
                onChangeText={(text: string) => {
                  setUserPhoneNumber(text);
                  showMobileError(false);
                  setMobileError(false);
                  setNumericError(false);
                }}
                onSubmitEditing={() => onNextPress()}
              />
              <View style={styles.fullWidthStyle}>
                <ErrorText
                  errorText={translate("EmptyError")}
                  is_visible={isShowMobileError}
                />
              </View>
              <View style={styles.fullWidthStyle}>
                <ErrorText
                  errorText={translate("NumberDigit")}
                  is_visible={mobileError}
                />
              </View>
              <View style={styles.fullWidthStyle}>
                <ErrorText
                  errorText={translate("NumericalText")}
                  is_visible={numericError}
                />
              </View>
            </View>

            <Button
              disabled={false}
              onPress={() => onNextPress()}
              title={translate("Next")}
              color={Colors.black}
              fontSize={Metrics.rfv(14)}
              backgroundColor={Colors.white}
            />
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </LinearGradient>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
}
