import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  mainLoginView: {
    flex: 1,
  },
  svgIconStyle: {
    alignItems: "center",
    marginTop: Metrics.rfv(10),
    width: Metrics.rfv(71),
    height: Metrics.rfv(22),
    resizeMode: "contain",
  },
  fullWidthStyle: {
    width: "100%",
  },
  signInText: {
    alignItems: "center",
    marginTop: Metrics.rfv(30),
  },
  horizontalContainerView: {
    marginHorizontal: Metrics.rfv(20),
    // marginBottom: Metrics.rfv(30),
    // zIndex: 1000,
  },
  phoneNumberContainer: {
    zIndex: 1000,
    width: "100%",
  },
  signInTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.IN_SemiBold,
  },
  aleredyAccountContainer: {
    flexDirection: "row",
    marginTop: Metrics.rfv(5),
  },
  notHaveAccountTextStyle: {
    color: Colors.lightGrayBoxGray,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
  },
  signUpTextStyle: {
    color: Colors.lightGrayBoxGray,
    marginLeft: Metrics.rfv(8),
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Bold,
    textDecorationLine: "underline",
    textDecorationColor: Colors.white,
  },
  emailTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
  },
  stateTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
    marginTop: Metrics.rfv(15),
  },
  dobStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    alignSelf: "flex-start",
    marginTop: Metrics.rfv(15),
  },
  titleTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    alignSelf: "flex-start",
    marginTop: Metrics.rfv(5),
  },
  height: {
    height: Metrics.rfv(40),
  },
  step1Style: {
    color: Colors.stepColor,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(14),
    marginTop: Metrics.rfv(25),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(20),
  },
  signUpInfo: {
    color: Colors.lightGrayBoxGray,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    marginTop: Metrics.rfv(10),
  },
  dropDownContainerStyle: {
    backgroundColor: Colors.lightblue,
    width: "100%",
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    top: Metrics.rfv(-7),
    textAlign: "center",
    position: "relative", // It was absolute
  },
  contryContainer: {
    zIndex: Metrics.rfv(2000),
  },
  dropDownStyleRed: {
    width: "100%",
    backgroundColor: Colors.lightblue,
  },
  dropDownStyleWhite: {
    height: Metrics.rfv(44),
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    marginTop: Metrics.rfv(5),
    backgroundColor: Colors.lightblue,
    width: "100%",
    marginBottom: Metrics.rfv(5),
    padding: 0,
  },
  signUpAgeStyle: {
    fontSize: Metrics.rfv(11),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    color: Colors.lightGrayBoxGray,
  },
  selectedItemContainerStyle: {
    backgroundColor: Colors.lightGray,
    color: Colors.white,
  },
  dropDownPlaceholder: {
    color: Colors.placeholder,
  },
  labelSelectStyle: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    color: Colors.white,
  },
  dialogCancelStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(18),
    marginHorizontal: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
  },
  dialogDoneStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    marginHorizontal: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
    paddingVertical: Metrics.rfv(10),
  },
  dropDownView: {
    // zIndex: Metrics.rfv(2000),
  },
  dataPicker: {
    backgroundColor: Colors.white,
    width: Metrics.rfv(600),
  },
  modal: {
    justifyContent: "flex-end",
    alignItems: "center",
    margin: Metrics.rfv(0),
  },
  dateView: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.borderGrey,
    justifyContent: "space-between",
    backgroundColor: Colors.cream,
    width: "100%",
  },
  bottomView: {
    marginBottom: Metrics.rfv(20),
  },
  userAlreadyRegisterText: {
    color: Colors.lightBlueBackground,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    textAlign: "center",
    marginTop: Metrics.rfv(10),
  },
  errorTextStyle: {
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    color: Colors.red,
    marginTop: Metrics.rfv(5),
  },
  countryIndex: {
    zIndex: Metrics.rfv(2000),
  },
  scrollViewStyle: {
    flexGrow: 1,
    paddingBottom: Metrics.rfv(50),
  },
  backArrowStyle: {
    width: Metrics.rfv(16),
    height: Metrics.rfv(16),
  },
  arrowContainerStyle: {
    width: Metrics.rfv(50),
    paddingVertical: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
  },
});
