import { StyleSheet } from "react-native";
import { Colors, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  mainLoginView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  fullWidthStyle: {
    width: "100%",
  },
  inputTextStyle: {
    margin: Metrics.rfv(30),
  },

  horizontalView: {
    flex: 1,
    marginHorizontal: Metrics.rfv(20),
  },
  commonRow: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginVertical: Metrics.rfv(20),
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  buttonWidth: {
    flex: 1,
  },
  formCotainerStyle: {
    flex: 1,
  },
});
