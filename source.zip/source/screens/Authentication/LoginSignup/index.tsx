import React, { createRef, useState } from "react";
import { Keyboard, Platform, ScrollView, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import KeyboardSpacer from "react-native-keyboard-spacer";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import Button from "../../../component/Button/index";
import { NAVIGATION } from "../../../navigation";
import { Colors, CommonStyle, Metrics } from "../../../theme/index";
import commonStyles from "../../../theme/commonStyle";
import styles from "./style";
import CustomTextInput from "../../../component/TextInput/index";
import ErrorText from "../../../component/ErrorText";
import { APP_CONSTANT } from "../../../utils/appConstant";
import {
  isConnectionAvailable,
  showToast,
} from "../../../utils/commonFunction";
import CommonHeader from "../../../component/CommonHeader";
import { useNavigation } from "@react-navigation/native";
import Loader from "../../../component/ProgressBar";
import { translate } from "../../../utils/Localize";

export default function LoginSignUp(props: any) {
  const navigation = useNavigation();
  const userEmailRef = createRef();
  const usePasswordRef = createRef();
  const useRetypeRef = createRef();

  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const [isShowEmailError, showEmailError] = useState(false);
  const [isShowPassError, showPassError] = useState(false);
  const [emailErrorText, setEmailErrorText] = useState("");

  const [repeatPassword, setRepeatPassword] = useState("");
  const [isShowReTypePassError, showReTypePassError] = useState(false);
  const [reTypeassErrorText, setRetypePassErrorText] = useState("");
  const [passErrorText, setPassErrorText] = useState("");
  const { registerData } = props.route.params;

  const onPressBack = () => {
    navigation.goBack();
  };

  const onNextPress = async () => {
    Keyboard.dismiss();
    let is_validate = true;
    if (await isConnectionAvailable()) {
      if (userEmail?.length == 0) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("EmptyError"));
      } else if (!APP_CONSTANT.EMAIL_PATTERN.test(userEmail)) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("EmailNotValidError"));
      }
      if (userPassword?.length == 0) {
        is_validate = false;
        showPassError(true);
        setPassErrorText(translate("EmptyError"));
      } else if (userPassword?.length < 6) {
        is_validate = false;
        showPassError(true);
        setPassErrorText(translate("PasswordNotValidError"));
      }
      if (repeatPassword?.length == 0) {
        is_validate = false;
        showReTypePassError(true);
        setRetypePassErrorText(translate("EmptyError"));
      } else if (repeatPassword?.length < 6) {
        is_validate = false;
        showReTypePassError(true);
        setRetypePassErrorText(translate("PasswordNotValidError"));
      } else if (userPassword != repeatPassword) {
        is_validate = false;
        showReTypePassError(true);
        setRetypePassErrorText(translate("DoesNotMatch"));
      }
      if (is_validate) {
        registerData.userEmail = userEmail;
        registerData.userPassword = userPassword;
        registerData.repeatPassword = repeatPassword;
        navigation.navigate(NAVIGATION.NEXT3SIGN_UP, { registerData });
      }
    } else {
      showToast(translate("InternetConnection"));
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />

      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
        >
          <View style={styles.formCotainerStyle}>
            <CommonHeader
              title={translate("StepSecond")}
              subTitle={translate("LoginInfo")}
            />

            <View style={styles.horizontalView}>
              <View style={styles.formCotainerStyle}>
                <CustomTextInput
                  ref={userEmailRef}
                  textInputStyle={commonStyles.textInputStyle}
                  placeholderTextColor={Colors.white}
                  containerStyle={commonStyles.inputTextContainerStyle}
                  lableText={translate("EmailAddress")}
                  lableTextStyle={commonStyles.labelTextStyle}
                  inputTextStyle={commonStyles.inputTextStyle}
                  value={userEmail}
                  returnKeyType={"next"}
                  keyboardType={"email-address"}
                  onChangeText={(text: string) => {
                    setUserEmail(text);
                    showEmailError(false);
                  }}
                  onSubmitEditing={() => {
                    if (usePasswordRef) {
                      usePasswordRef.current.focus();
                    }
                  }}
                />
                <View style={styles.fullWidthStyle}>
                  <ErrorText
                    errorText={emailErrorText}
                    is_visible={isShowEmailError}
                  />
                </View>

                <CustomTextInput
                  ref={usePasswordRef}
                  textInputStyle={commonStyles.textInputStyle}
                  isPasswordField={true}
                  secureTextEntry={true}
                  containerStyle={commonStyles.inputTextContainerStyle}
                  lableText={translate("Password")}
                  lableTextStyle={commonStyles.labelTextStyle}
                  inputTextStyle={commonStyles.inputTextStyle}
                  value={userPassword}
                  onChangeText={(text: string) => {
                    setUserPassword(text);
                    showPassError(false);
                  }}
                  returnKeyType={"next"}
                  onSubmitEditing={() => {
                    if (useRetypeRef) {
                      useRetypeRef.current.focus();
                    }
                  }}
                />
                <View style={styles.fullWidthStyle}>
                  <ErrorText
                    errorText={passErrorText}
                    is_visible={isShowPassError}
                  />
                </View>
                <CustomTextInput
                  ref={useRetypeRef}
                  textInputStyle={commonStyles.textInputStyle}
                  isPasswordField={true}
                  secureTextEntry={true}
                  containerStyle={commonStyles.inputTextContainerStyle}
                  lableText={translate("RepeatPassword")}
                  lableTextStyle={commonStyles.labelTextStyle}
                  inputTextStyle={commonStyles.inputTextStyle}
                  value={repeatPassword}
                  returnKeyType={"done"}
                  onChangeText={(text: string) => {
                    setRepeatPassword(text);
                    showReTypePassError(false);
                  }}
                  onSubmitEditing={() => onNextPress()}
                />
                <View style={styles.fullWidthStyle}>
                  <ErrorText
                    errorText={reTypeassErrorText}
                    is_visible={isShowReTypePassError}
                  />
                </View>
              </View>
              <View style={styles.commonRow}>
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onPressBack()}
                    title={translate("Back")}
                    borderColor={Colors.white}
                    color={Colors.white}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.linearColor2}
                  />
                </View>
                <View style={styles.gapViewStyle} />
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onNextPress()}
                    title={translate("Next")}
                    borderColor={Colors.white}
                    color={Colors.linearColor1}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.white}
                  />
                </View>
              </View>
            </View>
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </LinearGradient>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
}
