import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  mainLoginView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  svgIconStyle: {
    marginTop: Metrics.rfv(30),
    width: Metrics.rfv(71),
    resizeMode: "contain",
    height: Metrics.rfv(22),
  },
  signInText: {
    marginTop: Metrics.rfv(50),
  },
  signInTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(23),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.IN_SemiBold,
  },
  notHaveAccountTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
    marginTop: Metrics.rfv(5),
  },
  height: {
    height: Metrics.rfv(40),
  },
  inputTextStyle: {
    marginHorizontal: Metrics.rfv(20),
    marginTop: Metrics.rfv(30),
  },
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  horizontalContainerView: {
    alignItems: "center",
  },
  fullWidthStyle: {
    width: "100%",
  },
  resendOtpText: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
    paddingVertical: Metrics.rfv(10),
    marginTop: Metrics.rfv(12),
    textDecorationLine: "underline",
  },
  errorTextStyle: {
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    color: Colors.red,
    marginTop: Metrics.rfv(5),
  },
  arrowContainerStyle: {
    width: Metrics.rfv(50),
    paddingVertical: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
  },
  backArrowStyle: {
    width: Metrics.rfv(16),
    height: Metrics.rfv(16),
  },
});
