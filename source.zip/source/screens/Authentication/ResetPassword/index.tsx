import React, { useRef, useState } from "react";
import {
  Image,
  Keyboard,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import Button from "../../../component/Button/index";
import { Colors, CommonStyle, Images, Metrics } from "../../../theme/index";
import { BackArrow, SmartBAppSmallIcon } from "../../../theme/svg";
import commonStyles from "../../../theme/commonStyle";
import styles from "./style";
import CustomTextInput from "../../../component/TextInput/index";
import ErrorText from "../../../component/ErrorText";
import {
  isConnectionAvailable,
  showToast,
} from "../../../utils/commonFunction";
import Loader from "../../../component/ProgressBar";
import KeyboardSpacer from "react-native-keyboard-spacer";
import { NAVIGATION } from "../../../navigation";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../utils/Localize";
import { print_data } from "../../../utils/Logs";
import API_CONFIG from "../../../api/api_url";
import { callApi } from "../../../api";

type Props = {
  loading?: boolean;
  navigation?: any;
};

export default function ResetPassword(props: Props) {
  const navigation = useNavigation();
  const newPasswordRef = useRef<any>(null);
  const repeatNewPasswordRef = useRef<any>(null);
  const [password, setPassword] = useState("");

  const [repeatPassword, setRepeatPassword] = useState("");
  const [passErrorText, setPassErrorText] = useState("");
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [userpassErrorText, setUserPassErrorText] = useState("");
  const [isShowPassAgainError, setShowPassAgainError] = useState(false);
  const [passwordSecureText, setPasswordSecureText] = useState(false);
  const [otpVerify, setOtpVerify] = useState("");
  const [isShowOtpError, showOtpError] = useState(false);
  const [otpErrorText, setOtpErrorText] = useState("");
  const [errorNotFoundData, setErrorNotFoundData] = useState("");
  const [resendOtpData, setResendOtpData] = useState("");
  const [verifyOtpError, setVerifyOtpError] = useState(false);
  const [verifyOtpErrorText, setverifyOtpErrorText] = useState("");
  const { userEmail } = props.route.params;

  const onSubmitPress = async () => {
    Keyboard.dismiss();
    let is_validate = true;
    if (await isConnectionAvailable()) {
      if (otpVerify?.length == 0) {
        is_validate = false;
        showOtpError(true);
        setOtpErrorText(translate("PleaseEnterOtp"));
        setErrorNotFoundData("");
        setOtpVerify("");
        setResendOtpData("");
      }
      if (password?.length == 0) {
        is_validate = false;
        setPasswordSecureText(true);
        setPassErrorText(translate("EmptyError"));
      } else if (password?.length < 6) {
        is_validate = false;
        setPasswordSecureText(true);
        setPassErrorText(translate("PasswordNotValidError"));
      }
      if (repeatPassword?.length == 0) {
        is_validate = false;
        setShowPassAgainError(true);
        setUserPassErrorText(translate("EmptyError"));
      } else if (repeatPassword?.length < 6) {
        is_validate = false;
        setShowPassAgainError(true);
        setUserPassErrorText(translate("PasswordNotValidError"));
      } else if (password != repeatPassword) {
        is_validate = false;
        setShowPassAgainError(true);
        setUserPassErrorText(translate("DoesNotMatch"));
      }
      if (is_validate) {
        setIsLoaderVisible(true);
        callVerifyOtp();
      }
    } else {
      showToast(translate("InternetConnection"));
    }
  };

  const onResendePresss = () => {
    setOtpVerify("");
    showOtpError(false);
    setIsLoaderVisible(true);
    callResendOtp();
  };
  const callResendOtp = async () => {
    try {
      const response = await callApi(
        API_CONFIG.RESEND_OTP + "/" + userEmail,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          setIsLoaderVisible(false);
          setVerifyOtpError(false);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const callVerifyOtp = async () => {
    try {
      const response = await callApi(
        API_CONFIG.VERIFY_OTP + userEmail + "/" + otpVerify,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          callResentPasswordAPi(response.body?.data?.access_token);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setVerifyOtpError(true);
            setverifyOtpErrorText(translate("InvalidOtp"));
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  const redirectToLogin = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const callResentPasswordAPi = async (token) => {
    try {
      var param_data = {
        password: password,
        token: token,
      };
      const response = await callApi(
        API_CONFIG.RESET_PASSWORD + userEmail,
        param_data,
        API_CONFIG.PUT,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setIsLoaderVisible(false);
          redirectToLogin();
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <Pressable
          style={styles.arrowContainerStyle}
          onPress={() => navigation.goBack()}
        >
          <BackArrow style={styles.backArrowStyle} color={Colors.white} />
        </Pressable>
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
        >
          <View style={styles.horizontalContainerView}>
            {/* <SmartBAppSmallIcon style={styles.svgIconStyle} /> */}
            <Image source={Images.registerLogo} style={styles.svgIconStyle} />
            <View style={styles.height} />
            <Text style={styles.signInTextStyle}>
              {translate("ResetPassword")}
            </Text>
          </View>

          <View style={styles.inputTextStyle}>
            <CustomTextInput
              textInputStyle={commonStyles.textInputStyle}
              placeholderTextColor={Colors.white}
              containerStyle={commonStyles.inputTextContainerStyle}
              lableTextStyle={commonStyles.labelTextStyle}
              inputTextStyle={commonStyles.inputTextStyle}
              lableText={translate("Otp")}
              keyboardType={"numeric"}
              value={otpVerify}
              maxLength={6}
              onChangeText={(text: string) => {
                setOtpVerify(text);
                setErrorNotFoundData("");
                showOtpError(false);
              }}
              onSubmitEditing={() => {
                if (newPasswordRef) {
                  newPasswordRef.current.focus();
                }
              }}
            />
            <View style={styles.fullWidthStyle}>
              <ErrorText errorText={otpErrorText} is_visible={isShowOtpError} />
            </View>
            {verifyOtpError ? (
              <Text style={styles.errorTextStyle}>{verifyOtpErrorText}</Text>
            ) : null}
            <CustomTextInput
              ref={newPasswordRef}
              textInputStyle={commonStyles.textInputStyle}
              placeholderTextColor={Colors.white}
              containerStyle={commonStyles.inputTextContainerStyle}
              lableTextStyle={commonStyles.labelTextStyle}
              inputTextStyle={commonStyles.inputTextStyle}
              lableText={translate("NewPassword")}
              value={password}
              isPasswordField={true}
              secureTextEntry={true}
              onChangeText={(text: string) => {
                setPassword(text);
                setPasswordSecureText(false);
              }}
              onSubmitEditing={() => {
                if (repeatNewPasswordRef) {
                  repeatNewPasswordRef.current.focus();
                }
              }}
            />
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={passErrorText}
                is_visible={passwordSecureText}
              />
            </View>
            <CustomTextInput
              ref={repeatNewPasswordRef}
              textInputStyle={commonStyles.textInputStyle}
              placeholderTextColor={Colors.white}
              lableText={translate("RepeatNewPassword")}
              containerStyle={commonStyles.inputTextContainerStyle}
              lableTextStyle={commonStyles.labelTextStyle}
              inputTextStyle={commonStyles.inputTextStyle}
              isPasswordField={true}
              secureTextEntry={true}
              value={repeatPassword}
              onChangeText={(text: string) => {
                setRepeatPassword(text);
                setShowPassAgainError(false);
              }}
            />
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={userpassErrorText}
                is_visible={isShowPassAgainError}
              />
            </View>
            <Pressable onPress={() => onResendePresss()}>
              <Text style={styles.resendOtpText}>{translate("ResendOtp")}</Text>
            </Pressable>
            <Button
              disabled={false}
              onPress={onSubmitPress}
              title={translate("Continue")}
              color={Colors.black}
              fontSize={Metrics.rfv(14)}
              backgroundColor={Colors.white}
            />
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </LinearGradient>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
}
