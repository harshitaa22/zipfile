import { Text, View } from "react-native";
import React from "react";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import { Colors } from "../../../theme";
import AppStatusBar from "../../../component/AppStatusBar";
import styles from "./style";
import { translate } from "../../../utils/Localize";

const GeoLocation = () => {
  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={{
        color: Colors.white,
        backgroundColor: Colors.white,
      }}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <View style={styles.accesContainer}>
        <Text style={styles.accessStyle}>{translate("AccesDenied")}</Text>
        <Text style={styles.contentStyle}>{translate("ContentText")}</Text>
      </View>
    </AppSafeAreaView>
  );
};

export default GeoLocation;
