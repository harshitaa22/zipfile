import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  accessStyle: {
    fontSize: Metrics.rfv(20),
    fontFamily: Fonts.IN_Bold,
    lineHeight: Metrics.rfv(24),
    color: Colors.black,
  },
  contentStyle: {
    textAlign: "center",
    fontSize: Metrics.rfv(15),
    marginTop: Metrics.rfv(15),
    fontFamily: Fonts.IN_Regular,
    color: Colors.black,
  },
  accesContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: Metrics.rfv(15),
  },
});
