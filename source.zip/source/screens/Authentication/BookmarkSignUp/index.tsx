import React, { useEffect, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import KeyboardSpacer from "react-native-keyboard-spacer";
import { useNavigation } from "@react-navigation/native";
//component
import Button from "../../../component/Button";
import CustomTextInput from "../../../component/TextInput";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import CommonHeader from "../../../component/CommonHeader";
import Loader from "../../../component/ProgressBar";
//theme
import { BookMarkData } from "../../../theme/dummyArray";
import { Colors, CommonStyle, Metrics } from "../../../theme/index";
import { IconEmpty, IconFill } from "../../../theme/svg";
import styles from "./style";
import commonStyles from "../../../theme/commonStyle";
//utils
import { translate } from "../../../utils/Localize";
import { showToast } from "../../../utils/commonFunction";
//navigation
import { NAVIGATION } from "../../../navigation";
//api
import { callApi } from "../../../api";
import API_CONFIG from "../../../api/api_url";
import { print_data } from "../../../utils/Logs";

export default function BookMarkSignUp(props: any) {
  const navigation = useNavigation();
  const { registerData } = props.route.params;
  const [data, setData] = useState([]);
  const [userAlreadyRegister, setAlreadyRegister] = useState("");
  const [addbookMarker, setAddbookMarker] = useState("");
  const [otherSelectedVisible, setOtherSelectedVisible] = useState(false);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [isYes, setIsYes] = useState(false);
  const [isNo, setIsNo] = useState(false);
  const [otherSelected, setOtherSelected] = useState(false);
  const [alreadyRegisterError, setAlreadyRegisterError] = useState(false);
  let bookmarkerAccountItem = isYes === true ? true : false;
  registerData.bookMarkerAccount = bookmarkerAccountItem;

  useEffect(() => {
    let bookmarkerData = [...BookMarkData];
    bookmarkerData.forEach((item, _index) => {
      item.isSelected = false;
    });
    setData(bookmarkerData);
  }, []);

  const itemSelected = (item, index) => {
    let temp = [...data];
    temp[index].isSelected = !item.isSelected;
    setData(temp);
    if (
      item?.isSelected == false &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setAddbookMarker("");
      setOtherSelected(false);
    } else if (
      item?.isSelected == true &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setOtherSelected(true);
    }
  };

  const yesRight = () => {
    setAlreadyRegisterError(false);
    setIsYes(true);
    setIsNo(false);
  };

  const noRight = () => {
    setIsYes(false);
    setIsNo(true);
  };

  const bookMarkValidationYesSelection = () => {
    const bookMarkData = BookMarkData.filter((item) => {
      return item.isSelected;
    });
    let bookMakers = [];
    bookMarkData.map((item, index) => {
      bookMakers.push(item.textBookMark);
    });
    registerData.bookMakers = bookMakers;
    registerData.otherItem = addbookMarker.length > 0 ? [addbookMarker] : [];
    navigation.navigate(NAVIGATION.NEXT4SIGN_UP, {
      registerData,
    });
  };

  const onPressBackYes = () => {
    navigation.goBack();
  };

  const onPressNextYes = () => {
    if (otherSelected) {
      if (addbookMarker?.length > 0) {
        setOtherSelectedVisible(false);
        bookMarkValidationYesSelection();
      } else {
        setOtherSelectedVisible(true);
      }
    } else {
      bookMarkValidationYesSelection();
    }
  };

  const onFinishPress = () => {
    setIsLoaderVisible(true);
    callRegisterApi();
  };

  const verifyOtp = () => {
    navigation.navigate(NAVIGATION.REGISTER_OTP, {
      registerData,
    });
  };

  const renderItem = (item, index) => {
    return (
      <View>
        <View style={styles.renderListStyle}>
          <Pressable
            onPress={() => itemSelected(item, index)}
            style={!item.isSelected ? styles.selectItem : styles.notSelectItem}
          >
            <Text
              style={
                !item.isSelected
                  ? styles.bookMarkTextStyle
                  : styles.selectedBookMarkTextStyle
              }
            >
              {item.textBookMark}
            </Text>
            {item.textBookMark == translate("OtherPleaseSpecify") &&
            item?.isSelected == true ? (
              <>
                <View style={styles.otherwidth}>
                  <CustomTextInput
                    textInputStyle={styles.inputStyle}
                    containerStyle={styles.inputTextContainerStyle}
                    lableTextStyle={commonStyles.labelTextStyle}
                    inputTextStyle={styles.textInputStyle}
                    value={addbookMarker}
                    onChangeText={(text: string) => {
                      setAddbookMarker(text);
                    }}
                  />
                </View>
              </>
            ) : null}
          </Pressable>
        </View>
        {item.textBookMark == translate("OtherPleaseSpecify") &&
        item?.isSelected == true ? (
          <>
            {otherSelectedVisible && (
              <Text style={styles.addBookmarkerText}>
                {translate("AddBookmarker")}
              </Text>
            )}
          </>
        ) : null}
      </View>
    );
  };

  const callRegisterApi = async () => {
    try {
      var param_data = {
        firstName: registerData?.userName,
        lastName: registerData?.userLastName,
        dob: registerData?.dateOfBirth,
        bookMakerAccount: registerData?.bookMarkerAccount
          ? registerData?.bookMarkerAccount
          : "",
        phone: registerData?.userPhoneNumber,
        titlePrefix: registerData?.selectedTitle,
        address: {
          country: registerData?.selectedCountry,
          state: registerData?.selectedState,
        },
        username: registerData?.userEmail,
        password: registerData?.userPassword,
        bookMakersOther: registerData?.otherItem
          ? registerData?.otherItem
          : translate("OtherPleaseSpecify"),
        bookMakers: registerData?.bookMakers ? registerData?.bookMakers : [],
        sportOrEvent: registerData?.sportOrEvent
          ? registerData?.sportOrEvent
          : "",
        sportOrEventOther: registerData?.sportEventData,
        offerings: registerData?.offeringOther
          ? registerData?.offeringOther
          : "",
        offeringsOther: registerData?.offerItem ? registerData?.offerItem : [],
      };
      const response = await callApi(
        API_CONFIG.SIGNUP,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          setIsLoaderVisible(false);
          verifyOtp();
        } else {
          setIsLoaderVisible(false);
          setTimeout(() => {
            if (response?.body?.data?.message) {
              setAlreadyRegisterError(true);
              setAlreadyRegister(response?.body?.data?.message);
            } else {
              showToast(translate("SomethingWrong"));
            }
          }, 10);
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
        >
          <View style={commonStyles.commonFlex}>
            <CommonHeader
              title={translate("StepThird")}
              subTitle={translate("BookMarkSelectionInfo")}
            />
            <View style={styles.horizontalContainerView}>
              <Text style={styles.accountSignUpInfo}>
                {translate("BookMarkAccountInfo")}
              </Text>
              <View style={styles.checkBoxMainStyle}>
                <Pressable onPress={yesRight} style={styles.radioContainer}>
                  {isYes ? (
                    <IconFill
                      width={Metrics.rfv(16)}
                      height={Metrics.rfv(16)}
                    />
                  ) : (
                    <IconEmpty
                      width={Metrics.rfv(16)}
                      height={Metrics.rfv(16)}
                    />
                  )}
                  <Text style={styles.selectionInfoYes}>
                    {translate("Yes")}
                  </Text>
                </Pressable>
                <Pressable onPress={noRight} style={styles.radioContainer}>
                  {isNo ? (
                    <IconFill
                      width={Metrics.rfv(16)}
                      height={Metrics.rfv(16)}
                    />
                  ) : (
                    <IconEmpty
                      width={Metrics.rfv(16)}
                      height={Metrics.rfv(16)}
                    />
                  )}
                  <Text style={styles.selectionInfoYes}>{translate("No")}</Text>
                </Pressable>
              </View>
            </View>
            {isYes && (
              <View style={styles.horizontalContainerView}>
                <Text style={styles.signUpInfo}>{translate("YesInfo")}</Text>
                <FlatList
                  data={data}
                  numColumns={2}
                  scrollEnabled={false}
                  showsVerticalScrollIndicator={false}
                  renderItem={({ item, index }) => renderItem(item, index)}
                  keyExtractor={(item, index) => index.toString()}
                />
              </View>
            )}
            <View style={styles.inputTextStyle}>
              <View style={CommonStyle.alignCenterView}>
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onPressBackYes()}
                    title={translate("Back")}
                    borderColor={Colors.white}
                    color={Colors.white}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.linearColor2}
                  />
                </View>
                <View style={styles.gapViewStyle} />
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onPressNextYes()}
                    title={translate("Next")}
                    borderColor={Colors.white}
                    color={Colors.linearColor1}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.white}
                  />
                </View>
              </View>
              <Pressable onPress={() => onFinishPress()}>
                <Text style={styles.finishAccountSignUpInfo}>
                  {isYes
                    ? translate("Finish")
                    : translate("FinishStartFooterInfo")}
                </Text>
              </Pressable>
              {alreadyRegisterError ? (
                <Text style={styles.userAlreadyRegisterText}>
                  {userAlreadyRegister}
                </Text>
              ) : null}
            </View>
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </LinearGradient>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
}
