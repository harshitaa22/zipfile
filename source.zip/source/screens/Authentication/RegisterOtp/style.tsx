import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  mainLoginView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  svgIconStyle: {
    marginTop: Metrics.rfv(30),
    width: Metrics.rfv(71),
    height: Metrics.rfv(22),
    resizeMode: "contain",
  },
  signInText: {
    marginTop: Metrics.rfv(50),
  },
  signInTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(20),
    lineHeight: Metrics.rfv(22),
    fontFamily: Fonts.IN_SemiBold,
  },
  notHaveAccountTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
    marginTop: Metrics.rfv(5),
  },
  userEmailText: {
    fontFamily: Fonts.IN_Bold,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  height: {
    height: Metrics.rfv(40),
  },
  sentOtpText: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(19),
    textAlign: "center",
    marginBottom: Metrics.rfv(10),
  },
  inputTextStyle: {
    marginHorizontal: Metrics.rfv(20),
    marginTop: Metrics.rfv(25),
  },
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  horizontalContainerView: {
    alignItems: "center",
  },
  fullWidthStyle: {
    width: "100%",
  },
  resendOtpText: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
    paddingVertical: Metrics.rfv(15),
    marginTop: Metrics.rfv(10),
    textDecorationLine: "underline",
  },
  errorTextStyle: {
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    color: Colors.red,
    marginTop: Metrics.rfv(5),
  },
  sucessViewStyle: {
    paddingVertical: Metrics.rfv(5),
    backgroundColor: Colors.green,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(20),
  },
  sucessText: {
    color: Colors.white,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    marginLeft: Metrics.rfv(10),
  },
  sucessIcon: {
    height: Metrics.rfv(19),
    width: Metrics.rfv(19),
  },
  endView: {
    flex: 1,
    justifyContent: "flex-end",
    marginBottom: Metrics.rfv(20),
    marginHorizontal: Metrics.rfv(20),
  },
});
