import React, { useEffect, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import Button from "../../../component/Button";
import CommonHeader from "../../../component/CommonHeader";
import { NAVIGATION } from "../../../navigation";
import { ReceivingData } from "../../../theme/dummyArray";
import { Colors, CommonStyle, Metrics } from "../../../theme/index";
import styles from "./style";
import commonStyles from "../../../theme/commonStyle";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../utils/Localize";
import API_CONFIG from "../../../api/api_url";
import { showToast } from "../../../utils/commonFunction";
import { callApi } from "../../../api";
import Loader from "../../../component/ProgressBar";
import CustomTextInput from "../../../component/TextInput";
import KeyboardSpacer from "react-native-keyboard-spacer";
import { print_data } from "../../../utils/Logs";

export default function HabitsAndInterests(props: any) {
  const navigation = useNavigation();
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [userAlreadyRegister, setAlreadyRegister] = useState("");
  const [alreadyRegisterError, setAlreadyRegisterError] = useState(false);
  const [data, setData] = useState([]);
  const [offeringData, setOfferingData] = useState("");
  const [otherSelectedVisible, setOtherSelectedVisible] = useState(false);
  const [otherSelected, setOtherSelected] = useState(false);

  const { registerData } = props.route.params;

  useEffect(() => {
    let receivingData = [...ReceivingData];
    receivingData.forEach((item, _index) => {
      item.isSelected = false;
    });
    setData(receivingData);
  }, []);

  const itemSelected = (item, index) => {
    let temp = [...data];
    temp[index].isSelected = !item.isSelected;
    setData(temp);
    if (
      item?.isSelected == false &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setOfferingData("");
      setOtherSelected(false);
      setOtherSelectedVisible(false);
    } else if (
      item?.isSelected == true &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setOtherSelected(true);
    }
  };

  const receivingValidationFinishSelection = () => {
    const receivedSelected = ReceivingData.filter((item) => {
      return item.isSelected;
    });
    let sportOrEventOther = [];
    receivedSelected.map((item, index) => {
      let data = item.textBookMark;
      sportOrEventOther.push(data);
    });
    registerData.offeringOther = sportOrEventOther;
    registerData.offerItem = offeringData?.length > 0 ? [offeringData] : [];

    setTimeout(() => {
      setIsLoaderVisible(true);
      callRegisterApi();
    }, 100);
  };

  const onPressBack = () => {
    navigation.goBack();
  };
  const onPressFinish = () => {
    if (otherSelected) {
      if (offeringData?.length > 0) {
        setOtherSelectedVisible(false);
        receivingValidationFinishSelection();
      } else {
        setOtherSelectedVisible(true);
      }
    } else {
      receivingValidationFinishSelection();
    }
  };

  const verifyOtp = () => {
    navigation.navigate(NAVIGATION.REGISTER_OTP, { registerData });
  };

  const renderItem = (item, index) => {
    return (
      <View>
        <View style={styles.renderListStyle}>
          <Pressable
            onPress={() => itemSelected(item, index)}
            style={!item.isSelected ? styles.selectItem : styles.notSelectItem}
          >
            <Text
              style={
                !item.isSelected
                  ? styles.bookMarkTextStyle
                  : styles.selectedBookMarkTextStyle
              }
            >
              {item.textBookMark}
            </Text>
            {item.textBookMark == translate("OtherPleaseSpecify") &&
            item?.isSelected == true ? (
              <View style={styles.otherwidth}>
                <CustomTextInput
                  textInputStyle={styles.inputStyle}
                  containerStyle={styles.inputTextContainerStyle}
                  lableTextStyle={commonStyles.labelTextStyle}
                  inputTextStyle={styles.textInputStyle}
                  value={offeringData}
                  onChangeText={(text: string) => {
                    setOfferingData(text);
                  }}
                />
              </View>
            ) : null}
          </Pressable>
        </View>
        {item.textBookMark == translate("OtherPleaseSpecify") &&
        item?.isSelected == true ? (
          <>
            {otherSelectedVisible && (
              <Text style={styles.addBookmarkerText}>
                {translate("AddOffering")}
              </Text>
            )}
          </>
        ) : null}
      </View>
    );
  };

  const callRegisterApi = async () => {
    try {
      var param_data = {
        firstName: registerData?.userName,
        lastName: registerData?.userLastName,
        dob: registerData?.dateOfBirth,
        bookMakerAccount: registerData?.bookMarkerAccount
          ? registerData?.bookMarkerAccount
          : "",
        phone: registerData?.userPhoneNumber,
        titlePrefix: registerData?.selectedTitle,
        address: {
          country: registerData?.selectedCountry,
          state: registerData?.selectedState,
        },
        username: registerData?.userEmail,
        password: registerData?.userPassword,
        bookMakersOther: registerData?.otherItem
          ? registerData?.otherItem
          : translate("OtherPleaseSpecify"),
        bookMakers: registerData?.bookMakers ? registerData?.bookMakers : [],
        sportOrEvent: registerData?.sportOrEvent
          ? registerData?.sportOrEvent
          : "",
        sportOrEventOther: registerData?.sportEventData,
        offerings: registerData?.offeringOther
          ? registerData?.offeringOther
          : "",
        offeringsOther: registerData?.offerItem ? registerData?.offerItem : [],
      };
      const response = await callApi(
        API_CONFIG.SIGNUP,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          setIsLoaderVisible(false);
          verifyOtp();
        } else {
          setIsLoaderVisible(false);
          setTimeout(() => {
            if (response?.body?.data?.message) {
              setAlreadyRegisterError(true);
              setAlreadyRegister(response?.body?.data?.message);
            } else {
              showToast(translate("SomethingWrong"));
            }
          }, 10);
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
        >
          <View style={styles.formContainerStyle}>
            <CommonHeader
              title={translate("StepFive")}
              subTitle={translate("BookMarkSelectionInfo")}
            />
            <View style={styles.horizontalContainerView}>
              <Text style={styles.accountSignUpInfo}>
                {translate("ReceivingInfo")}
              </Text>
              <FlatList
                data={data}
                scrollEnabled={false}
                numColumns={2}
                renderItem={({ item, index }) => renderItem(item, index)}
                keyExtractor={(item, index) => index.toString()}
              />
            </View>
            <View style={styles.inputTextStyle}>
              <View style={CommonStyle.commonRow}>
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onPressBack()}
                    title={translate("Back")}
                    borderColor={Colors.white}
                    color={Colors.white}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.linearColor2}
                  />
                </View>
                <View style={styles.gapViewStyle} />
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onPressFinish()}
                    title={translate("Finish")}
                    borderColor={Colors.white}
                    color={Colors.linearColor1}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.white}
                  />
                </View>
              </View>
              {alreadyRegisterError ? (
                <Text style={styles.userAlreadyRegisterText}>
                  {userAlreadyRegister}
                </Text>
              ) : null}
            </View>
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </LinearGradient>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
}
