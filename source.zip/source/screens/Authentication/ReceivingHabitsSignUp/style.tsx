import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  horizontalContainerView: {
    marginHorizontal: Metrics.rfv(20),
  },
  mainLoginView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  svgIconStyle: {
    alignItems: "center",
    marginTop: Metrics.rfv(50),
    marginLeft: Metrics.rfv(22),
  },
  signInText: {
    alignItems: "center",
    marginTop: Metrics.rfv(50),
  },
  signInTextStyle: {
    marginHorizontal: Metrics.rfv(60),
    color: Colors.white,
    fontSize: Metrics.rfv(22),
    fontFamily: Fonts.IN_SemiBold,
  },
  notHaveAccountTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
  },
  addBookmarkerText: {
    color: Colors.red,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    marginTop: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
  },
  signUpTextStyle: {
    color: Colors.white,
    marginLeft: Metrics.rfv(8),
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Bold,
    textDecorationLine: "underline",
    textDecorationColor: Colors.white,
  },
  emailTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(15),
    fontFamily: Fonts.IN_SemiBold,
    alignSelf: "flex-start",
    marginBottom: Metrics.rfv(5),
  },
  passwordTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(15),
    fontFamily: Fonts.IN_SemiBold,
    alignSelf: "flex-start",
    marginTop: Metrics.rfv(15),
    marginBottom: Metrics.rfv(5),
  },
  inputTextStyle: {
    alignItems: "center",
    justifyContent: "flex-end",
    flex: 1,
    marginBottom: Metrics.rfv(20),
    marginHorizontal: Metrics.rfv(15),
  },
  yesSelectionStyle: {
    margin: Metrics.rfv(45),
    flex: 1,
  },
  textInputErrorStyle: {
    marginTop: Metrics.rfv(60),
  },
  forgotPasswordTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    textDecorationLine: "underline",
    textDecorationColor: Colors.white,
    marginTop: Metrics.rfv(12),
  },
  step1Style: {
    color: Colors.stepColor,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(14),
    marginLeft: Metrics.rfv(18),
    marginTop: Metrics.rfv(45),
  },
  accountSignUpInfo: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  bottomButtonStyle: {
    marginLeft: Metrics.rfv(12),
    width: Metrics.rfv(165),
  },
  checkBoxStyle: {
    height: Metrics.rfv(16),
    width: Metrics.rfv(16),
    borderRadius: Metrics.rfv(4),
  },
  selectionInfo: {
    color: Colors.white,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(13),
    marginLeft: Metrics.rfv(15),
  },
  width: {
    width: Metrics.rfv(165),
  },
  userAlreadyRegisterText: {
    color: Colors.red,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    textAlign: "center",
    marginTop: Metrics.rfv(10),
  },
  renderListStyle: {
    marginRight: Metrics.rfv(10),
    marginTop: Metrics.rfv(10),
    flex: 1,
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  bookMarkTextStyle: {
    color: Colors.notSelectedColor,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
  },
  selectedBookMarkTextStyle: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
  },
  itemSeparatorComponent: {
    backgroundColor: Colors.gray,
    margin: Metrics.rfv(15),
  },
  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  bookMarkList: {
    marginHorizontal: Metrics.rfv(5),
    marginTop: Metrics.rfv(10),
  },
  selectItem: {
    borderRadius: 20,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.lightblue,
    paddingHorizontal: Metrics.rfv(10),
    height: Metrics.rfv(37),
  },
  notSelectItem: {
    borderRadius: Metrics.rfv(20),
    backgroundColor: Colors.stepColor,
    alignItems: "center",
    height: Metrics.rfv(37),
    justifyContent: "center",
    paddingHorizontal: Metrics.rfv(10),
    flexDirection: "row",
  },
  textInputStyle: {
    height: Metrics.rfv(25),
    backgroundColor: Colors.white,
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    width: Metrics.rfv(100),
    padding: 0,
  },
  otherwidth: {
    marginLeft: Metrics.rfv(8),
  },
  inputStyle: {
    flex: 1,
    padding: 0,
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  formContainerStyle: {
    flex: 1,
  },
  inputTextContainerStyle: {
    width: "100%",
  },
});
