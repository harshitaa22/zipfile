import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  horizontalContainerView: {
    marginHorizontal: Metrics.rfv(20),
  },
  mainLoginView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  svgIconStyle: {
    alignItems: "center",
    marginTop: Metrics.rfv(50),
    marginLeft: Metrics.rfv(22),
  },
  inputTextStyle: {
    alignItems: "center",
    justifyContent: "flex-end",
    flex: 1,
    marginBottom: Metrics.rfv(20),
    marginHorizontal: Metrics.rfv(15),
  },
  width: {
    width: "100%",
    flex: 1,
  },
  addBookmarkerText: {
    color: Colors.red,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    marginTop: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  accountSignUpInfo: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    marginBottom: Metrics.rfv(5),
  },
  finishAccountSignUpInfo: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    marginTop: Metrics.rfv(15),
    textAlign: "center",
    textDecorationColor: Colors.white,
    textDecorationLine: "underline",
  },
  bottomButtonStyle: {
    marginLeft: Metrics.rfv(10),
    width: Metrics.rfv(165),
  },
  mainHomePageView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  signUpButton: {
    marginLeft: Metrics.rfv(12),
  },
  loginButton: {
    marginLeft: Metrics.rfv(150),
  },
  headerStyle: {
    justifyContent: "space-between",
    flexDirection: "row",
    margin: Metrics.rfv(15),
  },
  AdStyle: {
    margin: Metrics.rfv(15),
  },
  listTitle: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginHorizontal: Metrics.rfv(15),
  },
  renderListStyle: {
    marginRight: Metrics.rfv(6),
    marginTop: Metrics.rfv(10),
  },
  imageStyle: {
    width: Metrics.rfv(36),
    height: Metrics.rfv(36),
    resizeMode: "contain",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    marginTop: Metrics.rfv(8),
  },
  bookMarkTextStyle: {
    color: Colors.notSelectedColor,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
  },
  selectedBookMarkTextStyle: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
  },
  timeTextStyle: {
    color: Colors.white,
    borderRadius: Metrics.rfv(10),
    backgroundColor: Colors.orange,
    fontSize: Metrics.rfv(12),
    padding: Metrics.rfv(8),
    fontFamily: Fonts.IN_SemiBold,
  },
  nextTopicTextStyle: {
    color: Colors.black,
    margin: Metrics.rfv(5),
    fontFamily: Fonts.IN_SemiBold,
  },
  seeAllStyle: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(15),
    margin: Metrics.rfv(5),
    textDecorationLine: "underline",
    fontFamily: Fonts.IN_Regular,
    textDecorationColor: Colors.linearColor2,
  },
  itemSeparatorComponent: {
    backgroundColor: Colors.gray,
    margin: Metrics.rfv(15),
  },
  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  outerBoxStyle: {
    height: "auto",
    borderRadius: Metrics.rfv(8),
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(1),
    margin: Metrics.rfv(8),
  },
  selectItem: {
    borderRadius: Metrics.rfv(20),
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.lightblue,
    paddingHorizontal: Metrics.rfv(10),
    height: Metrics.rfv(37),
  },
  notSelectItem: {
    borderRadius: 20,
    backgroundColor: Colors.stepColor,
    alignItems: "center",
    height: Metrics.rfv(37),
    justifyContent: "center",
    paddingHorizontal: Metrics.rfv(10),
    flexDirection: "row",
  },
  userAlreadyRegisterText: {
    color: Colors.red,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    textAlign: "center",
    marginTop: Metrics.rfv(10),
  },
  textInputStyle: {
    height: Metrics.rfv(25),
    backgroundColor: Colors.white,
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    width: Metrics.rfv(100),
    padding: 0,
  },
  otherwidth: {
    marginLeft: Metrics.rfv(8),
  },
  inputStyle: {
    flex: 1,
    padding: 0,
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  flex: {
    flex: 1,
  },

  inputTextContainerStyle: {
    width: "100%",
  },
});
