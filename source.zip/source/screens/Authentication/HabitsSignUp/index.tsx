import React, { useEffect, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import Button from "../../../component/Button";
import { NAVIGATION } from "../../../navigation";
import { HabitsData } from "../../../theme/dummyArray";
import { Colors, CommonStyle, Metrics } from "../../../theme/index";
import commonStyles from "../../../theme/commonStyle";
import styles from "./style";
import CommonHeader from "../../../component/CommonHeader";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../utils/Localize";
import API_CONFIG from "../../../api/api_url";
import { callApi } from "../../../api";
import { showToast } from "../../../utils/commonFunction";
import Loader from "../../../component/ProgressBar";
import CustomTextInput from "../../../component/TextInput";
import KeyboardSpacer from "react-native-keyboard-spacer";

export default function HabitsAndInterests(props: any) {
  const navigation = useNavigation();
  const [data, setData] = useState([]);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [userAlreadyRegister, setAlreadyRegister] = useState("");
  const [alreadyRegisterError, setAlreadyRegisterError] = useState(false);
  const [otherSelectedVisible, setOtherSelectedVisible] = useState(false);
  const [sportEvent, setSportEvent] = useState("");
  const [otherSelected, setOtherSelected] = useState(false);
  const { registerData } = props.route.params;

  useEffect(() => {
    let habitsData = [...HabitsData];
    habitsData.forEach((item, _index) => {
      item.isSelected = false;
    });
    setData(habitsData);
  }, []);

  const itemSelected = (item, index) => {
    let temp = [...data];
    temp[index].isSelected = !item.isSelected;
    setData(temp);
    if (
      item?.isSelected == false &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setSportEvent("");
      setOtherSelected(false);
      setOtherSelectedVisible(false);
    } else if (
      item?.isSelected == true &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setOtherSelected(true);
    }
  };

  const onPressBack = () => {
    navigation.goBack();
  };

  const onPressNext = () => {
    if (otherSelected) {
      if (sportEvent?.length > 0) {
        setOtherSelectedVisible(false);
        habitsValidationYesSelection();
      } else {
        setOtherSelectedVisible(true);
      }
    } else {
      habitsValidationYesSelection();
    }
  };

  const onFinishPress = () => {
    setIsLoaderVisible(true);
    callRegisterApi();
  };

  const habitsValidationYesSelection = () => {
    const habitData = HabitsData.filter((item) => {
      return item.isSelected;
    });
    let sportOrEvent = [];

    habitData.map((item, index) => {
      let data = item.textBookMark;
      sportOrEvent.push(data);
    });

    registerData.sportOrEvent = sportOrEvent;
    registerData.sportEventData = sportEvent?.length > 0 ? [sportEvent] : [];

    navigation.navigate(NAVIGATION.NEXT5SIGN_UP, {
      registerData,
    });
  };

  const renderItem = (item, index) => {
    return (
      <View>
        <View style={styles.renderListStyle}>
          <Pressable
            onPress={() => itemSelected(item, index)}
            style={!item.isSelected ? styles.selectItem : styles.notSelectItem}
          >
            <Text
              style={
                !item.isSelected
                  ? styles.bookMarkTextStyle
                  : styles.selectedBookMarkTextStyle
              }
            >
              {item.textBookMark}
            </Text>
            {item.textBookMark == translate("OtherPleaseSpecify") &&
            item?.isSelected == true ? (
              <View style={styles.otherwidth}>
                <CustomTextInput
                  textInputStyle={styles.inputStyle}
                  containerStyle={styles.inputTextContainerStyle}
                  lableTextStyle={commonStyles.labelTextStyle}
                  inputTextStyle={styles.textInputStyle}
                  value={sportEvent}
                  onChangeText={(text: string) => {
                    setSportEvent(text);
                  }}
                />
              </View>
            ) : null}
          </Pressable>
        </View>
        {item.textBookMark == translate("OtherPleaseSpecify") &&
        item?.isSelected == true ? (
          <>
            {otherSelectedVisible && (
              <Text style={styles.addBookmarkerText}>
                {translate("AddSportOrEvent")}
              </Text>
            )}
          </>
        ) : null}
      </View>
    );
  };

  const verifyOtp = () => {
    navigation.navigate(NAVIGATION.REGISTER_OTP, {
      registerData,
    });
  };

  const callRegisterApi = async () => {
    try {
      var param_data = {
        firstName: registerData?.userName,
        lastName: registerData?.userLastName,
        dob: registerData?.dateOfBirth,
        bookMakerAccount: registerData?.bookMarkerAccount
          ? registerData?.bookMarkerAccount
          : "",
        phone: registerData?.userPhoneNumber,
        titlePrefix: registerData?.selectedTitle,
        address: {
          country: registerData?.selectedCountry,
          state: registerData?.selectedState,
        },
        username: registerData?.userEmail,
        password: registerData?.userPassword,
        bookMakersOther: registerData?.otherItem
          ? registerData?.otherItem
          : translate("OtherPleaseSpecify"),
        bookMakers: registerData?.bookMakers ? registerData?.bookMakers : [],
        sportOrEvent: registerData?.sportOrEvent
          ? registerData?.sportOrEvent
          : "",
        sportOrEventOther: registerData?.sportEventData
          ? registerData?.sportEventData
          : [],
        offerings: registerData?.offeringOther
          ? registerData?.offeringOther
          : "",
        offeringsOther: registerData?.offerItem ? registerData?.offerItem : [],
      };
      const response = await callApi(
        API_CONFIG.SIGNUP,
        param_data,
        API_CONFIG.POST,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setIsLoaderVisible(false);
          verifyOtp();
        } else {
          setIsLoaderVisible(false);
          setTimeout(() => {
            if (response?.body?.data?.message) {
              setAlreadyRegisterError(true);
              setAlreadyRegister(response?.body?.data?.message);
            } else {
              showToast(translate("SomethingWrong"));
            }
          }, 10);
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };
  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
        >
          <View style={styles.flex}>
            <CommonHeader
              title={translate("StepFour")}
              subTitle={translate("BookMarkSelectionInfo")}
            />

            <View style={styles.horizontalContainerView}>
              <Text style={styles.accountSignUpInfo}>
                {translate("HabitAccountInfo")}
              </Text>
              <FlatList
                data={data}
                numColumns={2}
                scrollEnabled={false}
                renderItem={({ item, index }) => renderItem(item, index)}
                keyExtractor={(item, index) => index.toString()}
              />
            </View>
            <View style={styles.inputTextStyle}>
              <View style={CommonStyle.commonRow}>
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onPressBack()}
                    title={translate("Back")}
                    borderColor={Colors.white}
                    color={Colors.white}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.linearColor2}
                  />
                </View>
                <View style={styles.gapViewStyle} />
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    onPress={() => onPressNext()}
                    title={translate("Next")}
                    borderColor={Colors.white}
                    color={Colors.linearColor1}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.white}
                  />
                </View>
              </View>
              <Pressable onPress={() => onFinishPress()}>
                <Text style={styles.finishAccountSignUpInfo}>
                  {translate("Finish")}
                </Text>
              </Pressable>
              {alreadyRegisterError ? (
                <Text style={styles.userAlreadyRegisterText}>
                  {userAlreadyRegister}
                </Text>
              ) : null}
            </View>
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </LinearGradient>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
}
