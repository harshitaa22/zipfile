import React, { useState } from "react";
import { Image, Text, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import AppSafeAreaView from "../../../component/AppSafeAreaView";
import AppStatusBar from "../../../component/AppStatusBar";
import Button from "../../../component/Button";
import { NAVIGATION } from "../../../navigation";
import { Colors, Images, Metrics } from "../../../theme/index";
import { FinishRightIcon, SmartBAppSmallIcon } from "../../../theme/svg";
import styles from "./style";
import { CommonActions, useNavigation } from "@react-navigation/native";
import { translate } from "../../../utils/Localize";
import { print_data } from "../../../utils/Logs";
import { useDispatch } from "react-redux";
import { Constant } from "../../../utils";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function Finish(props: any) {
  const navigation = useNavigation();
  const dispatch = useDispatch();

  const { responsData } = props?.route?.params;

  const onPressFinish = (response) => {
    saveUserData(response);
    clearFieldsAndNavigate();
  };

  const clearFieldsAndNavigate = async () => {
    navigation.dispatch(
      CommonActions.reset({
        index: 1,
        routes: [{ name: NAVIGATION.TAB_STACK }],
      })
    );
  };

  const saveUserData = async (response) => {
    try {
      const customData = {
        token: response?.access_token,
      };
      dispatch({
        type: Constant.SAVE_TOKEN,
        payload: JSON.stringify(customData),
      });
      await AsyncStorage.setItem(
        Constant.SAVE_TOKEN,
        JSON.stringify(customData)
      );
    } catch (e) {
      print_data("========exception in login data save=========" + e);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <View style={styles.horizontalContainerView}>
          {/* <SmartBAppSmallIcon style={styles.svgIconStyle} /> */}
          <Image source={Images.registerLogo} style={styles.svgIconStyle} />
        </View>
        <View style={styles.finishRightIconMainStyle}>
          <View style={styles.height} />
          <FinishRightIcon style={styles.finishIconStyle} />
          <Text style={styles.signUpInfo}>{translate("AllDone")}</Text>
          <Text style={styles.accountSignUpInfo}>{translate("AllStepUp")}</Text>
        </View>

        <View style={styles.bottomButtonStyle}>
          <Button
            disabled={false}
            onPress={() => onPressFinish(responsData)}
            title={translate("ContinueToHome")}
            borderColor={Colors.white}
            color={Colors.linearColor1}
            fontSize={Metrics.rfv(14)}
            backgroundColor={Colors.white}
          />
        </View>
      </LinearGradient>
    </AppSafeAreaView>
  );
}
