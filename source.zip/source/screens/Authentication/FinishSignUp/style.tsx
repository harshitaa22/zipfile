import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  safeAreaViewStyle: {
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
  horizontalContainerView: {
    marginHorizontal: Metrics.rfv(20),
    alignItems: "center",
  },
  mainLoginView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  svgIconStyle: {
    marginTop: Metrics.rfv(20),
    width: Metrics.rfv(71),
    height: Metrics.rfv(22),
    resizeMode: "contain",
  },
  signUpInfo: {
    color: Colors.white,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(23),
    marginTop: Metrics.rfv(25),
    lineHeight: Metrics.rfv(25),
    textAlign: "center",
  },
  accountSignUpInfo: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
    marginTop: Metrics.rfv(5),
  },
  bottomButtonStyle: {
    flex: 1,
    marginHorizontal: Metrics.rfv(20),
    justifyContent: "flex-end",
    marginBottom: Metrics.rfv(20),
  },
  finishRightIconMainStyle: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  finishIconStyle: {
    alignSelf: "center",
    height: Metrics.rfv(85),
    width: Metrics.rfv(85),
  },
  height: {
    height: Metrics.rfv(200),
  },
});
