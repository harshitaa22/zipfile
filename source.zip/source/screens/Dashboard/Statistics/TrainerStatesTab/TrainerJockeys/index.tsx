// import React from "react";
// import { ScrollView, View } from "react-native";

// import { useNavigation } from "@react-navigation/native";
// import JockeyCommonList from "../../../../../component/JockeyCommonList/index";
// import PartnersList from "../../../../../component/PartnersList";
// import TabCommonTitle from "../../../../../component/TabCommonTitle";
// import TextHeaderTitle from "../../../../../component/Text/index";
// import { NAVIGATION } from "../../../../../navigation";
// import commonStyles from "../../../../../theme/commonStyle";
// import {
//   JockeyList,
//   JockeyListDetailsItem,
//   JockeyListItem,
// } from "../../../../../theme/dummyArray";
// import { translate } from "../../../../../utils/Localize";
// import styles from "./style";

// const TrainerJockeys = () => {
//   const navigation = useNavigation();

//   return (
//     <ScrollView
//       contentContainerStyle={commonStyles.scrollViewStyle}
//       overScrollMode={"never"}
//       showsVerticalScrollIndicator={false}
//       keyboardShouldPersistTaps={"handled"}
//       nestedScrollEnabled={true}
//     >
//       <View style={styles.horizontalView}>
//         <TabCommonTitle
//           title={translate("JockeyStatistics")}
//           subTitle={translate("LoremNewsCommonTitle")}
//         />
//       </View>

//       <View style={styles.horizontalView}>
//         <View style={styles.statesView}>
//           <JockeyCommonList
//             listItem={JockeyListDetailsItem}
//             data={JockeyListItem}
//             onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
//           />
//         </View>
//       </View>

//       <View style={styles.horizontalView}>
//         <View style={styles.statesView}>
//           <JockeyCommonList
//             listItem={JockeyListDetailsItem}
//             data={JockeyList}
//             onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
//           />
//         </View>
//       </View>

//       <View style={styles.horizontalView}>
//         <View style={styles.statesView}>
//           <JockeyCommonList
//             listItem={JockeyListDetailsItem}
//             data={JockeyList}
//             onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
//           />
//         </View>
//       </View>
//       <View style={styles.textCenter}>
//         <TextHeaderTitle
//           title={translate("OurPartners")}
//           textStyle={styles.sportStyle}
//         />
//       </View>
//       <View style={styles.partnerListBottom}>
//         <PartnersList />
//       </View>
//     </ScrollView>
//   );
// };

// export default TrainerJockeys;

import React from "react";
import { ScrollView, View } from "react-native";
import JockeyCommonList from "../../../../../component/JockeyCommonList";
import PartnersList from "../../../../../component/PartnersList";
import TabCommonTitle from "../../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../../component/Text/index";
import commonStyles from "../../../../../theme/commonStyle";
import {
  CurrentSessionList,
  JockeyListDetailsItem,
  JockeyListItem,
  JockeyMonthListItem,
  TrainerListItem,
  TrainerTrackListItem,
} from "../../../../../theme/dummyArray";
import { translate } from "../../../../../utils/Localize";
import styles from "./style";

const TrainerJockeys = (props: any) => {
  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.horizontalView}>
        <TabCommonTitle
          title={
            props.listTitleData
              ? translate("TopJockeys")
              : translate("JockeyTracks")
          }
        />
      </View>
      <View style={styles.horizontalView}>
        <View style={styles.statesView}>
          <JockeyCommonList
            listItem={JockeyListDetailsItem}
            data={props.listTitleData ? JockeyListItem : TrainerListItem}
          />
        </View>
      </View>
      <View style={styles.horizontalView}>
        <View style={styles.statesView}>
          <JockeyCommonList
            listItem={JockeyListDetailsItem}
            data={CurrentSessionList}
          />
        </View>
      </View>
      <View style={styles.textCenter}>
        <TextHeaderTitle
          title={translate("OurPartners")}
          textStyle={styles.sportStyle}
        />
      </View>
      <View style={styles.partnerListBottom}>
        <PartnersList />
      </View>
    </ScrollView>
  );
};

export default TrainerJockeys;
