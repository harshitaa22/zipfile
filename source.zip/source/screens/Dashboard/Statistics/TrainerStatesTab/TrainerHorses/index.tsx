import React from "react";
import { ScrollView, Text, View } from "react-native";
import HorsesProfileList from "../../../../../component/HorsesProfileList/index";
import PartnersList from "../../../../../component/PartnersList";
import TabCommonTitle from "../../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../../component/Text/index";
import commonStyles from "../../../../../theme/commonStyle";
import {
  HorsesProfileListItem,
  UpcomingListItem,
} from "../../../../../theme/dummyArray";
import { translate } from "../../../../../utils/Localize";
import styles from "./style";

const TrainerHorses = () => {
  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.horizontalView}>
        <TabCommonTitle title={translate("Horses")} />
      </View>
      <View style={styles.horsesContainerView}>
        <Text style={styles.dateText}>Upcoming</Text>
        <View style={styles.bottomWidth} />
        <HorsesProfileList data={UpcomingListItem} />
      </View>
      <View style={styles.horsesContainerView}>
        <Text style={styles.dateText}>October 2022</Text>
        <View style={styles.bottomWidth} />
        <HorsesProfileList data={HorsesProfileListItem} />
      </View>
      <View style={styles.horsesContainerView}>
        <Text style={styles.dateText}>October 2022</Text>
        <View style={styles.bottomWidth} />
        <HorsesProfileList data={HorsesProfileListItem} />
      </View>
      <View style={styles.horsesContainerView}>
        <Text style={styles.dateText}>October 2022</Text>
        <View style={styles.bottomWidth} />
        <HorsesProfileList data={HorsesProfileListItem} />
      </View>
      <View style={styles.textCenter}>
        <TextHeaderTitle
          title={translate("OurPartners")}
          textStyle={styles.sportStyle}
        />
      </View>
      <View style={styles.partnerListBottom}>
        <PartnersList />
      </View>
    </ScrollView>
  );
};

export default TrainerHorses;
