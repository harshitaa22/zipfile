import { useNavigation } from "@react-navigation/native";
import React from "react";
import { ScrollView, View } from "react-native";
import JockeyCommonList from "../../../../component/JockeyCommonList/index";
import PartnersList from "../../../../component/PartnersList";
import TabCommonTitle from "../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../component/Text/index";
import { NAVIGATION } from "../../../../navigation";
import commonStyles from "../../../../theme/commonStyle";
import {
  JockeyListDetailsItem,
  JockeyTrainerStatsListItem,
  TrainerFirstListItem,
} from "../../../../theme/dummyArray";
import { translate } from "../../../../utils/Localize";
import styles from "./style";

const StatisticsTrainers = () => {
  const navigation = useNavigation();

  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.horizontalView}>
        <TabCommonTitle
          title={translate("JockeyStatistics")}
          subTitle={translate("LoremNewsCommonTitle")}
        />
      </View>
      <View style={styles.horizontalView}>
        <View style={styles.statesView}>
          <JockeyCommonList
            listItem={JockeyListDetailsItem}
            data={JockeyTrainerStatsListItem}
            onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
          />
        </View>
      </View>
      <View style={styles.secondItem} />
      <View style={styles.horizontalView}>
        <View style={styles.statesView}>
          <JockeyCommonList
            listItem={JockeyListDetailsItem}
            data={TrainerFirstListItem}
            onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
          />
        </View>
      </View>
      <View style={styles.textCenter}>
        <TextHeaderTitle
          title={translate("OurPartners")}
          textStyle={styles.sportStyle}
        />
      </View>
      <View style={styles.partnerListBottom}>
        <PartnersList />
      </View>
    </ScrollView>
  );
};

export default StatisticsTrainers;
