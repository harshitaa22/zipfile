import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../theme/index";

export default StyleSheet.create({
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(8),
    backgroundColor: Colors.white,
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(18),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  headerContainer: (visible) => ({
    backgroundColor: visible ? Colors.linearColor2 : Colors.lightGrayBoxGray,
    alignItems: "center",
    paddingVertical: Metrics.rfv(8),
  }),
  headerBlueContainer: {
    backgroundColor: Colors.purpleColor,
    alignItems: "center",
    paddingVertical: Metrics.rfv(8),
  },
  headerTitle: (visible) => ({
    color: visible ? Colors.white : Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  }),
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  container: {
    flex: 1,
    paddingTop: 25,
    marginHorizontal: 16,
  },
  item: {
    backgroundColor: "#f9c2ff",
    padding: 20,
    marginVertical: 8,
  },
  betContainer: {
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
  },
  betText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
  },
  header: {
    fontSize: 32,
    backgroundColor: "#fff",
  },
  titleText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    paddingBottom: Metrics.rfv(3),
  },
  topView: {
    marginTop: Metrics.rfv(12),
  },
  lastText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
  },
  bottomWidth: {
    width: "100%",
    borderWidth: Metrics.rfv(0.5),
    marginTop: Metrics.rfv(8),
    borderColor: Colors.lineBreak,
  },
  reviewText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
  },
  orengeView: (visible) => ({
    backgroundColor: visible ? Colors.green : Colors.orange,
    paddingHorizontal: Metrics.rfv(5),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
  }),
  softView: {
    backgroundColor: Colors.linearColor2,
    paddingHorizontal: Metrics.rfv(7),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
  },
  goodView: {
    backgroundColor: Colors.green,
    paddingHorizontal: Metrics.rfv(7),
    borderRadius: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(2),
  },
  height: {
    height: Metrics.rfv(15),
  },
});
