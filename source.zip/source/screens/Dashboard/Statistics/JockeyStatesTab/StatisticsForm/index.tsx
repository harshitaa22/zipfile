import React from "react";
import { ScrollView, SectionList, Text, View } from "react-native";
import PartnersList from "../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../component/Text/index";
import commonStyles from "../../../../../theme/commonStyle";
import { STATISTICS_FORM_DATA } from "../../../../../theme/dummyArray";
import { translate } from "../../../../../utils/Localize";
import styles from "./style";

const StatisticsForm = () => {
  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.horizontalView}>
        <TextHeaderTitle
          title={translate("JockeyForm")}
          textStyle={styles.textStyle}
        />
      </View>
      <View style={styles.height} />
      <SectionList
        sections={STATISTICS_FORM_DATA}
        keyExtractor={(item, index) => item + index}
        renderItem={({ item }) => <View></View>}
        renderSectionHeader={({ section: { title } }) => (
          <>
            <View style={styles.headerContainer(title == "1 of 11")}>
              <Text style={styles.headerTitle(title == "1 of 11")}>
                {title}
              </Text>
            </View>
            <View style={styles.betContainer}>
              <Text style={styles.betText}>
                bet365 Echuca 11-Oct-22 1000m{"  "}
                <View style={styles.orengeView(title == "1 of 11")}>
                  <Text style={styles.reviewText}>
                    {title == "1 of 11" ? "Good 4" : "Heavy 8"}
                  </Text>
                </View>
                <Text style={styles.betText}>
                  {"  "}
                  R7 0-64 $675 (of $27,000) , Barrier 7 , Winning Time: 58.66 ,
                  SP: $31.00 In-Running: 800m 9th, 400m 11th,
                </Text>
              </Text>
              {/* <View style={styles.orengeView}> */}

              {/* </View> */}

              <View style={styles.topView}>
                <Text style={styles.titleText}>
                  1st{"     "}Tori's Dee (J Hill 60kg, Cd 60kg)
                </Text>
                <Text style={styles.titleText}>
                  2nd{"     "}Valjeta (J Duffy 56kg, Cd 56kg) 0.30L
                </Text>
                <Text style={styles.titleText}>
                  3rd{"     "}Starz Barwon (B Mertens 58.5kg, Cd 58.5kg) 1.05L
                </Text>
                <Text style={styles.lastText}>
                  8th{"     "}Hugo Loves Vegas (S Clarke 55.5kg, Cd 54kg) 3.85L
                </Text>
                <View style={styles.bottomWidth} />
              </View>
            </View>
          </>
        )}
      />
      <View style={styles.textCenter}>
        <TextHeaderTitle
          title={translate("OurPartners")}
          textStyle={styles.sportStyle}
        />
      </View>
      <View style={styles.partnerListBottom}>
        <PartnersList />
      </View>
    </ScrollView>
  );
};

export default StatisticsForm;
