import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../theme/index";

export default StyleSheet.create({
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(10),
    marginTop: Metrics.rfv(15),
    marginBottom: Metrics.rfv(10),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },

  tabViewStyle: {
    height: Metrics.rfv(3),
    marginTop: Metrics.rfv(50),
    backgroundColor: Colors.linearColor2,
  },
  indicatorStyle: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "center",
    width: Metrics.rfv(120),
    height: Metrics.rfv(6),
  },
  tabBarMainStyle: {
    backgroundColor: Colors.white,
    shadowOffset: { height: Metrics.rfv(0), width: Metrics.rfv(0) },
    shadowColor: "transparent",
    shadowOpacity: Metrics.rfv(0),
    elevation: Metrics.rfv(0),
    marginBottom: Metrics.rfv(8),
  },
  contentContainerStyle: {
    justifyContent: "center",
  },
  renderTabStyle: {
    elevation: Metrics.rfv(0),
    width: Metrics.rfv(120),
  },
  labelStyle: {
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
  },
  editUserDetails: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    textDecorationLine: "underline",
    marginBottom: Metrics.rfv(10),
  },
  box: {
    height: 250,
    width: "100%",
  },
  boxA: {
    backgroundColor: "white",
  },
  boxB: {
    backgroundColor: "#D8D8D8",
  },
  tabStyle: {
    alignSelf: "center",
    justifyContent: "center",
    flexDirection: "row",
    padding: 0,
    marginRight: Metrics.rfv(10),
  },
  indicator: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "center",
    height: Metrics.rfv(4),
    width: Metrics.rfv(100),
  },

  bottomBorder: {
    borderBottomWidth: Metrics.rfv(3),
    borderBottomColor: Colors.linearColor2,
    elevation: 0,
  },
});
