import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../theme/index";

export default StyleSheet.create({
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,

    marginBottom: Metrics.rfv(15),
  },
  horizontalGalleryView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    paddingBottom: Metrics.rfv(5),
    marginBottom: Metrics.rfv(15),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  hightView: {
    height: Metrics.rfv(20),
    backgroundColor: "red",
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginBottom: Metrics.rfv(8),
  },
  statesView: {
    paddingTop: Metrics.rfv(20),
  },
  secondItem: {
    height: Metrics.rfv(5),
    backgroundColor: Colors.cream,
  },
  listWidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(10),
    width: "100%",
  },
  containerView: {
    backgroundColor: Colors.cream,
  },
  titleView: {
    backgroundColor: Colors.white,
    paddingHorizontal: Metrics.rfv(15),
    paddingBottom: Metrics.rfv(10),
  },
});
