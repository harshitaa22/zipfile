import { useNavigation } from "@react-navigation/native";
import React from "react";
import { ScrollView, View } from "react-native";
import JockeyCommonList from "../../../../../component/JockeyCommonList";
import PartnersList from "../../../../../component/PartnersList";
import TabCommonTitle from "../../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../../component/Text/index";
import { NAVIGATION } from "../../../../../navigation";
import commonStyles from "../../../../../theme/commonStyle";
import {
  CurrentSessionList,
  JockeyListDetailsItem,
  TrainerTrackListItem,
} from "../../../../../theme/dummyArray";
import { translate } from "../../../../../utils/Localize";
import styles from "./style";

const StatisticsTracks = () => {
  const navigation = useNavigation();
  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.horizontalGalleryView}>
        <TabCommonTitle title={translate("JockeyTracks")} />
      </View>

      <View style={styles.horizontalView}>
        <View style={styles.statesView}>
          <JockeyCommonList
            listItem={JockeyListDetailsItem}
            data={TrainerTrackListItem}
            onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
          />
        </View>
      </View>

      <View style={styles.horizontalView}>
        <View style={styles.statesView}>
          <JockeyCommonList
            listItem={JockeyListDetailsItem}
            data={CurrentSessionList}
            onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
          />
        </View>
      </View>

      <View style={styles.textCenter}>
        <TextHeaderTitle
          title={translate("OurPartners")}
          textStyle={styles.sportStyle}
        />
      </View>
      <View style={styles.partnerListBottom}>
        <PartnersList />
      </View>
    </ScrollView>
  );
};

export default StatisticsTracks;
