import React from "react";
import { ScrollView, View } from "react-native";

import { useNavigation } from "@react-navigation/native";
import JockeyCommonList from "../../../../component/JockeyCommonList/index";
import TabCommonTitle from "../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../component/Text";
import commonStyles from "../../../../theme/commonStyle";
import {
  JockeyListDetailsItem,
  JockeyListItem,
  JockeySecondListItem,
} from "../../../../theme/dummyArray";
import { translate } from "../../../../utils/Localize";
import styles from "./style";

import PartnersList from "../../../../component/PartnersList";
import { NAVIGATION } from "../../../../navigation";

const TrackJoketStarts = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.containerView}>
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <View style={styles.titleView}>
          <TabCommonTitle
            title={translate("JockeyStatistics")}
            subTitle={translate("LoremNewsCommonTitle")}
          />
        </View>
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={JockeyListItem}
              onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
            />
          </View>
        </View>
        <View style={styles.secondItem} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={JockeySecondListItem}
              onClick={() => navigation.navigate(NAVIGATION.TRAINER_TAB)}
            />
          </View>
        </View>
        {/* <View style={commonStyles.commonFlex}>
              <JockeyDetailsList data={JockeyList} />
            </View> */}
        {/* <View style={commonStyles.bottomWidth} /> */}
        {/* <View style={commonStyles.commonRow}>
            <View style={commonStyles.commonFlex}>
              <JockeyCommonList
                data={JockeySecondListItem}
                onClick={() => navigation.navigate(NAVIGATION.JOCKEY_STATES)}
              />
            </View>
            <View style={commonStyles.commonFlex}>
              <JockeyDetailsList data={JockeyList} />
            </View>
          </View> */}
        {/* <View style={commonStyles.bottomWidth} /> */}
        {/* <View style={styles.textCenter}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.sportStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View> */}

        <View style={styles.textCenter}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.sportStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </View>
  );
};

export default TrackJoketStarts;
