import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../theme/index";

export default StyleSheet.create({
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    paddingBottom: Metrics.rfv(15),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textCenter: {
    alignSelf: "center",
    marginTop: Metrics.rfv(20),
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  listContainer: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    paddingTop: Metrics.rfv(20),
    marginTop: Metrics.rfv(15),
    paddingBottom: Metrics.rfv(20),
  },
});
