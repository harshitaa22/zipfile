import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../theme/index";

export default StyleSheet.create({
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
  },
  profileHorizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    paddingBottom: Metrics.rfv(5),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.cream,
  },
  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  statesView: {
    paddingTop: Metrics.rfv(20),
  },
  containerStyle: {
    flex: 1,
    backgroundColor: Colors.cream,
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  height: {
    height: Metrics.rfv(10),
    backgroundColor: Colors.cream,
    marginTop: Metrics.rfv(8),
  },
  partnersContainer: {
    backgroundColor: Colors.cream,
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  topView: {
    height: Metrics.rfv(10),
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(8),
  },
});
