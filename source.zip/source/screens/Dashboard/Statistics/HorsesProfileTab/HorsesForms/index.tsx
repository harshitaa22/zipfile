import React from "react";
import { ScrollView, View } from "react-native";
import JockeyCommonList from "../../../../../component/JockeyCommonList";
import PartnersList from "../../../../../component/PartnersList";
import TabCommonTitle from "../../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../../component/Text/index";
import commonStyles from "../../../../../theme/commonStyle";
import {
  BarrierList,
  BarrierListItem,
  CareerList,
  CussionList,
  DistanceList,
  DistanceListItem,
  FieldListItem,
  FieldsList,
  JockeyListDetailsItem,
  PrizeList,
  PrizeListItem,
  ProfileCusionList,
  ProfileListItem,
  ProfileMonthlyListItem,
  ProfileSecondListItem,
  ProfileTrackList,
  SpellsList,
  SpellsListItem,
  WeightList,
  WeightListItem,
} from "../../../../../theme/dummyArray";
import { translate } from "../../../../../utils/Localize";
import styles from "./style";

const HorsesForms = () => {
  return (
    <View style={styles.containerStyle}>
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <View style={styles.profileHorizontalView}>
          <TabCommonTitle title={translate("HorseStatistics")} />
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={ProfileListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={ProfileSecondListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={ProfileMonthlyListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={ProfileTrackList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={CareerList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={ProfileCusionList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={CussionList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={DistanceListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={DistanceList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={BarrierListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={BarrierList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={PrizeListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={PrizeList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={WeightListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={WeightList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={FieldListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={FieldsList}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={SpellsListItem}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalView}>
          <View style={styles.statesView}>
            <JockeyCommonList
              listItem={JockeyListDetailsItem}
              data={SpellsList}
            />
          </View>
        </View>
        <View style={styles.textCenter}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.sportStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </View>
  );
};

export default HorsesForms;
