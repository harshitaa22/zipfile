import React from "react";
import { ScrollView, SectionList, Text, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import PartnersList from "../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../component/Text/index";
import { Colors } from "../../../../../theme";
import commonStyles from "../../../../../theme/commonStyle";
import { STATISTICS_FORM_DATA } from "../../../../../theme/dummyArray";
import { translate } from "../../../../../utils/Localize";
import styles from "./style";

const HorsesProfile = (props: any) => {
  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.horizontalView}>
        <TextHeaderTitle
          title={translate("HorseProfile")}
          textStyle={styles.textStyle}
        />
      </View>
      <View style={styles.horizontalDistrtrust}>
        <Text style={styles.dateText}>Distrustful Award - Career Stats</Text>
        <View style={styles.bottomBlueWidth} />
      </View>
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainLoginView}
      >
        <View style={commonStyles.centerView}>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.todayTitleTextStyle}>Earnings: </Text>
            <Text style={styles.priceText}>$22k</Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.todayTitleTextStyle}>Avg Odds: </Text>
            <Text style={styles.priceText}>1.26</Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.todayTitleTextStyle}>Ratings: </Text>
            <Text style={styles.priceText}>63</Text>
          </View>
        </View>
      </LinearGradient>
      <View style={styles.horsesContainerView}>
        <View style={styles.containerView}>
          <View style={commonStyles.commonFlex}>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Career:</Text>
              <Text style={styles.detailsText}>3 1-0-1</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>1st Up:</Text>
              <Text style={styles.detailsText}>1 0-0-1</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Firm:</Text>
              <Text style={styles.detailsText}>0 0-0-0</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Wins:</Text>
              <Text style={styles.detailsText}>33%</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Synthetic:</Text>
              <Text style={styles.detailsText}>0 0-0-0</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Heavy:</Text>
              <Text style={styles.detailsText}>2 0-0-1</Text>
            </View>
          </View>
          <View style={commonStyles.commonFlex}>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Last Up:</Text>
              <Text style={styles.detailsText}>3 1-0-1</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>2nd Up: </Text>
              <Text style={styles.detailsText}>1 0-0-0</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Good:</Text>
              <Text style={styles.detailsText}>1 1-0-0</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Places:</Text>
              <Text style={styles.detailsText}>67%</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>ROI:</Text>
              <Text style={styles.detailsText}>-58%</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Win Range:</Text>
              <Text style={styles.detailsText}>2000m - 2000m</Text>
            </View>
          </View>
          <View style={commonStyles.commonFlex}>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>12 months: </Text>
              <Text style={styles.detailsText}>3 1-0-1</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Turf: </Text>
              <Text style={styles.detailsText}>3 1-0-1</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>Soft: </Text>
              <Text style={styles.detailsText}>0 0-0-0</Text>
            </View>
          </View>
        </View>

        <View style={styles.bottomWidth} />
        <Text style={styles.dateText}>October 2022</Text>
        <View style={styles.bottomBlueWidth} />
        <Text style={styles.oddsText}>
          *Odds shown below are as at the last update SmartB has taken directly
          from the various Bookmakers. Odds on the bookmaker website may vary.
          Some bookmakers may have No Odds Available (NOA) for this race.
        </Text>
        <View style={styles.bottomWidth} />
      </View>
      <SectionList
        sections={STATISTICS_FORM_DATA}
        keyExtractor={(item, index) => item + index}
        renderItem={({ item }) => <View></View>}
        renderSectionHeader={({ section: { title } }) => (
          <>
            <View style={styles.headerContainer(title == "1 of 11")}>
              <Text style={styles.headerTitle(title == "1 of 11")}>
                {title}
              </Text>
            </View>
            <View style={styles.betContainer}>
              <Text style={styles.betText}>
                bet365 Echuca 11-Oct-22 1000m{"  "}
                <View style={styles.orengeView(title == "1 of 11")}>
                  <Text style={styles.reviewText}>
                    {title == "1 of 11" ? "Good 4" : "Heavy 8"}
                  </Text>
                </View>
                <Text style={styles.betText}>
                  {"  "}
                  R7 0-64 $675 (of $27,000) , Barrier 7 , Winning Time: 58.66 ,
                  SP: $31.00 In-Running: 800m 9th, 400m 11th,
                </Text>
              </Text>
              {/* <View style={styles.orengeView}> */}

              {/* </View> */}

              <View style={styles.topView}>
                <Text style={styles.titleText}>
                  1st{"     "}Tori's Dee (J Hill 60kg, Cd 60kg)
                </Text>
                <Text style={styles.titleText}>
                  2nd{"     "}Valjeta (J Duffy 56kg, Cd 56kg) 0.30L
                </Text>
                <Text style={styles.titleText}>
                  3rd{"     "}Starz Barwon (B Mertens 58.5kg, Cd 58.5kg) 1.05L
                </Text>
                <Text style={styles.lastText}>
                  8th{"     "}Hugo Loves Vegas (S Clarke 55.5kg, Cd 54kg) 3.85L
                </Text>
                <View style={styles.bottomWidth} />
              </View>
            </View>
          </>
        )}
      />
      <View style={styles.textCenter}>
        <TextHeaderTitle
          title={translate("OurPartners")}
          textStyle={styles.sportStyle}
        />
      </View>
      <View style={styles.partnerListBottom}>
        <PartnersList />
      </View>
    </ScrollView>
  );
};

export default HorsesProfile;
