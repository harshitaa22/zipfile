import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../theme/index";

export default StyleSheet.create({
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(8),
    backgroundColor: Colors.white,
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  horsesContainerView: {
    paddingHorizontal: Metrics.rfv(15),
    paddingBottom: Metrics.rfv(15),
  },

  dateText: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  oddsText: {
    color: Colors.LoremText,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    paddingBottom: Metrics.rfv(15),
  },
  todayTitleTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_SemiBold,
  },
  priceText: {
    color: Colors.white,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
  },

  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(18),
  },
  horizontalDistrtrust: {
    paddingHorizontal: Metrics.rfv(15),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  headerContainer: (visible) => ({
    backgroundColor: visible ? Colors.linearColor2 : Colors.lightGrayBoxGray,
    alignItems: "center",
    paddingVertical: Metrics.rfv(8),
  }),
  headerBlueContainer: {
    backgroundColor: Colors.purpleColor,
    alignItems: "center",
    paddingVertical: Metrics.rfv(8),
  },
  bottomBlueWidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.linearColor2,
    marginBottom: Metrics.rfv(10),
    width: "100%",
  },
  headerTitle: (visible) => ({
    color: visible ? Colors.white : Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  }),
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },

  item: {
    backgroundColor: "#f9c2ff",
    padding: 20,
    marginVertical: 8,
  },
  betContainer: {
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
  },
  betText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
  },
  header: {
    fontSize: 32,
    backgroundColor: "#fff",
  },
  titleText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    paddingBottom: Metrics.rfv(3),
  },
  topView: {
    marginTop: Metrics.rfv(12),
  },
  lastText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
  },
  bottomWidth: {
    width: "100%",
    borderWidth: Metrics.rfv(0.5),
    marginTop: Metrics.rfv(8),
    borderColor: Colors.lineBreak,
  },
  listTitle: {
    color: Colors.linearColor2,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    marginRight: Metrics.rfv(20),
  },
  reviewText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
  },
  orengeView: (visible) => ({
    backgroundColor: visible ? Colors.green : Colors.orange,
    paddingHorizontal: Metrics.rfv(5),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
  }),
  softView: {
    backgroundColor: Colors.linearColor2,
    paddingHorizontal: Metrics.rfv(7),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
  },
  goodView: {
    backgroundColor: Colors.green,
    paddingHorizontal: Metrics.rfv(7),
    borderRadius: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(2),
  },
  height: {
    height: Metrics.rfv(15),
  },
  detailsText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
  },
  subTitleText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
  emptyImage: {
    height: Metrics.rfv(80),
    width: "100%",
  },
  separateLine: {
    height: Metrics.rfv(75),
    borderWidth: Metrics.rfv(0.3),
    borderColor: Colors.lineBreak,
  },

  containerView: {
    flexDirection: "row",
  },
  commonRowContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  containerStyle: {},
  raceText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  nextRaceText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(20),
  },
  raceMeterText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    marginTop: Metrics.rfv(10),
  },
  mainLoginView: {
    paddingVertical: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    marginBottom: Metrics.rfv(10),
  },

  listText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    marginRight: Metrics.rfv(20),
    flex: 1,
    paddingTop: Metrics.rfv(10),
    paddingBottom: Metrics.rfv(15),
  },
  firstList: {
    flex: 1,
    width: "100%",
    marginTop: Metrics.rfv(5),
    marginBottom: Metrics.rfv(4),
  },
  descriptionText: {
    color: Colors.LoremText,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  topText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    textAlign: "center",
  },
  topToteContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
  },
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
    justifyContent: "space-between",
  },

  indexView: {
    flexDirection: "row",
    alignItems: "center",
  },
  indexText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  indexContainer: {
    backgroundColor: Colors.linearColor2,
    height: Metrics.rfv(25),
    width: Metrics.rfv(25),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
    marginRight: Metrics.rfv(5),
  },
  indexLowText: {
    color: Colors.gray,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  indexLowContainer: {
    backgroundColor: Colors.drownDownBackground,
    height: Metrics.rfv(25),
    width: Metrics.rfv(25),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
    marginRight: Metrics.rfv(5),
  },
  sepraterLine: {
    borderWidth: Metrics.rfv(0.3),
    height: Metrics.rfv(40),
    opacity: Metrics.rfv(0.5),
    color: Colors.borderLightGrey,
  },
  detailsTitle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    marginRight: Metrics.rfv(20),
  },

  dateContainer: {
    height: Metrics.rfv(35),
  },
});
