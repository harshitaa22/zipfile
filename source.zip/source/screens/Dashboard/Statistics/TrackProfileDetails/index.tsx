import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import { Pressable, ScrollView, View } from "react-native";
import { TextInput } from "react-native-gesture-handler";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";
import Header from "../../../../component/HeaderComponent/index";
import LeaguePicker from "../../../../component/LeaguePicker";
import PartnersList from "../../../../component/PartnersList";
import ProfileDetailist from "../../../../component/ProfileDetailsList";
import TextHeaderTitle from "../../../../component/Text/index";
import CustomTextInput from "../../../../component/TextInput";
import { NAVIGATION } from "../../../../navigation";
import { Colors, Images } from "../../../../theme";
import commonStyles from "../../../../theme/commonStyle";
import { profileDetailList } from "../../../../theme/dummyArray";
import { StatisticsSearchIcon } from "../../../../theme/svg";
import { translate } from "../../../../utils/Localize";
import styles from "./style";

const TrackProfileDetails = (props: any) => {
  const navigation = useNavigation();
  const selectData = props?.route?.params?.selectData;
  const [isLeaugeModalVisible, setLeagueModalVisible] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedOddsText, setSelectedOddsText] = useState(translate("State"));

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <LeaguePicker
          isVisible={isLeaugeModalVisible}
          showModel={setLeagueModalVisible}
          data={oddsDataOption}
          onItemSelect={(selectedData) => {
            setSelectedOddsText(selectedData?.title);
          }}
        />
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          showBannerIcon={true}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={selectData ? selectData : translate("TrackProfiles")}
            textStyle={styles.textStyle}
          />
        </View>
        <View style={styles.searchView}>
          <View style={styles.mainPickerStyle}>
            <Pressable
              style={styles.oddTypeWidth}
              onPress={() => setLeagueModalVisible(true)}
            >
              <CustomTextInput
                editable={false}
                pointerEvents="none"
                textInputStyle={styles.textModelInputStyle(
                  selectedOddsText == translate("State")
                )}
                // dropDown={true}
                racingDropDown={true}
                dropDownStyle={styles.dropDownArrow}
                dropDownIconStyle={styles.dropDownContainer}
                placeholderText={""}
                inputTextStyle={styles.inputTextStyle}
                placeholderTextColor={Colors.red}
                onPressWheelPicker={() => setLeagueModalVisible(true)}
                value={selectedOddsText}
                activeOpacity={1}
              />
            </Pressable>
          </View>
          <View style={styles.serchContainerStyle}>
            <StatisticsSearchIcon style={styles.searchIconStyle} />
            <TextInput
              style={styles.searchTextinputStyle}
              placeholder={translate("SearchBYName")}
              placeholderTextColor={Colors.borderDropDown}
              numberOfLines={1}
              value={search}
              onChangeText={(text) => {
                setSearch(text);
              }}
            />
          </View>
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalContainer}>
          <ProfileDetailist data={profileDetailList} />
        </View>

        <View style={styles.textCenter}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.sportStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
};

export default TrackProfileDetails;
export const oddsDataOption = [
  "Australian Capital Territory",
  "Win Fixed",
  "Place Fixed",
  "Place Tote",
];
