import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import { MaterialTabBar, Tabs } from "react-native-collapsible-tab-view";
import { ScrollView } from "react-native-gesture-handler";
import { SceneMap } from "react-native-tab-view";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";
import Header from "../../../../component/HeaderComponent";
import TabTrackerPicker from "../../../../component/TabTrackerPicker";
import { NAVIGATION } from "../../../../navigation";
import { Colors, Images } from "../../../../theme";
import commonStyles from "../../../../theme/commonStyle";
import { print_data } from "../../../../utils/Logs";
import TrackJoketStarts from "../TrackJocketStats";
import TrackNewsTab from "../TrackNewsTab";
import TrackRecords from "../TrackRecords";
import TrackResults from "../TrackResults";
import TrainerStats from "../TrainerStats";
import styles from "./style";

const TrackNews = (props: any) => {
  print_data("helo");
  const navigation = useNavigation();
  const [index, setIndex] = useState(0);

  const [routes] = React.useState(SPORT_ARRAY);
  const [tabVisible, setTabVisible] = useState(false);

  const first = () => <TrackNewsTab />;
  const second = () => <TrackResults />;
  const third = () => <TrackRecords />;
  const fourth = () => <TrackJoketStarts />;
  const fifth = () => <TrainerStats />;

  // const OtherRoute = () => <OtherTab />;

  const renderScene = SceneMap({
    first: first,
    second: second,
    third: third,
    fourth: fourth,
    fifth: fifth,
  });

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  // const onProfilePress = () => {
  //   navigation.navigate(NAVIGATION.PROFILE);
  // };

  const HEADER_HEIGHT = 250;

  const MINHEADER_HEIGHT = 0;

  const myHeader = () => {
    return (
      <>
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <TabTrackerPicker />
      </>
    );
  };

  const tabBar = (props) => {
    return (
      <MaterialTabBar
        {...props}
        scrollEnabled={true}
        activeColor={Colors.linearColor2}
        inactiveColor={Colors.black}
        labelStyle={styles.labelStyle}
        width={"100%"}
        tabStyle={styles.tabStyle}
        indicatorStyle={styles.indicator}
        style={styles.bottomBorder}
      />
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />

      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Tabs.Container
          renderHeader={myHeader}
          renderTabBar={tabBar}
          headerHeight={HEADER_HEIGHT} // optional
          lazy={true}
          minHeaderHeight={MINHEADER_HEIGHT}
        >
          <Tabs.Tab name="first" label="News">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrackNewsTab />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="second" label="Results">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrackResults />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="third" label="Records">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrackRecords />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="fourth" label="Jockey Stats">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrackJoketStarts />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="fifth" label="Trainer Stats">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrainerStats />
            </Tabs.ScrollView>
          </Tabs.Tab>
        </Tabs.Container>
      </ScrollView>
      {/* <TabView
        navigationState={{ index, routes }}
        onIndexChange={(index) => setIndex(index)}
        renderScene={renderScene}
        initialLayout={styles.tabViewStyle}
        renderTabBar={(props) => (
          <TabBar
            {...props}
            activeColor={Colors.linearColor2}
            inactiveColor={Colors.black}
            indicatorStyle={styles.indicatorStyle}
            style={styles.tabBarMainStyle}
            indicatorContainerStyle={styles.tabViewStyle}
            contentContainerStyle={styles.contentContainerStyle}
            tabStyle={styles.renderTabStyle}
            labelStyle={styles.labelStyle}
            getLabelText={({ route }) =>
              route.title.slice(0).toUpperCase() +
              route.title.charAt(0).slice(1)
            }
            scrollEnabled={true}
          />
        )}
      /> */}
    </AppSafeAreaView>
  );
};

export default TrackNews;

const SPORT_ARRAY = [
  { key: "first", title: "News" },
  { key: "second", title: "Results" },
  { key: "third", title: "Records" },
  { key: "fourth", title: "Jockey Stats" },
  { key: "fifth", title: "Trainer Stats" },
];
