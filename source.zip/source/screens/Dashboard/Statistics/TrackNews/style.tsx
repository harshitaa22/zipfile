import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../theme/index";

export default StyleSheet.create({
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    flex: 1,
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  tabStyle: {
    alignSelf: "center",
    justifyContent: "center",
    flexDirection: "row",
    padding: 0,
    marginRight: Metrics.rfv(10),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },

  tabViewStyle: {
    width: Metrics.rfp(180),
    height: Metrics.rfv(3),
    marginTop: Metrics.rfv(50),
    backgroundColor: Colors.linearColor2,
  },
  indicatorStyle: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "center",
    width: Metrics.rfv(120),
    height: Metrics.rfv(6),
  },

  tabBarMainStyle: {
    backgroundColor: Colors.white,
    shadowOffset: { height: Metrics.rfv(0), width: Metrics.rfv(0) },
    shadowColor: "transparent",
    shadowOpacity: Metrics.rfv(0),
    elevation: Metrics.rfv(0),
    // marginBottom: Metrics.rfv(8),
  },
  contentContainerStyle: {
    // justifyContent: "center",

    justifyContent: "space-around",
  },
  renderTabStyle: {
    elevation: Metrics.rfv(0),
    width: Metrics.rfv(180),
  },
  labelStyle: {
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
  },

  betsContainerView: {
    flexDirection: "row",
    // alignItems: "flex-start",
    alignItems: "center",
    // justifyContent: "space-around",
    justifyContent: "flex-start",
  },
  button: {
    paddingHorizontal: Metrics.rfv(35),
    alignItems: "center",
    height: Metrics.rfv(45),
    justifyContent: "center",
  },
  betsText: (tabVisible: any) => ({
    fontSize: Metrics.rfv(16),
    color: tabVisible ? Colors.linearColor2 : Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    lineHeight: Metrics.rfv(20),
    textAlign: "center",
  }),
  box: {
    height: 250,
    width: "100%",
  },
  boxA: {
    backgroundColor: "white",
  },
  boxB: {
    backgroundColor: "#D8D8D8",
  },

  viewstyle: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "flex-end",
    marginHorizontal: Metrics.rfv(15),
    width: Metrics.rfv(170),
    height: Metrics.rfv(4),
  },
  activeStyle: (tabVisible: any) => ({
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: tabVisible ? Colors.linearColor1 : Colors.white,
    alignSelf: "flex-start",
    // marginHorizontal: Metrics.rfv(15),
    width: Metrics.rfv(100),
    height: Metrics.rfv(4),
  }),
  widthStyle: {
    borderWidth: Metrics.rfv(1),
    backgroundColor: Colors.linearColor2,
    borderColor: Colors.linearColor2,
    width: "100%",
    height: Metrics.rfv(1),
  },
  bottomBorder: {
    borderBottomWidth: Metrics.rfv(3),
    borderBottomColor: Colors.linearColor2,
    elevation: 0,
  },
  indicator: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "center",
    height: Metrics.rfv(4),
    width: Metrics.rfv(100),
  },

  editUserDetails: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    textDecorationLine: "underline",
    marginBottom: Metrics.rfv(10),
  },
});
