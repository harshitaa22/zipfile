import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../theme/index";

export default StyleSheet.create({
  horizontalView: {
    marginHorizontal: Metrics.rfv(10),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  mainLoginView: {
    paddingVertical: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
  },
  headerView: {
    paddingHorizontal: Metrics.rfv(10),
    backgroundColor: Colors.white,
    paddingBottom: Metrics.rfv(10),
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.linearColor2,
  },
  ausTitle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(20),
    lineHeight: Metrics.rfv(24),
    marginTop: Metrics.rfv(18),
  },
});
