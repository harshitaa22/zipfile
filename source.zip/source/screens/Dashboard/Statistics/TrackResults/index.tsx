import React from "react";
import { ScrollView, Text, View } from "react-native";
import LatestResultList from "../../../../component/LatestResultList";
import PartnersList from "../../../../component/PartnersList";
import ResultCommonList from "../../../../component/ResultCommonList/index";
import TabCommonTitle from "../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../component/Text/index";
import commonStyles from "../../../../theme/commonStyle";
import {
  LatestResultsList,
  ResultsDetailsList,
  ResultsList,
} from "../../../../theme/dummyArray";
import { translate } from "../../../../utils/Localize";
import styles from "./style";

const TrackResults = () => {
  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.headerView}>
        <TabCommonTitle
          title={translate("ResultsTab")}
          subTitle={translate("LoremNewsCommonTitle")}
        />
      </View>
      <View style={styles.horizontalView}>
        <Text style={styles.ausTitle}>{translate("AustraliaText")}</Text>
        <View style={styles.bottomWidth} />
      </View>
      <ResultCommonList data={ResultsList} listData={ResultsDetailsList} />

      <View style={styles.horizontalView}>
        <Text style={styles.ausTitle}>{translate("LatestResults")}</Text>
        <View style={styles.bottomWidth} />
        <LatestResultList data={LatestResultsList} />
      </View>
      <View style={styles.textCenter}>
        <TextHeaderTitle
          title={translate("OurPartners")}
          textStyle={styles.sportStyle}
        />
      </View>
      <View style={styles.partnerListBottom}>
        <PartnersList />
      </View>
    </ScrollView>
  );
};

export default TrackResults;
