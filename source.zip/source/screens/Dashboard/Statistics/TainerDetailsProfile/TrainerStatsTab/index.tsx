import { useNavigation } from "@react-navigation/native";
import React from "react";
import { ScrollView, View } from "react-native";
import { MaterialTabBar, Tabs } from "react-native-collapsible-tab-view";
import AppSafeAreaView from "../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../component/CommonHeaderComponent";
import Header from "../../../../../component/HeaderComponent";
import TextHeaderTitle from "../../../../../component/Text";
import { NAVIGATION } from "../../../../../navigation";
import { Colors, Images } from "../../../../../theme";
import commonStyles from "../../../../../theme/commonStyle";
import { translate } from "../../../../../utils/Localize";
import TrainerForm from "../../TrainerStatesTab/TrainerForm";
import TrainerHorses from "../../TrainerStatesTab/TrainerHorses";
import TrainerJockeys from "../../TrainerStatesTab/TrainerJockeys";
import TrainerProfile from "../../TrainerStatesTab/TrainerProfile";
import TrainerTracks from "../../TrainerStatesTab/TrainerTracks";
import styles from "./style";

const TrainerStatsTab = (props: any) => {
  const navigation = useNavigation();
  const listTitleData = props?.route?.params?.listTitleData;

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const HEADER_HEIGHT = 250;

  const MINHEADER_HEIGHT = 0;

  const myHeader = () => {
    return (
      <>
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={listTitleData ? listTitleData : translate("JyeMcNeil")}
            textStyle={styles.textStyle}
          />
        </View>
      </>
    );
  };

  const tabBar = (props) => {
    return (
      <MaterialTabBar
        {...props}
        scrollEnabled={true}
        activeColor={Colors.linearColor2}
        inactiveColor={Colors.black}
        labelStyle={styles.labelStyle}
        width={"100%"}
        tabStyle={styles.tabStyle}
        indicatorStyle={styles.indicator}
        style={styles.bottomBorder}
      />
    );
  };
  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Tabs.Container
          renderHeader={myHeader}
          renderTabBar={tabBar}
          headerHeight={HEADER_HEIGHT} // optional
          lazy={true}
          minHeaderHeight={MINHEADER_HEIGHT}
        >
          <Tabs.Tab name="first" label="Profile">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrainerProfile />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="second" label="Form">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrainerForm listTitleData={listTitleData} />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="third" label="Tracks">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrainerTracks listTitleData={listTitleData} />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="fourth" label="Jockeys">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrainerJockeys listTitleData={listTitleData} />
            </Tabs.ScrollView>
          </Tabs.Tab>
          <Tabs.Tab name="fifth" label="Horses">
            <Tabs.ScrollView showsVerticalScrollIndicator={false}>
              <TrainerHorses />
            </Tabs.ScrollView>
          </Tabs.Tab>
        </Tabs.Container>
      </ScrollView>
    </AppSafeAreaView>
  );
};

export default TrainerStatsTab;
