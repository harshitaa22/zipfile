import React from "react";
import { ScrollView, View } from "react-native";
import styles from "./style";

import PartnersList from "../../../../component/PartnersList";
import TabCommonTitle from "../../../../component/TabCommonTitle";
import TextHeaderTitle from "../../../../component/Text/index";
import TrackNewsCommonList from "../../../../component/TrackNewsCommonList";
import commonStyles from "../../../../theme/commonStyle";
import { NewsList } from "../../../../theme/dummyArray";
import { translate } from "../../../../utils/Localize";

const TrackNewsTab = () => {
  return (
    <View style={styles.containerView}>
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <View style={styles.newsView}>
          <TabCommonTitle
            title={translate("NewsText")}
            subTitle={translate("LoremNewsCommonTitle")}
          />
        </View>
        <View style={styles.horizontalView}>
          <TrackNewsCommonList data={NewsList} />
        </View>
        <View style={styles.textCenter}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.sportStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </View>
  );
};

export default TrackNewsTab;
