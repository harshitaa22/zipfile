import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { ScrollView, TextInput, View } from "react-native";

import { callApi } from "../../../../api";
import API_CONFIG from "../../../../api/api_url";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";
import DropDownPickerComponent from "../../../../component/DropdownPicker";
import Header from "../../../../component/HeaderComponent/index";
import PartnersList from "../../../../component/PartnersList";
import ProfileDetailist from "../../../../component/ProfileDetailsList";
import Loader from "../../../../component/ProgressBar";
import TextHeaderTitle from "../../../../component/Text/index";
import { NAVIGATION } from "../../../../navigation";
import { Colors, Images } from "../../../../theme";
import commonStyles from "../../../../theme/commonStyle";
import { StatisticsSearchIcon } from "../../../../theme/svg";
import { translate } from "../../../../utils/Localize";
import { print_data } from "../../../../utils/Logs";
import { showToast } from "../../../../utils/commonFunction";
import styles from "./styles";

const TrackProfiles = () => {
  const navigation = useNavigation();
  const [isLeaugeModalVisible, setLeagueModalVisible] = useState(false);
  const [isStateModelVisible, setStateModelVisible] = useState(false);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [search, setSearch] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [stateList, setStateList] = useState([]);
  const [countryId, setCountryId] = useState("");
  const [stateId, setStateId] = useState(null);
  const [countryOffset, setCountryOffset] = useState(0);
  const [counryCount, setCountryCount] = useState(0);
  const [stateCount, setStateCount] = useState(0);
  const [stateOffset, setStateOffset] = useState(0);
  const [isLoadMore, setIsLoadMore] = useState(false);
  const [selectedTitle, setSelectedTitle] = useState("");
  const [countryOpen, setCountryOpen] = useState(false);
  const [titleOpen, setTitleOpen] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState("");
  const [isCountryBorder, setIsCountryBorder] = useState(false);
  const [selectedState, setSelectedState] = useState("");
  const [stateOpen, setStateOpen] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [isStateBorder, setIsStateBorder] = useState(false);
  const [isCountryErrorShow, setIsCountryErrorShow] = useState(false);
  const [trackListData, setTrackListData] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredData, setFilteredData] = useState([]);

  const [selectedOddsText, setSelectedOddsText] = useState(
    translate("RoundThree")
  );
  const [selectedStateText, setSelectedStateText] = useState(
    translate("State")
  );

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  useEffect(() => {
    // setIsLoaderVisible(true);
    callCountryAPi(countryOffset);
    fetchTrackList(0, 0);
  }, []);

  const handleSearch = (text) => {
    setSearchQuery(text);
    const filteredItems = trackListData.filter((item) =>
      item?.name?.toLowerCase().includes(text.toLowerCase())
    );
    setFilteredData(filteredItems);
  };

  const fetchTrackList = async (country, state) => {
    try {
      const response = await callApi(
        `statistics/getTrackList?countryId=${country ? country : ""}&stateId=${
          state ? state : ""
        }`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          print_data(response);
          setTrackListData(response?.body?.data?.result);
          setIsLoaderVisible(false);

          setRefreshing(false);
        } else {
          setIsLoaderVisible(false);
          setRefreshing(false);
        }
      } else {
        setIsLoaderVisible(false);
        setRefreshing(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setRefreshing(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      // print_data("=====exception===callRacingAPi==");
    }
  };

  const callCountryAPi = async (countryOffset) => {
    try {
      const response = await callApi(
        API_CONFIG.COUNTRY + countryOffset,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let countryAPIList = response?.body?.data?.result?.rows;
          const itemData: any = [];
          countryAPIList.map((item: any, index) => {
            itemData.push({
              label: item?.country,
              value: item?.id,
              key: index,
            });
          });
          itemData?.unshift({
            label: "All Country",
            value: 0,
          });
          print_data(response);
          const finalList = [...countryList, ...itemData];
          setCountryList(finalList);
          setCountryCount(Math.ceil(response?.body?.data?.result?.count / 20));
          setIsLoadMore(false);
          setIsLoaderVisible(false);
        } else {
          setIsLoadMore(false);
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoadMore(false);
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoadMore(false);
      setIsLoaderVisible(false);
      print_data("=====exception=====" + error);
    }
  };

  const callStateAPi = async (selectedCountry, page, type) => {
    try {
      const response = await callApi(
        API_CONFIG.STATE + `/${selectedCountry}?limit=20&offset=${page}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let stateAPIList = response?.body?.data?.result?.rows;
          let itemData = [];
          for (let i = 0; i < stateAPIList.length; i++) {
            itemData.push({
              label: stateAPIList[i].state,
              value: stateAPIList[i].id,
            });
          }

          setStateCount(Math.ceil(response?.body?.data?.result?.count / 20));

          if (type) {
            setStateList(itemData);
          } else {
            const finalList = [...stateList, ...itemData];
            setStateList(finalList);
          }

          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        {/* <LeaguePicker
          isVisible={isLeaugeModalVisible}
          showModel={setLeagueModalVisible}
          data={countryList}
          onItemSelect={(selectedData) => {
            print_data(selectedData);
            setSelectedOddsText(selectedData?.title);
            callStateAPi(selectedData?.id, 0, true);
          }}
        /> */}
        {/* <LeaguePicker
          isVisible={isStateModelVisible}
          showModel={setStateModelVisible}
          data={stateList}
          onItemSelect={(selectedData) => {
            setSelectedStateText(selectedData?.title);
          }}
        /> */}
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          showBannerIcon={true}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("TrackProfiles")}
            textStyle={styles.textStyle}
          />
        </View>
        <View style={styles.searchView}>
          <View
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <View style={{ flexDirection: "row", position: "relative" }}>
              <DropDownPickerComponent
                zIndex={3000}
                containerStyle={{
                  height: 40,
                  width: 150,
                  marginRight: 10,
                  zIndex: 1,
                }}
                placeHolder={translate("Country")}
                open={countryOpen}
                value={selectedCountry}
                scrollViewProps={{
                  nestedScrollEnabled: true,
                  showsVerticalScrollIndicator: false,
                  showsHorizontalScrollIndicator: false,
                  onMomentumScrollEnd(event) {
                    if (
                      !isLoadMore &&
                      counryCount !== Math.ceil(countryOffset / 20)
                    ) {
                      setIsLoadMore(true);
                      // setIsLoaderVisible(true);
                      callCountryAPi(countryOffset + 20);
                      setCountryOffset(countryOffset + 20);
                    }
                  },
                }}
                labelExtractor={({ country }) => country}
                valueExtractor={({ selectedCountry }) => selectedCountry}
                items={countryList}
                setOpen={(isOpen) => {
                  setCountryOpen(isOpen);
                  setStateOpen(false);
                  setTitleOpen(false);
                }}
                listMode="SCROLLVIEW"
                setValue={setSelectedCountry}
                onChangeValue={(selectedCountry) => {
                  setIsCountryBorder(false);
                  setIsCountryErrorShow(false);
                  setCountryId(selectedCountry);
                  setIsLoaderVisible(true);
                  setTimeout(() => {
                    if (selectedCountry?.toString().length > 0) {
                      setStateList([]);
                      setStateCount(0);
                      setSelectedState("");
                      callStateAPi(selectedCountry, 0, true);
                      // setStateId("");
                    }
                  }, 100);
                }}
                setItems={setCountryList}
                dropDownDirection="BOTTOM"
                style={
                  isCountryBorder
                    ? styles.dropDownStyleRed
                    : styles.dropDownStyleWhite
                }
                placeholder={translate("PlaceHolder")}
              />
              {/* <Pressable
                style={styles.oddTypeWidth}
                onPress={() => setLeagueModalVisible(true)}
              >
                <Text
                  style={styles.textModelInputStyle(
                    selectedOddsText == translate("RoundThree")
                  )}
                  numberOfLines={3}
                >
                  {selectedOddsText}
                </Text>
                {isLeaugeModalVisible ? (
                  <UpBlueArrow style={styles.dropDownArrow} />
                ) : (
                  <DownBlueArrow style={styles.dropDownArrow} />
                )}
              </Pressable> */}

              <DropDownPickerComponent
                zIndex={3000}
                open={stateOpen}
                containerStyle={{ height: 40, width: 150, zIndex: 2000 }}
                autoScroll={true}
                scrollViewProps={{
                  showsVerticalScrollIndicator: false,
                  showsHorizontalScrollIndicator: false,

                  onMomentumScrollEnd(event) {
                    if (stateCount !== Math.ceil(stateOffset / 20)) {
                      callStateAPi(countryId, stateOffset + 20, false);
                      setStateOffset(stateOffset + 20);
                    }
                  },
                }}
                value={selectedState}
                labelExtractor={({ label }) => label}
                valueExtractor={({}) => selectedState}
                items={stateList}
                setOpen={(isOpen) => {
                  setStateOpen(isOpen);
                  setCountryOpen(false);
                  setTitleOpen(false);
                }}
                dropDownContainerStyle={styles.dropDownContainerStyle}
                setValue={setSelectedState}
                onChangeValue={(selectedState) => {
                  // setIsLoaderVisible(true);

                  setStateId(selectedState);
                  setIsStateBorder(false);
                  // setIsStateErrorShow(false);
                }}
                setItems={setStateList}
                dropDownDirection="BOTTOM"
                style={
                  isStateBorder
                    ? styles.dropDownStyleRed
                    : styles.dropDownStyleWhite
                }
                placeholder={translate("PlaceHolder")}
              />
            </View>
          </View>
          {/* <View style={styles.mainPickerStyle}>
              <Pressable
                style={styles.oddTypeWidth}
                onPress={() => setStateModelVisible(true)}
              >
                <Text
                  style={styles.textModelInputStyle(
                    selectedStateText == translate("State")
                  )}
                  numberOfLines={3}
                >
                  {selectedStateText}
                </Text>
                {isStateModelVisible ? (
                  <UpBlueArrow style={styles.dropDownArrow} />
                ) : (
                  <DownBlueArrow style={styles.dropDownArrow} />
                )}
              </Pressable>
            </View> */}

          {/* <View> */}
          {/* <Pressable
                style={styles.oddTypeWidth}
                onPress={() => setStateModelVisible(true)}
              >
                <CustomTextInput
                  editable={false}
                  pointerEvents="none"
                  textInputStyle={styles.textModelInputStyle(
                    selectedStateText == translate("State")
                  )}
                  // dropDown={true}
                  numberOfLines={2}
                  racingDropDown={true}
                  dropDownStyle={styles.dropDownArrow}
                  dropDownIconStyle={styles.dropDownContainer}
                  placeholderText={""}
                  inputTextStyle={styles.inputTextStyle}
                  placeholderTextColor={Colors.red}
                  onPressWheelPicker={() => setStateModelVisible(true)}
                  value={selectedStateText}
                  activeOpacity={1}
                />
              </Pressable> */}
          {/* </View> */}

          <View style={styles.serchContainerStyle}>
            <StatisticsSearchIcon style={styles.searchIconStyle} />
            <TextInput
              style={styles.searchTextinputStyle}
              placeholder={translate("SearchBYName")}
              placeholderTextColor={Colors.borderDropDown}
              numberOfLines={1}
              onChangeText={handleSearch}
              value={searchQuery}
            />
          </View>
          {/* <TrackProfileSectionPage
            data={TrackData}
            onItemClick={(index) => {
              setSelectIndex(index);
              navigation.navigate(NAVIGATION.TRACK_NEWS);
            }}
            selectedId={isSelectIndex}
          /> */}
          {/* <TrackProfileSectionPage
            data={TrackData}
            isSelectIndex={isSelectIndex}
            onItemClick={(index) => {
              print_data("index");
              print_data(index);
              setSelectIndex(index);
              navigation.navigate(NAVIGATION.TRACK_NEWS);
            }}
          /> */}
          {/* <View style={styles.topWidth} /> */}
        </View>
        <View style={styles.height} />
        <View style={styles.horizontalContainer}>
          <ProfileDetailist
            data={filteredData.length > 0 ? filteredData : trackListData}
          />
        </View>

        <View style={styles.textCenter}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.sportStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default TrackProfiles;
export const oddsDataOption = [
  "Australia",
  "Win Fixed",
  "Place Fixed",
  "Place Tote ",
];

export const stateDataOption = [
  "Australian Capital Territory",
  "Win Fixed",
  "Place Fixed",
  "Place Tote",
];
