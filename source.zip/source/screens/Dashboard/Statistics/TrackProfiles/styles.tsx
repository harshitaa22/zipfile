import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../theme/index";

export default StyleSheet.create({
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(10),
    paddingTop: Metrics.rfv(20),
    backgroundColor: Colors.cream,
  },
  headerView: {
    paddingHorizontal: Metrics.rfv(15),
    paddingTop: Metrics.rfv(20),
    backgroundColor: Colors.cream,
    paddingBottom: Metrics.rfv(15),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textCenter: {
    alignSelf: "center",
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  serchContainerStyle: {
    height: Metrics.rfv(40),
    borderColor: Colors.drownDownBackground,
    borderWidth: Metrics.rfv(0.5),
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: Metrics.rfv(10),
    backgroundColor: Colors.white,
  },
  searchIconStyle: {
    width: Metrics.rfv(20),
    height: Metrics.rfv(20),
  },
  searchTextinputStyle: {
    flex: 1,
    marginLeft: Metrics.rfv(10),
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  topWidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.linearColor2,
    marginTop: Metrics.rfv(8),
    marginBottom: Metrics.rfv(5),
  },
  searchView: {
    paddingHorizontal: Metrics.rfv(10),
    backgroundColor: Colors.white,
    paddingTop: Metrics.rfv(10),
    marginTop: Metrics.rfv(10),
    // paddingBottom: Metrics.rfv(20),
  },
  horizontal: {
    marginHorizontal: Metrics.rfv(15),
  },
  mainPickerStyle: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    backgroundColor: "red",
    // marginHorizontal: Metrics.rfv(15),
    marginBottom: Metrics.rfv(5),
    flex: 1,
  },
  OddsTitleStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  textInputStyle: {
    width: "100%",
    padding: 0,
    color: Colors.linearColor1,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(18),
    lineHeight: Metrics.rfv(22),
  },
  inputTextStyle: {
    borderColor: Colors.gray,
    padding: 0,
    color: Colors.black,
  },
  dropDownContainer: {
    paddingLeft: Metrics.rfv(8),
  },
  dropDownArrow: {
    width: Metrics.rfv(14),
    height: Metrics.rfv(8),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(8),
  },
  horizontalContainer: {
    backgroundColor: Colors.white,
    paddingHorizontal: Metrics.rfv(10),
    paddingBottom: Metrics.rfv(10),
  },
  height: {
    height: Metrics.rfv(15),
    backgroundColor: Colors.cream,
  },
  dropDownStyleRed: {
    width: "100%",
    // backgroundColor: Colors.lightblue,
  },
  dropDownStyleWhite: {
    height: Metrics.rfv(44),
    borderColor: Colors.white,
    borderWidth: Metrics.rfv(0.6),

    marginTop: Metrics.rfv(5),
    // backgroundColor: Colors.lightblue,
    width: "100%",
    marginBottom: Metrics.rfv(5),
    padding: 0,
  },
  textModelInputStyle: (visible) => ({
    padding: 0,
    color: visible ? Colors.linearColor2 : Colors.linearColor2,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(18),
    lineHeight: Metrics.rfv(22),
  }),
  oddTypeWidth: {
    flexDirection: "row",
    alignItems: "center",
  },
  modelContainerView: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "red",
    // justifyContent: "space-around",
  },
});
