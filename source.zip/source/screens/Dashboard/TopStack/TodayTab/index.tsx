import moment from "moment";
import React, { useEffect, useState } from "react";
import {
  FlatList,
  Image,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
//component
import AddsCommonList from "../../../../component/AddsCommonApi";
import DatePickerDialog from "../../../../component/DatePicker";
import FilterList from "../../../../component/FilterList/index";
import PartnersList from "../../../../component/PartnersList/index";
import Loader from "../../../../component/ProgressBar";
import RacingSectionList from "../../../../component/RacingSectionList";
import TextHeaderTitle from "../../../../component/Text/index";
import CustomTextInput from "../../../../component/TextInput";
//theme
import { Images, Metrics } from "../../../../theme";
import Colors from "../../../../theme/colors";
import commonStyles from "../../../../theme/commonStyle";
import { FuturesEvent, PartnersData } from "../../../../theme/dummyArray";
import { DownWhiteArrow, UpWhiteArrow } from "../../../../theme/svg";
//utils
import usePrevious from "../../../../utils/customHook";
import { translate } from "../../../../utils/Localize";
import { print_data } from "../../../../utils/Logs";
//api
import { callApi } from "../../../../api";
import API_CONFIG from "../../../../api/api_url";
//style
import styles from "./style";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../../../navigation";
import EmptyViewRace from "../../../../component/EmptyView";
import FuturesRacingSectionList from "../../../../component/FutureSectionList";

let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

export default function TodayTab(props: any) {
  const racingAllData = [
    {
      id: 1,
      img: Images.racingIcon,
      title: translate("Horses"),
      isExpanded: true,
    },
    {
      id: 2,
      img: Images.whiteGreyHoundsIcon,
      title: translate("Greyhounds"),
      isExpanded: true,
    },
    {
      id: 3,
      img: Images.whiteHarnessIcon,
      title: translate("Harness"),
      isExpanded: true,
    },
  ];
  const navigation = useNavigation();
  const [isLoading, setIsLoaderVisible] = useState({});
  const [greyhoundsRaceData, setGreyhoundsRaceData] = useState({});
  const [horseRaceData, setHorseRaceData] = useState({});
  const [harnessRaceData, setHarnessRaceData] = useState({});
  const [dataUpdated, setDataUpdated] = useState(false);
  const [racingData, setRacingData] = useState(racingAllData);
  const [isShowDatePicker, showDatePicker] = useState(false);
  const [selectedRaceType, setSelectedRaceType] = useState(props.sportId);
  const [selectedCountry, setSelectedCountry] = useState(["Aus/NZ", "Intl"]);
  const [selectedDate, setSelectedDate] = useState(props.selectedDate);
  const prevSportId = usePrevious(props.sportId);
  const prevAusId = usePrevious(selectedCountry);

  useEffect(() => {
    if (JSON.stringify(props.sportId) == JSON.stringify(selectedRaceType)) {
    } else {
      if (JSON.stringify(props.sportId) != JSON.stringify(prevSportId)) {
        setSelectedRaceType(props.sportId);
      }
    }
  }, [props.sportId]);

  useEffect(() => {
    setIsLoaderVisible(true);
    callRacingAPi();
  }, [selectedRaceType, selectedCountry, selectedDate]);

  // setTimeout(() => {
  //   setIsLoaderVisible(true);
  //   callRacingAPi();
  // }, 10000);

  const onRacingPress = (item, index) => {
    if (item.isExpanded) {
      item.isExpanded = false;
    } else {
      racingData.forEach((item, _index) => {
        let obj = { ...item }; //Remember to copy Object
        if (_index === index) {
          obj.isExpanded = true;
        } else {
          obj.isExpanded = false;
        }
        racingData[_index] = obj;
      });
    }
    setDataUpdated(!dataUpdated);
    setRacingData(racingData);
  };

  const callRacingAPi = async () => {
    try {
      const response = await callApi(
        `v2/events/trackList/?todate=${selectedDate}&sportId=${selectedRaceType}&MeetingState=${selectedCountry}&countryId=""&stateId=""&timezone=${timezone}`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          const data = response?.body?.data;
          const data_pass =
            data?.events?.length > 0
              ? // Remove raceNumber === 0 and duplicate raceNumber
                data?.events?.map((obj) => {
                  return {
                    ...obj,
                    race: Array.from(
                      new Set(obj?.race.map((a) => a?.raceNumber))
                    )
                      .map((id) => {
                        return obj?.race.find((a) => a?.raceNumber === id);
                      })
                      .filter((race) => race?.raceNumber !== 0),
                  };
                })
              : [];
          const horsesraceData = data_pass.filter((item: any) => {
            return item.sportId == 1;
          });
          const harnessData = data_pass.filter((item: any) => {
            return item.sportId == 2;
          });
          const greyhoundsData = data_pass.filter((item: any) => {
            return item.sportId == 3;
          });
          const singlehorsesraceData = horsesraceData?.map((obj) => {
            let data = obj?.race;
            let a = data.map((a) => a.raceNumber) || [];
            for (var i = 1; i <= 12; i++) {
              if (a.indexOf(i) == -1) {
                let dummy_obj = { startTimeDate: null, raceNumber: i };
                data.push(dummy_obj);
              }
            }
            obj["race"] = data.sort((a, b) => {
              return a?.raceNumber - b?.raceNumber;
            });
            return { ...obj };
          });
          const singlegreyhoundsraceData = greyhoundsData?.map((obj) => {
            let data = obj?.race;
            let a = data.map((a) => a.raceNumber) || [];
            for (var i = 1; i <= 12; i++) {
              if (a.indexOf(i) == -1) {
                let dummy_obj = { startTimeDate: null, raceNumber: i };
                data.push(dummy_obj);
              }
            }
            obj["race"] = data.sort((a, b) => {
              return a?.raceNumber - b?.raceNumber;
            });
            return { ...obj };
          });
          const singleharnessraceData = harnessData?.map((obj) => {
            let data = obj?.race;
            let a = data.map((a) => a.raceNumber) || [];
            for (var i = 1; i <= 12; i++) {
              if (a.indexOf(i) == -1) {
                let dummy_obj = { startTimeDate: null, raceNumber: i };
                data.push(dummy_obj);
              }
            }
            obj["race"] = data.sort((a, b) => {
              return a?.raceNumber - b?.raceNumber;
            });
            return { ...obj };
          });
          const filteredHourseData = {
            ausData: singlehorsesraceData?.filter((item) => {
              return (
                item?.track?.Country?.id == 13 ||
                item?.track?.Country?.id == 157
              );
            }),
            intlData: singlehorsesraceData?.filter((item) => {
              return (
                item?.track?.Country?.id != 13 &&
                item?.track?.Country?.id != 157
              );
            }),
          };
          const filteredGreyhoundsData = {
            ausData: singlegreyhoundsraceData?.filter((item) => {
              return (
                item?.track?.Country?.id == 13 ||
                item?.track?.Country?.id == 157
              );
            }),
            intlData: singlegreyhoundsraceData?.filter((item) => {
              return (
                item?.track?.Country?.id != 13 &&
                item?.track?.Country?.id != 157
              );
            }),
          };
          const filteredHarnessData = {
            ausData: singleharnessraceData?.filter((item) => {
              return (
                item?.track?.Country?.id == 13 ||
                item?.track?.Country?.id == 157
              );
            }),
            intlData: singleharnessraceData?.filter((item) => {
              return (
                item?.track?.Country?.id != 13 &&
                item?.track?.Country?.id != 157
              );
            }),
          };
          setHorseRaceData(filteredHourseData);
          setGreyhoundsRaceData(filteredGreyhoundsData);
          setHarnessRaceData(filteredHarnessData);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      print_data("=====exception=====" + error);
    }
  };

  const checkForEmptyData = (item) => {
    if (item.id == 1) {
      return (
        horseRaceData?.ausData?.length > 0 ||
        horseRaceData?.intlData?.length > 0
      );
    } else if (item.id == 2) {
      return (
        greyhoundsRaceData?.ausData?.length > 0 ||
        greyhoundsRaceData?.intlData?.length > 0
      );
    } else if (item.id == 3) {
      return (
        harnessRaceData?.ausData?.length > 0 ||
        harnessRaceData?.intlData?.length > 0
      );
    }
  };

  const checkIfAusCountryData = (item) => {
    if (item.id == 1) {
      return horseRaceData?.ausData?.length > 0;
    } else if (item.id == 2) {
      return greyhoundsRaceData?.ausData?.length > 0;
    } else if (item.id == 3) {
      return harnessRaceData?.ausData?.length > 0;
    }
  };

  const checkIfIntlCountryData = (item) => {
    if (item.id == 1) {
      return horseRaceData?.intlData?.length > 0;
    } else if (item.id == 2) {
      return greyhoundsRaceData?.intlData?.length > 0;
    } else if (item.id == 3) {
      return harnessRaceData?.intlData?.length > 0;
    }
  };

  const renderRacingItem = (item, index) => {
    if (checkForEmptyData(item)) {
      return (
        <>
          {props.tabIndex == 8 ? (
            <View style={styles.listItemStyle}>
              <Pressable
                onPress={() => {
                  onRacingPress(item, index);
                }}
              >
                <LinearGradient
                  colors={[Colors.linearColor1, Colors.linearColor2]}
                  style={styles.mainLoginView}
                >
                  <View style={commonStyles.alignCenterView}>
                    <Image
                      style={styles.whiteIcon}
                      resizeMode="contain"
                      source={item?.img}
                    />
                    <Text style={styles.todayTitleTextStyle}>
                      {item?.title}
                    </Text>
                  </View>
                  {item?.isExpanded ? (
                    <UpWhiteArrow style={styles.arrowIcon} />
                  ) : (
                    <DownWhiteArrow style={styles.arrowIcon} />
                  )}
                </LinearGradient>
              </Pressable>
              {item?.isExpanded && (
                <View style={styles.horizontalContainer}>
                  {checkIfAusCountryData(item) && (
                    <>
                      <Text style={styles.racingTitle}>
                        {translate("RacingTitleOne")}
                      </Text>
                      <View style={styles.separatorStyle} />
                      {item?.id == 1 ? (
                        <>
                          <FuturesRacingSectionList listData={FuturesEvent} />
                        </>
                      ) : item?.id == 1 ? (
                        <EmptyViewRace name={translate("NoHorsesfuture")} />
                      ) : item?.id == 2 ? (
                        <EmptyViewRace name={translate("NoGreyhoundsfuture")} />
                      ) : (
                        <EmptyViewRace name={translate("NoHarnessfuture")} />
                      )}
                    </>
                  )}
                  {checkIfIntlCountryData(item) && (
                    <>
                      <Text style={styles.racingTitle}>
                        {translate("RacingTitleOneSub")}
                      </Text>
                      <View style={styles.separatorStyle} />
                      {item?.id == 1 ? (
                        <EmptyViewRace name={translate("NoHorsesfuture")} />
                      ) : item?.id == 2 ? (
                        <EmptyViewRace name={translate("NoGreyhoundsfuture")} />
                      ) : (
                        <EmptyViewRace name={translate("NoHarnessfuture")} />
                      )}
                      {/* <RacingSectionList
                        listData={
                          item.id == 1
                            ? horseRaceData?.intlData
                            : item.id === 2
                            ? greyhoundsRaceData?.intlData
                            : harnessRaceData.intlData
                        }
                        selectedDate={selectedDate}
                        isIntl={false}
                      /> */}
                    </>
                  )}
                </View>
              )}
              {index == 0 && (
                <AddsCommonList
                  AboveGreyhounds={"AboveGreyhounds"}
                  page={2}
                  placeholder={Images.sportFirstImg}
                  bannerStyle={styles.secondBannerStyle}
                />
              )}
              {index == 1 && (
                <AddsCommonList
                  AboveHarness={"AboveHarness"}
                  page={2}
                  placeholder={Images.sportFirstImg}
                  bannerStyle={styles.secondBannerStyle}
                />
              )}
            </View>
          ) : (
            <View style={styles.listItemStyle}>
              <Pressable onPress={() => onRacingPress(item, index)}>
                <LinearGradient
                  colors={[Colors.linearColor1, Colors.linearColor2]}
                  style={styles.mainLoginView}
                >
                  <View style={commonStyles.alignCenterView}>
                    <Image
                      style={styles.whiteIcon}
                      resizeMode="contain"
                      source={item?.img}
                    />
                    <Text style={styles.todayTitleTextStyle}>
                      {item?.title}
                    </Text>
                  </View>
                  {item?.isExpanded ? (
                    <UpWhiteArrow style={styles.arrowIcon} />
                  ) : (
                    <DownWhiteArrow style={styles.arrowIcon} />
                  )}
                </LinearGradient>
              </Pressable>
              {item?.isExpanded && (
                <View style={styles.horizontalContainer}>
                  {checkIfAusCountryData(item) && (
                    <>
                      <Text style={styles.racingTitle}>
                        {translate("RacingTitleOne")}
                      </Text>
                      <View style={styles.separatorStyle} />
                      <RacingSectionList
                        listData={
                          item.id === 1
                            ? horseRaceData?.ausData
                            : item.id === 2
                            ? greyhoundsRaceData?.ausData
                            : harnessRaceData?.ausData
                        }
                        selectedDate={selectedDate}
                        isIntl={false}
                      />
                    </>
                  )}
                  {checkIfIntlCountryData(item) && (
                    <>
                      <Text style={styles.racingTitle}>
                        {translate("RacingTitleOneSub")}
                      </Text>
                      <View style={styles.separatorStyle} />
                      <RacingSectionList
                        listData={
                          item.id == 1
                            ? horseRaceData?.intlData
                            : item.id === 2
                            ? greyhoundsRaceData?.intlData
                            : harnessRaceData.intlData
                        }
                        selectedDate={selectedDate}
                        isIntl={false}
                      />
                    </>
                  )}
                </View>
              )}
              {index == 0 && (
                <AddsCommonList
                  AboveGreyhounds={"AboveGreyhounds"}
                  page={2}
                  placeholder={Images.sportFirstImg}
                  bannerStyle={styles.secondBannerStyle}
                />
              )}
              {index == 1 && (
                <AddsCommonList
                  AboveHarness={"AboveHarness"}
                  page={2}
                  placeholder={Images.sportFirstImg}
                  bannerStyle={styles.secondBannerStyle}
                />
              )}
            </View>
          )}
        </>
      );
    } else {
      return null;
    }
  };

  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={commonStyles.commonFlex}>
        <View style={styles.filterContainer}>
          <FilterList
            sportId={props.sportId}
            prevSportId={prevSportId}
            prevAusId={prevAusId}
            selectedRaceType={selectedRaceType}
            onRaceTypeFilterChange={(selectedData: any) => {
              setSelectedRaceType(selectedData);
            }}
            onCountryTypeFilterChange={(selectedData: any) =>
              setSelectedCountry(selectedData)
            }
          />
        </View>
        {(props.tabIndex == 8 || props.tabIndex == 9) && (
          <CustomTextInput
            editable={false}
            textInputStyle={commonStyles.datePickerTextInputStyle}
            backgroundColor={Colors.white}
            placeholderText={translate("DatePickerPlaceHolder")}
            width={Metrics.rfp(45)}
            borderColor={Colors.validationBorder}
            inputTextStyle={commonStyles.datePickerStyle}
            placeholderTextColor={Colors.lightGrayBoxGray}
            onChangeText={(text: string) => {
              setSelectedDate(text);
            }}
            value={moment(selectedDate).format("DD/MM/YYYY")}
            datePickerVisibleBlue={true}
            datePickerPress={() => showDatePicker(true)}
            returnKeyType="next"
            placeholder={translate("DatePickerPlaceHolder")}
            activeOpacity={1}
          />
        )}
        {isLoading ? (
          <View style={styles.loader}>
            <Loader />
          </View>
        ) : (
          <>
            <AddsCommonList
              AboveHorses={"AboveHorses"}
              page={2}
              placeholder={Images.sportFirstImg}
              bannerStyle={styles.topHorseBanner}
            />
            <FlatList
              scrollEnabled={false}
              data={racingData}
              showsVerticalScrollIndicator={false}
              renderItem={({ item, index }) => renderRacingItem(item, index)}
              keyExtractor={(item, index) => index.toString()}
              ListFooterComponent={() => (
                <>
                  <View style={styles.partnersView}>
                    <View style={styles.horizontalView}>
                      {/* <FixedOffred /> */}
                      <TextHeaderTitle
                        title={translate("OurPartners")}
                        textStyle={styles.textStyle}
                      />
                    </View>
                    <View style={styles.partnerListBottom}>
                      <PartnersList />
                    </View>
                  </View>
                </>
              )}
              extraData={dataUpdated}
            />
          </>
        )}
        {(props.tabIndex == 8 || props.tabIndex == 9) && (
          <DatePickerDialog
            isVisible={isShowDatePicker}
            showModel={showDatePicker}
            tabIndex={props.tabIndex}
            onDateSelect={(selectedDate: Date) =>
              setSelectedDate(moment(selectedDate).format("YYYY-MM-DD"))
            }
          />
        )}
      </View>
    </ScrollView>
  );
}
