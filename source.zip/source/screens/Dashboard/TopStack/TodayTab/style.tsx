import { Platform, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../theme/index";

export default StyleSheet.create({
  racingTitle: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    lineHeight: Metrics.rfv(18),
    marginTop: Metrics.rfv(10),
  },
  separatorStyle: {
    height: Metrics.rfv(1),
    backgroundColor: Colors.linearColor2,
    marginTop: Metrics.rfv(5),
    marginBottom: Metrics.rfv(10),
  },
  separatorWidth: {
    height: Metrics.rfv(25),
    width: Metrics.rfv(1),
    backgroundColor: Colors.lineBreak,
    marginHorizontal: Metrics.rfv(20),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  textStyle: {
    textAlign: "center",
    marginTop: Metrics.rfv(30),
    color: Colors.black,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(10),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(20),
  },
  partnersView: {
    paddingBottom:
      Platform.OS === "android" ? Metrics.rfv(60) : Metrics.rfv(90),
  },
  contentContainerStyle: {
    marginTop: Metrics.rfv(15),
  },
  mainLoginView: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Metrics.rfv(20),
    paddingVertical: Metrics.rfv(5),
    justifyContent: "space-between",
  },
  todayTitleTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(18),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginLeft: Metrics.rfv(15),
  },
  whiteIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(30),
    tintColor: Colors.white,
  },
  arrowIcon: {
    height: Metrics.rfv(8),
    width: Metrics.rfv(15),
  },
  horizontalContainer: {
    marginHorizontal: Metrics.rfv(15),
    flex: 1,
  },
  listItemStyle: {
    width: "100%",
    backgroundColor: Colors.white,
  },
  filterContainer: {
    backgroundColor: Colors.white,
  },
  secondBannerStyle: {
    width: "100%",
    height: Metrics.rfv(63),
    resizeMode: "contain",
  },
  topHorseBanner: {
    width: "100%",
    height: Metrics.rfv(63),
    resizeMode: "contain",
  },
  loader: {
    marginTop: Metrics.rfv(15),
    alignItems: "center",
    justifyContent: "center",
  },
  commonRow: {
    width: "100%",
    flexDirection: "row",
  },
  itemViewStyle: {
    width: "100%",
  },
  itemView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  eventView: {
    flex: 1.5,
    justifyContent: "center",
    alignItems: "center",
  },
  dateText: {
    color: Colors.linearColor1,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_SemiBold,
    marginTop: Metrics.rfv(8),
  },
  eventText: {
    color: Colors.linearColor1,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_SemiBold,
    marginTop: Metrics.rfv(8),
    marginLeft: "30%",
  },
  separator: {
    width: "100%",
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.lineBreak,
    marginVertical: Metrics.rfv(5),
  },
  locationText: {
    color: Colors.black,
    fontSize: Metrics.rfv(10),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    textAlign: "center",
    textTransform: "uppercase",
  },
  emptyView: {
    width: "100%",
    height: Metrics.rfv(40),
    backgroundColor: Colors.drownDownBackground,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyText: {
    color: Colors.lineBreak,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
  },
});
