import _ from "lodash";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { callApi } from "../../../../api";
import API_CONFIG from "../../../../api/api_url";
import DatePickerModel from "../../../../component/DatePickerModel";
import PartnersList from "../../../../component/PartnersList";
import Loader from "../../../../component/ProgressBar";
import SportHeaderComponent from "../../../../component/SportHeaderComponent";
import SportsItemList from "../../../../component/SportsItemList";
import SportModel from "../../../../component/SportsModelComponent";
import TextHeaderTitle from "../../../../component/Text";
import { Colors } from "../../../../theme";
import { translate } from "../../../../utils/Localize";
import { print_data } from "../../../../utils/Logs";
import { showToast } from "../../../../utils/commonFunction";
import { SPORTS } from "../../../../utils/constant";
import styles from "./style";

export default function MatchesTab(props: any) {
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [teamOptions, setTeamOptions] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isMarketModalVisible, setIsMarketModalVisible] = useState(false);
  const [isTeamModalVisible, setIsTeamModalVisible] = useState(false);
  const [search, setSearch] = useState("");
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const [teamDataSource, setTeamDataSource] = useState([]);
  const [tournamentOptions, setTournamentOptions] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedseries, setselectedseries] = useState(0);
  const [stepperCount, setStepperCount] = useState(0);
  const [getUTCDate, setGetUTCDate] = useState(new Date());
  const [selectedTornaments, setSelectedTornaments] = useState({});
  const [selectedTeamData, setSelectedTeamData] = useState({});
  const [selectedMarkets, setSelectedMarkets] = useState({});
  const [selectedFirstMarkets, setSelectedFirstMarkets] = useState({});
  const [isShowDatePicker, showDatePicker] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(0);
  const [selectedMarketsValue, setSelectedMarketsValue] = useState(0);
  const [sportDetailsList, setSportDetailsList] = useState([]);
  const [sponsoredId, setSponsoredId] = useState([]);
  const [tournamentsHeight, setTournamentsHeight] = useState(0);
  const [marketAllData, setMarketAllData] = useState([]);
  const [marketItem, setMarketItem] = useState([]);
  const [marketOdds, setMarketOdds] = useState(0);
  const [marketData, setMarketData] = useState([]);
  const [marketList, setMarketList] = useState([]);
  const [marketAllName, setMarketAllName] = useState("");
  const [individualTeamData, setIndividualTeamData] = useState(
    props?.individualTeamdata
  );
  const [isSeeAll, setSeeAll] = useState(props?.isSeeAll);
  const [bookkeeperData, setBookKeeperData] = useState([]);
  useEffect(() => {
    fetchDropDowndata(0);
    getSeeAllData();
    fetchBookKeeper();
    getMarketAllData();
  }, []);

  useEffect(() => {
    setSearch("");
    setIsLoaderVisible(true);

    if (individualTeamData && isSeeAll) {
      fetchIndividualTeamdata();
    } else {
      getSeeAllData();
      callMarketsApi();
      fetchAllEvents(0);
    }
    callSponsoredApi();
  }, [
    props?.sportData?.title,
    // props?.sportId,
    // props?.sportItem,

    selectedseries,
    selectedDate,
    selectedTeam,
    selectedMarketsValue,
    stepperCount,
    props?.homeData,
    props?.sportData,
    individualTeamData,
  ]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchAllEvents(0);
  };

  const capitalizeFirstLetter = (string: any) => {
    if (!string) return ""; // Return empty string if the input is falsy
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  const handleStepper = (value) => {
    if (stepperCount >= 0) {
      return value === "left"
        ? stepperCount > 0
          ? setStepperCount(stepperCount - 1)
          : ""
        : setStepperCount(stepperCount + 1);
    }
  };

  function capitalizeWords(arr) {
    return arr.map((word) => {
      const firstLetter = word.charAt(0).toUpperCase();
      const rest = word.slice(1).toLowerCase();

      return firstLetter + rest;
    });
  }

  const onNextPress = () => {
    setIndividualTeamData(false);
    setSeeAll(false);
    setselectedseries(selectedTornaments?.value);
    setIsModalVisible(false);
    setSearch("");
  };
  const onPressBack = () => {
    setIsModalVisible(false);
    setSearch("");
  };

  const onTeamNextPress = () => {
    setIndividualTeamData(false);
    setSeeAll(false);
    setSelectedTeam(selectedTeamData?.value);
    setIsTeamModalVisible(false);
  };

  const onMarketNextPress = () => {
    setIndividualTeamData(false);
    setSeeAll(false);
    setSelectedMarketsValue(selectedMarkets?.value);
    setIsMarketModalVisible(false);
  };

  const onTeamBackPress = () => {
    setIsTeamModalVisible(false);
  };

  const onMarketPressBack = () => {
    setIsMarketModalVisible(false);
  };

  const onselectedPress = (item) => {
    setSelectedTornaments(item);
  };

  const onselectedTeamPress = (item) => {
    setSelectedTeamData(item);
  };

  const onMarketPress = (item) => {
    setSelectedMarkets(item);
  };

  const onLayout = (event) => {
    const { x, y, height, width } = event.nativeEvent.layout;
    setTournamentsHeight(height);
  };

  // const sportListData = () => {
  //   const neweventListData = sportDetailsList?.sort(
  //     (a, b) => new Date(a?.startTime) - new Date(b?.startTime)
  //   );
  //   return neweventListData;
  // };

  const sportListData = sportDetailsList?.sort(
    (a, b) => new Date(a?.startTime) - new Date(b?.startTime)
  );

  // const sportListData = sportDetailsList?.sort(
  //   (a, b) => new Date(a?.startTime) - new Date(b?.startTime)
  // );

  // sportDetailsList?.sort(
  //   (a, b) => new Date(a?.startTime) - new Date(b?.startTime)
  // );

  const searchFilterFunction = (text, filterTournamentData) => {
    const newData = filterTournamentData.filter(function (item) {
      const itemData = item?.label
        ? item?.label?.toUpperCase()
        : "".toUpperCase();

      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    setFilteredDataSource(newData);
  };

  const searchTeamFilter = (text, filterTournamentData) => {
    const newData = filterTournamentData.filter(function (item) {
      const itemData = item?.label
        ? item?.label?.toUpperCase()
        : "".toUpperCase();

      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    setTeamDataSource(newData);
  };

  const searchMarketFilter = (text, filterTournamentData) => {
    const newData = filterTournamentData.filter(function (item) {
      const itemData = item?.label
        ? item?.label?.toUpperCase()
        : "".toUpperCase();

      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    setMarketList(newData);
  };

  const renderItem = (item, index) => {
    return (
      <Pressable onPress={() => onselectedPress(item)} key={index}>
        <Text
          style={
            selectedTornaments?.value == item?.value
              ? styles.selectedItem
              : styles.labelText
          }
        >
          {item.label}
        </Text>
      </Pressable>
    );
  };

  const teamRenderItem = (item, index) => {
    return (
      <Pressable onPress={() => onselectedTeamPress(item)} key={index}>
        <Text
          style={
            selectedTeamData?.value == item?.value
              ? styles.selectedItem
              : styles.labelText
          }
        >
          {item?.label}
        </Text>
      </Pressable>
    );
  };

  const marketRenderItem = (item, index) => {
    return (
      <Pressable onPress={() => onMarketPress(item)} key={index}>
        <Text
          style={
            selectedMarkets?.value == item?.value
              ? styles.selectedItem
              : styles.labelText
          }
        >
          {item?.label}
        </Text>
      </Pressable>
    );
  };

  const headerSeeAllCompnent = () => {
    return (
      <>
        <SportHeaderComponent
          homeData={props?.homeData}
          sportDataTitle={
            props?.sportData?.title ? props?.sportData?.title : props?.homeData
          }
          ontournamentPress={() => {
            setIsModalVisible(true);
            setSelectedTornaments({});
          }}
          tournamentsValue={
            selectedTornaments?.label
              ? selectedTornaments?.label
              : translate("AllTournaments")
          }
          isMarketVisible={false}
          marketValue={
            selectedFirstMarkets?.label?.length > 0
              ? selectedFirstMarkets?.label
                ? selectedFirstMarkets?.label
                : translate("HeadToHead")
              : selectedMarkets?.label
          }
          onMarketPress={() => {
            setIsMarketModalVisible(true);
            setSelectedMarkets({});
            setSelectedFirstMarkets({});
          }}
          onRoundPress={() => {
            showDatePicker(true);
          }}
          handleStepper={handleStepper}
          stepperCount={stepperCount}
          teamValue={
            selectedTeamData?.label
              ? selectedTeamData?.label
              : translate("AllTeams")
          }
          onTeamPress={() => {
            setIsTeamModalVisible(true), setSelectedTeamData({});
          }}
          selectedDate={setSelectedDate}
          showModel={() => showDatePicker(true)}
          selectedDateValue={selectedDate}
        />
      </>
    );
  };

  const headerComponent = () => {
    return (
      <>
        {!isLoadervisible && (
          <>
            <SportHeaderComponent
              homeData={props?.homeData}
              sportDataTitle={
                props?.sportData?.title
                  ? props?.sportData?.title
                  : props?.homeData
              }
              ontournamentPress={() => {
                setIsModalVisible(true);
                setSelectedTornaments({});
              }}
              isMarketVisible={true}
              tournamentsValue={
                selectedTornaments?.label
                  ? selectedTornaments?.label
                  : translate("AllTournaments")
              }
              marketValue={
                selectedFirstMarkets?.label?.length > 0
                  ? selectedFirstMarkets?.label
                    ? selectedFirstMarkets?.label
                    : translate("HeadToHead")
                  : selectedMarkets?.label
                  ? selectedMarkets?.label
                  : translate("HeadToHead")
              }
              onMarketPress={() => {
                setIsMarketModalVisible(true);
                setSelectedMarkets({});
                setSelectedFirstMarkets({});
              }}
              onRoundPress={() => {
                showDatePicker(true);
              }}
              handleStepper={handleStepper}
              stepperCount={stepperCount}
              teamValue={
                selectedTeamData?.label
                  ? selectedTeamData?.label
                  : translate("AllTeams")
              }
              onTeamPress={() => {
                setIsTeamModalVisible(true), setSelectedTeamData({});
              }}
              selectedDate={setSelectedDate}
              showModel={() => showDatePicker(true)}
              selectedDateValue={selectedDate}
            />
          </>
        )}
      </>
    );
  };

  const footerComponent = () => {
    return (
      <>
        {!isLoadervisible && (
          <>
            <View style={styles.partnersView}>
              <View style={styles.textCenter}>
                <TextHeaderTitle
                  title={translate("OurPartners")}
                  textStyle={styles.textStyle}
                />
              </View>
              <View style={styles.partnerListBottom}>
                <PartnersList />
              </View>
            </View>
          </>
        )}
      </>
    );
  };

  const seeAllfooterComponent = () => {
    return (
      <View style={styles.partnersView}>
        <View style={styles.textCenter}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.textStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </View>
    );
  };

  const callSponsoredApi = async () => {
    try {
      const sportId =
        props?.sportData?.title === SPORTS.CRICKET ||
        props?.homeData === SPORTS.CRICKET
          ? 4
          : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
            props?.homeData === SPORTS.RUBGY_LEAGUE
          ? 12
          : props?.sportData?.title === SPORTS.RUBGY_UNION ||
            props?.homeData === SPORTS.RUBGY_UNION
          ? 13
          : props?.sportData?.title === SPORTS.BASKETBALL ||
            props?.homeData === SPORTS.BASKETBALL
          ? 10
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? 15
          : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
            props?.homeData === SPORTS.AUSTRALIAN_RULES
          ? 9
          : props?.sportData?.title === SPORTS.GOLF ||
            props?.homeData === SPORTS.GOLF
          ? 16
          : props?.sportData?.title === SPORTS.TENNIS ||
            props?.homeData === SPORTS.TENNIS
          ? 7
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? 11
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? 17
          : props?.sportData?.title === SPORTS.BOXING ||
            props?.homeData === SPORTS.BOXING
          ? 6
          : props?.sportData?.title === SPORTS.MMA ||
            props?.homeData === SPORTS.MMA
          ? 5
          : props?.sportData?.title === SPORTS.SOCCER ||
            props?.homeData === SPORTS.SOCCER
          ? 8
          : 14;
      const response = await callApi(
        `public/sponsor?timeZone=${timezone}&SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let sponsoredData = response?.body?.data?.result;
          let providerId = [];
          sponsoredData?.map((item) => providerId?.push(item?.bookKeepersId));
          setSponsoredId(providerId);
        } else {
          setSponsoredId([]);
        }
      }
    } catch (error) {
      setSponsoredId([]);
    }
  };

  const callMarketsApi = async () => {
    try {
      const sportName =
        props?.sportData?.title === SPORTS.CRICKET ||
        props?.homeData === SPORTS.CRICKET
          ? "crickets"
          : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
            props?.homeData === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportData?.title === SPORTS.RUBGY_UNION ||
            props?.homeData === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportData?.title === SPORTS.BASKETBALL ||
            props?.homeData === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
            props?.homeData === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportData?.title === SPORTS.GOLF ||
            props?.homeData === SPORTS.GOLF
          ? "golf"
          : props?.sportData?.title === SPORTS.TENNIS ||
            props?.homeData === SPORTS.TENNIS
          ? "tennis"
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportData?.title === SPORTS.BOXING ||
            props?.homeData === SPORTS.BOXING
          ? "boxing"
          : props?.sportData?.title === SPORTS.MMA ||
            props?.homeData === SPORTS.MMA
          ? "mma"
          : props?.sportData?.title === SPORTS.SOCCER ||
            props?.homeData === SPORTS.SOCCER
          ? "soccer"
          : "rls";
      const response = await callApi(
        `public/${sportName}/market?isTeam=true`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let marketData = response?.body?.data?.result?.rows;

          let market = [];
          let marketAllData = [];
          marketData.forEach((item) => {
            market.push(item?.displayName);
            marketAllData.push(item);
          });
          setMarketItem(marketAllData);
          setMarketAllData(market);
        } else {
          print_data("error==");
        }
      }
    } catch (error) {
      print_data("error==");
    }
  };

  const fetchUrlAllEvents = (eventPage) => {
    const utcDate = moment(getUTCDate).format("YYYY-MM-DD");
    const startDate = selectedDate === null ? utcDate : selectedDate;
    const endDate = selectedDate === null ? "" : selectedDate;
    const tournamentID = selectedseries === 0 ? "" : selectedseries;
    const teamID = selectedTeam === 0 ? "" : selectedTeam;
    const teamRound = stepperCount === 0 ? "" : stepperCount;
    const marketId = selectedMarketsValue === 0 ? 1 : selectedMarketsValue;

    if (
      props?.sportData?.title === SPORTS.CRICKET ||
      props?.homeData === SPORTS.CRICKET
    ) {
      return `public/crickets/event?startDate=${startDate}&endDate=${endDate}&CricketTournamentId=${tournamentID}&teamId=${teamID}&${eventPage}&timezone=${timezone}&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
      props?.homeData === SPORTS.RUBGY_LEAGUE
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=12&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_UNION ||
      props?.homeData === SPORTS.RUBGY_UNION
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=13&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.GOLF ||
      props?.homeData === SPORTS.GOLF
    ) {
      return `public/golf/event?startDate=${startDate}&endDate=${endDate}&GolfTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=16&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.TENNIS ||
      props?.homeData === SPORTS.TENNIS
    ) {
      return `public/tennis/event?startDate=${startDate}&endDate=${endDate}&TennisTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=7&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.BASEBALL ||
      props?.homeData === SPORTS.BASEBALL
    ) {
      return `public/baseball/event?startDate=${startDate}&endDate=${endDate}&BaseballTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=11&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.ICE_HOCKEY ||
      props?.homeData === SPORTS.ICE_HOCKEY
    ) {
      return `public/icehockey/event?startDate=${startDate}&endDate=${endDate}&IceHockeyTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=17&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.BOXING ||
      props?.homeData === SPORTS.BOXING
    ) {
      return `public/boxing/event?startDate=${startDate}&endDate=${endDate}&BoxingTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=6&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.MMA ||
      props?.homeData === SPORTS.MMA
    ) {
      return `public/mma/event?startDate=${startDate}&endDate=${endDate}&MMATournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=5&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.SOCCER ||
      props?.homeData === SPORTS.SOCCER
    ) {
      return `public/soccer/event?startDate=${startDate}&endDate=${endDate}&SoccerTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=8&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
      props?.homeData === SPORTS.AMERICAN_FOOTBALL
    ) {
      return `public/afl/event?startDate=${startDate}&endDate=${endDate}&AFLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=15&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
      props?.homeData === SPORTS.AUSTRALIAN_RULES
    ) {
      return `public/ar/event?startDate=${startDate}&endDate=${endDate}&ARTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=9&oddCheck=true&marketId=${marketId}`;
    } else if (
      props?.sportData?.title === SPORTS.BASKETBALL ||
      props?.homeData === SPORTS.BASKETBALL
    ) {
      return `public/nba/event?startDate=${startDate}&endDate=${endDate}&NBATournamentId=${tournamentID}&teamId=${teamID}&${eventPage}&timezone=${timezone}&oddCheck=true&marketId=${marketId}`;
    } else {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=14&oddCheck=true&marketId=${marketId}`;
    }
  };

  const fetchAllEvents = async (eventPage) => {
    try {
      let passApi = fetchUrlAllEvents(eventPage);
      const response = await callApi(passApi, null, API_CONFIG.GET, null);
      print_data(response);
      if (response.body != null) {
        if (response.body?.status === 200) {
          let fullData = [];
          let itemData = response?.body?.data?.result?.rows;
          let teamdata = [itemData?.[0]];
          let newData =
            teamdata?.length > 0
              ? props?.sportData?.title === SPORTS.CRICKET ||
                props?.homeData === SPORTS.CRICKET
                ? teamdata?.[0]?.CricketBetOffers
                : props?.sportData?.title === SPORTS.BASKETBALL ||
                  props?.homeData === SPORTS.BASKETBALL
                ? teamdata?.[0]?.NBABetOffers
                : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                  props?.homeData === SPORTS.AMERICAN_FOOTBALL
                ? teamdata?.[0]?.AFLBetOffers
                : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                  props?.homeData === SPORTS.AUSTRALIAN_RULES
                ? teamdata?.[0]?.ARBetOffers
                : props?.sportData?.title === SPORTS.TENNIS ||
                  props?.homeData === SPORTS.TENNIS
                ? teamdata?.[0]?.TennisBetOffers
                : props?.sportData?.title === SPORTS.BASEBALL ||
                  props?.homeData === SPORTS.BASEBALL
                ? teamdata?.[0]?.BaseballBetOffers
                : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                  props?.homeData === SPORTS.ICE_HOCKEY
                ? teamdata?.[0]?.IceHockeyBetOffers
                : props?.sportData?.title === SPORTS.BOXING ||
                  props?.homeData === SPORTS.BOXING
                ? teamdata?.[0]?.BoxingBetOffers
                : props?.sportData?.title === SPORTS.MMA ||
                  props?.homeData === SPORTS.MMA
                ? teamdata?.[0]?.MMABetOffers
                : props?.sportData?.title === SPORTS.SOCCER ||
                  props?.homeData === SPORTS.SOCCER
                ? teamdata?.[0]?.SoccerBetOffers
                : teamdata?.[0]?.RLBetOffers
              : [];

          let SportMarket =
            props?.sportData?.title === SPORTS.CRICKET ||
            props?.homeData === SPORTS.CRICKET
              ? newData?.[0]?.CricketMarket?.name
              : props?.sportData?.title === SPORTS.BASKETBALL ||
                props?.homeData === SPORTS.BASKETBALL
              ? newData?.[0]?.NBAMarket?.name
              : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                props?.homeData === SPORTS.AMERICAN_FOOTBALL
              ? newData?.[0]?.AFLMarket?.name
              : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                props?.homeData === SPORTS.AUSTRALIAN_RULES
              ? newData?.[0]?.ARMarket?.name
              : props?.sportData?.title === SPORTS.TENNIS ||
                props?.homeData === SPORTS.TENNIS
              ? newData?.[0]?.TennisMarket?.name
              : props?.sportData?.title === SPORTS.BASEBALL ||
                props?.homeData === SPORTS.BASEBALL
              ? newData?.[0]?.BaseballMarket?.name
              : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                props?.homeData === SPORTS.ICE_HOCKEY
              ? newData?.[0]?.IceHockeyMarket?.name
              : props?.sportData?.title === SPORTS.BOXING ||
                props?.homeData === SPORTS.BOXING
              ? newData?.[0]?.BoxingMarket?.name
              : props?.sportData?.title === SPORTS.MMA ||
                props?.homeData === SPORTS.MMA
              ? newData?.[0]?.MMAMarket?.name
              : props?.sportData?.title === SPORTS.SOCCER ||
                props?.homeData === SPORTS.SOCCER
              ? newData?.[0]?.SoccerMarket?.name
              : newData?.[0]?.RLMarket?.name;
          setMarketAllName(SportMarket);
          // let tournaments = [];
          // itemData?.map((item) => {
          //   props?.sportData?.title === SPORTS.CRICKET  ||
          //   props?.homeData === SPORTS.CRICKET
          //     ? tournaments.push({
          //         label: item?.CricketTournament?.name,
          //         value: item?.CricketTournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.BASKETBALL ||
          //       props?.homeData === SPORTS.BASKETBALL
          //     ? tournaments.push({
          //         label:
          //           item?.NBATournament?.name +
          //           " " +
          //           item?.NBATournament?.NBACategory?.name,
          //         value: item?.NBATournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
          //       props?.homeData === SPORTS.AMERICAN_FOOTBALL
          //     ? tournaments.push({
          //         label: item?.AFLTournament?.name,
          //         value: item?.AFLTournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
          //       props?.homeData === SPORTS.AUSTRALIAN_RULES
          //     ? tournaments.push({
          //         label: item?.ARTournament?.name,
          //         value: item?.ARTournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.BASEBALL ||
          //       props?.homeData === SPORTS.BASEBALL
          //     ? tournaments.push({
          //         label: item?.BaseballTournament?.name,
          //         value: item?.BaseballTournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
          //       props?.homeData === SPORTS.ICE_HOCKEY
          //     ? tournaments.push({
          //         label: item?.IceHockeyTournament?.name,
          //         value: item?.IceHockeyTournament?.id,
          //       })
          //     : props?.sportData?.title ===SPORTS.TENNIS ||
          //       props?.homeData === SPORTS.TENNIS
          //     ? tournaments.push({
          //         label: item?.TennisTournament?.name,
          //         value: item?.TennisTournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.BOXING ||
          //       props?.homeData === SPORTS.BOXING
          //     ? tournaments.push({
          //         label: item?.BoxingTournament?.name,
          //         value: item?.BoxingTournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.MMA ||
          //       props?.homeData === SPORTS.MMA
          //     ? tournaments.push({
          //         label: item?.MMATournament?.name,
          //         value: item?.MMATournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.SOCCER ||
          //       props?.homeData === SPORTS.SOCCER
          //     ? tournaments.push({
          //         label: item?.SoccerTournament?.name,
          //         value: item?.SoccerTournament?.id,
          //       })
          //     : tournaments.push({
          //         label: item?.RLTournament?.name,
          //         value: item?.RLTournament?.id,
          //       });
          // });

          // let filterTournamentData = _.uniqBy(tournaments, function (e) {
          //   return e.value;
          // })
          //   ?.filter((a) => a?.value !== undefined)
          //   .sort((a, b) => {
          //     return a?.label.localeCompare(b?.label);
          //   });
          // filterTournamentData?.unshift({
          //   label: "All Tournaments",
          //   value: 0,
          // });

          // setTournamentOptions(filterTournamentData);

          // setFilteredDataSource(filterTournamentData);

          // if (search.length > 0) {
          //   searchFilterFunction(search, filterTournamentData);
          // }

          let teams = [];
          itemData?.map((item) => {
            teams.push({
              label: item?.homeTeam?.name,
              value: item?.homeTeam?.id,
            });
            teams.push({
              label: item?.awayTeam?.name,
              value: item?.awayTeam?.id,
            });
          });
          let filterTeamData = _.uniqBy(teams, function (e) {
            return e.value;
          })
            ?.filter((a) => a?.value !== undefined)
            ?.sort((a, b) => {
              return a?.label.localeCompare(b?.label);
            });
          filterTeamData?.unshift({
            label: "All Teams",
            value: 0,
          });

          setTeamOptions(filterTeamData);
          setTeamDataSource(filterTeamData);
          if (search.length > 0) {
            searchTeamFilter(search, filterTeamData);
          }

          itemData.map(async (item) => {
            let passApi =
              props?.sportData?.title === SPORTS.CRICKET ||
              props?.homeData === SPORTS.CRICKET
                ? `public/crickets/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
                  props?.homeData === SPORTS.RUBGY_LEAGUE
                ? `public/rls/event/odd/${item?.id}?SportId=12`
                : props?.sportData?.title === SPORTS.RUBGY_UNION ||
                  props?.homeData === SPORTS.RUBGY_UNION
                ? `public/rls/event/odd/${item?.id}?SportId=13`
                : props?.sportData?.title === SPORTS.BASKETBALL ||
                  props?.homeData === SPORTS.BASKETBALL
                ? `public/nba/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                  props?.homeData === SPORTS.AMERICAN_FOOTBALL
                ? `public/afl/event/odd/${item?.id}?SportId=15`
                : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                  props?.homeData === SPORTS.AUSTRALIAN_RULES
                ? `public/ar/event/odd/${item?.id}?SportId=9`
                : props?.sportData?.title === SPORTS.GOLF ||
                  props?.homeData === SPORTS.GOLF
                ? `public/golf/event/odd/${item?.id}?SportId=16`
                : props?.sportData?.title === SPORTS.TENNIS ||
                  props?.homeData === SPORTS.TENNIS
                ? `public/tennis/event/odd/${item?.id}?SportId=7`
                : props?.sportData?.title === SPORTS.BASEBALL ||
                  props?.homeData === SPORTS.BASEBALL
                ? `public/baseball/event/odd/${item?.id}?SportId=11`
                : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                  props?.homeData === SPORTS.ICE_HOCKEY
                ? `public/iceHockey/event/odd/${item?.id}?SportId=17`
                : props?.sportData?.title === SPORTS.BOXING ||
                  props?.homeData === SPORTS.BOXING
                ? `public/boxing/event/odd/${item?.id}?SportId=6`
                : props?.sportData?.title === SPORTS.MMA ||
                  props?.homeData === SPORTS.MMA
                ? `public/mma/event/odd/${item?.id}?SportId=5`
                : props?.sportData?.title === SPORTS.SOCCER ||
                  props?.homeData === SPORTS.SOCCER
                ? `public/soccer/event/odd/${item?.id}?SportId=8`
                : `public/rls/event/odd/${item?.id}?SportId=14`;

            const response1 = await callApi(
              passApi,
              null,
              API_CONFIG.GET,
              null
            );

            if (response1?.body != null) {
              if (response1?.body?.status === 200) {
                let sportData = response1?.body?.data?.result;
                let newData =
                  sportData?.length > 0
                    ? props?.sportData?.title === SPORTS.CRICKET ||
                      props?.homeData === SPORTS.CRICKET
                      ? sportData?.[0]?.CricketOdds
                      : props?.sportData?.title === SPORTS.BASKETBALL ||
                        props?.homeData === SPORTS.BASKETBALL
                      ? sportData?.[0]?.NBAOdds
                      : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                        props?.homeData === SPORTS.AMERICAN_FOOTBALL
                      ? sportData?.[0]?.AFLOdds
                      : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                        props?.homeData === SPORTS.AUSTRALIAN_RULES
                      ? sportData?.[0]?.AROdds
                      : props?.sportData?.title === SPORTS.BASEBALL ||
                        props?.homeData === SPORTS.BASEBALL
                      ? sportData?.[0]?.BaseballOdds
                      : props?.sportData?.title === SPORTS.TENNIS ||
                        props?.homeData === SPORTS.TENNIS
                      ? sportData?.[0]?.TennisOdds
                      : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                        props?.homeData === SPORTS.ICE_HOCKEY
                      ? sportData?.[0]?.IceHockeyOdds
                      : props?.sportData?.title === SPORTS.BOXING ||
                        props?.homeData === SPORTS.BOXING
                      ? sportData?.[0]?.BoxingOdds
                      : props?.sportData?.title === SPORTS.MMA ||
                        props?.homeData === SPORTS.MMA
                      ? sportData?.[0]?.MMAOdds
                      : props?.sportData?.title === SPORTS.SOCCER ||
                        props?.homeData === SPORTS.SOCCER
                      ? sportData?.[0]?.SoccerOdds
                      : sportData?.[0]?.RLOdds
                    : [];

                item.MarketNumber = response1?.body?.data?.result?.length;
                item.homeTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((homeTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? homeTeam?.CricketTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? homeTeam?.NBATeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? homeTeam?.AFLTeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? homeTeam?.ARTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? homeTeam?.BaseballTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? homeTeam?.IceHockeyTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? homeTeam?.TennisTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? homeTeam?.BoxingTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? homeTeam?.MMATeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? homeTeam?.SoccerTeamId == item?.homeTeamId
                          : homeTeam?.RLTeamId == item?.homeTeamId;
                      })
                    : "";
                item.awayTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((awayTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? awayTeam?.CricketTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? awayTeam?.NBATeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? awayTeam?.AFLTeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? awayTeam?.ARTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? awayTeam?.BaseballTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? awayTeam?.TennisTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? awayTeam?.IceHockeyTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? awayTeam?.BoxingTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? awayTeam?.MMATeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? awayTeam?.SoccerTeamId == item?.awayTeamId
                          : awayTeam?.RLTeamId == item?.awayTeamId;
                      })
                    : "";
              }
            }

            fullData.push(item);
          });

          // setSportDetailsList(fullData);
          setSportDetailsList(itemData);

          setRefreshing(false);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          setRefreshing(false);
        }
      } else {
        setIsLoaderVisible(false);
        setRefreshing(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setRefreshing(false);
    }
  };

  const getSeeAllData = async () => {
    try {
      let sportName =
        props?.sportData?.title === SPORTS.CRICKET ||
        props?.homeData === SPORTS.CRICKET
          ? "crickets"
          : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
            props?.homeData === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportData?.title === SPORTS.RUBGY_UNION ||
            props?.homeData === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportData?.title === SPORTS.BASKETBALL ||
            props?.homeData === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
            props?.homeData === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportData?.title === SPORTS.TENNIS ||
            props?.homeData === SPORTS.TENNIS
          ? "tennis"
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportData?.title === SPORTS.BOXING ||
            props?.homeData === SPORTS.BOXING
          ? "boxing"
          : props?.sportData?.title === SPORTS.MMA ||
            props?.homeData === SPORTS.MMA
          ? "mma"
          : props?.sportData?.title === SPORTS.SOCCER ||
            props?.homeData === SPORTS.SOCCER
          ? "soccer"
          : "rls";
      const response = await callApi(
        `public/${sportName}/market?isTeam=true`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let data = response.body?.data?.result;

          let newdata = [];
          let dropdownData = data?.rows?.map((item) => {
            newdata.push({
              label: capitalizeFirstLetter(item?.displayName),
              value: item?.id,
            });
          });
          setMarketList(newdata);

          if (search.length > 0) {
            searchMarketFilter(search, newdata);
          }
          setIsLoaderVisible(false);
        }
      }
    } catch (error) {
      print_data("error======");
    }
  };

  // const getSeeAllData = async (oddsId, id) => {
  //   try {
  //     let sportName =
  //       props?.sportId == "Cricket"
  //         ? "crickets"
  //         : props?.sportId == "Rugby League"
  //         ? "rls"
  //         : props?.sportId == "Rugby Union"
  //         ? "rls"
  //         : props?.sportId == "Basketball"
  //         ? "nba"
  //         : props?.sportId == "American Football"
  //         ? "afl"
  //         : props?.sportId == "Australian Rules"
  //         ? "ar"
  //         : props?.sportId == "Tennis"
  //         ? "tennis"
  //         : props?.sportId == "Baseball"
  //         ? "baseball"
  //         : props?.sportId == "Ice Hockey"
  //         ? "icehockey"
  //         : props?.sportId == "Boxing"
  //         ? "boxing"
  //         : props?.sportId == "Mixed Martial Arts"
  //         ? "mma"
  //         : props?.sportId == "Soccer"
  //         ? "soccer"
  //         : "rls";
  //     const response = await callApi(
  //       `public/${sportName}/event/${oddsId}?marketId=${id}`,
  //       null,
  //       API_CONFIG.GET,
  //       null
  //     );
  //     if (response.body != null) {
  //       if (response.body?.status === 200) {
  //         let data = response.body?.data?.result;
  //         setTeamsData([data]);

  //         let teamdata = [data];
  //         let newData =
  //           teamdata?.length > 0
  //             ? props?.sportId == "Cricket"
  //               ? teamdata?.[0]?.CricketBetOffers
  //               : props?.sportId == "Basketball"
  //               ? teamdata?.[0]?.NBABetOffers
  //               : props?.sportId == "American Football"
  //               ? teamdata?.[0]?.AFLBetOffers
  //               : props?.sportId == "Australian Rules"
  //               ? teamdata?.[0]?.ARBetOffers
  //               : props?.sportId == "Tennis"
  //               ? teamdata?.[0]?.TennisBetOffers
  //               : props?.sportId == "Baseball"
  //               ? teamdata?.[0]?.BaseballBetOffers
  //               : props?.sportId == "Ice Hockey"
  //               ? teamdata?.[0]?.IceHockeyBetOffers
  //               : props?.sportId == "Boxing"
  //               ? teamdata?.[0]?.BoxingBetOffers
  //               : props?.sportId == "Mixed Martial Arts"
  //               ? teamdata?.[0]?.MMABetOffers
  //               : props?.sportId == "Soccer"
  //               ? teamdata?.[0]?.SoccerBetOffers
  //               : teamdata?.[0]?.RLBetOffers
  //             : [];

  //         let sportsOdds =
  //           props?.sportId == "Cricket"
  //             ? newData?.[0]?.CricketOdds
  //             : props?.sportId == "Basketball"
  //             ? newData?.[0]?.NBAOdds
  //             : props?.sportId == "American Football"
  //             ? newData?.[0]?.AFLOdds
  //             : props?.sportId == "Australian Rules"
  //             ? newData?.[0]?.AROdds
  //             : props?.sportId == "Tennis"
  //             ? newData?.[0]?.TennisOdds
  //             : props?.sportId == "Baseball"
  //             ? newData?.[0]?.BaseballOdds
  //             : props?.sportId == "Ice Hockey"
  //             ? newData?.[0]?.IceHockeyOdds
  //             : props?.sportId == "Boxing"
  //             ? newData?.[0]?.BoxingOdds
  //             : props?.sportId == "Mixed Martial Arts"
  //             ? newData?.[0]?.MMAOdds
  //             : props?.sportId == "Soccer"
  //             ? newData?.[0]?.SoccerOdds
  //             : newData?.[0]?.RLOdds;

  //         let sportMarket =
  //           props?.sportId == "Cricket"
  //             ? newData?.[0]?.CricketMarket?.name
  //             : props?.sportId == "Basketball"
  //             ? newData?.[0]?.NBAMarket?.name
  //             : props?.sportId == "American Football"
  //             ? newData?.[0]?.AFLMarket?.name
  //             : props?.sportId == "Australian Rules"
  //             ? newData?.[0]?.ARMarket?.name
  //             : props?.sportId == "Tennis"
  //             ? newData?.[0]?.TennisMarket?.name
  //             : props?.sportId == "Baseball"
  //             ? newData?.[0]?.BaseballMarket?.name
  //             : props?.sportId == "Ice Hockey"
  //             ? newData?.[0]?.IceHockeyMarket?.name
  //             : props?.sportId == "Boxing"
  //             ? newData?.[0]?.BoxingMarket?.name
  //             : props?.sportId == "Mixed Martial Arts"
  //             ? newData?.[0]?.MMAMarket?.name
  //             : props?.sportId == "Soccer"
  //             ? newData?.[0]?.SoccerMarket?.name
  //             : newData?.[0]?.RLMarket?.name;

  //         setMarketName(sportMarket);
  //         let bookkeeper = [];
  //         let BookkeeperList = sportsOdds?.map((element) => {
  //           return bookkeeper?.push(element?.BookKeeperId);
  //         });
  //         fetchTableHeading([...new Set(bookkeeper)]);
  //         setSelectedOddsText(
  //           data?.CricketBetOffers
  //             ? data?.CricketBetOffers[0]?.CricketMarket?.displayName
  //             : data?.NBABetOffers
  //             ? data?.NBABetOffers[0]?.NBAMarket?.displayName
  //             : data?.AFLBetOffers
  //             ? data?.AFLBetOffers[0]?.AFLMarket?.displayName
  //             : data?.ARBetOffers
  //             ? data?.ARBetOffers[0]?.ARMarket?.displayName
  //             : data?.TennisBetOffers
  //             ? data?.TennisBetOffers[0]?.TennisMarket?.displayName
  //             : data?.BaseballBetOffers
  //             ? data?.BaseballBetOffers[0]?.BaseballMarket?.displayName
  //             : data?.IceHockeyBetOffers
  //             ? data?.IceHockeyBetOffers[0]?.IceHockeyMarket?.displayName
  //             : data?.BoxingBetOffers
  //             ? data?.BoxingBetOffers[0]?.BoxingMarket?.displayName
  //             : data?.MMABetOffers
  //             ? data?.MMABetOffers[0]?.MMAMarket?.displayName
  //             : data?.SoccerBetOffers
  //             ? data?.SoccerBetOffers[0]?.SoccerMarket?.displayName
  //             : data?.RLMarket?.displayName
  //         );

  //         setIsLoadMoreVisible(false);
  //       }
  //     }
  //   } catch (error) {
  //     print_data("error======");
  //   }
  // };

  const getMarketAllData = async () => {
    try {
      let sportName =
        props?.sportData?.title === SPORTS.CRICKET ||
        props?.homeData === SPORTS.CRICKET
          ? "crickets"
          : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
            props?.homeData === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportData?.title === SPORTS.RUBGY_UNION ||
            props?.homeData === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportData?.title === SPORTS.BASKETBALL ||
            props?.homeData === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
            props?.homeData === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportData?.title === SPORTS.TENNIS ||
            props?.homeData === SPORTS.TENNIS
          ? "tennis"
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportData?.title === SPORTS.BOXING ||
            props?.homeData === SPORTS.BOXING
          ? "boxing"
          : props?.sportData?.title === SPORTS.MMA ||
            props?.homeData === SPORTS.MMA
          ? "mma"
          : props?.sportData?.title === SPORTS.SOCCER ||
            props?.homeData === SPORTS.SOCCER
          ? "soccer"
          : "rls";
      const response = await callApi(
        `public/${sportName}/market?isTeam=true`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let data = response.body?.data?.result;

          let newdata = [];
          let dropdownData = data?.rows?.map((item) => {
            newdata.push({
              label: capitalizeFirstLetter(item?.displayName),
              value: item?.id,
            });
          });
          setSelectedFirstMarkets(newdata[0]);
          setIsLoaderVisible(false);
        }
      }
    } catch (error) {
      print_data("error======");
    }
  };

  const fetchURLData = (eventPage) => {
    const utcDate = moment(getUTCDate).format("YYYY-MM-DD");
    const startDate = selectedDate === null ? utcDate : selectedDate;
    const endDate = selectedDate === null ? "" : selectedDate;
    if (
      props?.sportData?.title === SPORTS.CRICKET ||
      props?.homeData === SPORTS.CRICKET
    ) {
      return `public/crickets/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
      props?.homeData === SPORTS.RUBGY_LEAGUE
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=12&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_UNION ||
      props?.homeData === SPORTS.RUBGY_UNION
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=13&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
      props?.homeData === SPORTS.AMERICAN_FOOTBALL
    ) {
      return `public/afl/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=15&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
      props?.homeData === SPORTS.AUSTRALIAN_RULES
    ) {
      return `public/ar/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=9&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.BASKETBALL ||
      props?.homeData === SPORTS.BASKETBALL
    ) {
      return `public/nba/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.GOLF ||
      props?.homeData === SPORTS.GOLF
    ) {
      return `public/golf/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=16&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.TENNIS ||
      props?.homeData === SPORTS.TENNIS
    ) {
      return `public/tennis/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=7&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.BASEBALL ||
      props?.homeData === SPORTS.BASEBALL
    ) {
      return `public/baseball/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=11&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.ICE_HOCKEY ||
      props?.homeData === SPORTS.ICE_HOCKEY
    ) {
      return `public/icehockey/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=17&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.BOXING ||
      props?.homeData === SPORTS.BOXING
    ) {
      return `public/boxing/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=6&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.MMA ||
      props?.homeData === SPORTS.MMA
    ) {
      return `public/mma/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=5&oddCheck=true&marketId=1&isOuright=`;
    } else if (
      props?.sportData?.title === SPORTS.SOCCER ||
      props?.homeData === SPORTS.SOCCER
    ) {
      return `public/soccer/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=8&oddCheck=true&marketId=1&isOuright=`;
    } else {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=14&oddCheck=true&marketId=1&isOuright=`;
    }
  };

  const fetchDropDowndata = async (eventPage) => {
    try {
      let passApi = fetchURLData(eventPage);
      const response = await callApi(passApi, null, API_CONFIG.GET, null);
      if (response.body != null) {
        if (response.body?.status === 200) {
          let fullData = [];
          let itemData = response?.body?.data?.result?.rows;

          let tournaments = [];
          itemData?.map((item) => {
            props?.sportData?.title === SPORTS.CRICKET ||
            props?.homeData === SPORTS.CRICKET
              ? tournaments.push({
                  label: item?.CricketTournament?.name,
                  value: item?.CricketTournament?.id,
                })
              : props?.sportData?.title === SPORTS.BASKETBALL ||
                props?.homeData === SPORTS.BASKETBALL
              ? tournaments.push({
                  label:
                    item?.NBATournament?.name +
                    " " +
                    item?.NBATournament?.NBACategory?.name,
                  value: item?.NBATournament?.id,
                })
              : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                props?.homeData === SPORTS.AMERICAN_FOOTBALL
              ? tournaments.push({
                  label: item?.AFLTournament?.name,
                  value: item?.AFLTournament?.id,
                })
              : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                props?.homeData === SPORTS.AUSTRALIAN_RULES
              ? tournaments.push({
                  label: item?.ARTournament?.name,
                  value: item?.ARTournament?.id,
                })
              : props?.sportData?.title === SPORTS.BASEBALL ||
                props?.homeData === SPORTS.BASEBALL
              ? tournaments.push({
                  label: item?.BaseballTournament?.name,
                  value: item?.BaseballTournament?.id,
                })
              : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                props?.homeData === SPORTS.ICE_HOCKEY
              ? tournaments.push({
                  label: item?.IceHockeyTournament?.name,
                  value: item?.IceHockeyTournament?.id,
                })
              : props?.sportData?.title === SPORTS.TENNIS ||
                props?.homeData === SPORTS.TENNIS
              ? tournaments.push({
                  label: item?.TennisTournament?.name,
                  value: item?.TennisTournament?.id,
                })
              : props?.sportData?.title === SPORTS.BOXING ||
                props?.homeData === SPORTS.BOXING
              ? tournaments.push({
                  label: item?.BoxingTournament?.name,
                  value: item?.BoxingTournament?.id,
                })
              : props?.sportData?.title === SPORTS.MMA ||
                props?.homeData === SPORTS.MMA
              ? tournaments.push({
                  label: item?.MMATournament?.name,
                  value: item?.MMATournament?.id,
                })
              : props?.sportData?.title === SPORTS.SOCCER ||
                props?.homeData === SPORTS.SOCCER
              ? tournaments.push({
                  label: item?.SoccerTournament?.name,
                  value: item?.SoccerTournament?.id,
                })
              : tournaments.push({
                  label: item?.RLTournament?.name,
                  value: item?.RLTournament?.id,
                });
          });

          let filterTournamentData = _.uniqBy(tournaments, function (e) {
            return e.value;
          })
            ?.filter((a) => a?.value !== undefined)
            .sort((a, b) => {
              return a?.label.localeCompare(b?.label);
            });
          filterTournamentData?.unshift({
            label: "All Tournaments",
            value: 0,
          });

          // setTournamentOptions(
          //   _.uniqBy(
          //     [...tournamentOptions, ...filterTournamentData],
          //     function (e) {
          //       return e?.value;
          //     }
          //   )
          // );

          // setFilteredDataSource(
          //   _.uniqBy(
          //     [...tournamentOptions, ...filterTournamentData],
          //     function (e) {
          //       return e?.value;
          //     }
          //   )
          // );

          setTournamentOptions(filterTournamentData);

          setFilteredDataSource(filterTournamentData);

          if (search.length > 0) {
            searchFilterFunction(search, filterTournamentData);
          }

          let teams = [];
          itemData?.map((item) => {
            if (!item?.outrights) {
              teams.push({
                label: item?.homeTeam?.name,
                value: item?.homeTeam?.id,
              });
              teams.push({
                label: item?.awayTeam?.name,
                value: item?.awayTeam?.id,
              });
            } else {
              let outRightTeams =
                props?.sportData?.title === "Cricket" ||
                props?.homeData == "Cricket"
                  ? item?.CricketOutRightTeams
                  : props?.sportData?.title === "Basketball" ||
                    props?.homeData == "Basketball"
                  ? item?.NBAOutRightTeams
                  : props?.sportData?.title === "American Football" ||
                    props?.homeData == "American Football"
                  ? item?.AFLOutRightTeams
                  : props?.sportData?.title === "Australian Rules" ||
                    props?.homeData == "Australian Rules"
                  ? item?.AROutRightTeams
                  : props?.sportData?.title === "Baseball" ||
                    props?.homeData == "Baseball"
                  ? item?.BaseballOutRightTeams
                  : props?.sportData?.title === "Ice Hockey" ||
                    props?.homeData == "Ice Hockey"
                  ? item?.IceHockeyOutRightTeams
                  : props?.sportData?.title === "Tennis" ||
                    props?.homeData == "Tennis"
                  ? item?.TennisOutRightTeams
                  : props?.sportData?.title === "Boxing" ||
                    props?.homeData == "Boxing"
                  ? item?.BoxingOutRightTeams
                  : props?.sportData?.title === "Mixed Martial Arts" ||
                    props?.homeData == "Mixed Martial Arts"
                  ? item?.MMAOutRightTeams
                  : props?.sportData?.title === "Soccer" ||
                    props?.homeData == "Soccer"
                  ? item?.SoccerOutRightTeams
                  : item?.RLOutRightTeams;
              let outRightTeamKey =
                props?.sportData?.title === "Cricket" ||
                props?.homeData == "Cricket"
                  ? "CricketTeam"
                  : props?.sportData?.title === "Basketball" ||
                    props?.homeData == "Basketball"
                  ? "NBATeam"
                  : props?.sportData?.title === "American Football" ||
                    props?.homeData == "American Football"
                  ? "AFLTeam"
                  : props?.sportData?.title === "Australian Rules" ||
                    props?.homeData == "Australian Rules"
                  ? "ARTeam"
                  : props?.sportData?.title === "Tennis" ||
                    props?.homeData == "Tennis"
                  ? "TennisTeam"
                  : props?.sportData?.title === "Baseball" ||
                    props?.homeData == "Baseball"
                  ? "BaseballTeam"
                  : props?.sportData?.title === "Ice Hockey" ||
                    props?.homeData == "Ice Hockey"
                  ? "IceHockeyTeam"
                  : props?.sportData?.title === "Boxing" ||
                    props?.homeData == "Boxing"
                  ? "BoxingTeam"
                  : props?.sportData?.title === "Mixed Martial Arts" ||
                    props?.homeData == "Mixed Martial Arts"
                  ? "MMATeam"
                  : props?.sportData?.title === "Soccer" ||
                    props?.homeData == "Soccer"
                  ? "SoccerTeam"
                  : "RLTeam";
              let TeamData = outRightTeams?.map((item) => {
                teams.push({
                  label: item?.[outRightTeamKey]?.name,
                  value: item?.[outRightTeamKey]?.id,
                });
              });
            }
          });
          let filterTeamData = _.uniqBy(teams, function (e) {
            return e.value;
          })
            ?.filter((a) => a?.value !== undefined)
            ?.sort((a, b) => {
              return a?.label.localeCompare(b?.label);
            });
          filterTeamData?.unshift({
            label: "All Teams",
            value: 0,
          });

          // setTeamOptions(
          //   _.uniqBy([...teamOptions, ...filterTeamData], function (e) {
          //     return e?.value;
          //   })
          // );
          // setTeamDataSource(
          //   _.uniqBy([...teamOptions, ...filterTeamData], function (e) {
          //     return e?.value;
          //   })
          // );

          setTeamOptions(filterTeamData);
          setTeamDataSource(filterTeamData);
          if (search.length > 0) {
            searchTeamFilter(search, filterTeamData);
          }
        } else {
          if (response?.body?.data?.success == false) {
          }
        }
      } else {
      }
    } catch (error) {}
  };

  const fetchBookKeeper = async () => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setBookKeeperData(response?.body?.data?.result);
        }
      }
    } catch (error) {}
  };

  const fetchIndividualTeamdata = async () => {
    try {
      const passApi =
        props?.sportData?.title === SPORTS.CRICKET ||
        props?.homeData === SPORTS.CRICKET
          ? `public/crickets/event/${props?.sportItem?.id}`
          : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
            props?.homeData === SPORTS.RUBGY_LEAGUE
          ? `public/rls/event/${props?.sportItem?.id}?SportId=12`
          : props?.sportData?.title === SPORTS.RUBGY_UNION ||
            props?.homeData === SPORTS.RUBGY_UNION
          ? `public/rls/event/${props?.sportItem?.id}?SportId=13`
          : props?.sportData?.title === SPORTS.BASKETBALL ||
            props?.homeData === SPORTS.BASKETBALL
          ? `public/nba/event/${props?.sportItem?.id}`
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? `public/afl/event/${props?.sportItem?.id}?SportId=15`
          : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
            props?.homeData === SPORTS.AUSTRALIAN_RULES
          ? `public/ar/event/${props?.sportItem?.id}?SportId=9`
          : props?.sportData?.title === SPORTS.GOLF ||
            props?.homeData === SPORTS.GOLF
          ? `public/golf/event/${props?.sportItem?.id}?SportId=16`
          : props?.sportData?.title === SPORTS.TENNIS ||
            props?.homeData === SPORTS.TENNIS
          ? `public/tennis/event/${props?.sportItem?.id}?SportId=7`
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? `public/baseball/event/${props?.sportItem?.id}?SportId=11`
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? `public/icehockey/event/${props?.sportItem?.id}?SportId=17`
          : props?.sportData?.title === SPORTS.BOXING ||
            props?.homeData === SPORTS.BOXING
          ? `public/boxing/event/${props?.sportItem?.id}?SportId=6`
          : props?.sportData?.title === SPORTS.MMA ||
            props?.homeData === SPORTS.MMA
          ? `public/mma/event/${props?.sportItem?.id}?SportId=5`
          : props?.sportData?.title === SPORTS.SOCCER ||
            props?.homeData === SPORTS.SOCCER
          ? `public/soccer/event/${props?.sportItem?.id}?SportId=8`
          : `public/rls/event/${props?.sportItem?.id}?SportId=14`;

      const response = await callApi(passApi, null, API_CONFIG.GET, null);
      if (response.body != null) {
        if (response.body?.status === 200) {
          let itemData = [response?.body?.data?.result];

          let fullData = [];
          itemData?.map(async (item) => {
            let passApi =
              props?.sportData?.title === SPORTS.CRICKET ||
              props?.homeData === SPORTS.CRICKET
                ? `public/crickets/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
                  props?.homeData === SPORTS.RUBGY_LEAGUE
                ? `public/rls/event/odd/${item?.id}?SportId=12`
                : props?.sportData?.title === SPORTS.RUBGY_UNION ||
                  props?.homeData === SPORTS.RUBGY_UNION
                ? `public/rls/event/odd/${item?.id}?SportId=13`
                : props?.sportData?.title === SPORTS.BASKETBALL ||
                  props?.homeData === SPORTS.BASKETBALL
                ? `public/nba/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                  props?.homeData === SPORTS.AMERICAN_FOOTBALL
                ? `public/afl/event/odd/${item?.id}?SportId=15`
                : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                  props?.homeData === SPORTS.AUSTRALIAN_RULES
                ? `public/ar/event/odd/${item?.id}?SportId=9`
                : props?.sportData?.title === SPORTS.GOLF ||
                  props?.homeData === SPORTS.GOLF
                ? `public/golf/event/odd/${item?.id}?SportId=16`
                : props?.sportData?.title === SPORTS.TENNIS ||
                  props?.homeData === SPORTS.TENNIS
                ? `public/tennis/event/odd/${item?.id}?SportId=7`
                : props?.sportData?.title === SPORTS.BASEBALL ||
                  props?.homeData === SPORTS.BASEBALL
                ? `public/baseball/event/odd/${item?.id}?SportId=11`
                : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                  props?.homeData === SPORTS.ICE_HOCKEY
                ? `public/icehockey/event/odd/${item?.id}?SportId=17`
                : props?.sportData?.title === SPORTS.BOXING ||
                  props?.homeData === SPORTS.BOXING
                ? `public/boxing/event/odd/${item?.id}?SportId=6`
                : props?.sportData?.title === SPORTS.MMA ||
                  props?.homeData === SPORTS.MMA
                ? `public/mma/event/odd/${item?.id}?SportId=5`
                : props?.sportData?.title === SPORTS.SOCCER ||
                  props?.homeData === SPORTS.SOCCER
                ? `public/soccer/event/odd/${item?.id}?SportId=8`
                : `public/rls/event/odd/${item?.id}?SportId=14`;
            const response = await callApi(passApi, null, API_CONFIG.GET, null);
            if (response.body != null) {
              if (response.body?.status === 200) {
                let itemData = response?.body?.data?.result;
                let newData =
                  itemData?.length > 0
                    ? props?.sportData?.title === SPORTS.CRICKET ||
                      props?.homeData === SPORTS.CRICKET
                      ? itemData?.[0]?.CricketOdds
                      : props?.sportData?.title === SPORTS.BASKETBALL ||
                        props?.homeData === SPORTS.BASKETBALL
                      ? itemData?.[0]?.NBAOdds
                      : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                        props?.homeData === SPORTS.AMERICAN_FOOTBALL
                      ? itemData?.[0]?.AFLOdds
                      : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                        props?.homeData === SPORTS.AUSTRALIAN_RULES
                      ? itemData?.[0]?.AROdds
                      : props?.sportData?.title === SPORTS.BASEBALL ||
                        props?.homeData === SPORTS.BASEBALL
                      ? itemData?.[0]?.BaseballOdds
                      : props?.sportData?.title === SPORTS.TENNIS ||
                        props?.homeData === SPORTS.TENNIS
                      ? itemData?.[0]?.TennisOdds
                      : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                        props?.homeData === SPORTS.ICE_HOCKEY
                      ? itemData?.[0]?.IceHockeyOdds
                      : props?.sportData?.title === SPORTS.BOXING ||
                        props?.homeData === SPORTS.BOXING
                      ? itemData?.[0]?.BoxingOdds
                      : props?.sportData?.title === SPORTS.MMA ||
                        props?.homeData === SPORTS.MMA
                      ? itemData?.[0]?.MMAOdds
                      : props?.sportData?.title === SPORTS.SOCCER ||
                        props?.homeData === SPORTS.SOCCER
                      ? itemData?.[0]?.SoccerOdds
                      : itemData?.[0]?.RLOdds
                    : [];
                // handleRemoveSeeAllOddsColumn(newData);
                // setoddsApiData(newData);
                item.MarketNumber = itemData?.length;
                item.homeTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((homeTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? homeTeam?.CricketTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? homeTeam?.NBATeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? homeTeam?.AFLTeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? homeTeam?.ARTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? homeTeam?.BaseballTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? homeTeam?.IceHockeyTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? homeTeam?.TennisTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? homeTeam?.BoxingTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? homeTeam?.MMATeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? homeTeam?.SoccerTeamId == item?.homeTeamId
                          : homeTeam?.RLTeamId == item?.homeTeamId;
                      })
                    : "";
                item.awayTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((awayTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? awayTeam?.CricketTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? awayTeam?.NBATeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? awayTeam?.AFLTeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? awayTeam?.ARTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? awayTeam?.BaseballTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? awayTeam?.TennisTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? awayTeam?.IceHockeyTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? awayTeam?.BoxingTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? awayTeam?.MMATeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? awayTeam?.SoccerTeamId == item?.awayTeamId
                          : awayTeam?.RLTeamId == item?.awayTeamId;
                      })
                    : "";
                setSportDetailsList([item]);
                setIsLoaderVisible(false);
                // setTimeout(() => {
                //   setIsEventLoading(false);
                // }, 3000);
              }
            }
          });
        }
      }
    } catch {
      setIsLoaderVisible(false);
      setRefreshing(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  return (
    <View style={styles.mainLoginView}>
      <DatePickerModel
        showClearButton={true}
        clearPress={() => {
          showDatePicker(false);
          setSelectedDate(null);
          setGetUTCDate(new Date());
        }}
        isVisible={isShowDatePicker}
        date={getUTCDate ? getUTCDate : new Date()}
        showModel={showDatePicker}
        onDateSelect={() => {
          setSelectedDate(moment(getUTCDate).format("YYYY-MM-DD"));
          showDatePicker(false);
        }}
        getUtcDate={(date) => {
          setGetUTCDate(date);
        }}
      />
      <SportModel
        isSearchVisible={true}
        search={search}
        onchangeText={(text: any) => {
          setSearch(text);
          searchFilterFunction(text, tournamentOptions);
        }}
        isVisible={isModalVisible}
        showModel={setIsModalVisible}
        data={filteredDataSource}
        onPressBack={() => onPressBack()}
        onNextPress={() => onNextPress()}
        renderItem={(item, index) => renderItem(item, index)}
      />
      <SportModel
        isSearchVisible={true}
        search={search}
        onchangeText={(text: any) => {
          setSearch(text);
          searchTeamFilter(text, teamOptions);
        }}
        renderItem={(item, index) => teamRenderItem(item, index)}
        isVisible={isTeamModalVisible}
        showModel={setIsTeamModalVisible}
        data={teamDataSource}
        onPressBack={() => onTeamBackPress()}
        onNextPress={() => onTeamNextPress()}
      />
      {/* <LeaguePicker
        isVisible={isMarketModalVisible}
        showModel={setIsMarketModalVisible}
        // data={oddsDataOption}
        data={marketList}
        onItemSelect={(selectedData) => {
          marketList?.forEach((item, _index) => {
            return (
              <Pressable
                onPress={() => onMarketPress(selectedData)}
                key={index}
              >
                <Text
                  style={
                    selectedMarkets?.value == item?.value
                      ? styles.selectedItem
                      : styles.labelText
                  }
                >
                  {item?.label}
                </Text>
              </Pressable>
            );
          });

          // oddsTypeChange(selectedData);
          // setSelectedOddsText(selectedData?.title);
        }}
      /> */}

      <SportModel
        isSearchVisible={false}
        search={search}
        onchangeText={(text: any) => {
          setSearch(text);
          searchMarketFilter(text, marketList);
        }}
        isVisible={isMarketModalVisible}
        showModel={setIsMarketModalVisible}
        data={marketList}
        onPressBack={() => onMarketPressBack()}
        onNextPress={() => onMarketNextPress()}
        renderItem={(item, index) => marketRenderItem(item, index)}
      />
      {/* <View style={{ flex: 1, backgroundColor: "red", position: "relative" }}>
        <ActivityIndicator size="large" color="#00ff00" />
      </View> */}
      {isLoadervisible && (
        <View style={styles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}

      {!isLoadervisible && (
        // <View onLayout={onLayout}>
        <SportsItemList
          marketValue={
            selectedFirstMarkets?.label?.length > 0
              ? selectedFirstMarkets?.label
                ? selectedFirstMarkets?.label
                : translate("HeadToHead")
              : selectedMarkets?.label
          }
          onMarketPress={() => {
            setIsMarketModalVisible(true);
            setSelectedMarkets({});
            setSelectedFirstMarkets({});
          }}
          // tournamentsHeight={tournamentsHeight}
          isSeeAll={isSeeAll}
          selectedMarkets={selectedMarkets}
          marketItem={marketItem}
          marketAllData={marketAllData}
          sponsoredId={sponsoredId}
          marketAllName={marketAllName}
          headerSeeAllCompnent={() => headerSeeAllCompnent()}
          headerComponent={() => headerComponent()}
          data={sportListData}
          marketOdds={marketOdds}
          bookkeeperData={bookkeeperData}
          sportId={
            props?.sportData?.title ? props?.sportData?.title : props?.homeData
          }
          footerComponent={() => footerComponent()}
          seeAllfooterComponent={() => seeAllfooterComponent()}
          onRefresh={onRefresh}
          refreshing={refreshing}
        />
        // </View>
      )}
    </View>
  );
}
