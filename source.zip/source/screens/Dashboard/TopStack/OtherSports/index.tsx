import React from "react";
import { Text } from "react-native";
import styles from "./style";

type Props = {
  loading?: boolean;
  navigation?: any;
};

export default function OtherTab(props: Props) {
  return <Text style={styles.colorBlack}>6</Text>;
}
