import { StyleSheet } from "react-native";
import { Colors } from "../../../../theme/index";

export default StyleSheet.create({
  colorBlack: {
    color: Colors.black,
    alignSelf: "center",
  },
});
