import _ from "lodash";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { callApi } from "../../../../api";
import API_CONFIG from "../../../../api/api_url";
import DatePickerModel from "../../../../component/DatePickerModel";
import GolfOutRightList from "../../../../component/GolfOutRightList";
import PartnersList from "../../../../component/PartnersList";
import Loader from "../../../../component/ProgressBar";
import SportHeaderComponent from "../../../../component/SportHeaderComponent";
import SportModel from "../../../../component/SportsModelComponent";
import TextHeaderTitle from "../../../../component/Text";
import { Colors } from "../../../../theme";
import { translate } from "../../../../utils/Localize";
import { print_data } from "../../../../utils/Logs";
import { showToast } from "../../../../utils/commonFunction";
import styles from "./style";
import { SPORTS } from "../../../../utils/constant";

export default function GolfOutRightTab(props: any) {
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [teamOptions, setTeamOptions] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isTeamModalVisible, setIsTeamModalVisible] = useState(false);
  const [search, setSearch] = useState("");
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const [teamDataSource, setTeamDataSource] = useState([]);
  const [tournamentOptions, setTournamentOptions] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedseries, setselectedseries] = useState(0);
  const [stepperCount, setStepperCount] = useState(0);
  const [getUTCDate, setGetUTCDate] = useState(new Date());
  const [selectedTornaments, setSelectedTornaments] = useState({});
  const [selectedTeamData, setSelectedTeamData] = useState({});
  const [isShowDatePicker, showDatePicker] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(0);
  const [sportDetailsList, setSportDetailsList] = useState([]);
  const [sponsoredId, setSponsoredId] = useState([]);
  // const [marketAllData, setMarketAllData] = useState([]);
  // const [marketItem, setMarketItem] = useState([]);
  const [eventList, setEventList] = useState([]);
  const [individualTeamData, setIndividualTeamData] = useState(
    props?.individualTeamdata
  );
  const [bookkeeperData, setBookKeeperData] = useState([]);

  useEffect(() => {
    fetchDropDowndata(0, "outrights");
    fetchBookKeeper();
  }, [
    props?.sportData?.title,
    props?.sportId,
    props?.sportItem,
    props?.homeData,
    props?.sportData,
    ,
  ]);

  useEffect(() => {
    setSearch("");
    setIsLoaderVisible(true);

    // if (individualTeamData) {
    fetchIndividualTeamdata();
    // } else {
    fetchAllEvents(0, 1, "outrights");
    // callMarketsApi();
    // }
    callSponsoredApi();
    setEventList([]);
  }, [
    props?.sportData?.title,
    props?.sportId,
    props?.sportItem,

    selectedseries,
    selectedDate,
    selectedTeam,
    stepperCount,
    props?.homeData,
    props?.sportData,
    individualTeamData,
  ]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchAllEvents(0, 1, "outrights");
  };

  const handleStepper = (value) => {
    if (stepperCount >= 0) {
      return value === "left"
        ? stepperCount > 0
          ? setStepperCount(stepperCount - 1)
          : ""
        : setStepperCount(stepperCount + 1);
    }
  };

  const onNextPress = () => {
    setIndividualTeamData(false);
    setselectedseries(selectedTornaments?.value);
    setIsModalVisible(false);
    setSearch("");
  };
  const onPressBack = () => {
    setIsModalVisible(false);
    setSearch("");
  };

  const onTeamNextPress = () => {
    setIndividualTeamData(false);
    setSelectedTeam(selectedTeamData?.value);
    setIsTeamModalVisible(false);
  };
  const onTeamBackPress = () => {
    setIsTeamModalVisible(false);
  };

  const onselectedPress = (item) => {
    setSelectedTornaments(item);
  };

  const onselectedTeamPress = (item) => {
    setSelectedTeamData(item);
  };

  const sportListData = sportDetailsList?.sort(
    (a, b) => new Date(a?.startTime) - new Date(b?.startTime)
  );

  const searchFilterFunction = (text, filterTournamentData) => {
    const newData = filterTournamentData.filter(function (item) {
      const itemData = item?.label
        ? item?.label?.toUpperCase()
        : "".toUpperCase();

      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    setFilteredDataSource(newData);
  };

  const searchTeamFilter = (text, filterTournamentData) => {
    const newData = filterTournamentData.filter(function (item) {
      const itemData = item?.label
        ? item?.label?.toUpperCase()
        : "".toUpperCase();

      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    setTeamDataSource(newData);
  };

  const renderItem = (item, index) => {
    return (
      <Pressable onPress={() => onselectedPress(item)} key={index}>
        <Text
          style={
            selectedTornaments?.value == item?.value
              ? styles.selectedItem
              : styles.labelText
          }
        >
          {item.label}
        </Text>
      </Pressable>
    );
  };

  const teamRenderItem = (item, index) => {
    return (
      <Pressable onPress={() => onselectedTeamPress(item)} key={index}>
        <Text
          style={
            selectedTeamData?.value == item?.value
              ? styles.selectedItem
              : styles.labelText
          }
        >
          {item?.label}
        </Text>
      </Pressable>
    );
  };

  const headerComponent = () => {
    return (
      <>
        <SportHeaderComponent
          homeData={props?.homeData}
          sportDataTitle={
            props?.sportData?.title ? props?.sportData?.title : props?.homeData
          }
          ontournamentPress={() => {
            setIsModalVisible(true);
            setSelectedTornaments({});
          }}
          tournamentsValue={
            selectedTornaments?.label
              ? selectedTornaments?.label
              : translate("AllTournaments")
          }
          onRoundPress={() => {
            showDatePicker(true);
          }}
          handleStepper={handleStepper}
          stepperCount={stepperCount}
          teamValue={
            selectedTeamData?.label
              ? selectedTeamData?.label
              : translate("AllTeams")
          }
          onTeamPress={() => {
            setIsTeamModalVisible(true), setSelectedTeamData({});
          }}
          selectedDate={setSelectedDate}
          showModel={() => showDatePicker(true)}
          selectedDateValue={selectedDate}
        />
      </>
    );
  };

  const footerComponent = () => {
    return (
      <>
        {!isLoadervisible && (
          <>
            <View style={styles.partnersView}>
              <View style={styles.textCenter}>
                <TextHeaderTitle
                  title={translate("OurPartners")}
                  textStyle={styles.textStyle}
                />
              </View>
              <View style={styles.partnerListBottom}>
                <PartnersList />
              </View>
            </View>
          </>
        )}
      </>
    );
  };

  const callSponsoredApi = async () => {
    try {
      const sportId =
        props?.sportData?.title === SPORTS.CRICKET ||
        props?.homeData === SPORTS.CRICKET
          ? 4
          : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
            props?.homeData === SPORTS.RUBGY_LEAGUE
          ? 12
          : props?.sportData?.title === SPORTS.RUBGY_UNION ||
            props?.homeData === SPORTS.RUBGY_UNION
          ? 13
          : props?.sportData?.title === SPORTS.BASKETBALL ||
            props?.homeData === SPORTS.BASKETBALL
          ? 10
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? 15
          : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
            props?.homeData === SPORTS.AUSTRALIAN_RULES
          ? 9
          : props?.sportData?.title === SPORTS.GOLF ||
            props?.homeData === SPORTS.GOLF
          ? 16
          : props?.sportData?.title === SPORTS.TENNIS ||
            props?.homeData === SPORTS.TENNIS
          ? 7
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? 11
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? 17
          : props?.sportData?.title === SPORTS.BOXING ||
            props?.homeData === SPORTS.BOXING
          ? 6
          : props?.sportData?.title === SPORTS.MMA ||
            props?.homeData === SPORTS.MMA
          ? 5
          : props?.sportData?.title === SPORTS.SOCCER ||
            props?.homeData === SPORTS.SOCCER
          ? 8
          : 14;
      const response = await callApi(
        `public/sponsor?timeZone=${timezone}&SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let sponsoredData = response?.body?.data?.result;
          let providerId = [];
          sponsoredData?.map((item) => providerId?.push(item?.bookKeepersId));
          setSponsoredId(providerId);
        } else {
          setSponsoredId([]);
        }
      }
    } catch (error) {
      setSponsoredId([]);
    }
  };

  // const callMarketsApi = async () => {
  //   try {
  //     const sportName =
  //       props?.sportData?.title === SPORTS.CRICKET || props?.homeData ===SPORTS.CRICKET
  //         ? "crickets"
  //         : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
  //           props?.homeData === SPORTS.RUBGY_LEAGUE
  //         ? "rls"
  //         : props?.sportData?.title === SPORTS.RUBGY_UNION ||
  //           props?.homeData === SPORTS.RUBGY_UNION
  //         ? "rls"
  //         : props?.sportData?.title === SPORTS.BASKETBALL||
  //           props?.homeData ===SPORTS.BASKETBALL
  //         ? "nba"
  //         : props?.sportData?.title ===SPORTS.AMERICAN_FOOTBALL ||
  //           props?.homeData === SPORTS.AMERICAN_FOOTBALL
  //         ? "afl"
  //         : props?.sportData?.title ===SPORTS.AUSTRALIAN_RULES ||
  //           props?.homeData === SPORTS.AUSTRALIAN_RULES
  //         ? "ar"
  //         : props?.sportData?.title === SPORTS.GOLF || props?.homeData === SPORTS.GOLF
  //         ? "golf"
  //         : props?.sportData?.title === SPORTS.TENNIS || props?.homeData === SPORTS.TENNIS
  //         ? "tennis"
  //         : props?.sportData?.title === SPORTS.BASEBALL ||
  //           props?.homeData ===SPORTS.BASEBALL
  //         ? "baseball"
  //         : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
  //           props?.homeData === SPORTS.ICE_HOCKEY
  //         ? "icehockey"
  //         : props?.sportData?.title === SPORTS.BOXING || props?.homeData === SPORTS.BOXING
  //         ? "boxing"
  //         : props?.sportData?.title === SPORTS.MMA ||
  //           props?.homeData === "SPORTS.MMA
  //         ? "mma"
  //         : props?.sportData?.title ===SPORTS.SOCCER || props?.homeData === SPORTS.SOCCER
  //         ? "soccer"
  //         : "rls";
  //     const response = await callApi(
  //       `public/${sportName}/market?isTeam=true`,
  //       null,
  //       API_CONFIG.GET,
  //       null
  //     );
  //     if (response.body != null) {
  //       if (response.body?.status === 200) {
  //         let marketData = response?.body?.data?.result?.rows;

  //         let market = [];
  //         let marketAllData = [];
  //         marketData.forEach((item) => {
  //           market.push(item?.displayName);
  //           marketAllData.push(item);
  //         });
  //         setMarketItem(marketAllData);
  //         setMarketAllData(market);
  //       } else {
  //         print_data("error==");
  //       }
  //     }
  //   } catch (error) {
  //     print_data("error==");
  //   }
  // };

  const fetchUrlAllEvents = (eventPage) => {
    const utcDate = moment(getUTCDate).format("YYYY-MM-DD");
    const startDate = selectedDate === null ? utcDate : selectedDate;
    const endDate = selectedDate === null ? "" : selectedDate;
    const tournamentID = selectedseries === 0 ? "" : selectedseries;
    const teamID = selectedTeam === 0 ? "" : selectedTeam;
    const teamRound = stepperCount === 0 ? "" : stepperCount;

    if (
      props?.sportData?.title === SPORTS.CRICKET ||
      props?.homeData === SPORTS.CRICKET
    ) {
      return `public/crickets/event?startDate=${startDate}&endDate=${endDate}&CricketTournamentId=${tournamentID}&teamId=${teamID}&${eventPage}&timezone=${timezone}&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
      props?.homeData === SPORTS.RUBGY_LEAGUE
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=12&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_UNION ||
      props?.homeData === SPORTS.RUBGY_UNION
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=13&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.GOLF ||
      props?.homeData === SPORTS.GOLF
    ) {
      return `public/golf/event?startDate=${startDate}&endDate=${endDate}&GolfTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=16&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.TENNIS ||
      props?.homeData === SPORTS.TENNIS
    ) {
      return `public/tennis/event?startDate=${startDate}&endDate=${endDate}&TennisTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=7&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BASEBALL ||
      props?.homeData === SPORTS.BASEBALL
    ) {
      return `public/baseball/event?startDate=${startDate}&endDate=${endDate}&BaseballTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=11&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.ICE_HOCKEY ||
      props?.homeData === SPORTS.ICE_HOCKEY
    ) {
      return `public/icehockey/event?startDate=${startDate}&endDate=${endDate}&IceHockeyTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=17&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BOXING ||
      props?.homeData === SPORTS.BOXING
    ) {
      return `public/boxing/event?startDate=${startDate}&endDate=${endDate}&BoxingTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=6&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.MMA ||
      props?.homeData === SPORTS.MMA
    ) {
      return `public/mma/event?startDate=${startDate}&endDate=${endDate}&MMATournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=5&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.SOCCER ||
      props?.homeData === SPORTS.SOCCER
    ) {
      return `public/soccer/event?startDate=${startDate}&endDate=${endDate}&SoccerTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=8&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
      props?.homeData === SPORTS.AMERICAN_FOOTBALL
    ) {
      return `public/afl/event?startDate=${startDate}&endDate=${endDate}&AFLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=15&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
      props?.homeData === SPORTS.AUSTRALIAN_RULES
    ) {
      return `public/ar/event?startDate=${startDate}&endDate=${endDate}&ARTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=9&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BASKETBALL ||
      props?.homeData === SPORTS.BASKETBALL
    ) {
      return `public/nba/event?startDate=${startDate}&endDate=${endDate}&NBATournamentId=${tournamentID}&teamId=${teamID}&${eventPage}&timezone=${timezone}&oddCheck=true`;
    } else {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=14&oddCheck=true`;
    }
  };

  const fetchAllEvents = async (eventPage, marketId, outrights) => {
    try {
      let passApi = fetchUrlAllEvents(eventPage);
      const response = await callApi(
        passApi +
          `&marketId=${outrights ? "" : marketId}&isOuright=${
            outrights ? true : ""
          }`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          let itemData = response?.body?.data?.result?.rows;

          let teams = [];
          itemData?.map((item) => {
            if (!item?.outrights) {
              teams.push({
                label: item?.homeTeam?.name,
                value: item?.homeTeam?.id,
              });
              teams.push({
                label: item?.awayTeam?.name,
                value: item?.awayTeam?.id,
              });
            } else {
              let OutRightTeams =
                props?.sportData?.title === SPORTS.CRICKET ||
                props?.homeData === SPORTS.CRICKET
                  ? item?.CricketOutRightTeams
                  : props?.sportData?.title === SPORTS.BASKETBALL ||
                    props?.homeData === SPORTS.BASKETBALL
                  ? item?.NBAOutRightTeams
                  : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                    props?.homeData === SPORTS.AMERICAN_FOOTBALL
                  ? item?.AFLOutRightTeams
                  : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                    props?.homeData === SPORTS.AUSTRALIAN_RULES
                  ? item?.AROutRightTeams
                  : props?.sportData?.title === SPORTS.GOLF ||
                    props?.homeData === SPORTS.GOLF
                  ? item?.GolfOutRightTeams
                  : props?.sportData?.title === SPORTS.TENNIS ||
                    props?.homeData === SPORTS.TENNIS
                  ? item?.TennisOutRightTeams
                  : props?.sportData?.title === SPORTS.BASEBALL ||
                    props?.homeData === SPORTS.BASEBALL
                  ? item?.BaseballOutRightTeams
                  : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                    props?.homeData === SPORTS.ICE_HOCKEY
                  ? item?.IceHockeyOutRightTeams
                  : props?.sportData?.title === SPORTS.BOXING ||
                    props?.homeData === SPORTS.BOXING
                  ? item?.BoxingOutRightTeams
                  : props?.sportData?.title === SPORTS.MMA ||
                    props?.homeData === SPORTS.MMA
                  ? item?.MMAOutRightTeams
                  : props?.sportData?.title === SPORTS.SOCCER ||
                    props?.homeData === SPORTS.SOCCER
                  ? item?.SoccerOutRightTeams
                  : item?.RLOutRightTeams;
              let OutRightTeamKey =
                props?.sportData?.title === SPORTS.CRICKET ||
                props?.homeData === SPORTS.CRICKET
                  ? "CricketTeam"
                  : props?.sportData?.title === SPORTS.BASKETBALL ||
                    props?.homeData === SPORTS.BASKETBALL
                  ? "NBATeam"
                  : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                    props?.homeData === SPORTS.AMERICAN_FOOTBALL
                  ? "AFLTeam"
                  : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                    props?.homeData === SPORTS.AUSTRALIAN_RULES
                  ? "ARTeam"
                  : props?.sportData?.title === SPORTS.GOLF ||
                    props?.homeData === SPORTS.GOLF
                  ? "GolfTeam"
                  : props?.sportData?.title === SPORTS.TENNIS ||
                    props?.homeData === SPORTS.TENNIS
                  ? "TennisTeam"
                  : props?.sportData?.title === SPORTS.BASEBALL ||
                    props?.homeData === SPORTS.BASEBALL
                  ? "BaseballTeam"
                  : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                    props?.homeData === SPORTS.ICE_HOCKEY
                  ? "IceHockeyTeam"
                  : props?.sportData?.title === SPORTS.BOXING ||
                    props?.homeData === SPORTS.BOXING
                  ? "BoxingTeam"
                  : props?.sportData?.title === SPORTS.MMA ||
                    props?.homeData === SPORTS.MMA
                  ? "MMATeam"
                  : props?.sportData?.title === SPORTS.SOCCER ||
                    props?.homeData === SPORTS.SOCCER
                  ? "SoccerTeam"
                  : "RLTeam";

              let TeamData = OutRightTeams?.map((item) => {
                teams.push({
                  label: item?.[OutRightTeamKey]?.name,
                  value: item?.[OutRightTeamKey]?.id,
                });
              });
            }
          });
          let filterTeamData = _.uniqBy(teams, function (e) {
            return e.value;
          })
            ?.filter((a) => a?.value !== undefined)
            ?.sort((a, b) => {
              return a?.label.localeCompare(b?.label);
            });
          filterTeamData?.unshift({
            label: "All Teams",
            value: 0,
          });

          setTeamOptions(filterTeamData);
          setTeamDataSource(filterTeamData);
          if (search.length > 0) {
            searchTeamFilter(search, filterTeamData);
          }

          setSportDetailsList(itemData);
          setEventList(itemData);

          setRefreshing(false);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          setRefreshing(false);
        }
      } else {
        setIsLoaderVisible(false);
        setRefreshing(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setRefreshing(false);
    }
  };

  const fetchURLData = (eventPage) => {
    const utcDate = moment(getUTCDate).format("YYYY-MM-DD");
    const startDate = selectedDate != null ? selectedDate : utcDate;
    const endDate = selectedDate != null ? selectedDate : "";
    if (
      props?.sportData?.title === SPORTS.CRICKET ||
      props?.homeData === SPORTS.CRICKET
    ) {
      return `public/crickets/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
      props?.homeData === SPORTS.RUBGY_LEAGUE
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=12&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_UNION ||
      props?.homeData === SPORTS.RUBGY_UNION
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=13&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
      props?.homeData === SPORTS.AMERICAN_FOOTBALL
    ) {
      return `public/afl/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=15&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
      props?.homeData === SPORTS.AUSTRALIAN_RULES
    ) {
      return `public/ar/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=9&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BASKETBALL ||
      props?.homeData === SPORTS.BASKETBALL
    ) {
      return `public/nba/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.GOLF ||
      props?.homeData === SPORTS.GOLF
    ) {
      return `public/golf/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=16&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.TENNIS ||
      props?.homeData === SPORTS.TENNIS
    ) {
      return `public/tennis/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=7&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BASEBALL ||
      props?.homeData === SPORTS.BASEBALL
    ) {
      return `public/baseball/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=11&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.ICE_HOCKEY ||
      props?.homeData === SPORTS.ICE_HOCKEY
    ) {
      return `public/icehockey/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=17&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BOXING ||
      props?.homeData === SPORTS.BOXING
    ) {
      return `public/boxing/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=6&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.MMA ||
      props?.homeData === SPORTS.MMA
    ) {
      return `public/mma/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=5&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.SOCCER ||
      props?.homeData === SPORTS.SOCCER
    ) {
      return `public/soccer/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=8&oddCheck=true`;
    } else {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&SportId=14&oddCheck=true`;
    }
  };

  const fetchDropDowndata = async (eventPage, outrights) => {
    try {
      let passApi = fetchURLData(eventPage);
      const response = await callApi(
        passApi +
          `&marketId=${outrights ? "" : 1}&isOuright=${outrights ? true : ""}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let fullData = [];
          let itemData = response?.body?.data?.result?.rows;

          let tournaments = [];
          itemData?.map((item) => {
            props?.sportData?.title === SPORTS.CRICKET ||
            props?.homeData === SPORTS.CRICKET
              ? tournaments.push({
                  label: item?.CricketTournament?.name,
                  value: item?.CricketTournament?.id,
                })
              : props?.sportData?.title === SPORTS.BASKETBALL ||
                props?.homeData === SPORTS.BASKETBALL
              ? tournaments.push({
                  label:
                    item?.NBATournament?.name +
                    " " +
                    item?.NBATournament?.NBACategory?.name,
                  value: item?.NBATournament?.id,
                })
              : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                props?.homeData === SPORTS.AMERICAN_FOOTBALL
              ? tournaments.push({
                  label: item?.AFLTournament?.name,
                  value: item?.AFLTournament?.id,
                })
              : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                props?.homeData === SPORTS.AUSTRALIAN_RULES
              ? tournaments.push({
                  label: item?.ARTournament?.name,
                  value: item?.ARTournament?.id,
                })
              : props?.sportData?.title === SPORTS.BASEBALL ||
                props?.homeData === SPORTS.BASEBALL
              ? tournaments.push({
                  label: item?.BaseballTournament?.name,
                  value: item?.BaseballTournament?.id,
                })
              : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                props?.homeData === SPORTS.ICE_HOCKEY
              ? tournaments.push({
                  label: item?.IceHockeyTournament?.name,
                  value: item?.IceHockeyTournament?.id,
                })
              : props?.sportData?.title === SPORTS.TENNIS ||
                props?.homeData === SPORTS.TENNIS
              ? tournaments.push({
                  label: item?.TennisTournament?.name,
                  value: item?.TennisTournament?.id,
                })
              : props?.sportData?.title === SPORTS.BOXING ||
                props?.homeData === SPORTS.BOXING
              ? tournaments.push({
                  label: item?.BoxingTournament?.name,
                  value: item?.BoxingTournament?.id,
                })
              : props?.sportData?.title === SPORTS.MMA ||
                props?.homeData === SPORTS.MMA
              ? tournaments.push({
                  label: item?.MMATournament?.name,
                  value: item?.MMATournament?.id,
                })
              : props?.sportData?.title === SPORTS.SOCCER ||
                props?.homeData === SPORTS.SOCCER
              ? tournaments.push({
                  label: item?.SoccerTournament?.name,
                  value: item?.SoccerTournament?.id,
                })
              : tournaments.push({
                  label: item?.RLTournament?.name,
                  value: item?.RLTournament?.id,
                });
          });

          let filterTournamentData = _.uniqBy(tournaments, function (e) {
            return e.value;
          })
            ?.filter((a) => a?.value !== undefined)
            .sort((a, b) => {
              return a?.label.localeCompare(b?.label);
            });
          filterTournamentData?.unshift({
            label: "All Tournaments",
            value: 0,
          });
          // setTournamentOptions(
          //   _.uniqBy(
          //     [...tournamentOptions, ...filterTournamentData],
          //     function (e) {
          //       return e?.value;
          //     }
          //   )
          // );

          // setFilteredDataSource(
          //   _.uniqBy(
          //     [...tournamentOptions, ...filterTournamentData],
          //     function (e) {
          //       return e?.value;
          //     }
          //   )
          // );
          setTournamentOptions(filterTournamentData);
          setFilteredDataSource(filterTournamentData);
          if (search.length > 0) {
            searchFilterFunction(search, filterTournamentData);
          }

          let teams = [];
          itemData?.map((item) => {
            if (!item?.outrights) {
              teams.push({
                label: item?.homeTeam?.name,
                value: item?.homeTeam?.id,
              });
              teams.push({
                label: item?.awayTeam?.name,
                value: item?.awayTeam?.id,
              });
            } else {
              let OutRightTeams =
                props?.sportData?.title === SPORTS.CRICKET ||
                props?.homeData === SPORTS.CRICKET
                  ? item?.CricketOutRightTeams
                  : props?.sportData?.title === SPORTS.BASKETBALL ||
                    props?.homeData === SPORTS.BASKETBALL
                  ? item?.NBAOutRightTeams
                  : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                    props?.homeData === SPORTS.AMERICAN_FOOTBALL
                  ? item?.AFLOutRightTeams
                  : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                    props?.homeData === SPORTS.AUSTRALIAN_RULES
                  ? item?.AROutRightTeams
                  : props?.sportData?.title === SPORTS.GOLF ||
                    props?.homeData === SPORTS.GOLF
                  ? item?.GolfOutRightTeams
                  : props?.sportData?.title === SPORTS.TENNIS ||
                    props?.homeData === SPORTS.TENNIS
                  ? item?.TennisOutRightTeams
                  : props?.sportData?.title === SPORTS.BASEBALL ||
                    props?.homeData === SPORTS.BASEBALL
                  ? item?.BaseballOutRightTeams
                  : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                    props?.homeData === SPORTS.ICE_HOCKEY
                  ? item?.IceHockeyOutRightTeams
                  : props?.sportData?.title === SPORTS.BOXING ||
                    props?.homeData === SPORTS.BOXING
                  ? item?.BoxingOutRightTeams
                  : props?.sportData?.title === SPORTS.MMA ||
                    props?.homeData === SPORTS.MMA
                  ? item?.MMAOutRightTeams
                  : props?.sportData?.title === SPORTS.SOCCER ||
                    props?.homeData === SPORTS.SOCCER
                  ? item?.SoccerOutRightTeams
                  : item?.RLOutRightTeams;
              let OutRightTeamKey =
                props?.sportData?.title === SPORTS.CRICKET ||
                props?.homeData === SPORTS.CRICKET
                  ? "CricketTeam"
                  : props?.sportData?.title === SPORTS.BASKETBALL ||
                    props?.homeData === SPORTS.BASKETBALL
                  ? "NBATeam"
                  : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                    props?.homeData === SPORTS.AMERICAN_FOOTBALL
                  ? "AFLTeam"
                  : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                    props?.homeData === SPORTS.AUSTRALIAN_RULES
                  ? "ARTeam"
                  : props?.sportData?.title === SPORTS.GOLF ||
                    props?.homeData === SPORTS.GOLF
                  ? "GolfTeam"
                  : props?.sportData?.title === SPORTS.TENNIS ||
                    props?.homeData === SPORTS.TENNIS
                  ? "TennisTeam"
                  : props?.sportData?.title === SPORTS.BASEBALL ||
                    props?.homeData === SPORTS.BASEBALL
                  ? "BaseballTeam"
                  : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                    props?.homeData === SPORTS.ICE_HOCKEY
                  ? "IceHockeyTeam"
                  : props?.sportData?.title === SPORTS.BOXING ||
                    props?.homeData === SPORTS.BOXING
                  ? "BoxingTeam"
                  : props?.sportData?.title === SPORTS.MMA ||
                    props?.homeData === SPORTS.MMA
                  ? "MMATeam"
                  : props?.sportData?.title === SPORTS.SOCCER ||
                    props?.homeData === SPORTS.SOCCER
                  ? "SoccerTeam"
                  : "RLTeam";

              let TeamData = OutRightTeams?.map((item) => {
                teams.push({
                  label: item?.[OutRightTeamKey]?.name,
                  value: item?.[OutRightTeamKey]?.id,
                });
              });
            }
          });
          let filterTeamData = _.uniqBy(teams, function (e) {
            return e.value;
          })
            ?.filter((a) => a?.value !== undefined)
            ?.sort((a, b) => {
              return a?.label.localeCompare(b?.label);
            });
          filterTeamData?.unshift({
            label: "All Teams",
            value: 0,
          });
          setTeamOptions(filterTeamData);
          setTeamDataSource(filterTeamData);

          // setTeamOptions(
          //   _.uniqBy([...teamOptions, ...filterTeamData], function (e) {
          //     return e?.value;
          //   })
          // );
          // setTeamDataSource(
          //   _.uniqBy([...teamOptions, ...filterTeamData], function (e) {
          //     return e?.value;
          //   })
          // );
          if (search.length > 0) {
            searchTeamFilter(search, filterTeamData);
          }
        } else {
          if (response?.body?.data?.success == false) {
          }
        }
      } else {
      }
    } catch (error) {}
  };

  const fetchBookKeeper = async () => {
    try {
      const sportId =
        props?.sportId === SPORTS.CRICKET
          ? 4
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? 12
          : props?.sportId === SPORTS.RUBGY_UNION
          ? 13
          : props?.sportId === SPORTS.BASKETBALL
          ? 10
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? 15
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? 9
          : props?.sportId === SPORTS.GOLF
          ? 16
          : props?.sportId === SPORTS.TENNIS
          ? 7
          : props?.sportId === SPORTS.BASEBALL
          ? 11
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? 17
          : props?.sportId === SPORTS.BOXING
          ? 6
          : props?.sportId === SPORTS.MMA
          ? 5
          : props?.sportId === SPORTS.SOCCER
          ? 8
          : 14;
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setBookKeeperData(response?.body?.data?.result);
        }
      }
    } catch (error) {}
  };

  const fetchIndividualTeamdata = async () => {
    try {
      const passApi =
        props?.sportData?.title === SPORTS.CRICKET ||
        props?.homeData === SPORTS.CRICKET
          ? `public/crickets/event/${props?.sportItem?.id}`
          : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
            props?.homeData === SPORTS.RUBGY_LEAGUE
          ? `public/rls/event/${props?.sportItem?.id}?SportId=12`
          : props?.sportData?.title === SPORTS.RUBGY_UNION ||
            props?.homeData === SPORTS.RUBGY_UNION
          ? `public/rls/event/${props?.sportItem?.id}?SportId=13`
          : props?.sportData?.title === SPORTS.BASKETBALL ||
            props?.homeData === SPORTS.BASKETBALL
          ? `public/nba/event/${props?.sportItem?.id}`
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? `public/afl/event/${props?.sportItem?.id}?SportId=15`
          : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
            props?.homeData === SPORTS.AUSTRALIAN_RULES
          ? `public/ar/event/${props?.sportItem?.id}?SportId=9`
          : props?.sportData?.title === SPORTS.GOLF ||
            props?.homeData === SPORTS.GOLF
          ? `public/golf/event/${props?.sportItem?.id}?SportId=16`
          : props?.sportData?.title === SPORTS.TENNIS ||
            props?.homeData === SPORTS.TENNIS
          ? `public/tennis/event/${props?.sportItem?.id}?SportId=7`
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? `public/baseball/event/${props?.sportItem?.id}?SportId=11`
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? `public/icehockey/event/${props?.sportItem?.id}?SportId=17`
          : props?.sportData?.title === SPORTS.BOXING ||
            props?.homeData === SPORTS.BOXING
          ? `public/boxing/event/${props?.sportItem?.id}?SportId=6`
          : props?.sportData?.title === SPORTS.MMA ||
            props?.homeData === SPORTS.MMA
          ? `public/mma/event/${props?.sportItem?.id}?SportId=5`
          : props?.sportData?.title === SPORTS.SOCCER ||
            props?.homeData === SPORTS.SOCCER
          ? `public/soccer/event/${props?.sportItem?.id}?SportId=8`
          : `public/rls/event/${props?.sportItem?.id}?SportId=14`;

      const response = await callApi(passApi, null, API_CONFIG.GET, null);

      if (response.body != null) {
        if (response.body?.status === 200) {
          let itemData = [response?.body?.data?.result];

          let fullData = [];
          itemData?.map(async (item) => {
            let passApi =
              props?.sportData?.title === SPORTS.CRICKET ||
              props?.homeData === SPORTS.CRICKET
                ? `public/crickets/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
                  props?.homeData === SPORTS.RUBGY_LEAGUE
                ? `public/rls/event/odd/${item?.id}?SportId=12`
                : props?.sportData?.title === SPORTS.RUBGY_UNION ||
                  props?.homeData === SPORTS.RUBGY_UNION
                ? `public/rls/event/odd/${item?.id}?SportId=13`
                : props?.sportData?.title === SPORTS.BASKETBALL ||
                  props?.homeData === SPORTS.BASKETBALL
                ? `public/nba/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                  props?.homeData === SPORTS.AMERICAN_FOOTBALL
                ? `public/afl/event/odd/${item?.id}?SportId=15`
                : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                  props?.homeData === SPORTS.AUSTRALIAN_RULES
                ? `public/ar/event/odd/${item?.id}?SportId=9`
                : props?.sportData?.title === SPORTS.GOLF ||
                  props?.homeData === SPORTS.GOLF
                ? `public/golf/event/odd/${item?.id}?SportId=16`
                : props?.sportData?.title === SPORTS.TENNIS ||
                  props?.homeData === SPORTS.TENNIS
                ? `public/tennis/event/odd/${item?.id}?SportId=7`
                : props?.sportData?.title === SPORTS.BASEBALL ||
                  props?.homeData === SPORTS.BASEBALL
                ? `public/baseball/event/odd/${item?.id}?SportId=11`
                : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                  props?.homeData === SPORTS.ICE_HOCKEY
                ? `public/icehockey/event/odd/${item?.id}?SportId=17`
                : props?.sportData?.title === SPORTS.BOXING ||
                  props?.homeData === SPORTS.BOXING
                ? `public/boxing/event/odd/${item?.id}?SportId=6`
                : props?.sportData?.title === SPORTS.MMA ||
                  props?.homeData === SPORTS.MMA
                ? `public/mma/event/odd/${item?.id}?SportId=5`
                : props?.sportData?.title === SPORTS.SOCCER ||
                  props?.homeData === SPORTS.SOCCER
                ? `public/soccer/event/odd/${item?.id}?SportId=8`
                : `public/rls/event/odd/${item?.id}?SportId=14`;
            const response = await callApi(passApi, null, API_CONFIG.GET, null);
            if (response.body != null) {
              if (response.body?.status === 200) {
                let itemData = response?.body?.data?.result;
                let newData =
                  itemData?.length > 0
                    ? props?.sportData?.title === SPORTS.CRICKET ||
                      props?.homeData === SPORTS.CRICKET
                      ? itemData?.[0]?.CricketOdds
                      : props?.sportData?.title === SPORTS.BASKETBALL ||
                        props?.homeData === SPORTS.BASKETBALL
                      ? itemData?.[0]?.NBAOdds
                      : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                        props?.homeData === SPORTS.AMERICAN_FOOTBALL
                      ? itemData?.[0]?.AFLOdds
                      : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                        props?.homeData === SPORTS.AUSTRALIAN_RULES
                      ? itemData?.[0]?.AROdds
                      : props?.sportData?.title === SPORTS.BASEBALL ||
                        props?.homeData === SPORTS.BASEBALL
                      ? itemData?.[0]?.BaseballOdds
                      : props?.sportData?.title === SPORTS.TENNIS ||
                        props?.homeData === SPORTS.TENNIS
                      ? itemData?.[0]?.TennisOdds
                      : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                        props?.homeData === SPORTS.ICE_HOCKEY
                      ? itemData?.[0]?.IceHockeyOdds
                      : props?.sportData?.title === SPORTS.BOXING ||
                        props?.homeData === SPORTS.BOXING
                      ? itemData?.[0]?.BoxingOdds
                      : props?.sportData?.title === SPORTS.MMA ||
                        props?.homeData === SPORTS.MMA
                      ? itemData?.[0]?.MMAOdds
                      : props?.sportData?.title === SPORTS.SOCCER ||
                        props?.homeData === SPORTS.SOCCER
                      ? itemData?.[0]?.SoccerOdds
                      : itemData?.[0]?.RLOdds
                    : [];
                // handleRemoveSeeAllOddsColumn(newData);
                // setoddsApiData(newData);
                item.MarketNumber = itemData?.length;
                item.homeTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((homeTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? homeTeam?.CricketTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? homeTeam?.NBATeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? homeTeam?.AFLTeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? homeTeam?.ARTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? homeTeam?.BaseballTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? homeTeam?.IceHockeyTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? homeTeam?.TennisTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? homeTeam?.BoxingTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? homeTeam?.MMATeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? homeTeam?.SoccerTeamId == item?.homeTeamId
                          : homeTeam?.RLTeamId == item?.homeTeamId;
                      })
                    : "";
                item.awayTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((awayTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? awayTeam?.CricketTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? awayTeam?.NBATeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? awayTeam?.AFLTeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? awayTeam?.ARTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? awayTeam?.BaseballTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? awayTeam?.TennisTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? awayTeam?.IceHockeyTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? awayTeam?.BoxingTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? awayTeam?.MMATeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? awayTeam?.SoccerTeamId == item?.awayTeamId
                          : awayTeam?.RLTeamId == item?.awayTeamId;
                      })
                    : "";
                setSportDetailsList([item]);
                setIsLoaderVisible(false);
                // setTimeout(() => {
                //   setIsEventLoading(false);
                // }, 3000);
              }
            }
          });
        }
      }
    } catch {
      setIsLoaderVisible(false);
      setRefreshing(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  return (
    <>
      {/* {isLoadervisible && (
        <View style={styles.loader}>
          <Loader color={Colors.black} />
        </View>
      )} */}
      <View style={styles.mainLoginView}>
        <DatePickerModel
          isVisible={isShowDatePicker}
          date={getUTCDate ? getUTCDate : new Date()}
          showModel={showDatePicker}
          onDateSelect={() => {
            setSelectedDate(moment(getUTCDate).format("YYYY-MM-DD"));
            showDatePicker(false);
          }}
          getUtcDate={(date) => {
            setGetUTCDate(date);
          }}
        />
        <SportModel
          isSearchVisible={true}
          search={search}
          onchangeText={(text: any) => {
            setSearch(text);
            searchFilterFunction(text, tournamentOptions);
          }}
          isVisible={isModalVisible}
          showModel={setIsModalVisible}
          data={filteredDataSource}
          onPressBack={() => onPressBack()}
          onNextPress={() => onNextPress()}
          renderItem={(item, index) => renderItem(item, index)}
        />
        <SportModel
          isSearchVisible={true}
          search={search}
          onchangeText={(text: any) => {
            setSearch(text);
            searchTeamFilter(text, teamOptions);
          }}
          renderItem={teamRenderItem}
          isVisible={isTeamModalVisible}
          showModel={setIsTeamModalVisible}
          data={teamDataSource}
          onPressBack={() => onTeamBackPress()}
          onNextPress={() => onTeamNextPress()}
        />
        {isLoadervisible && (
          <View style={styles.loader}>
            <Loader color={Colors.black} />
          </View>
        )}
        {!isLoadervisible && (
          <GolfOutRightList
            // marketItem={marketItem}
            // marketAllData={marketAllData}
            sponsoredId={sponsoredId}
            headerComponent={() => headerComponent()}
            data={sportListData}
            bookkeeperData={bookkeeperData}
            eventList={eventList}
            sportId={
              props?.sportData?.title
                ? props?.sportData?.title
                : props?.homeData
            }
            footerComponent={() => footerComponent()}
            onRefresh={onRefresh}
            refreshing={refreshing}
          />
        )}
      </View>
    </>
  );
}
