import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import {
  FlatList,
  Image,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import CardView from "react-native-cardview";
//component
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";
import Header from "../../../../component/HeaderComponent";

import TextHeaderTitle from "../../../../component/Text/index";
import { NAVIGATION } from "../../../../navigation";
//theme
import { Colors, CommonStyle, Images } from "../../../../theme";
import { translate } from "../../../../utils/Localize";
import commonStyles from "../../../../theme/commonStyle";
//style
import styles from "./style";
import {
  MarketAllData,
  MiamiOpen,
  MiamiTeamPoint,
  TennisSetList,
  TennisTeam,
  Tips,
} from "../../../../theme/dummyArray";
import {
  DownWhiteArrow,
  GrayArrow,
  RightArrow,
  UpWhiteArrow,
} from "../../../../theme/svg";
import { print_data } from "../../../../utils/Logs";
import PartnersList from "../../../../component/PartnersList";

const TennisMarkets = () => {
  const navigation = useNavigation();
  const [dataUpdated, setDataUpdated] = useState(false);
  const [matchDataUpdated, setMatchDataUpdated] = useState(false);
  const [statsExpand, setStatsExpand] = useState(false);
  const [detailsAllData, setDetailsAllData] = useState([]);
  const [allMarketsData, setAllMarketsData] = useState([]);
  const [Tipsdata, setTipsData] = useState(Tips);
  const [tennisTeams, setTennisTeam] = useState([]);
  const [miamiOpen, setMiamiOpen] = useState([]);
  const [miamDataUpdate, setMiamDataUpdate] = useState(false);

  useEffect(() => {
    let marketsData = [...MarketAllData];
    print_data(marketsData);
    setAllMarketsData(marketsData);
    setTennisTeam(TennisTeam);
    setMiamiOpen(MiamiOpen);

    MarketAllData.map((item, index) => {
      setDetailsAllData(item?.winSet);
    });
  }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const listHeader = () => {
    return (
      <Text style={styles.noRaceText}>{translate("NoDataAvailable")}</Text>
    );
  };

  const onMarketItemPress = (item, index) => {
    setDetailsAllData(item?.winSet);
    if (item.isExpanded) {
      item.isExpanded = false;
    } else {
      allMarketsData.forEach((item, _index) => {
        let obj = { ...item }; //Remember to copy Object
        if (_index === index) {
          obj.isExpanded = true;
        } else {
          obj.isExpanded = false;
        }
        allMarketsData[_index] = obj;
      });
    }
    setDataUpdated(!dataUpdated);
    setAllMarketsData(allMarketsData);
  };

  const onMatchItemPress = (item, index) => {
    if (item.isMatchExpanded) {
      item.isMatchExpanded = false;
    } else {
      detailsAllData.forEach((item, _index) => {
        let obj = { ...item }; //Remember to copy Object
        if (_index === index) {
          obj.isMatchExpanded = true;
        } else {
          obj.isMatchExpanded = false;
        }
        detailsAllData[_index] = obj;
      });
    }
    setMatchDataUpdated(!matchDataUpdated);
    setDetailsAllData(detailsAllData);
  };

  const onMiamiItemPress = (item, id) => {
    miamiOpen.forEach((item, _index) => {
      let obj = { ...item }; //Remember to copy Object
      if (_index == id) {
        obj.isSelected = !obj.isSelected;
      } else {
        obj.isSelected = false;
      }
      miamiOpen[_index] = obj;
    });
    setMiamDataUpdate(!miamDataUpdate);
    setMiamiOpen(miamiOpen);
  };

  const onTeamItemPress = (item, id) => {
    TennisTeam.map((item, index) => {
      if (index == id) {
        TennisTeam[index].selected = !TennisTeam[index].selected;
      } else {
        TennisTeam[index].selected = false;
      }
    });
    setTennisTeam([...TennisTeam]);
  };

  const renderTennisSetItem = (item: any, index: any) => {
    return (
      <View style={styles.tennisContainerView} key={index}>
        <Text style={styles.titleText} numberOfLines={1}>
          {item?.listTitle}
        </Text>
        <View style={CommonStyle.center}>
          <View style={CommonStyle.commonCeterView}>
            <Text style={styles.numberText}>{item?.SetsText}</Text>
          </View>
          <View style={CommonStyle.commonCeterView}>
            <Text style={styles.numberText}>{item?.PointsText}</Text>
          </View>
        </View>
      </View>
    );
  };

  const renderMiamiSetItem = (item: any, index: any) => {
    return (
      <>
        <View style={styles.miamiContainerView} key={index}>
          {item?.id !== 0 && item?.id !== 1 && item?.id !== 2 ? (
            <View style={styles.separatorStyleMiami} />
          ) : null}
          <View style={styles.tipsView}>
            <Text style={styles.titleMiamiText} numberOfLines={1}>
              {item?.listTitle}
            </Text>
            <View style={CommonStyle.center}>
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.numberText}>{item?.SetsText}</Text>
              </View>
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.numberText}>{item?.S1Text}</Text>
              </View>
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.numberText}>{item?.S2Text}</Text>
              </View>
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.numberText}>{item?.S3Text}</Text>
              </View>
            </View>
          </View>
          <View style={CommonStyle.centerView}>
            <Text style={styles.teamtextbett}>{item?.title} </Text>
            <Text style={styles.teamtextbett}>{item?.count} </Text>
          </View>
        </View>
      </>
    );
  };

  const rendermarketItem = (item: any, index: any) => {
    return (
      <>
        <Pressable
          style={styles.mainLoginView(item.id == 0)}
          onPress={() => onMarketItemPress(item, index)}
        >
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.todayTitleTextStyle}>{item?.title}</Text>
          </View>
          {item?.isExpanded ? (
            <UpWhiteArrow style={styles.arrowIcon} />
          ) : (
            <DownWhiteArrow style={styles.arrowIcon} />
          )}
        </Pressable>
        {item?.isExpanded && (
          <View>
            {item?.isExpanded && item?.title === "Stats & Insights" ? (
              <View style={styles.mainView}>
                <Text style={styles.statsTexts}>State & Insights</Text>
                <CardView
                  style={styles.winView}
                  cardElevation={5}
                  cardMaxElevation={4}
                >
                  <Text style={styles.textHead}>{translate("WhoWillWin")}</Text>
                  <View style={styles.flagView}>
                    <Image source={Images.ukFlag} style={styles.flagImage} />
                    <Text style={styles.votesText}>99 votes</Text>
                    <View style={styles.tipsFlex} />
                    <Text style={styles.votesText}>32 votes</Text>
                    <Image source={Images.ausflag} style={styles.flagImage} />
                  </View>
                  <View style={styles.flagView}>
                    <View style={styles.percentageView1}>
                      <Text style={styles.percentageText1}>76%</Text>
                    </View>
                    <View style={styles.percentengeWidth} />
                    <View style={styles.percentageView2}>
                      <Text style={styles.percentageText2}>24%</Text>
                    </View>
                  </View>
                </CardView>
                <CardView
                  style={styles.winView}
                  cardElevation={5}
                  cardMaxElevation={4}
                >
                  <Text style={styles.tipsText}>Tips & Match Insights</Text>
                  <FlatList
                    data={Tipsdata}
                    scrollEnabled={false}
                    showsVerticalScrollIndicator={false}
                    renderItem={({ item, index }) =>
                      renderTipsItems(item, index)
                    }
                    style={styles.bottomView}
                    ListEmptyComponent={() => listHeader()}
                    keyExtractor={(item, index) => index.toString()}
                    extraData={Tipsdata}
                  />
                </CardView>
                <CardView
                  style={styles.winView}
                  cardElevation={5}
                  cardMaxElevation={4}
                >
                  <Text style={styles.tipsText}>2023 & 2022 Results</Text>
                  <FlatList
                    data={tennisTeams}
                    scrollEnabled={false}
                    showsVerticalScrollIndicator={false}
                    renderItem={({ item, index }) =>
                      renderTennisTeam(item, index)
                    }
                    style={styles.resultsView}
                    ListEmptyComponent={() => listHeader()}
                    keyExtractor={(item, index) => index.toString()}
                    extraData={tennisTeams}
                  ></FlatList>
                  <Text style={styles.miamiTexts}>Miami Open</Text>
                  <FlatList
                    data={miamiOpen}
                    scrollEnabled={false}
                    showsVerticalScrollIndicator={false}
                    renderItem={({ item, index }) =>
                      renderMiamiOpne(item, index)
                    }
                    style={styles.bottomView}
                    ListEmptyComponent={() => listHeader()}
                    keyExtractor={(item, index) => index.toString()}
                    extraData={miamDataUpdate}
                  ></FlatList>
                  <Text style={styles.textHead}>Indian Wells</Text>
                  <View style={styles.moreView}>
                    <Text style={styles.moreText}>More</Text>
                    <DownWhiteArrow
                      style={styles.arrowIcon}
                      stroke={Colors.grayLight}
                    />
                  </View>
                </CardView>
              </View>
            ) : (
              <FlatList
                data={detailsAllData}
                scrollEnabled={false}
                showsVerticalScrollIndicator={false}
                renderItem={({ item, index }) => renderMatchItem(item, index)}
                style={styles.bottomView}
                ListEmptyComponent={() => listHeader()}
                keyExtractor={(item, index) => index.toString()}
                extraData={matchDataUpdated}
              />
            )}
          </View>
        )}
      </>
    );
  };
  const renderTipsItems = (item: any, index: any) => {
    return (
      <View
        key={index}
        style={
          (index = 0
            ? styles.firstItem
            : index == 1
            ? styles.secondItem
            : styles.tipsView)
        }
      >
        <View>{item?.iconImage}</View>
        <View style={commonStyles.commonFlex}>
          <View style={styles.titelHeadView}>
            <Text style={styles.tipsTitle}>{item?.title}</Text>
            <Text style={styles.descriptionPriceText}>{item?.text}</Text>
          </View>
          <Text style={styles.descriptionText}>{item?.description}</Text>
        </View>
        {index == 1 && <View style={styles.bottomidth} />}
      </View>
    );
  };
  const renderTennisTeam = (item: any, index: any) => {
    return (
      <>
        <Pressable
          style={styles.teamView}
          onPress={() => onTeamItemPress(item, index)}
        >
          <View style={styles.tipsView}>
            <View style={styles.arrowView}>
              {item?.selected ? (
                <RightArrow style={styles.arrow} />
              ) : (
                <GrayArrow style={styles.arrow} />
              )}
            </View>
            <Text style={styles.titelText}>{item?.titel}</Text>
          </View>
        </Pressable>
      </>
    );
  };
  const renderMiamiOpne = (item: any, index: any) => {
    return (
      <>
        <Pressable
          style={styles.miamiViewDrop}
          onPress={() => onMiamiItemPress(item, index)}
        >
          <View style={styles.vsView}>
            <Image source={item?.imageIcon} style={styles.flagImage} />
            {/* <View style={commonStyles.alignCenterView}> */}
            <Text style={styles.teamTitleText}>{item?.title}</Text>
          </View>
          {/* </View> */}
          <View style={styles.rnumberView}>
            <Text style={styles.rText}>{item?.rText}</Text>
            <Text style={styles.winText}>{item?.winText}</Text>
          </View>
          {item?.isSelected ? (
            <UpWhiteArrow style={styles.dropArrowIcon} stroke={Colors.green} />
          ) : (
            <DownWhiteArrow
              style={styles.dropArrowIcon}
              stroke={Colors.green}
            />
          )}
        </Pressable>
        <View style={styles.separatorStyleGray} />
        {item?.isSelected && item?.id === 2 && (
          <View style={styles.hardCountContainer}>
            <View style={CommonStyle.centerView}>
              <Text style={styles.dateText}>Thu 23 March - Miami Open</Text>
              <Text style={styles.dateText}>Hard Court</Text>
            </View>
            <View style={styles.setTopViewData}>
              <View style={styles.pointflex} />
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.setTitleText}>F</Text>
              </View>
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.setTitleText}>S1</Text>
              </View>
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.setTitleText}>S2</Text>
              </View>
              <View style={CommonStyle.commonCeterView}>
                <Text style={styles.setTitleText}>S3</Text>
              </View>
            </View>
            <FlatList
              data={MiamiTeamPoint}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
              renderItem={({ item, index }) => renderMiamiSetItem(item, index)}
              ListEmptyComponent={() => listHeader()}
              style={styles.bottomView}
              keyExtractor={(item, index) => index.toString()}
            />
          </View>
        )}
      </>
    );
  };

  const renderTennisOddsItem = (item: any, index: any) => {
    return (
      <View key={index} style={styles.horizontalContainer}>
        <View style={CommonStyle.commonRow}>
          <Text style={styles.listTitle} numberOfLines={1}>
            {item?.listTitle}
          </Text>
          <View style={CommonStyle.commonFlex} />
        </View>
        <View style={styles.centerView}>
          <View style={styles.oddsView}>
            <Text style={styles.tennisTitleText} numberOfLines={1}>
              {item?.odds}
            </Text>
          </View>
          <Image source={item?.imageIcon} style={styles.iconStyle} />
        </View>
      </View>
    );
  };

  const renderMatchItem = (item: any, index: any) => {
    return (
      <>
        <Pressable
          style={styles.descriptionExpandContainer}
          onPress={() => onMatchItemPress(item, index)}
        >
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.descriptionTitleTextStyle}>{item?.title}</Text>
          </View>
          {item?.isMatchExpanded ? (
            <UpWhiteArrow style={styles.arrowIcon} stroke={Colors.black} />
          ) : (
            <DownWhiteArrow style={styles.arrowIcon} stroke={Colors.black} />
          )}
        </Pressable>
        {item?.isMatchExpanded && (
          <FlatList
            data={TennisSetList}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => renderTennisOddsItem(item, index)}
            ListEmptyComponent={() => listHeader()}
            keyExtractor={(item, index) => index.toString()}
          />
        )}
      </>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowSmartBIcon={true}
        isShowNewsBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPress={() => {}}
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalView}>
          <View style={commonStyles.centerView}>
            <Text style={styles.textStyle}>
              Adrian Mannarino v/s Christopher Eubanks
            </Text>
            <View style={styles.liveContainer}>
              <Text style={styles.liveText}>{translate("LiveText")}</Text>
            </View>
          </View>
        </View>
        <View style={styles.pointsContainer}>
          <View style={styles.setTopView}>
            <View style={styles.flex} />
            <View style={CommonStyle.commonCeterView}>
              <Text style={styles.setTitleText}>1st</Text>
            </View>
            <View style={CommonStyle.commonCeterView}>
              <Text style={styles.setTitleText}>Points</Text>
            </View>
          </View>
          <FlatList
            data={TennisSetList}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => renderTennisSetItem(item, index)}
            style={styles.bottomView}
            ListEmptyComponent={() => listHeader()}
            keyExtractor={(item, index) => index.toString()}
          />
        </View>
        {/* <View style={styles.dropdownContainer}>
          <Text style={styles.statsText}>Stats & Insights</Text>
        </View> */}

        {/* {statsExpand && (
          <View>
            <Text>helo</Text>
          </View>
        )} */}
        <FlatList
          data={allMarketsData}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.containerStyle}
          renderItem={({ item, index }) => rendermarketItem(item, index)}
          style={styles.bottomView}
          ListEmptyComponent={() => listHeader()}
          keyExtractor={(item, index) => index.toString()}
          extraData={dataUpdated}
        />
        <View style={commonStyles.commonFlex}>
          <View style={styles.textCenter}>
            <TextHeaderTitle
              title={translate("OurPartners")}
              textStyle={styles.sportStyle}
            />
          </View>
          <View style={styles.partnerListBottom}>
            <PartnersList />
          </View>
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
};

export default TennisMarkets;

// export const MatchAllData = [
//   {
//     id: 0,
//     SubTitle: Images.racingIcon,
//     winSet: [],
//     isExpanded: true,
//   },
//   {
//     id: 1,
//     SubTitle: Images.racingIcon,

//     isExpanded: true,
//   },
//   {
//     id: 2,
//     SubTitle: Images.whiteGreyHoundsIcon,
//     title: "Set 2 Game Markets",
//     isExpanded: true,
//   },
//   {
//     id: 3,
//     SubTitle: Images.whiteHarnessIcon,
//     title: "Set Correct Score Markets",
//     isExpanded: true,
//   },
//   {
//     id: 4,
//     SubTitle: Images.whiteHarnessIcon,
//     title: "Set Correct Score Markets",
//     isExpanded: true,
//   },
//   {
//     id: 5,
//     SubTitle: Images.whiteHarnessIcon,
//     title: "Set Markets",
//     isExpanded: true,
//   },
//   {
//     id: 5,
//     SubTitle: Images.whiteHarnessIcon,
//     title: "Total Games Markets",
//     isExpanded: true,
//   },
// ];
