import React, { createRef, useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  FlatList,
  Pressable,
  Image,
  Keyboard,
  Platform,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import DropDownPicker from "react-native-dropdown-picker";
import KeyboardSpacer from "react-native-keyboard-spacer";
import _ from "lodash";
//component
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../component/AppStatusBar";
import Header from "../../../../component/HeaderComponent";
import TextHeaderTitle from "../../../../component/Text/index";
import Button from "../../../../component/Button";
import CustomTextInput from "../../../../component/TextInput";
import ErrorText from "../../../../component/ErrorText";
import Loader from "../../../../component/ProgressBar";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";
//theme
import { Colors, Images, Metrics } from "../../../../theme";
import commonStyles from "../../../../theme/commonStyle";
import { InterestedList } from "../../../../theme/dummyArray";
import { CheckBox, DownArrow, UpArrow } from "../../../../theme/svg";
//utils
import { translate } from "../../../../utils/Localize";
import { print_data } from "../../../../utils/Logs";
import { APP_CONSTANT } from "../../../../utils/appConstant";
import {
  isConnectionAvailable,
  showToast,
} from "../../../../utils/commonFunction";
//api
import API_CONFIG from "../../../../api/api_url";
import { callApi } from "../../../../api";
//style
import styles from "./style";
//navigation
import { NAVIGATION } from "../../../../navigation";

const AdvertisingScreen = () => {
  const navigation = useNavigation();
  const userNameRef = createRef();
  const companyNameRef = createRef();
  const abnRef = createRef();
  const useMobileRef = createRef();
  const userEmailRef = createRef();
  const [userName, setUserName] = useState("");
  const [isShowNameError, showNameError] = useState(false);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [userPhoneNumber, setUserPhoneNumber] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [isShowEmailError, showEmailError] = useState(false);
  const [emailErrorText, setEmailErrorText] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [isShowCompanyError, showCompanyError] = useState(false);
  const [abnName, setAbnName] = useState("");
  const [isShowMobileError, showMobileError] = useState(false);
  const [userMessage, setUserMessage] = useState("");
  const [stateCount, setStateCount] = useState(0);
  const [stateList, setStateList] = useState([]);
  const [stateOpen, setStateOpen] = useState(false);
  const [selectedState, setSelectedState] = useState("");
  const [isDropDownBorder, setIsDropDownBorder] = useState(false);
  const [isStateErrorShow, setIsStateErrorShow] = useState(false);
  const [statePage, setStatepage] = useState(0);
  const [data, setData] = useState([]);
  const [selectedStateName, setSelectedStateName] = useState("");
  const [listData, setListData] = useState(null);
  const [showSucess, setShowSucess] = useState(false);
  const [sucessMessage, setsucessMessage] = useState("");
  const [interstedVisible, setInterstedVisible] = useState(false);

  useEffect(() => {
    let interstedData = [...InterestedList];
    interstedData.forEach((item, _index) => {
      item.isSelected = false;
    });
    setData(interstedData);
  }, []);

  useEffect(() => {
    setIsLoaderVisible(true);
    callGetStateApi(statePage);
  }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const itemSelected = (item, index) => {
    let temp = [...InterestedList];
    temp[index].isSelected = !item.isSelected;
    setData(temp);
    const selectedList = InterestedList.filter((item) => {
      return item.isSelected;
    });
    let sportOrEvent = [];
    selectedList.map((item, index) => {
      if (item?.isSelected == false) {
        setInterstedVisible(true);
      } else {
        setInterstedVisible(false);
      }
      let data = item?.title;
      sportOrEvent.push(data);
    });
    setListData(sportOrEvent);
  };

  const onSendPress = async () => {
    Keyboard.dismiss();
    let is_validate = true;
    if (await isConnectionAvailable()) {
      if (selectedState?.length == 0 || selectedState == "- Select -") {
        is_validate = false;
        setIsStateErrorShow(true);
      }
      if (userName?.trim().length == 0) {
        is_validate = false;
        showNameError(true);
      }
      if (companyName?.trim().length == 0) {
        is_validate = false;
        showCompanyError(true);
      }
      if (userPhoneNumber?.trim().length == 0) {
        is_validate = false;
        showMobileError(true);
      }
      if (userEmail?.length == 0) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("FieldError"));
      } else if (!APP_CONSTANT.EMAIL_PATTERN.test(userEmail)) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("EmailNotValidError"));
      }
      if (data.every(({ isSelected }) => !isSelected)) {
        is_validate = false;
        setInterstedVisible(true);
      } else {
        setInterstedVisible(false);
      }
      if (is_validate) {
        setIsLoaderVisible(true);
        callHubSportApi();
      }
    } else {
      showToast(translate("InternetConnection"));
    }
  };

  const callGetStateApi = async (statePage) => {
    try {
      const response = await callApi(
        API_CONFIG.GETSTATE + statePage,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let stateAPIList = response?.body?.data?.result?.rows;

          const itemData: any = [];
          stateAPIList.map((item: any, index: any) => {
            itemData.push({
              label: item?.state,
              value: item?.id,
              key: index,
            });
          });

          setStateList(_.unionBy(stateList, itemData));
          setStateCount(Math.ceil(response?.body?.data?.result?.count / 20));

          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const callHubSportApi = async () => {
    var param_data = {
      fullName: userName,
      companyName: companyName,
      abnacn: abnName,
      phoneNumber: userPhoneNumber,
      email: userEmail,
      state: selectedStateName,
      message: userMessage,
      interestedIn: listData,
    };
    try {
      const response = await callApi(
        API_CONFIG.HUBSPORT,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.data?.status == true
        ) {
          setShowSucess(true);
          setsucessMessage(response?.body?.data?.message);
          setTimeout(() => {
            setShowSucess(false);
            setUserName("");
            setCompanyName("");
            setAbnName("");
            setUserPhoneNumber("");
            setUserEmail("");
            setSelectedStateName("- Select -");
            setSelectedState("- Select -");
            setUserMessage("");
            let interstedData = [...InterestedList];
            interstedData.forEach((item, _index) => {
              item.isSelected = false;
            });
            setData(interstedData);
            setListData(null);
          }, 5000);
          setIsLoaderVisible(false);
        } else {
          if (response?.body?.data?.status == false) {
            setTimeout(() => {
              showToast(response?.body?.data?.message);
            }, 10);
            setIsLoaderVisible(false);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const renderItem = (item, index) => {
    return (
      <View style={styles.interstedcontainer}>
        <Pressable key={index} onPress={() => itemSelected(item, index)}>
          {item.isSelected ? (
            <Image
              source={Images.selectedCheckBox}
              style={styles.selectedCheckboxStyle}
            />
          ) : (
            <CheckBox style={styles.selectedCheckboxStyle} />
          )}
        </Pressable>
        <Text style={styles.advText}>{item.title}</Text>
      </View>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("AdvertisingEnquiries")}
            textStyle={styles.textStyle}
          />
          <Text style={styles.nextTopicTextStyle}>
            {translate("AdvertiseDetails")}
          </Text>
          <View style={styles.listTitle}>
            <Text style={styles.advertisText}>
              {translate("GeneralAdvertising")}
            </Text>
            <View style={styles.emailContainer}>
              <Text style={styles.SmartbEmailStyle}>
                {translate("SmartbEmail")}
              </Text>
              <Text style={styles.CodeNumberStyle}>
                {translate("CodeNumber")}
              </Text>
            </View>
          </View>
          {/* <View style={styles.downloadContainer}>
            <DownloadIcon style={styles.downloadIcon} />
            <Text style={styles.MediaText}>{translate("MediaPack")}</Text>
          </View>
          <View style={styles.downloadContainer}>
            <DownloadIcon style={styles.downloadIcon} />
            <Text style={styles.MediaText}>{translate("RateCard")}</Text>
          </View>
          <View style={styles.downloadContainer}>
            <DownloadIcon style={styles.downloadIcon} />
            <Text style={styles.MediaText}>{translate("DigitalMedia")}</Text>
          </View> */}
        </View>
        <View style={styles.advertiseContainer}>
          <Text style={styles.advertiseText}>{translate("AdvertiseNow")}</Text>
          <CustomTextInput
            ref={userNameRef}
            textInputStyle={styles.textInputStyle}
            placeholderTextColor={Colors.black}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("FullNameAdd")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.inputTextStyle}
            value={userName}
            returnKeyType={"next"}
            onChangeText={(text: string) => {
              setUserName(text);
              showNameError(false);
            }}
            onSubmitEditing={() => {
              if (companyNameRef) {
                companyNameRef.current?.focus();
              }
            }}
          />
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("FieldError")}
              is_visible={isShowNameError}
            />
          </View>
          <CustomTextInput
            ref={companyNameRef}
            textInputStyle={styles.textInputStyle}
            placeholderTextColor={Colors.black}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("CompanyName")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.inputTextStyle}
            value={companyName}
            returnKeyType={"next"}
            onChangeText={(text: string) => {
              setCompanyName(text);
              showCompanyError(false);
            }}
            onSubmitEditing={() => {
              if (abnRef) {
                abnRef.current?.focus();
              }
            }}
          />
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("FieldError")}
              is_visible={isShowCompanyError}
            />
          </View>
          <CustomTextInput
            ref={abnRef}
            textInputStyle={styles.textInputStyle}
            placeholderTextColor={Colors.black}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("AbnText")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.inputTextStyle}
            value={abnName}
            keyboardType={"number-pad"}
            returnKeyType={"next"}
            onChangeText={(text: string) => {
              setAbnName(text);
            }}
            onSubmitEditing={() => {
              if (useMobileRef) {
                useMobileRef.current?.focus();
              }
            }}
          />
          <View style={styles.numberStyle}>
            <CustomTextInput
              textInputStyle={styles.textInputStyle}
              ref={useMobileRef}
              containerStyle={commonStyles.inputTextContainerStyle}
              placeholderTextColor={Colors.black}
              lableText={translate("MobileNumber")}
              lableTextStyle={styles.labelTextStyle}
              inputTextStyle={styles.inputTextStyle}
              value={userPhoneNumber}
              maxLength={12}
              keyboardType={"number-pad"}
              returnKeyType={"next"}
              onChangeText={(text: string) => {
                setUserPhoneNumber(text);
                showMobileError(false);
              }}
              onSubmitEditing={() => {
                if (userEmailRef) {
                  userEmailRef.current.focus();
                }
              }}
            />
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("FieldError")}
                is_visible={isShowMobileError}
              />
            </View>
          </View>
          <CustomTextInput
            ref={userEmailRef}
            textInputStyle={styles.textInputStyle}
            placeholderTextColor={Colors.white}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("EmailAdd")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.inputTextStyle}
            value={userEmail}
            returnKeyType={"next"}
            keyboardType={"email-address"}
            onChangeText={(text: string) => {
              setUserEmail(text);
              showEmailError(false);
            }}
          />
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={emailErrorText}
              is_visible={isShowEmailError}
            />
          </View>
          <View style={styles.stateView}>
            <Text style={styles.titleTextStyle}>{translate("StateAdd")}</Text>
            <DropDownPicker
              onSelectItem={(item) => setSelectedStateName(item?.label)}
              textStyle={styles.labelSelectStyle}
              open={stateOpen}
              value={selectedState}
              labelExtractor={({ label }) => label}
              valueExtractor={({ selectedState }) => selectedState}
              items={stateList}
              scrollViewProps={{
                nestedScrollEnabled: true,
                showsVerticalScrollIndicator: false,
                showsHorizontalScrollIndicator: false,
                onMomentumScrollEnd(event) {
                  if (stateCount !== Math.ceil(statePage / 20)) {
                    callGetStateApi(statePage + 20);
                    setStatepage(statePage + 20);
                  }
                },
              }}
              setOpen={(isOpen) => {
                setStateOpen(isOpen);
              }}
              listMode="SCROLLVIEW"
              dropDownContainerStyle={styles.dropDownContainerStyle}
              setValue={setSelectedState}
              onChangeValue={(selectedState) => {
                setIsDropDownBorder(false);
                setIsStateErrorShow(false);
              }}
              setItems={setStateList}
              dropDownDirection="BOTTOM"
              autoScroll={true}
              style={
                isDropDownBorder
                  ? styles.dropDownStyleRed
                  : styles.dropDownStyleWhite
              }
              placeholder={translate("PlaceHolder")}
              ArrowUpIconComponent={({}) => (
                <UpArrow
                  width={Metrics.rfv(11)}
                  height={Metrics.rfv(6)}
                  fill={Colors.white}
                />
              )}
              ArrowDownIconComponent={({}) => (
                <DownArrow
                  width={Metrics.rfv(11)}
                  height={Metrics.rfv(6)}
                  fill={Colors.white}
                />
              )}
              selectedItemContainerStyle={styles.selectedItemContainerStyle}
              placeholderStyle={styles.dropDownPlaceholder}
            />
          </View>
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("FieldError")}
              is_visible={isStateErrorShow}
            />
          </View>

          <Text style={styles.interestedText}>
            {translate("InterestedInText")}
          </Text>

          <FlatList
            data={data}
            contentContainerStyle={styles.contentContainerStyle}
            renderItem={({ item, index }) => renderItem(item, index)}
            keyExtractor={(item, index) => index.toString()}
          />

          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("InteresstedField")}
              is_visible={interstedVisible}
            />
          </View>
          <CustomTextInput
            keyboardType={"email-address"}
            multiLine={true}
            textInputStyle={styles.textMessageInputStyle}
            placeholderTextColor={Colors.white}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("Message")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.messageInputTextStyle}
            value={userMessage}
            returnKeyType={"done"}
            onChangeText={(text: string) => {
              setUserMessage(text);
            }}
            onSubmitEditing={() => onSendPress()}
          />
          {showSucess ? (
            <View style={styles.sucessViewStyle}>
              <Text style={styles.sucessText}>{sucessMessage}</Text>
            </View>
          ) : null}
          <Button
            disabled={false}
            onPress={() => onSendPress()}
            title={translate("Send")}
            color={Colors.white}
            fontSize={Metrics.rfv(16)}
            backgroundColor={Colors.linearColor2}
          />
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={styles.bottomView} />
          )}
        </View>
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default AdvertisingScreen;
