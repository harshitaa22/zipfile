import React from "react";
import { ScrollView, View } from "react-native";
import AppSafeAreaView from "../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../component/AppStatusBar";
import Header from "../../../../../component/HeaderComponent/index";
import PartnersList from "../../../../../component/PartnersList/index";
import RacingList from "../../../../../component/RacingList/index";
import SportList from "../../../../../component/SportsList/index";
import TextHeaderTitle from "../../../../../component/Text/index";
import { NAVIGATION } from "../../../../../navigation";
import {
  GreyHoundData,
  HarnessData,
  PartnersData,
  RacingData,
  SportsData,
} from "../../../../../theme/dummyArray";
import { Colors, Images } from "../../../../../theme/index";
import commonStyles from "../../../../../theme/commonStyle";
import styles from "./style";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../utils/Localize";
import CommonHeaderComponent from "../../../../../component/CommonHeaderComponent";

type Props = {
  loading?: boolean;
  navigation?: any;
};

export default function RacingTab(props: Props) {
  const navigation = useNavigation();

  const commonDATA_RACING = [
    { data: RacingData, topicTitle: translate("NextToJumpHorses") },
  ];

  const commonDATA_RACING_OTHER = [
    { data: GreyHoundData, topicTitle: translate("NextToJumpGreyhounds") },
    { data: HarnessData, topicTitle: translate("NextToJumpHarness") },
  ];

  const commonDATA_SPORTS = [
    { data: SportsData, topicTitle: translate("UpcomingMatches") },
    { data: SportsData, topicTitle: translate("UpcomingMatches") },
    { data: SportsData, topicTitle: translate("UpcomingMatches") },
    { data: SportsData, topicTitle: translate("UpcomingMatches") },
  ];

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  // const onProfilePress = () => {
  //   navigation.navigate(NAVIGATION.PROFILE);
  // };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("Racing")}
            textStyle={styles.textStyle}
          />
          {commonDATA_RACING.map((item, index) => {
            return (
              <View key={index}>
                <RacingList
                  data={item.data}
                  topicTitle={item.topicTitle}
                  onPress={() =>
                    props.navigation.navigate(NAVIGATION.SEE_ALL_PAGE)
                  }
                />
              </View>
            );
          })}

          {commonDATA_RACING_OTHER.map((item, index) => {
            return (
              <View key={index}>
                <RacingList data={item.data} topicTitle={item.topicTitle} />
              </View>
            );
          })}

          <TextHeaderTitle
            title={translate("Sports")}
            textStyle={styles.sportStyle}
          />
          {commonDATA_SPORTS.map((item, index) => {
            return (
              <View key={index}>
                <SportList data={item.data} topicTitle={item.topicTitle} />
              </View>
            );
          })}

          <View style={styles.textCenter}>
            <TextHeaderTitle
              title={translate("OurPartners")}
              textStyle={styles.sportStyle}
            />
          </View>
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}
