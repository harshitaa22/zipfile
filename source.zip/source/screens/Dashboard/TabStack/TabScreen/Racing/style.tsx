import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../../../../theme/index";

export default StyleSheet.create({
  textCenter: {
    alignSelf: "center",
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(20),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  secondBannerStyle: {
    width: "100%",
    height: Metrics.rfv(63),
    resizeMode: "contain",
  },
});
