import React, { useEffect, useState } from "react";
import { FlatList, Image, Linking, Pressable, Text, View } from "react-native";

import { useNavigation } from "@react-navigation/native";
import moment from "moment";
import LinearGradient from "react-native-linear-gradient";
import { API_URL } from "../../../../../../../env.json";
import { callApi } from "../../../../../../api";
import API_CONFIG from "../../../../../../api/api_url";
import ImageLoad from "../../../../../../component/ImageLoad";
import Loader from "../../../../../../component/ProgressBar";
import SingleRaceItem from "../../../../../../component/RaceItemComponent";
import CustomTextInput from "../../../../../../component/TextInput";
import { Colors, Images, Metrics } from "../../../../../../theme";
import commonStyles from "../../../../../../theme/commonStyle";
import { BlackSmallUpArrow } from "../../../../../../theme/svg";
import { translate } from "../../../../../../utils/Localize";
import { print_data } from "../../../../../../utils/Logs";
import styles from "./style";

export default function ExoticsTab(props: any) {
  const navigation = useNavigation();
  const [refreshing, setRefreshing] = useState(false);
  const [runnerData, setRunnerData] = useState([]);
  const [isOrder, setIsOrder] = useState(false);
  const [isAllExpand, setIsAllExpand] = useState(false);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [isSeeAll, setSeeAll] = useState(false);
  const [bookkeeperData, setBookKeeperData] = useState([]);
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  useEffect(() => {
    setRunnerData(props?.runnerData);
  }, []);

  useEffect(() => {
    fetchBookKeeper();
  }, []);

  const onRacingPress = (item, index) => {
    if (item?.isExpanded) {
      item.isExpanded = false;
    } else {
      for (let i = 0; i < runnerData.length; i++) {
        if (i === index) {
          runnerData[i].isExpanded = true;
        } else {
          runnerData[i].isExpanded = false;
        }
      }
    }
    setDataUpdated(!dataUpdated);
    setRunnerData(runnerData);
  };

  const onRunnerPress = () => {
    setIsOrder(!isOrder);
    if (isOrder) {
      const runnerDescending = [...runnerData].sort((a, b) => a?.id - b?.id);
      setRunnerData(runnerDescending);
    } else {
      const runnerDescending = [...runnerData].sort((a, b) => b?.id - a?.id);
      setRunnerData(runnerDescending);
    }
  };

  const onExpandAllPress = () => {
    if (isAllExpand) {
      for (let i = 0; i < runnerData.length; i++) {
        runnerData[i].isExpanded = false;
      }
    } else {
      for (let i = 0; i < runnerData.length; i++) {
        runnerData[i].isExpanded = true;
      }
    }
    setIsAllExpand(!isAllExpand);
  };

  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(props?.sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body?.status === 200) {
        print_data(response);
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsCurrentBestContainer}
      >
        <Text style={styles.subLeftImageRight1}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };

  const oddsIcon = (BookKeeperId: number, type: any) => {
    let icon = bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    print_data(icon);
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
        }}
        style={styles.oddsImageContainer}
      >
        {BookKeeperId === 11 ? (
          <Image style={styles.oddsImageIcon} source={Images.topSportOdds} />
        ) : (
          <ImageLoad
            style={styles.oddsImageIcon}
            resizeMode={"contain"}
            source={
              iconData?.small_logo?.includes("uploads")
                ? API_URL + "/" + iconData?.small_logo
                : iconData?.small_logo
            }
          />
        )}
      </Pressable>
    );
  };

  const fetchBookKeeper = async () => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          setBookKeeperData(response?.body?.data?.result);
        }
      }
    } catch (error) {}
  };

  print_data(props?.exoticsData);

  const renderItem = (item: any, index: any) => {
    return (
      <>
        {item?.runnerNumber === 1 && (
          <>
            <View style={styles.exoticsView} />
            <LinearGradient
              style={styles.racingView}
              colors={[Colors.linearColor1, Colors.linearColor2]}
            >
              <Text style={styles.raceText}>
                {translate("Finalraceresults")}
              </Text>
            </LinearGradient>

            <View style={styles.resultsView}>
              <Text style={styles.dateText}>
                {moment(props?.raceResultData?.updatedAt)
                  .utc(timezone)
                  .local()
                  .format("DD/MM/YYYY")}
                {","}{" "}
                {moment
                  .utc(props?.raceResultData?.updatedAt)
                  .local()
                  .format("hh:mm A")}
              </Text>
              {props?.exoticsData?.length > 0 ? (
                props?.exoticsData?.map((item, index) => {
                  const positionsArray = item?.positions
                    ? Array.isArray(item?.positions)
                      ? item?.positions
                      : [item?.Positions]
                    : Array.isArray(item?.Positions)
                    ? item?.Positions
                    : [item?.Positions];

                  return (
                    <View key={index}>
                      <View style={styles.winMainContainer}>
                        <FlatList
                          horizontal
                          data={positionsArray}
                          scrollEnabled={false}
                          showsHorizontalScrollIndicator={false}
                          renderItem={({ item, index }) => {
                            return (
                              <View
                                style={styles.winpointContainer}
                                key={index}
                              >
                                <View
                                  style={styles.PointView(
                                    item?.Position == 1 || item?.position == 1
                                  )}
                                >
                                  <Text style={styles.winText}>
                                    {item?.position
                                      ? Number(item?.position) === 1
                                        ? "1st"
                                        : Number(item?.position) === 2
                                        ? "2nd"
                                        : Number(item?.position) === 3
                                        ? "3rd"
                                        : `${Number(item?.position)}th`
                                      : Number(item?.Position) === 1
                                      ? "1st"
                                      : Number(item?.Position) === 2
                                      ? "2nd"
                                      : Number(item?.Position) === 3
                                      ? "3rd"
                                      : `${Number(item?.Position)}th`}
                                  </Text>
                                </View>
                                <View style={styles.WinnerText}>
                                  <Text style={styles.oddsText}>
                                    {item?.RunnerNumber
                                      ? item?.RunnerNumber
                                      : item?.runner_number}
                                  </Text>
                                </View>
                              </View>
                            );
                          }}
                          keyExtractor={(item, index) => index.toString()}
                        />

                        {/* <View style={styles.winpointContainer}>
                          <View style={styles.PointView}>
                            <Text style={styles.winText}>1st</Text>
                          </View>
                          <View style={styles.WinnerText}>
                            <Text style={styles.oddsText}>1</Text>
                          </View>
                        </View>
                        <View style={styles.widthStyle} />
                        <View style={styles.winpointContainer}>
                          <View style={styles.secondPointView}>
                            <Text style={styles.winText}>2nd</Text>
                          </View>
                          <View style={styles.WinnerText}>
                            <Text style={styles.oddsText}>12</Text>
                          </View>
                        </View> */}
                      </View>
                      <View style={styles.winMainContainer}>
                        <View style={styles.winContainer}>
                          <View style={styles.winTextContiner}>
                            <Text style={styles.winPointText}>
                              {translate("BetType")}
                            </Text>
                          </View>
                          <View style={styles.iconContainerStyle}>
                            <Text style={styles.extraText}>
                              {item?.product_name
                                ? item?.product_name
                                : item?.ProductName}{" "}
                              ({item?.tote ? item?.tote : item?.Tote})
                            </Text>
                          </View>
                          {oddsIcon(3, "header")}
                        </View>

                        <View style={styles.bestWidthStyle} />
                        <View style={styles.winContainer}>
                          <View style={styles.winTextContiner}>
                            <Text style={styles.winPointText}>
                              {translate("Dividend")}
                            </Text>
                          </View>
                          <View style={styles.iconContainerStyle}>
                            {fetchClickableOdds(
                              item?.dividend ? item?.dividend : item?.Dividend,
                              3,
                              "header"
                            )}
                          </View>
                          {oddsIcon(3, "header")}
                        </View>
                      </View>
                      <View style={styles.winSeparatorComponent} />
                    </View>
                  );
                })
              ) : (
                <Text style={styles.noRaceText}>
                  {translate("NoDataAvailable")}
                </Text>
              )}
            </View>
            {/* );
            })} */}
            <LinearGradient
              style={styles.racingView}
              colors={[Colors.linearColor1, Colors.linearColor2]}
            >
              <Text style={styles.raceText}>{translate("RaceCard")}</Text>
            </LinearGradient>

            <View style={styles.mainPickerStyle}>
              <Pressable
                style={styles.oddTypeWidth}
                onPress={() => props?.setLeagueModalVisible(true)}
              >
                <CustomTextInput
                  editable={false}
                  pointerEvents="none"
                  textInputStyle={styles.textModelInputStyle(
                    props?.selectedOddsText == translate("OddsType")
                  )}
                  // dropDown={true}
                  racingDropDown={true}
                  dropDownStyle={styles.dropDownArrow}
                  dropDownIconStyle={styles.dropDownContainer}
                  placeholderText={""}
                  inputTextStyle={styles.inputTextStyle}
                  placeholderTextColor={Colors.red}
                  onPressWheelPicker={() => props?.setLeagueModalVisible(true)}
                  value={props?.selectedOddsText}
                  activeOpacity={1}
                />
              </Pressable>
            </View>

            <View style={styles.separatorStyle} />
            <View style={styles.runnerMainStyle}>
              <View style={styles.commonRow}>
                <Text style={styles.runnerText}>{translate("Runner")}</Text>
                <Pressable
                  style={styles.runnerArrowStyle}
                  onPress={() => onRunnerPress()}
                >
                  <BlackSmallUpArrow
                    width={Metrics.rfv(10)}
                    height={Metrics.rfv(12)}
                  />
                </Pressable>
              </View>
              <Pressable onPress={() => onExpandAllPress()}>
                <Text style={styles.expandFullForm}>
                  {translate("ExpandFullForm")}
                </Text>
              </Pressable>

              {isSeeAll == true ? (
                <Pressable onPress={() => setSeeAll(false)}>
                  <Text style={styles.expandFullForm}>
                    {translate("SeeBest")}
                  </Text>
                </Pressable>
              ) : (
                <Pressable onPress={() => setSeeAll(true)}>
                  <Text style={styles.expandFullForm}>
                    {translate("SeeAllRunner")}
                  </Text>
                </Pressable>
              )}
            </View>
          </>
        )}
        <SingleRaceItem
          seeAllOdds={isSeeAll}
          runnerData={props?.runnerData}
          itemData={item}
          itemIndex={index}
          sportId={props?.sportId}
          RaceResultData={props?.RaceResultData}
          raceId={props?.raceId}
          selectedOddsText={props?.selectedOddsText}
          runnerInfo={props?.runnersData}
          selectedOddsData={props?.oddsType}
          bookkeeperData={bookkeeperData}
          onRacingPress={onRacingPress}
        />
      </>
    );
  };

  return (
    <>
      {props?.isLoadervisible ? (
        <View style={commonStyles.loader}>
          <Loader />
        </View>
      ) : (
        <FlatList
          data={props?.runnerData}
          extraData={props?.runnerData}
          contentContainerStyle={styles.contentContainerStyle}
          renderItem={({ item, index }) => renderItem(item, index)}
          keyExtractor={(item, index) => index.toString()}
          // ListFooterComponent={footerComponent}
        />
      )}
    </>
  );
}
