import { useNavigation } from "@react-navigation/native";
import moment from "moment";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
} from "react-native";
import { callApi } from "../../../../../../api";
import API_CONFIG from "../../../../../../api/api_url";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
import Header from "../../../../../../component/HeaderComponent";
import LeaguePicker from "../../../../../../component/LeaguePicker";
import PartnersList from "../../../../../../component/PartnersList";
import Loader from "../../../../../../component/ProgressBar";
import RaceTrackPicker from "../../../../../../component/RaceTrackPicker";
import FuturesOddsNextList from "../../../../../../component/RacingFuturesOdds";
import TextHeaderTitle from "../../../../../../component/Text/index";
import CustomTextInput from "../../../../../../component/TextInput";
import { NAVIGATION } from "../../../../../../navigation";
import commonStyles from "../../../../../../theme/commonStyle";
import {
  FuturesEvent,
  RunnerFutures,
} from "../../../../../../theme/dummyArray";
import {
  Colors,
  CommonStyle,
  Images,
  Metrics,
} from "../../../../../../theme/index";
import { BlackSmallUpArrow } from "../../../../../../theme/svg";
import { translate } from "../../../../../../utils/Localize";
import { print_data } from "../../../../../../utils/Logs";
import { showToast } from "../../../../../../utils/commonFunction";
import styles from "./style";

export default function FuturesRace(props: any) {
  const navigation = useNavigation();
  const { sportId, id, eventId, startTimeDate, intl } = props?.route?.params;
  const [isLeaugeModalVisible, setLeagueModalVisible] = useState(false);
  const [isRacingModalVisible, setRacingModalVisible] = useState(false);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [raceData, setRaceData] = useState("");
  const [runnerData, setRunnerData] = useState([]);
  const [isOrder, setIsOrder] = useState(false);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [eventData, setEventData] = useState([]);
  const [eventDataAndroid, setEventDataAndroid] = useState([]);
  const [bookkeeperData, setBookKeeperData] = useState([]);
  const [layout, setLayout] = useState(0);
  const [raceResultData, setRaceResultData] = useState({});
  const [sponsoredId, setSponsoredId] = useState([]);
  const [raceCardData, setRaceCardData] = useState(false);
  const [oddsType, setOddsType] = useState({ marketId: 1, oddKey: 1 });
  const [pageHeadingData, setPageHeadingData] = useState([]);
  const [selectedEventId, setSelectedEventId] = useState(
    props?.route?.params?.name
  );
  const [selectedOddsText, setSelectedOddsText] = useState(
    "WIN FIXED"
    // translate("OddsType")
  );
  const [trackListData, setTrackListData] = useState([]);
  const [eventFullList, setEventFullList] = useState([]);
  const [summary, setSummary] = useState([]);

  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const scrollOffsetY = useRef(new Animated.Value(0)).current;
  const HEADER_HEIGHT = layout;
  const MINHEADER_HEIGHT = 0;
  const SCROLL_DISTANCE = HEADER_HEIGHT - MINHEADER_HEIGHT;
  const headerScrollHeight = scrollOffsetY.interpolate({
    inputRange: [0, SCROLL_DISTANCE],
    outputRange: [HEADER_HEIGHT, MINHEADER_HEIGHT],
    extrapolate: "clamp",
  });

  // useEffect(() => {
  //   // setIsLoaderVisible(true);
  //   getTrackListAPI();
  //   callRunnerApi();
  // }, [selectedEventId, selectedRaceID]);

  // useEffect(() => {
  //   let eventData = trackListData?.filter((item) => {
  //     return item?.id == selectedEventId;
  //   });
  //   setEventLocation(eventData);
  // }, [trackListData, selectedEventId]);

  // useEffect(() => {
  //   if (eventFullList?.length > 0) {
  //     let selectedEvent = eventFullList?.filter(
  //       (event) => event?.id === Number(eventId)
  //     );
  //     let selectedRace = selectedEvent?.[0]?.race?.filter(
  //       (item: any) => item?.id === Number(raceData?.id)
  //     );

  //     let resultData = selectedRace?.[0]?.RaceResultSummary;

  //     setRaceResultData(resultData);
  //   }
  // }, [eventData, eventId, sportId, raceData?.id]);

  useEffect(() => {
    if (raceData?.id) {
      callOddsDataAPI(raceData?.id);
    }
  }, [raceData?.id, runnerData, raceResultData]);

  useEffect(() => {
    const newData = [];
    FuturesEvent?.map((item) => {
      newData.push({
        label: item?.event,
        value: item?.id,
      });
      setEventData(newData);
    });
    fetchBookKeeper();
    getSponsoredOddsApi();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    getTrackListAPI();
    callRunnerApi();
  };
  const handleBackButtonClick = () => {
    navigation.navigate(NAVIGATION.SEE_ALL_PAGE);
    return true;
  };
  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const onRacingPress = (item, index) => {
    if (item?.isExpanded) {
      item.isExpanded = false;
    } else {
      for (let i = 0; i < runnerData.length; i++) {
        if (i === index) {
          runnerData[i].isExpanded = true;
        } else {
          runnerData[i].isExpanded = false;
        }
      }
    }
    setDataUpdated(!dataUpdated);
    setRunnerData(runnerData);
  };

  const onRunnerPress = () => {
    setIsOrder(!isOrder);
    if (isOrder) {
      const runnerDescending = [...runnerData].sort((a, b) => a?.id - b?.id);
      setRunnerData(runnerDescending);
    } else {
      const runnerDescending = [...runnerData].sort((a, b) => b?.id - a?.id);
      setRunnerData(runnerDescending);
    }
  };

  const oddsTypeChange = (selectedOdsType) => {
    switch (selectedOdsType?.id) {
      case 1:
        setOddsType({ marketId: 1, oddKey: 1 });
        break;
      case 2:
        setOddsType({ marketId: 1, oddKey: 2 });
        break;
      case 3:
        setOddsType({ marketId: 2, oddKey: 1 });
        break;
      case 4:
        setOddsType({ marketId: 2, oddKey: 2 });
        break;
      default:
        setOddsType({ marketId: 1, oddKey: 1 });
    }
  };

  const getEventName = () => {
    const eventName = eventData?.find((item) => {
      return item?.value == selectedEventId;
    });
    return eventName ? eventName?.label : props?.route?.params?.name;
  };

  const onTrackChanged = (selectedData) => {
    let selected_obj = FuturesEvent?.find(
      (obj) => obj?.id === selectedData?.id
    );
    // let haveRace = selected_obj?.race?.filter(
    //   (data) => data?.startTimeDate !== null
    // );
    // let upnextRaces = selected_obj?.race?.filter(
    //   (item) =>
    //     item?.startTimeDate !== null &&
    //     moment(new Date()).isBefore(new Date(item?.startTimeDate))
    // );

    // let RaceId = upnextRaces?.length > 0 ? upnextRaces[0]?.id : haveRace[0]?.id;
    // setSelectedRaceID(RaceId);
    setSelectedEventId(selectedData?.id);
  };

  const find_dimesions = (layout) => {
    const { height } = layout;
    setLayout(height);
  };
  const fetchTableHeading = async (provider) => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders?SportId=1,2,3`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          let filteredHeading = response?.body?.data?.result?.filter((item) =>
            provider?.includes(item?.BookKeeperId)
          );
          setPageHeadingData(filteredHeading);
        }
      }
    } catch (error) {}
  };

  const fetchBookKeeper = async () => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setBookKeeperData(response?.body?.data?.result);
        }
      }
    } catch (error) {}
  };

  const callOddsDataAPI = async (raceId: any) => {
    if (raceResultData) {
      let parsedResult = raceResultData?.summary
        ? JSON.parse(raceResultData?.summary)
        : [];

      let standingData = parsedResult?.map((item) => {
        return {
          ...item,
          RunnerDetails: runnerData?.filter((runner) => {
            return runner?.runnerNumber === Number(item?.RunnerNumber);
          }),
        };
      });

      try {
        const response = await callApi(
          `events/getOddsByrace/${raceId}?marketId=${oddsType?.oddKey}&oddKey=${oddsType?.oddKey}`,
          null,
          API_CONFIG.GET,
          null
        );

        if (response?.body?.status === 200) {
          let newData = standingData?.map((obj) => {
            return {
              ...obj,
              oddsData: response?.body?.data?.marketRelation
                ?.map((item) => {
                  return item?.RacingParticipantId ==
                    obj?.RunnerDetails?.[0]?.id
                    ? item
                    : [];
                })
                ?.filter((x) => {
                  return x?.data?.length > 0;
                }),
            };
          });
          const oddsList = response?.body?.data?.marketRelation;
          let provider = [];
          oddsList?.[0]?.data?.map((element) => {
            return provider?.push(element?.BookKeeperId);
          });
          fetchTableHeading(provider);
          print_data("newData=======");
          print_data(newData);

          setSummary(newData);
          setIsLoaderVisible(false);
        }
      } catch (error) {}
    }
  };

  const getTrackListAPI = async () => {
    try {
      let date_to_pass =
        startTimeDate !== null
          ? moment(startTimeDate).format("YYYY-MM-DD")
          : moment(new Date()).format("YYYY-MM-DD");
      let meetingStateValue = intl == "true" ? "Intl" : "Aus/NZ,Intl";
      const response = await callApi(
        `events/trackList/?sportId=${sportId}&MeetingState=${meetingStateValue}&todate=${date_to_pass}&countryId=${""}&stateId=${""}&timezone=${timezone}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let eventData = response?.body?.data?.events;
          let data_pass =
            eventData?.length > 0
              ? eventData?.map((obj) => {
                  return {
                    ...obj,
                    race: Array.from(
                      new Set(obj?.race.map((a) => a?.raceNumber))
                    )
                      .map((id) => {
                        return obj?.race.find((a) => a?.raceNumber === id);
                      })
                      .filter((race) => race?.raceNumber != 0),
                  };
                })
              : [];
          setEventFullList(data_pass);
          const newData = [];
          data_pass?.map((item) => {
            newData.push({
              label: item?.state?.stateCode
                ? item?.eventName + "," + item?.state?.stateCode
                : item?.eventName,
              value: item?.id,
            });
          });
          if (Platform.OS == "android") {
            const newDataAdnroid = [];
            data_pass?.map((item) => {
              newDataAdnroid.push(
                item?.state?.stateCode
                  ? item?.eventName + "," + item?.state?.stateCode
                  : item?.eventName
              );
            });
            setEventDataAndroid(newDataAdnroid);
          }

          // setEventData(newData);
          setTrackListData(data_pass);
          // setIsLoaderVisible(false);
        }
      }
    } catch (error) {
      print_data("=====exception=====" + error);
    }
  };

  const callRunnerApi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.RUNEER + selectedRaceID,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setRaceData(response?.body?.data?.data?.race);
          setRunnerData(response?.body?.data?.data?.runners);

          setRefreshing(false);
        } else {
          setRefreshing(false);
        }
      } else {
        setRefreshing(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setRefreshing(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const getSponsoredOddsApi = async () => {
    try {
      const response = await callApi(
        // `events/getOddsByrace/${raceId}?marketId=${selectedOddsData?.marketId}&oddKey=${selectedOddsData?.oddKey}`,
        `public/sponsor?timeZone=${timezone}&SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          const data = response?.body?.data;
          let providerId = [];
          let Ids = data?.result?.map((item) =>
            providerId?.push(item?.bookKeepersId)
          );
          setSponsoredId(providerId);
          // setOddsData(filteredList);
        } else {
          setSponsoredId([]);
        }
      }
    } catch (error) {}
  };
  const renderRunner = (item, index) => {
    return (
      <>
        <View style={styles.itemViewStyle}>
          <FuturesOddsNextList
            bookkeeperData={bookkeeperData}
            runnerName={item?.name}
            pageHeadingData={pageHeadingData}
          />
          <View style={styles.itemSeparatorComponent} />
        </View>
      </>
    );
  };

  return (
    <View
      style={CommonStyle.commonFlex}
      onLayout={(event) => {
        find_dimesions(event.nativeEvent.layout);
      }}
    >
      <AppSafeAreaView
        firstSafeAreaViewStyle={styles.safeAreaViewStyle}
        backgroundColor={Colors.white}
      >
        <AppStatusBar
          backgroundColor={Colors.white}
          isTransperent={false}
          barStyle={"dark-content"}
        />
        <CommonHeaderComponent
          isShowBack={true}
          // onBackPress={() => handleBackButtonClick()}
          onBackPress={() => navigation.goBack()}
        />
        <LeaguePicker
          isVisible={isLeaugeModalVisible}
          showModel={setLeagueModalVisible}
          onItemSelect={(selectedData) => {
            setRaceCardData(true);
            oddsTypeChange(selectedData);
            setSelectedOddsText(selectedData?.title);
            setTimeout(() => {
              setRaceCardData(false);
            }, 100);
          }}
        />
        <RaceTrackPicker
          isVisible={isRacingModalVisible}
          showModel={setRacingModalVisible}
          eventData={eventData}
          eventDataAndroid={eventData}
          selectedEventId={selectedEventId}
          onItemSelect={(selectedData) => onTrackChanged(selectedData)}
        />
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => onRefresh()}
            />
          }
        >
          <>
            {!isLoadervisible && (
              <>
                <Header
                  onPressSignUp={() => onPressSignUp()}
                  onPressSignIn={() => onPressSignIn()}
                  isBackgroundSignUp={Colors.linearColor2}
                  isBackgroundSignIn={Colors.white}
                  colorUp={Colors.white}
                  colorIn={Colors.linearColor2}
                  sourceIcon={Images.adBannerIcon}
                  pageId={3}
                  isPasswordField={true}
                  onbannerPress={() =>
                    navigation.navigate(NAVIGATION.ADVERTISING)
                  }
                  // onBackPress={() => navigation.goBack()}
                />
                <View style={styles.HorizontalView}>
                  <Pressable
                    style={styles.rowContainerView}
                    onPress={() => setRacingModalVisible(true)}
                  >
                    <CustomTextInput
                      pointerEvents="none"
                      editable={false}
                      textInputStyle={styles.headerTextStyle}
                      racingDropDown={true}
                      placeholderText={""}
                      onPressWheelPicker={() => setRacingModalVisible(true)}
                      inputTextStyle={styles.inputTextStyle}
                      placeholderTextColor={Colors.black}
                      // value={props?.route?.params?.name}
                      value={getEventName()}
                      activeOpacity={1}
                    />
                  </Pressable>
                  <View style={styles.separatorStyle} />
                  <View style={styles.HeadView}>
                    <Text style={styles.eventText}>{getEventName()}</Text>
                    <Text style={styles.TimeText}>
                      Start Time: Nov 5, 2022 11:00AM
                    </Text>
                  </View>
                  <View style={styles.itemSeparatorComponent} />
                  <View style={styles.mainPickerStyle}>
                    <Pressable
                      style={styles.oddTypeWidth}
                      onPress={() => setLeagueModalVisible(true)}
                    >
                      <CustomTextInput
                        editable={false}
                        pointerEvents="none"
                        textInputStyle={styles.textModelInputStyle}
                        // dropDown={true}
                        racingDropDown={true}
                        dropDownStyle={styles.dropDownArrow}
                        dropDownIconStyle={styles.dropDownContainer}
                        placeholderText={""}
                        inputTextStyle={styles.inputTextStyle}
                        placeholderTextColor={Colors.red}
                        onPressWheelPicker={() => setLeagueModalVisible(true)}
                        value={selectedOddsText}
                        activeOpacity={1}
                      />
                    </Pressable>
                  </View>
                  <View style={styles.separatorStyle} />
                  <View style={styles.runnerMainStyle}>
                    <View style={styles.commonRow}>
                      <Text style={styles.runnerText}>
                        {translate("Runner")}
                      </Text>
                      <Pressable
                        style={styles.runnerArrowStyle}
                        onPress={() => onRunnerPress()}
                      >
                        <BlackSmallUpArrow
                          width={Metrics.rfv(10)}
                          height={Metrics.rfv(12)}
                        />
                      </Pressable>
                    </View>
                    <Pressable onPress={() => navigation.goBack()}>
                      <Text style={styles.expandFullForm}>
                        {translate("SeeBest")}
                      </Text>
                    </Pressable>
                  </View>

                  <FlatList
                    scrollEnabled={false}
                    data={RunnerFutures}
                    showsVerticalScrollIndicator={false}
                    renderItem={({ item, index }) => renderRunner(item, index)}
                    keyExtractor={(item, index) => index.toString()}
                    extraData={RunnerFutures}
                  />
                </View>
                <View style={styles.HorizontalView}>
                  <TextHeaderTitle
                    title={translate("OurPartners")}
                    textStyle={styles.textStyle}
                  />
                </View>
                <View style={styles.partnerListBottom}>
                  <PartnersList />
                </View>
              </>
            )}
          </>
        </ScrollView>

        {isLoadervisible && (
          <View style={commonStyles.loader}>
            <Loader />
          </View>
        )}
      </AppSafeAreaView>
    </View>
  );
}
