import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  separatorStyle: {
    height: Metrics.rfv(1),
    backgroundColor: Colors.linearColor2,
    marginHorizontal: Metrics.rfv(12),
    marginBottom: Metrics.rfv(8),
  },
  modal: {
    margin: Metrics.rfv(0),
    justifyContent: "flex-end",
  },
  dialogCancelTextStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    alignSelf: "flex-end",
    marginRight: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(5),
  },
  dateDialogStyle: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-between",
    zIndex: Metrics.rfv(5),
    padding: Metrics.rfv(10),
    backgroundColor: Colors.white,
  },
  background: {
    backgroundColor: Colors.white,
  },
  pickerDoneTextStyle: {
    height: Metrics.rfv(30),
    backgroundColor: Colors.lightGrayColor,
    justifyContent: "center",
  },
  runnerMainStyle: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: Metrics.rfv(12),
    justifyContent: "space-between",
  },
  runnerText: {
    color: Colors.black,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
  },
  runnerArrowStyle: {
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(5),
  },
  commonRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  button: {
    paddingHorizontal: Metrics.rfv(25),
    alignItems: "center",
    height: Metrics.rfv(45),
    justifyContent: "center",
  },

  expandFullForm: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    textDecorationColor: Colors.linearColor2,
    textDecorationLine: "underline",
  },
  betsContainerView: {
    flexDirection: "row",
    // alignItems: "flex-start",
    alignItems: "center",
    // justifyContent: "space-around",
    justifyContent: "flex-start",
  },
  betsText: (tabVisible: any) => ({
    fontSize: Metrics.rfv(16),
    color: tabVisible ? Colors.linearColor2 : Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    lineHeight: Metrics.rfv(20),
    textAlign: "center",
  }),
  viewstyle: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "flex-end",
    marginHorizontal: Metrics.rfv(15),
    width: Metrics.rfv(170),
    height: Metrics.rfv(4),
  },
  activeStyle: (tabVisible: any) => ({
    justifyContent: "center",
    backgroundColor: tabVisible ? Colors.linearColor1 : Colors.white,

    marginHorizontal: Metrics.rfv(3),
    width: Metrics.rfv(92),
    height: Metrics.rfv(4),
  }),
  widthStyle: {
    borderWidth: Metrics.rfv(1),
    backgroundColor: Colors.linearColor2,
    borderColor: Colors.linearColor2,
    width: "100%",
    height: Metrics.rfv(1),
  },
  seeAllText: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    textDecorationColor: Colors.linearColor2,
    textDecorationLine: "underline",
  },
  downBlueArrowStyle: {
    marginTop: Metrics.rfv(15),
    marginLeft: Metrics.rfv(15),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(50),
  },
  adStyle: {
    marginBottom: Metrics.rfv(5),
  },
  adImage: {
    width: Metrics.rfv(390),
    height: Metrics.rfv(95),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    textAlign: "center",
    marginBottom: Metrics.rfv(10),
  },
  headerTextStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(20),
    lineHeight: Metrics.rfv(25),
    marginLeft: Metrics.rfv(15),
  },
  homeRacingStyle: {
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    color: Colors.black,
  },
  rowContainer: {
    flexDirection: "row",
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(18),
  },
  horseText: {
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    color: Colors.linearColor2,
  },
  mainPickerStyle: {
    flexDirection: "row",
    alignItems: "center",
    // marginHorizontal: Metrics.rfv(15),
    marginBottom: Metrics.rfv(5),
  },
  OddsTitleStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  textInputStyle: {
    width: "100%",
    padding: 0,
    color: Colors.linearColor1,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(18),
    lineHeight: Metrics.rfv(22),
  },
  inputTextStyle: {
    borderColor: Colors.gray,
    borderRadius: Metrics.rfv(7),
    paddingHorizontal: Metrics.rfv(10),
    width: "100%",
    padding: 0,
    color: Colors.black,
  },
  textModelInputStyle: (visible) => ({
    width: "100%",
    padding: 0,
    color: visible ? Colors.black : Colors.linearColor1,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(18),
    lineHeight: Metrics.rfv(22),
  }),
  oddTypeWidth: {
    width: "35%",
    paddingVertical: 3,
    // marginLeft: Metrics.rfv(10),
  },
  HorizontalView: {
    marginTop: Metrics.rfv(16),
    marginHorizontal: Metrics.rfv(15),
    flex: 1,
  },
  rowContainerView: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(5),
  },

  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  contentContainerStyle: {
    flex: 1,
    marginTop: Metrics.rfv(10),
  },
  itemSeparatorComponent: {
    backgroundColor: Colors.lineBreak,
    marginTop: Metrics.rfv(15),
    height: Metrics.rfv(1),
    marginVertical: Metrics.rfv(15),
  },
  countryName: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(18),
    fontFamily: Fonts.IN_SemiBold,
  },
  commonMargin15: {
    marginTop: Metrics.rfv(15),
  },

  showContainStyle: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Metrics.rfv(15),

    justifyContent: "space-between",
  },
  showContainSub: {
    height: Metrics.rfv(40),
    width: "50%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.lightGrayBoxGray,
  },

  showContainSubCurrent: {
    height: Metrics.rfv(40),
    width: "50%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.lightGrayBoxGray,
    marginLeft: Metrics.rfv(5),
  },
  showContain: {
    alignItems: "center",
    justifyContent: "space-around",
    flexDirection: "row",
    marginTop: Metrics.rfv(5),
  },
  currentBestText: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.IN_SemiBold,
    textAlign: "center",
  },
  bestOpenWidth: {},
  marginHorizontal: {},
  currentBestTextView: {
    alignItems: "center",
    width: "50%",
  },
  currentBest: {
    color: Colors.black,
    marginLeft: Metrics.rfv(12),
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
  },
  imageStyle: {
    width: Metrics.rfv(45),
    height: Metrics.rfv(30),
    marginTop: Metrics.rfv(10),
  },
  CurrentBestTextOther: {
    height: Metrics.rfv(40),
    width: Metrics.rfp(50),
    marginHorizontal: Metrics.rfv(5),
    marginVertical: Metrics.rfv(3),
    backgroundColor: Colors.lightGrayBoxGray,
  },
  OddsNextStyle: {
    marginTop: Metrics.rfv(20),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(12),
  },
  countryCotainerStyle: {
    width: "100%",
    flexDirection: "row",
    paddingHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(10),
    alignItems: "center",
  },
  flagImageStyle: {
    width: Metrics.rfv(25),
    height: Metrics.rfv(15),
  },
  countryTextStyle: {
    color: Colors.black,
    marginLeft: Metrics.rfv(5),
    fontSize: Metrics.rfv(10),
    lineHeight: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    textTransform: "uppercase",
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  dropDownContainer: {
    marginLeft: Metrics.rfv(-20),
    justifyContent: "center",
  },
  dropDownArrow: {
    width: Metrics.rfv(14),
    height: Metrics.rfv(8),
    resizeMode: "contain",
  },
  labelStyle: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    color: Colors.black,

    textTransform: "capitalize",
  },
  bottomBorder: {
    borderBottomWidth: Metrics.rfv(3),
    borderBottomColor: Colors.linearColor2,
    elevation: 0,
  },
});
