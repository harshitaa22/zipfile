import { useNavigation } from "@react-navigation/native";
import moment from "moment";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
} from "react-native";
import { API_URL } from "../../../../../../../env.json";
import { callApi } from "../../../../../../api";
import API_CONFIG from "../../../../../../api/api_url";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
import CountryDetailsPageList from "../../../../../../component/CountryDetailsPage";
import Header from "../../../../../../component/HeaderComponent";
import ImageLoad from "../../../../../../component/ImageLoad";
import LeaguePicker from "../../../../../../component/LeaguePicker";
import PartnersList from "../../../../../../component/PartnersList";
import Loader from "../../../../../../component/ProgressBar";
import SingleRaceItem from "../../../../../../component/RaceItemComponent";
import RaceTrackPicker from "../../../../../../component/RaceTrackPicker";
import SectionRoundList from "../../../../../../component/SingleSectionList";
import TextHeaderTitle from "../../../../../../component/Text/index";
import CustomTextInput from "../../../../../../component/TextInput";
import { NAVIGATION } from "../../../../../../navigation";
import commonStyles from "../../../../../../theme/commonStyle";
import {
  Colors,
  CommonStyle,
  Images,
  Metrics,
} from "../../../../../../theme/index";
import { BlackSmallUpArrow } from "../../../../../../theme/svg";
import { translate } from "../../../../../../utils/Localize";
import { print_data } from "../../../../../../utils/Logs";
import { showToast } from "../../../../../../utils/commonFunction";
import ResultsTab from "../../../../TopStack/RacingResults";
import DividendsTab from "../DividendsTab";
import MultiplesTab from "../MultiplesTab";
import ExoticsTab from "../RacingExoticsTab";
import styles from "./style";

export default function SingleRacingPage(props: any) {
  const navigation = useNavigation();
  const { sportId, id, eventId, startTimeDate, intl } = props?.route?.params;
  const [isLeaugeModalVisible, setLeagueModalVisible] = useState(false);
  const [tabVisible, setTabVisible] = useState(true);
  const [isRacingModalVisible, setRacingModalVisible] = useState(false);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [raceData, setRaceData] = useState({});
  const [runnerData, setRunnerData] = useState([]);
  const [isOrder, setIsOrder] = useState(false);
  const [isAllExpand, setIsAllExpand] = useState(false);
  const [selectedRaceID, setSelectedRaceID] = useState(id);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [eventData, setEventData] = useState([]);
  const [eventDataAndroid, setEventDataAndroid] = useState([]);
  const [isSeeAll, setSeeAll] = useState(false);
  const [bookkeeperData, setBookKeeperData] = useState([]);
  const [layout, setLayout] = useState(0);
  const [raceResultData, setRaceResultData] = useState({});
  const [sponsoredId, setSponsoredId] = useState([]);
  const [raceCardData, setRaceCardData] = useState(false);
  const [exoticsVisible, setExoticsVisible] = useState(false);
  const [dividensVisible, setDividensVisible] = useState(false);
  const [multiplesVisible, setMultiplesVisible] = useState(false);
  const [exoticsData, setExoticsData] = useState([]);
  const [multipleData, setMultipleData] = useState([]);
  const [toteWinData, setToteWinData] = useState([]);
  const [totePlaceData, setTotePlaceData] = useState([]);
  const [dividendData, setDividendData] = useState([]);
  const [oddsType, setOddsType] = useState({ marketId: 1, oddKey: 1 });
  const [oddsFirstType, setOddsFirstType] = useState({
    marketId: 1,
    oddKey: 1,
  });
  const [selectedDividend, setSelectedDividend] = useState("1");
  const [selectedOddsText, setSelectedOddsText] = useState(
    translate("WinFixed")
  );
  const [selectedEventId, setSelectedEventId] = useState(eventId);
  const [trackListData, setTrackListData] = useState([]);
  const [eventLocation, setEventLocation] = useState([]);
  const [eventFullList, setEventFullList] = useState([]);
  const [summary, setSummary] = useState([]);
  const [listLoader, setListLoader] = useState(false);

  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const scrollOffsetY = useRef(new Animated.Value(0)).current;
  const HEADER_HEIGHT = layout;
  const MINHEADER_HEIGHT = 0;
  const SCROLL_DISTANCE = HEADER_HEIGHT - MINHEADER_HEIGHT;
  const headerScrollHeight = scrollOffsetY.interpolate({
    inputRange: [0, SCROLL_DISTANCE],
    outputRange: [HEADER_HEIGHT, MINHEADER_HEIGHT],
    extrapolate: "clamp",
  });

  useEffect(() => {
    setIsLoaderVisible(true);
    getTrackListAPI();
    callRunnerApi();
  }, [selectedEventId, selectedRaceID]);

  useEffect(() => {
    let eventData = trackListData?.filter((item) => {
      return item?.id == selectedEventId;
    });
    setEventLocation(eventData);
  }, [trackListData, selectedEventId]);

  useEffect(() => {
    if (eventFullList?.length > 0) {
      let selectedEvent = eventFullList?.filter(
        (event) => event?.id === Number(eventId)
      );
      let selectedRace = selectedEvent?.[0]?.race?.filter(
        (item: any) => item?.id === Number(raceData?.id)
      );

      let resultData = selectedRace?.[0]?.RaceResultSummary;

      setRaceResultData(resultData);
    }
  }, [eventData, eventId, sportId, raceData?.id]);

  useEffect(() => {
    if (raceData?.id) {
      callOddsDataAPI(raceData?.id);
    }
  }, [raceData?.id, runnerData, raceResultData, oddsFirstType]);

  useEffect(() => {
    if (raceResultData) {
      let parsedExotics = raceResultData?.dividends
        ? raceResultData?.dividends === '""'
          ? []
          : JSON.parse(raceResultData?.dividends)
        : [];
      let exacta = parsedExotics?.filter((item) =>
        item?.product_name
          ? item?.product_name === "Exacta"
          : item?.ProductName === "Exacta"
      );
      let trifecta = parsedExotics?.filter((item) =>
        item?.product_name
          ? item?.product_name === "Trifecta"
          : item?.ProductName === "Trifecta"
      );

      let toteWin = parsedExotics?.filter((item) =>
        item?.product_name
          ? item?.product_name === "Tote Win"
          : item?.ProductName === "Tote Win"
      );
      let totePlace = parsedExotics?.filter((item) =>
        item?.product_name
          ? item?.product_name === "Tote Place"
          : item?.ProductName === "Tote Place"
      );
      let restArray = parsedExotics?.filter((item) =>
        item?.product_name
          ? item?.product_name !== "Exacta" &&
            item?.product_name !== "Trifecta" &&
            item?.product_name !== "Tote Win" &&
            item?.product_name !== "Tote Place"
          : item?.ProductName !== "Exacta" &&
            item?.ProductName !== "Trifecta" &&
            item?.ProductName !== "Tote Win" &&
            item?.ProductName !== "Tote Place"
      );

      const sortedData = restArray?.sort((a, b) => {
        return a?.product_name
          ? a?.product_name.localeCompare(b?.product_name)
          : a?.ProductName.localeCompare(b?.ProductName);
      });
      let exotics = [...exacta, ...trifecta];
      setExoticsData(exotics);
      setToteWinData(toteWin);
      setMultipleData(sortedData);
      setTotePlaceData(totePlace);
      fetchDividendData(selectedDividend, toteWin, totePlace);
    }
  }, [raceData?.id, runnerData, raceResultData, selectedDividend]);

  const fetchDividendData = (selectedDividend, toteWin, totePlace) => {
    if (raceResultData && runnerData) {
      let parsedResult = raceResultData?.summary
        ? JSON.parse(raceResultData?.summary)
        : [];
      let dividend = selectedDividend == 1 ? toteWin : totePlace;
      let standingData = parsedResult?.map((item) => {
        return {
          ...item,
          RunnerDetails: runnerData?.filter((runner) => {
            return item?.runner_number
              ? runner?.runnerNumber === Number(item?.runner_number)
              : runner?.runnerNumber === Number(item?.RunnerNumber);
          }),
        };
      });
      let newData = standingData?.map((obj) => {
        let runnerDividend = dividend?.filter((runner) =>
          runner?.positions?.runner_number
            ? Number(runner?.positions?.runner_number) ===
              Number(obj?.runner_number)
            : Number(runner?.Positions?.RunnerNumber) ===
              Number(obj?.RunnerNumber)
        );

        return {
          ...obj,
          DividendData: runnerDividend ? runnerDividend : [],
        };
      });
      setDividendData(newData);
    }
  };

  useEffect(() => {
    fetchBookKeeper();
    getSponsoredOddsApi();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    getTrackListAPI();
    callRunnerApi();
  };

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const onRacingPress = (item, index) => {
    if (item?.isExpanded) {
      item.isExpanded = false;
    } else {
      for (let i = 0; i < runnerData.length; i++) {
        if (i === index) {
          runnerData[i].isExpanded = true;
        } else {
          runnerData[i].isExpanded = false;
        }
      }
    }
    setDataUpdated(!dataUpdated);
    setRunnerData(runnerData);
  };

  const onRunnerPress = () => {
    setIsOrder(!isOrder);
    if (isOrder) {
      const runnerDescending = [...runnerData].sort((a, b) => a?.id - b?.id);
      setRunnerData(runnerDescending);
    } else {
      const runnerDescending = [...runnerData].sort((a, b) => b?.id - a?.id);
      setRunnerData(runnerDescending);
    }
  };

  const onExpandAllPress = () => {
    if (isAllExpand) {
      for (let i = 0; i < runnerData.length; i++) {
        runnerData[i].isExpanded = false;
      }
    } else {
      for (let i = 0; i < runnerData.length; i++) {
        runnerData[i].isExpanded = true;
      }
    }
    setIsAllExpand(!isAllExpand);
  };

  const oddsTypeChange = (selectedOdsType) => {
    print_data(selectedOdsType);
    switch (selectedOdsType?.id) {
      case 1:
        setOddsType({ marketId: 1, oddKey: 1 });
        break;
      case 2:
        setOddsType({ marketId: 1, oddKey: 2 });
        break;
      case 3:
        setOddsType({ marketId: 2, oddKey: 1 });
        break;
      case 4:
        setOddsType({ marketId: 2, oddKey: 2 });
        break;
      default:
        setOddsType({ marketId: 1, oddKey: 1 });
    }
  };

  const oddsTypeFirstChange = (selectedOdsType) => {
    switch (selectedOdsType?.id) {
      case 1:
        setOddsFirstType({ marketId: 1, oddKey: 1 });
        break;
      case 2:
        setOddsFirstType({ marketId: 1, oddKey: 2 });
        break;
      case 3:
        setOddsFirstType({ marketId: 2, oddKey: 1 });
        break;
      case 4:
        setOddsFirstType({ marketId: 2, oddKey: 2 });
        break;
      default:
        setOddsFirstType({ marketId: 1, oddKey: 1 });
    }
  };

  const getEventName = () => {
    const eventName = eventData?.find((item) => {
      return item?.value == selectedEventId;
    });
    return eventName?.label;
  };

  const onTrackChanged = (selectedData) => {
    let selected_obj = trackListData?.find(
      (obj) => obj?.id === selectedData?.id
    );
    let haveRace = selected_obj?.race?.filter(
      (data) => data?.startTimeDate !== null
    );
    let upnextRaces = selected_obj?.race?.filter(
      (item) =>
        item?.startTimeDate !== null &&
        moment(new Date()).isBefore(new Date(item?.startTimeDate))
    );

    let RaceId = upnextRaces?.length > 0 ? upnextRaces[0]?.id : haveRace[0]?.id;
    setSelectedRaceID(RaceId);
    setSelectedEventId(selectedData?.id);
  };

  const find_dimesions = (layout) => {
    const { height } = layout;
    setLayout(height);
  };

  const fetchBookKeeper = async () => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setBookKeeperData(response?.body?.data?.result);
        }
      }
    } catch (error) {}
  };

  const callOddsDataAPI = async (raceId: any) => {
    if (raceResultData) {
      let parsedResult = raceResultData?.summary
        ? JSON.parse(raceResultData?.summary)
        : [];
      let standingData = parsedResult?.map((item) => {
        return {
          ...item,
          RunnerDetails: runnerData?.filter((runner) => {
            return item?.runner_number
              ? runner?.runnerNumber === Number(item?.runner_number)
              : runner?.runnerNumber === Number(item?.RunnerNumber);
          }),
        };
      });
      try {
        const response = await callApi(
          `events/getOddsByrace/${raceId}?marketId=${oddsFirstType?.marketId}&oddKey=${oddsFirstType?.oddKey}`,
          null,
          API_CONFIG.GET,
          null
        );

        if (response?.body?.status === 200) {
          let newData = standingData?.map((obj) => {
            print_data("obj=======");
            print_data(obj);
            return {
              ...obj,
              oddsData: response?.body?.data?.marketRelation
                ?.map((item) => {
                  return item?.RacingParticipantId ==
                    obj?.RunnerDetails?.[0]?.id
                    ? item
                    : [];
                })
                ?.filter((x) => {
                  return x?.data?.length > 0;
                }),
            };
          });
          setSummary(newData);
        }
      } catch (error) {}
    }
  };

  const getTrackListAPI = async () => {
    try {
      let date_to_pass =
        startTimeDate !== null
          ? moment(startTimeDate).format("YYYY-MM-DD")
          : moment(new Date()).format("YYYY-MM-DD");
      let meetingStateValue = intl == "true" ? "Intl" : "Aus/NZ,Intl";
      const response = await callApi(
        `events/trackList/?sportId=${sportId}&MeetingState=${meetingStateValue}&todate=${date_to_pass}&countryId=${""}&stateId=${""}&timezone=${timezone}`,
        null,
        API_CONFIG.GET,
        null
      );

      print_data("track=======");
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let eventData = response?.body?.data?.events;
          let data_pass =
            eventData?.length > 0
              ? eventData?.map((obj) => {
                  return {
                    ...obj,
                    race: Array.from(
                      new Set(obj?.race.map((a) => a?.raceNumber))
                    )
                      .map((id) => {
                        return obj?.race.find((a) => a?.raceNumber === id);
                      })
                      .filter((race) => race?.raceNumber != 0),
                  };
                })
              : [];
          setEventFullList(data_pass);
          const newData = [];
          data_pass?.map((item) => {
            newData.push({
              label: item?.state?.stateCode
                ? item?.eventName + "," + item?.state?.stateCode
                : item?.eventName,
              value: item?.id,
            });
          });
          if (Platform.OS == "android") {
            const newDataAdnroid = [];
            data_pass?.map((item) => {
              newDataAdnroid.push(
                item?.state?.stateCode
                  ? item?.eventName + "," + item?.state?.stateCode
                  : item?.eventName
              );
            });
            setEventDataAndroid(newDataAdnroid);
          }

          setEventData(newData);
          setTrackListData(data_pass);
          setIsLoaderVisible(false);
        }
      }
    } catch (error) {
      print_data("=====exception=====" + error);
    }
  };

  const callRunnerApi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.RUNEER + selectedRaceID,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setRaceData(response?.body?.data?.data?.race);
          print_data("rsvghdfvdghfvs====");
          print_data(response?.body?.data?.data);
          setRunnerData(response?.body?.data?.data?.runners);

          setRefreshing(false);
        } else {
          setRefreshing(false);
        }
      } else {
        setRefreshing(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setRefreshing(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const getSponsoredOddsApi = async () => {
    try {
      const response = await callApi(
        // `events/getOddsByrace/${raceId}?marketId=${selectedOddsData?.marketId}&oddKey=${selectedOddsData?.oddKey}`,
        `public/sponsor?timeZone=${timezone}&SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          const data = response?.body?.data;
          let providerId = [];
          let Ids = data?.result?.map((item) =>
            providerId?.push(item?.bookKeepersId)
          );
          setSponsoredId(providerId);
          // setOddsData(filteredList);
        } else {
          setSponsoredId([]);
        }
      }
    } catch (error) {}
  };

  return (
    <View
      style={CommonStyle.commonFlex}
      onLayout={(event) => {
        find_dimesions(event.nativeEvent.layout);
      }}
    >
      <AppSafeAreaView
        firstSafeAreaViewStyle={styles.safeAreaViewStyle}
        backgroundColor={Colors.white}
      >
        <AppStatusBar
          backgroundColor={Colors.white}
          isTransperent={false}
          barStyle={"dark-content"}
        />
        <CommonHeaderComponent
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
        />
        <LeaguePicker
          isVisible={isLeaugeModalVisible}
          showModel={setLeagueModalVisible}
          onItemSelect={(selectedData) => {
            setRaceCardData(true);
            oddsTypeChange(selectedData);
            print_data(selectedData);
            setSelectedOddsText(selectedData?.title);

            setRaceCardData(false);
          }}
        />
        <RaceTrackPicker
          isVisible={isRacingModalVisible}
          showModel={setRacingModalVisible}
          eventData={eventData}
          eventDataAndroid={eventDataAndroid}
          selectedEventId={selectedEventId}
          onItemSelect={(selectedData) => onTrackChanged(selectedData)}
        />
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => onRefresh()}
            />
          }
        >
          <>
            <>
              <Header
                onPressSignUp={() => onPressSignUp()}
                onPressSignIn={() => onPressSignIn()}
                isBackgroundSignUp={Colors.linearColor2}
                isBackgroundSignIn={Colors.white}
                colorUp={Colors.white}
                colorIn={Colors.linearColor2}
                sourceIcon={Images.adBannerIcon}
                pageId={3}
                isPasswordField={true}
                onbannerPress={() =>
                  navigation.navigate(NAVIGATION.ADVERTISING)
                }
                onBackPress={() => navigation.goBack()}
              />
              <Pressable
                style={styles.rowContainerView}
                onPress={() => setRacingModalVisible(true)}
              >
                <CustomTextInput
                  pointerEvents="none"
                  editable={false}
                  textInputStyle={styles.headerTextStyle}
                  racingDropDown={true}
                  placeholderText={""}
                  onPressWheelPicker={() => setRacingModalVisible(true)}
                  inputTextStyle={styles.inputTextStyle}
                  placeholderTextColor={Colors.black}
                  value={getEventName()}
                  activeOpacity={1}
                />
              </Pressable>
              <View style={styles.separatorStyle} />
              {eventLocation[0]?.race?.length > 0 ? (
                <SectionRoundList
                  raceTrackData={eventLocation[0]?.race}
                  selectedRaceID={selectedRaceID}
                  onTrackSelected={(itemData) =>
                    setSelectedRaceID(itemData?.id)
                  }
                />
              ) : null}
              {eventLocation?.length > 0 && (
                <View style={styles.countryCotainerStyle}>
                  <ImageLoad
                    resizeMode={"contain"}
                    source={
                      eventLocation[0]?.country?.country_flag?.includes(
                        "uploads"
                      )
                        ? API_URL +
                          "/" +
                          eventLocation[0]?.country?.country_flag
                        : eventLocation[0]?.country?.country_flag
                    }
                    style={styles.flagImageStyle}
                  />
                  <Text style={styles.countryTextStyle}>
                    {eventLocation[0]?.country
                      ? eventLocation[0]?.country?.country + " / "
                      : ""}
                    {eventLocation[0]?.state
                      ? eventLocation[0]?.state?.state + " / "
                      : ""}
                    {eventLocation[0]?.eventName}
                  </Text>
                </View>
              )}

              <CountryDetailsPageList raceData={raceData} />

              {summary[0]?.oddsData?.length > 0 ? (
                <>
                  {isLoadervisible ? (
                    <View>
                      <Loader />
                    </View>
                  ) : (
                    <>
                      <ScrollView
                        style={{ flexGrow: 1 }}
                        horizontal
                        showsHorizontalScrollIndicator={false}
                      >
                        <View style={{}}>
                          <View style={styles.betsContainerView}>
                            <Pressable
                              style={styles.button}
                              onPress={() => {
                                setTabVisible(true),
                                  setExoticsVisible(false),
                                  setDividensVisible(false),
                                  setMultiplesVisible(false);
                              }}
                            >
                              <Text style={styles.betsText(tabVisible)}>
                                {translate("ResultsTab")}
                              </Text>
                            </Pressable>
                            <Pressable
                              style={styles.button}
                              onPress={() => {
                                setExoticsVisible(true),
                                  setDividensVisible(false),
                                  setTabVisible(false),
                                  setMultiplesVisible(false);
                              }}
                            >
                              <Text style={styles.betsText(exoticsVisible)}>
                                {translate("Exotics")}
                              </Text>
                            </Pressable>
                            <Pressable
                              style={styles.button}
                              onPress={() => {
                                setDividensVisible(true),
                                  setTabVisible(false),
                                  setExoticsVisible(false);
                                setMultiplesVisible(false);
                              }}
                            >
                              <Text style={styles.betsText(dividensVisible)}>
                                {translate("Dividends")}
                              </Text>
                            </Pressable>
                            <Pressable
                              style={styles.button}
                              onPress={() => {
                                setDividensVisible(false),
                                  setTabVisible(false),
                                  setExoticsVisible(false);
                                setMultiplesVisible(true);
                              }}
                            >
                              <Text style={styles.betsText(multiplesVisible)}>
                                {translate("Multiples")}
                              </Text>
                            </Pressable>
                          </View>
                          <View style={CommonStyle.commonRow}>
                            <View style={styles.activeStyle(tabVisible)} />
                            <View style={styles.activeStyle(exoticsVisible)} />
                            <View style={styles.activeStyle(dividensVisible)} />
                            <View
                              style={styles.activeStyle(multiplesVisible)}
                            />
                          </View>
                        </View>
                      </ScrollView>

                      <View style={styles.widthStyle} />
                      {tabVisible && (
                        <ResultsTab
                          // isLoadervisible={isLoadervisible}
                          // selectedOddsText={selectedOddsText}
                          // sportId={sportId}
                          // raceId={raceData?.id}
                          // runnerData={runnerData}
                          // raceCardData={raceCardData}
                          // selectedDividend={selectedDividend}
                          // oddsType={oddsFirstType}
                          // bookkeeperData={props?.bookkeeperData}
                          // setLeagueModalVisible={setLeagueModalVisible}
                          // RaceResultData={raceResultData}
                          // selectedOddsData={oddsType}
                          // seeAllOdds={isSeeAll}
                          // runnerInfo={runnerData}
                          // onRacingPress={onRacingPress}
                          isLoadervisible={isLoadervisible}
                          selectedOddsText={selectedOddsText}
                          sportId={sportId}
                          raceId={raceData?.id}
                          runnerData={runnerData}
                          exoticsData={exoticsData}
                          raceCardData={raceCardData}
                          oddsType={oddsType}
                          bookkeeperData={props?.bookkeeperData}
                          setLeagueModalVisible={setLeagueModalVisible}
                          raceResultData={raceResultData}
                          runnerInfo={runnerData}
                          sponsoredId={sponsoredId}
                          selectedDividend={selectedDividend}
                          summary={summary}
                          onchangeResult={(e) => {
                            oddsTypeFirstChange(e);
                          }}
                        />
                      )}
                      {exoticsVisible && (
                        <ExoticsTab
                          isLoadervisible={isLoadervisible}
                          selectedOddsText={selectedOddsText}
                          sportId={sportId}
                          raceId={raceData?.id}
                          runnerData={runnerData}
                          exoticsData={exoticsData}
                          raceCardData={raceCardData}
                          oddsType={oddsType}
                          bookkeeperData={props?.bookkeeperData}
                          setLeagueModalVisible={setLeagueModalVisible}
                          raceResultData={raceResultData}
                          runnerInfo={runnerData}
                          sponsoredId={sponsoredId}
                          selectedDividend={selectedDividend}
                          onchangeResult={(e) => {
                            oddsTypeFirstChange(e);
                          }}
                        />
                      )}
                      {multiplesVisible && (
                        <MultiplesTab
                          isLoadervisible={isLoadervisible}
                          selectedOddsText={selectedOddsText}
                          sportId={sportId}
                          raceId={raceData?.id}
                          runnerData={runnerData}
                          exoticsData={exoticsData}
                          raceCardData={raceCardData}
                          oddsType={oddsType}
                          bookkeeperData={props?.bookkeeperData}
                          setLeagueModalVisible={setLeagueModalVisible}
                          raceResultData={raceResultData}
                          runnerInfo={runnerData}
                          sponsoredId={sponsoredId}
                          selectedDividend={selectedDividend}
                          onchangeResult={(e) => {
                            oddsTypeFirstChange(e);
                          }}
                          multipleData={multipleData}
                        />
                      )}
                      {dividensVisible && (
                        <DividendsTab
                          isLoadervisible={isLoadervisible}
                          selectedOddsText={selectedOddsText}
                          sportId={sportId}
                          raceId={raceData?.id}
                          runnerData={runnerData}
                          exoticsData={exoticsData}
                          raceCardData={raceCardData}
                          oddsType={oddsType}
                          bookkeeperData={props?.bookkeeperData}
                          setLeagueModalVisible={setLeagueModalVisible}
                          raceResultData={raceResultData}
                          runnerInfo={runnerData}
                          sponsoredId={sponsoredId}
                          dividendData={dividendData}
                          selectedDividend={selectedDividend}
                          onchangeResult={(e) => {
                            oddsTypeFirstChange(e);
                            setSelectedDividend(e?.id);
                            fetchDividendData(
                              e?.id,
                              toteWinData,
                              totePlaceData
                            );
                          }}
                        />
                      )}
                    </>
                  )}
                </>
              ) : (
                <>
                  <View style={styles.mainPickerStyle}>
                    <Pressable
                      style={styles.oddTypeWidth}
                      onPress={() => setLeagueModalVisible(true)}
                    >
                      <CustomTextInput
                        editable={false}
                        pointerEvents="none"
                        textInputStyle={styles.textModelInputStyle(
                          selectedOddsText == translate("OddsType")
                        )}
                        // dropDown={true}
                        racingDropDown={true}
                        dropDownStyle={styles.dropDownArrow}
                        dropDownIconStyle={styles.dropDownContainer}
                        placeholderText={""}
                        inputTextStyle={styles.inputTextStyle}
                        placeholderTextColor={Colors.red}
                        onPressWheelPicker={() => setLeagueModalVisible(true)}
                        value={selectedOddsText}
                        activeOpacity={1}
                      />
                    </Pressable>
                  </View>
                  <View style={styles.separatorStyle} />
                  <View style={styles.runnerMainStyle}>
                    <View style={styles.commonRow}>
                      <Text style={styles.runnerText}>
                        {translate("Runner")}
                      </Text>
                      <Pressable
                        style={styles.runnerArrowStyle}
                        onPress={() => onRunnerPress()}
                      >
                        <BlackSmallUpArrow
                          width={Metrics.rfv(10)}
                          height={Metrics.rfv(12)}
                        />
                      </Pressable>
                    </View>
                    <Pressable onPress={() => onExpandAllPress()}>
                      <Text style={styles.expandFullForm}>
                        {translate("ExpandFullForm")}
                      </Text>
                    </Pressable>

                    {isSeeAll == true ? (
                      <Pressable onPress={() => setSeeAll(false)}>
                        <Text style={styles.expandFullForm}>
                          {translate("SeeBest")}
                        </Text>
                      </Pressable>
                    ) : (
                      <Pressable onPress={() => setSeeAll(true)}>
                        <Text style={styles.expandFullForm}>
                          {translate("SeeAllRunner")}
                        </Text>
                      </Pressable>
                    )}
                  </View>
                  {isLoadervisible ? (
                    <View>
                      <Loader />
                    </View>
                  ) : (
                    <FlatList
                      data={runnerData}
                      extraData={runnerData}
                      contentContainerStyle={styles.contentContainerStyle}
                      renderItem={({ item, index }) => (
                        <SingleRaceItem
                          seeAllOdds={isSeeAll}
                          itemData={item}
                          itemIndex={index}
                          sportId={sportId}
                          raceId={raceData?.id}
                          raceData={raceData}
                          selectedOddsText={selectedOddsText}
                          runnerInfo={runnerData}
                          selectedOddsData={oddsType}
                          bookkeeperData={bookkeeperData}
                          onRacingPress={onRacingPress}
                        />
                      )}
                      keyExtractor={(item, index) => index.toString()}
                    />
                  )}
                </>
              )}

              <View style={styles.HorizontalView}>
                <TextHeaderTitle
                  title={translate("OurPartners")}
                  textStyle={styles.textStyle}
                />
              </View>
              <View style={styles.partnerListBottom}>
                <PartnersList />
              </View>
            </>
          </>
        </ScrollView>

        {/* <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
          nestedScrollEnabled={true}
        > */}
        {/* <>
          <View style={styles.betsContainerView}>
            <Pressable
              style={styles.button}
              onPress={() => setTabVisible(false)}
            >
              <Text style={styles.betsText(!tabVisible)}>
                {translate("Bets")}
              </Text>
            </Pressable>
            <Pressable
              style={styles.button}
              onPress={() => setTabVisible(true)}
            >
              <Text style={styles.betsText(tabVisible)}>
                {translate("Money")}
              </Text>
            </Pressable>
          </View>

          <View style={styles.activeStyle(tabVisible)} />
          <View style={styles.widthStyle} />
          {tabVisible ? (
            <ResultsTab
              selectedOddsText={selectedOddsText}
              sportId={sportId}
              raceId={raceData?.id}
              runnerData={runnerData}
              oddsType={oddsType}
              bookkeeperData={props?.bookkeeperData}
              setLeagueModalVisible={setLeagueModalVisible}
              RaceResultData={RaceResultData}
              runnerInfo={runnerData}
            />
          ) : (
            <ExoticsTab
              selectedOddsText={selectedOddsText}
              sportId={sportId}
              raceId={raceData?.id}
              runnerData={runnerData}
              oddsType={oddsType}
              bookkeeperData={props?.bookkeeperData}
              setLeagueModalVisible={setLeagueModalVisible}
            />
          )}
        </> */}
        {/* </ScrollView> */}
        {/* {isLoadervisible ? (
          <View style={commonStyles.loader}>
            <Loader />
          </View>
        ) : ( */}

        {/* )} */}
      </AppSafeAreaView>
    </View>
  );
}

{
  /* <ScrollView
  contentContainerStyle={commonStyles.scrollViewStyle}
  overScrollMode={"never"}
  showsVerticalScrollIndicator={false}
  keyboardShouldPersistTaps={"handled"}
  refreshControl={
    <RefreshControl
      refreshing={refreshing}
      onRefresh={() => onRefresh()}
    />
  }
>
  <Header
    onPressSignUp={() => onPressSignUp()}
    onPressSignIn={() => onPressSignIn()}
    isBackgroundSignUp={Colors.linearColor2}
    isBackgroundSignIn={Colors.white}
    colorUp={Colors.white}
    colorIn={Colors.linearColor2}
    sourceIcon={Images.adBannerIcon}
    pageId={3}
    isPasswordField={true}
    onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
    onBackPress={() => navigation.goBack()}
  />
  <Pressable
    style={styles.rowContainerView}
    onPress={() => setRacingModalVisible(true)}
  >
    <CustomTextInput
      pointerEvents="none"
      editable={false}
      textInputStyle={styles.headerTextStyle}
      racingDropDown={true}
      placeholderText={""}
      onPressWheelPicker={() => setRacingModalVisible(true)}
      inputTextStyle={styles.inputTextStyle}
      placeholderTextColor={Colors.black}
      value={getEventName()}
      activeOpacity={1}
    />
  </Pressable>
  <View style={styles.separatorStyle} />
  {eventLocation[0]?.race?.length > 0 ? (
    <SectionRoundList
      raceTrackData={eventLocation[0]?.race}
      selectedRaceID={selectedRaceID}
      onTrackSelected={(itemData) => setSelectedRaceID(itemData?.id)}
    />
  ) : null}
  {eventLocation?.length > 0 && (
    <View style={styles.countryCotainerStyle}>
      <ImageLoad
        resizeMode={"contain"}
        source={
          eventLocation[0]?.country?.country_flag?.includes("uploads")
            ? API_URL + "/" + eventLocation[0]?.country?.country_flag
            : eventLocation[0]?.country?.country_flag
        }
        style={styles.flagImageStyle}
      />
      <Text style={styles.countryTextStyle}>
        {eventLocation[0]?.country
          ? eventLocation[0]?.country?.country + " / "
          : ""}
        {eventLocation[0]?.state
          ? eventLocation[0]?.state?.state + " / "
          : ""}
        {eventLocation[0]?.eventName}
      </Text>
    </View>
  )}

  <CountryDetailsPageList raceData={raceData} />
  <View style={styles.mainPickerStyle}>
    {/* <Text style={styles.OddsTitleStyle}>{translate("OddsType")}</Text> */
}
//     <Pressable
//       style={styles.oddTypeWidth}
//       onPress={() => setLeagueModalVisible(true)}
//     >
//       <CustomTextInput
//         editable={false}
//         pointerEvents="none"
//         textInputStyle={styles.textModelInputStyle(
//           selectedOddsText == translate("OddsType")
//         )}
//         // dropDown={true}
//         racingDropDown={true}
//         dropDownStyle={styles.dropDownArrow}
//         dropDownIconStyle={styles.dropDownContainer}
//         placeholderText={""}
//         inputTextStyle={styles.inputTextStyle}
//         placeholderTextColor={Colors.red}
//         onPressWheelPicker={() => setLeagueModalVisible(true)}
//         value={selectedOddsText}
//         activeOpacity={1}
//       />
//     </Pressable>
//   </View>

//   <View style={styles.separatorStyle} />
//   <View style={styles.runnerMainStyle}>
//     <View style={styles.commonRow}>
//       <Text style={styles.runnerText}>{translate("Runner")}</Text>
//       <Pressable
//         style={styles.runnerArrowStyle}
//         onPress={() => onRunnerPress()}
//       >
//         <BlackSmallUpArrow
//           width={Metrics.rfv(10)}
//           height={Metrics.rfv(12)}
//         />
//       </Pressable>
//     </View>
//     <Pressable onPress={() => onExpandAllPress()}>
//       <Text style={styles.expandFullForm}>
//         {translate("ExpandFullForm")}
//       </Text>
//     </Pressable>

//     {isSeeAll == true ? (
//       <Pressable onPress={() => setSeeAll(false)}>
//         <Text style={styles.expandFullForm}>
//           {translate("SeeBest")}
//         </Text>
//       </Pressable>
//     ) : (
//       <Pressable onPress={() => setSeeAll(true)}>
//         <Text style={styles.expandFullForm}>
//           {translate("SeeAllRunner")}
//         </Text>
//       </Pressable>
//     )}
//   </View>
//   <FlatList
//     data={runnerData}
//     extraData={runnerData}
//     contentContainerStyle={styles.contentContainerStyle}
//     renderItem={({ item, index }) => (
//       <SingleRaceItem
//         seeAllOdds={isSeeAll}
//         itemData={item}
//         itemIndex={index}
//         sportId={sportId}
//         raceId={raceData?.id}
//         runnerInfo={runnerData}
//         selectedOddsData={oddsType}
//         bookkeeperData={bookkeeperData}
//         onRacingPress={onRacingPress}
//       />
//     )}
//     keyExtractor={(item, index) => index.toString()}
//   />
//   <View style={styles.HorizontalView}>
//     <TextHeaderTitle
//       title={translate("OurPartners")}
//       textStyle={styles.textStyle}
//     />
//     <View style={styles.partnerListBottom}>
//       <PartnersList data={PartnersData} />
//     </View>
//   </View>
// </ScrollView> */}

// <Animated.View
// style={{
//   position: "relative",
//   left: 0,
//   right: 0,
//   top: 0,
//   height: headerScrollHeight,
//   width: "100%",
//   overflow: "hidden",
//   zIndex: 1,
// }}
// >
// <Tabs.Container
//   renderHeader={myHeader}
//   renderTabBar={tabBar}
//   lazy={true}
//   headerHeight={HEADER_HEIGHT}
//   minHeaderHeight={MINHEADER_HEIGHT}
// >
//   <Tabs.Tab name="Results" label="Results">
//     <Tabs.ScrollView
// showsVerticalScrollIndicator={false}
// scrollEnabled={true}
// >
//     <ResultsTab
//       selectedOddsText={selectedOddsText}
//       sportId={sportId}
//       raceId={raceData?.id}
//       runnerData={runnerData}
//       oddsType={oddsType}
//       bookkeeperData={props?.bookkeeperData}
//       setLeagueModalVisible={setLeagueModalVisible}
//       RaceResultData={RaceResultData}
//       runnerInfo={runnerData}
//     />
//     </Tabs.ScrollView>
//   </Tabs.Tab>
//   <Tabs.Tab name="Exotics" label="Exotics">
//     <Tabs.ScrollView
// showsVerticalScrollIndicator={false}
// scrollEnabled={true}
// >
//     <ExoticsTab
//       selectedOddsText={selectedOddsText}
//       sportId={sportId}
//       raceId={raceData?.id}
//       runnerData={runnerData}
//       oddsType={oddsType}
//       bookkeeperData={props?.bookkeeperData}
//       setLeagueModalVisible={setLeagueModalVisible}
//     />
//     </Tabs.ScrollView>
//   </Tabs.Tab>
// </Tabs.Container>
// </Animated.View>
