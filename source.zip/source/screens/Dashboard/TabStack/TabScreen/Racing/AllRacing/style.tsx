import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  tabViewStyle: {
    width: Metrics.rfp(180),
    height: Metrics.rfv(3),
    marginTop: Metrics.rfv(50),
    backgroundColor: Colors.linearColor2,
  },
  indicatorStyle: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "center",
    width: Metrics.rfv(120),
    height: Metrics.rfv(6),
  },
  tabBarMainStyle: {
    backgroundColor: Colors.white,
    shadowOffset: { height: Metrics.rfv(0), width: Metrics.rfv(0) },
    shadowColor: "transparent",
    shadowOpacity: Metrics.rfv(0),
    elevation: Metrics.rfv(0),
    marginBottom: Metrics.rfv(8),
  },
  tabStyle: {
    alignSelf: "center",
    justifyContent: "center",
    flexDirection: "row",
    padding: 0,
  },
  contentContainerStyle: {
    justifyContent: "center",
  },
  indicator: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "center",
    height: Metrics.rfv(4),
    width: Metrics.rfv(100),
  },
  renderTabStyle: {
    elevation: Metrics.rfv(0),
    width: Metrics.rfv(120),
  },
  bottomBorder: {
    borderBottomWidth: Metrics.rfv(3),
    borderBottomColor: Colors.linearColor2,
    elevation: 0,
  },
  labelStyle: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(18),
    color: Colors.black,
    textTransform: "capitalize",
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(18),
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  seconBannerStyle: {
    marginTop: Metrics.rfv(10),
  },
});
