// import React, { useEffect, useState } from "react";
// import { DeviceEventEmitter, ScrollView, View } from "react-native";
// import { TabBar, TabView } from "react-native-tab-view";
// import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
// import AppStatusBar from "../../../../../../component/AppStatusBar";
// import Header from "../../../../../../component/HeaderComponent";
// import TextHeaderTitle from "../../../../../../component/Text";
// import { Colors, CommonStyle, Images } from "../../../../../../theme/index";
// import TodayTab from "../../../../TopStack/TodayTab";
// import styles from "./style";
// import { NAVIGATION } from "../../../../../../navigation";
// import { translate } from "../../../../../../utils/Localize";
// import commonStyles from "../../../../../../theme/commonStyle";
// import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
// const moment = require("moment");

// export default function AllRacingPage(props: any) {
//   const { navigation } = props;
//   const [index, setIndex] = useState(1);
//   const [routes, setRoutes] = useState(TAB_ARRAY);
//   const [selectedDate, setSelectedDate] = useState(
//     moment().format("YYYY-MM-DD")
//   );

//   const renderScene = ({ route }) => {
//     switch (route.key) {
//       case "firstTab":
//         return (
//           <TodayTab
//             tabIndex={1}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "secondTab":
//         return (
//           <TodayTab
//             tabIndex={2}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "thirdTab":
//         return (
//           <TodayTab
//             tabIndex={3}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "fourthTab":
//         return (
//           <TodayTab
//             tabIndex={4}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "fifthTab":
//         return (
//           <TodayTab
//             tabIndex={5}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "sixthTab":
//         return (
//           <TodayTab
//             tabIndex={6}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "saventhTab":
//         return (
//           <TodayTab
//             tabIndex={7}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "eighthTab":
//         return (
//           <TodayTab
//             tabIndex={8}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       case "ninthTab":
//         return (
//           <TodayTab
//             tabIndex={9}
//             selectedDate={selectedDate}
//             sportId={
//               props?.route?.params?.sportId
//                 ? [props?.route?.params?.sportId]
//                 : [1, 2, 3]
//             }
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   const onPressSignUp = () => {
//     navigation.navigate(NAVIGATION.REGISTER);
//   };
//   const onPressSignIn = () => {
//     navigation.navigate(NAVIGATION.LOGIN);
//   };

//   // const onProfilePress = () => {
//   //   navigation.navigate(NAVIGATION.PROFILE);
//   // };

//   return (
//     <AppSafeAreaView
//       firstSafeAreaViewStyle={styles.safeAreaViewStyle}
//       backgroundColor={Colors.white}
//     >
//       <AppStatusBar
//         backgroundColor={Colors.white}
//         isTransperent={false}
//         barStyle={"dark-content"}
//       />
//       <CommonHeaderComponent isShowSmartBIcon={true} />
//       <ScrollView
//         contentContainerStyle={commonStyles.scrollViewStyle}
//         overScrollMode={"never"}
//         showsVerticalScrollIndicator={false}
//         keyboardShouldPersistTaps={"handled"}
//         nestedScrollEnabled={true}
//       >
//         <Header
//           onPressSignUp={() => onPressSignUp()}
//           onPressSignIn={() => onPressSignIn()}
//           isBackgroundSignUp={Colors.linearColor2}
//           isBackgroundSignIn={Colors.white}
//           colorUp={Colors.white}
//           colorIn={Colors.linearColor2}
//           sourceIcon={Images.adBannerIcon}
//           isPasswordField={true}
//           onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
//           onBackPress={() => navigation.goBack()}
//           pageId={2}
//         />

//         <View style={CommonStyle.commonFlex}>
//           <View style={styles.horizontalView}>
//             <TextHeaderTitle
//               title={translate("Racing")}
//               textStyle={styles.textStyle}
//             />
//           </View>
//           <TabView
//             navigationState={{ index, routes }}
//             onIndexChange={(index) => setIndex(index)}
//             renderScene={renderScene}
//             lazy={true}
//             style={{ flex: 1 }}
//             swipeEnabled={false}
//             initialLayout={styles.tabViewStyle}
//             renderTabBar={(props) => (
//               <TabBar
//                 {...props}
//                 activeColor={Colors.linearColor2}
//                 inactiveColor={Colors.black}
//                 indicatorStyle={styles.indicatorStyle}
//                 style={styles.tabBarMainStyle}
//                 indicatorContainerStyle={styles.tabViewStyle}
//                 contentContainerStyle={styles.contentContainerStyle}
//                 tabStyle={styles.renderTabStyle}
//                 labelStyle={styles.labelStyle}
//                 onTabPress={({ route, preventDefault }) => {
//                   setSelectedDate(route.date);
//                 }}
//                 getLabelText={({ route }) => route.title}
//                 scrollEnabled={true}
//               />
//             )}
//           />
//         </View>
//       </ScrollView>
//     </AppSafeAreaView>
//   );
// }
// const TAB_ARRAY = [
//   {
//     key: "firstTab",
//     title: "Yesterday",
//     date: moment().subtract(1, "days").format("YYYY-MM-DD"),
//   },
//   { key: "secondTab", title: "Today", date: moment().format("YYYY-MM-DD") },
//   {
//     key: "thirdTab",
//     title: "Tomorrow",
//     date: moment().add(1, "days").format("YYYY-MM-DD"),
//   },
//   {
//     key: "fourthTab",
//     title: moment().add(2, "day").format("dddd"),
//     date: moment().add(2, "days").format("YYYY-MM-DD"),
//   },
//   {
//     key: "fifthTab",
//     title: moment().add(3, "day").format("dddd"),
//     date: moment().add(3, "days").format("YYYY-MM-DD"),
//   },
//   {
//     key: "sixthTab",
//     title: moment().add(4, "day").format("dddd"),
//     date: moment().add(4, "days").format("YYYY-MM-DD"),
//   },
//   {
//     key: "saventhTab",
//     title: moment().add(5, "day").format("dddd"),
//     date: moment().add(5, "days").format("YYYY-MM-DD"),
//   },
//   {
//     key: "eighthTab",
//     title: "Futures",
//     date: moment().add(1, "days").format("YYYY-MM-DD"),
//   },
//   {
//     key: "ninthTab",
//     title: "Archive",
//     date: moment().subtract(1, "days").format("YYYY-MM-DD"),
//   },
// ];

import React, { useRef, useState } from "react";
import { Animated, View } from "react-native";
import { MaterialTabBar, Tabs } from "react-native-collapsible-tab-view";

//component
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
import Header from "../../../../../../component/HeaderComponent";
import TextHeaderTitle from "../../../../../../component/Text";
//theme
import { Colors, CommonStyle, Images } from "../../../../../../theme/index";
import TodayTab from "../../../../TopStack/TodayTab";
//style
import styles from "./style";
//navigation
import { NAVIGATION } from "../../../../../../navigation";
//utils
import { translate } from "../../../../../../utils/Localize";

const moment = require("moment");

export default function AllRacingPage(props: any) {
  const { navigation } = props;
  const [layout, setLayout] = useState(0);
  const [selectedDate, setSelectedDate] = useState(
    moment().format("YYYY-MM-DD")
  );
  const scrollOffsetY = useRef(new Animated.Value(0)).current;
  const HEADER_HEIGHT = layout;
  const MINHEADER_HEIGHT = 0;
  const SCROLL_DISTANCE = HEADER_HEIGHT - MINHEADER_HEIGHT;
  const headerScrollHeight = scrollOffsetY.interpolate({
    inputRange: [0, SCROLL_DISTANCE],
    outputRange: [HEADER_HEIGHT, MINHEADER_HEIGHT],
    extrapolate: "clamp",
  });

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const find_dimesions = (layout) => {
    const { height } = layout;
    setLayout(height);
  };

  const myHeader = () => {
    return (
      <>
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <View style={CommonStyle.commonFlex}>
          <View style={styles.horizontalView}>
            <TextHeaderTitle
              title={translate("Racing")}
              textStyle={styles.textStyle}
            />
          </View>
        </View>
      </>
    );
  };
  const tabBar = (props) => {
    return (
      <MaterialTabBar
        {...props}
        scrollEnabled={true}
        activeColor={Colors.linearColor2}
        inactiveColor={Colors.black}
        labelStyle={styles.labelStyle}
        width={200}
        tabStyle={styles.tabStyle}
        indicatorStyle={styles.indicator}
        style={styles.bottomBorder}
      />
    );
  };
  return (
    <View
      style={CommonStyle.commonFlex}
      onLayout={(event) => {
        find_dimesions(event.nativeEvent.layout);
      }}
    >
      <AppSafeAreaView
        firstSafeAreaViewStyle={styles.safeAreaViewStyle}
        backgroundColor={Colors.cream}
      >
        <AppStatusBar
          backgroundColor={Colors.white}
          isTransperent={false}
          barStyle={"dark-content"}
        />
        <CommonHeaderComponent isShowSmartBIcon={true} />
        <Animated.View
          style={{
            position: "relative",
            left: 0,
            right: 0,
            top: 0,
            height: headerScrollHeight,
            width: "100%",
            overflow: "hidden",
            zIndex: 1,
          }}
        >
          <Tabs.Container
            renderHeader={myHeader}
            renderTabBar={tabBar}
            headerHeight={HEADER_HEIGHT}
            initialTabName={"secondTab"}
            lazy={true}
            onTabChange={(e) => {
              if (e?.index == 0) {
                setSelectedDate(
                  moment().subtract(1, "days").format("YYYY-MM-DD")
                );
              } else if (e?.index == 1) {
                setSelectedDate(moment().format("YYYY-MM-DD"));
              } else if (e?.index == 2) {
                setSelectedDate(moment().add(1, "days").format("YYYY-MM-DD"));
              } else if (e?.index == 3) {
                setSelectedDate(moment().add(2, "days").format("YYYY-MM-DD"));
              } else if (e?.index == 4) {
                setSelectedDate(moment().add(3, "days").format("YYYY-MM-DD"));
              } else if (e?.index == 5) {
                setSelectedDate(moment().add(4, "days").format("YYYY-MM-DD"));
              } else if (e?.index == 6) {
                setSelectedDate(moment().add(5, "days").format("YYYY-MM-DD"));
              } else if (e?.index == 7) {
                setSelectedDate(moment().add(1, "days").format("YYYY-MM-DD"));
              } else if (e?.index == 8) {
                setSelectedDate(
                  moment().subtract(1, "days").format("YYYY-MM-DD")
                );
              }
            }}
            minHeaderHeight={MINHEADER_HEIGHT}
          >
            <Tabs.Tab name="firstTab" label="Yesterday">
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={1}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab name="secondTab" label="Today">
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={2}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab name="thirdTab" label="Tomorrow">
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={3}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab
              name="fourthTab"
              label={moment().add(2, "day").format("dddd")}
            >
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={4}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab
              name="fifthTab"
              label={moment().add(3, "day").format("dddd")}
            >
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={5}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab
              name="sixthTab"
              label={moment().add(4, "day").format("dddd")}
            >
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={6}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab
              name="saventhTab"
              label={moment().add(5, "day").format("dddd")}
            >
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={7}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab name="eighthTab" label="Futures">
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={8}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
            <Tabs.Tab name="ninthTab" label="Archive">
              <Tabs.ScrollView showsVerticalScrollIndicator={false}>
                <TodayTab
                  tabIndex={9}
                  selectedDate={selectedDate}
                  sportId={
                    props?.route?.params?.sportId
                      ? [props?.route?.params?.sportId]
                      : [1, 2, 3]
                  }
                />
              </Tabs.ScrollView>
            </Tabs.Tab>
          </Tabs.Container>
        </Animated.View>
      </AppSafeAreaView>
    </View>
  );
}
