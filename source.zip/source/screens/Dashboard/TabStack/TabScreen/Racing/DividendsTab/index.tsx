import moment from "moment";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  FlatList,
  Linking,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { API_URL } from "../../../../../../../env.json";
import { callApi } from "../../../../../../api";
import API_CONFIG from "../../../../../../api/api_url";
import ImageLoad from "../../../../../../component/ImageLoad";
import LeaguePicker from "../../../../../../component/LeaguePicker";
import SingleRaceItem from "../../../../../../component/RaceItemComponent";
import CustomTextInput from "../../../../../../component/TextInput";
import { Colors, Metrics } from "../../../../../../theme";
import commonStyles from "../../../../../../theme/commonStyle";
import { BlackSmallUpArrow } from "../../../../../../theme/svg";
import { translate } from "../../../../../../utils/Localize";
import { print_data } from "../../../../../../utils/Logs";
import styles from "./style";

export default function DividendsTab(props: any) {
  const [runnerData, setRunnerData] = useState([]);
  const [isAllExpand, setIsAllExpand] = useState(false);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [isSeeAll, setSeeAll] = useState(false);
  const [bookkeeperData, setBookKeeperData] = useState([]);
  const [isLeaugeModalVisible, setLeagueModalVisible] = useState(false);
  const [selectedOddsText, setSelectedOddsText] = useState(
    translate("WinFixed")
  );

  const [visibleScrollBarWidth, setVisibleScrollBarWidth] = useState(0);
  const scrollIndicatorSize = visibleScrollBarWidth / 2.7;
  const difference = visibleScrollBarWidth - scrollIndicatorSize;
  const scrollIndicator = useRef(new Animated.Value(0)).current;

  const scrollIndicatorPosition = scrollIndicator.interpolate({
    extrapolate: "clamp",
    inputRange: [0, visibleScrollBarWidth / 6],
    outputRange: [0, difference],
  });
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  const onLayout = (event: { nativeEvent: { layout: { width: any } } }) => {
    const { width } = event.nativeEvent.layout;
    setVisibleScrollBarWidth(width);
  };

  useEffect(() => {
    setIsLoaderVisible(true);
    setRunnerData(props?.runnerData);
    fetchBookKeeper();
  }, []);

  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(props?.sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const oddsIcon = (BookKeeperId: number, type: any) => {
    let icon = bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;
    return (
      <Pressable
        onPress={() => {
          {
            Linking.openURL(iconData?.affiliate_link);
            handleBookkeeperCounter(BookKeeperId, type);
          }
        }}
        style={styles.oddsImageContainer}
      >
        <ImageLoad
          style={styles.oddsImageIcon}
          resizeMode={"stretch"}
          source={
            iconData?.small_logo?.includes("uploads")
              ? API_URL + "/" + iconData?.small_logo
              : iconData?.small_logo
          }
        />
      </Pressable>
    );
  };

  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          {
            Linking.openURL(iconData?.affiliate_link);
            handleBookkeeperCounter(BookKeeperId, type);
          }
        }}
      >
        <Text style={styles.bestValueTextStyle}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };

  const fetchSponsoredOdds = (data) => {
    let newOdds = data
      ?.filter((odds) => {
        return props?.sponsoredId?.includes(odds.BookKeeperId);
      })
      ?.slice(0, 2);
    let firstSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[0]
    );
    let secondSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[1]
    );
    let SponsoredOdds =
      props?.sponsoredId?.length > 0 ? (
        <>
          <View style={styles.sponsoreCenterView}>
            <View style={commonStyles.commonRow}>
              <View style={styles.sponsoreCenterView}>
                {firstSponsored?.length > 0 ? (
                  <>
                    {fetchClickableOdds(
                      firstSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0
                        ? firstSponsored?.[0]?.RaceOdds?.[0]?.intValue
                        : "SP",
                      firstSponsored?.[0]?.BookKeeperId,
                      "sponsored"
                    )}
                  </>
                ) : (
                  <View>
                    <Text style={styles.bestValueTextStyle}></Text>
                  </View>
                )}
                <View style={styles.topView}>
                  {oddsIcon(props?.sponsoredId?.[0], "sponsored")}
                </View>
              </View>
              {props?.sponsoredId?.[1] ? (
                <>
                  <View style={styles.sponsoreCenterView}>
                    {secondSponsored?.length > 0 ? (
                      <>
                        {fetchClickableOdds(
                          secondSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0
                            ? secondSponsored?.[0]?.RaceOdds?.[0]?.intValue
                            : "SP",
                          secondSponsored?.[0]?.BookKeeperId,
                          "sponsored"
                        )}
                      </>
                    ) : (
                      <View>
                        <Text style={styles.bestValueTextStyle}></Text>
                      </View>
                    )}
                    <View style={styles.topView}>
                      {oddsIcon(props?.sponsoredId?.[1], "sponsored")}
                    </View>
                  </View>
                </>
              ) : (
                <></>
              )}
            </View>
          </View>
        </>
      ) : (
        <Text>NOA</Text>
      );
    return SponsoredOdds;
  };

  const fetchBestOpenValue = (data) => {
    let maxno = data?.reduce((max, obj) => {
      obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue > max
        ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno == 0) {
        let newmaxno = data?.reduce((max, obj) => {
          obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue > max
            ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue)
            : (max = max);
          return max;
        }, -1);
        if (newmaxno !== -1) {
          let providerid = data
            ?.map((obj) => {
              if (obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue === maxno) {
                return obj?.BookKeeperId;
              }
            })
            ?.filter((x) => x !== undefined);
          return fetchClickableOdds(maxno, providerid?.[0], "header");
        } else {
          return "-";
        }
      } else {
        let providerid = data
          ?.map((obj) => {
            if (obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          ?.filter((x) => x !== undefined);
        return fetchClickableOdds(maxno, providerid?.[0], "header");
      }
    } else {
      return (
        <View style={styles.noaContainerView}>
          <Text style={styles.noaText}>{translate("NoaText")}</Text>
        </View>
      );
    }
  };

  const fetchBestOpenIcon = (data) => {
    let maxno = data?.reduce((max, obj) => {
      obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue > max
        ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = data
          ?.map((obj) => {
            if (obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          .filter((x) => x !== undefined);
        return oddsIcon(providerid?.[0], "header");
      } else {
        let newmaxno = data?.reduce((max, obj) => {
          obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue > max
            ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue)
            : (max = max);
          return max;
        }, -1);
        if (newmaxno !== -1) {
          let providerid = data
            ?.map((obj) => {
              if (
                obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue === newmaxno
              ) {
                return obj?.BookKeeperId;
              }
            })
            .filter((x) => x !== undefined);
          return oddsIcon(providerid?.[0], "header");
        } else {
          return "";
        }
      }
    } else {
      return "";
    }
  };
  const fetchCurrentBestValue = (data, oddsType) => {
    let maxno = data?.reduce((max, obj) => {
      obj?.RaceOdds?.[oddsType]?.intValue > max
        ? (max = obj?.RaceOdds?.[oddsType]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = data
          ?.map((obj) => {
            if (obj?.RaceOdds?.[oddsType]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          .filter((x) => x !== undefined);
        return fetchClickableOdds(maxno, providerid?.[0], "header");
      } else {
        return "SP";
      }
    } else {
      return "SP";
    }
  };
  const fetchCurrentBestIcon = (data, oddsType) => {
    let maxno = data?.reduce((max, obj) => {
      obj?.RaceOdds?.[oddsType]?.intValue > max
        ? (max = obj?.RaceOdds?.[oddsType]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = data
          ?.map((obj) => {
            if (obj?.RaceOdds?.[oddsType]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          .filter((x) => x !== undefined);
        return oddsIcon(providerid?.[0], "header");
      } else {
        return "";
      }
    } else {
      return "";
    }
  };

  const onRacingPress = (item, index) => {
    if (item?.isExpanded) {
      item.isExpanded = false;
    } else {
      for (let i = 0; i < runnerData.length; i++) {
        if (i === index) {
          runnerData[i].isExpanded = true;
        } else {
          runnerData[i].isExpanded = false;
        }
      }
    }
    setDataUpdated(!dataUpdated);
    setRunnerData(runnerData);
  };

  const fetchDividendOddsValue = (item, tote) => {
    if (item?.DividendData?.length > 0) {
      let oddsValue = item?.DividendData?.filter((obj) => {
        if (obj?.Tote === tote) {
          return obj?.Dividend;
        }
      });
      if (oddsValue?.[0]?.Dividend) {
        return (
          <View style={styles.dividerVicContainer}>
            <>{fetchClickableOdds(oddsValue?.[0]?.Dividend, 3, "header")}</>

            <View style={styles.topView}>{oddsIcon(3, "header")}</View>
          </View>
        );
      } else {
        return (
          <View style={styles.dividerVicContainer}>
            <View style={styles.noaNswContainer}>
              <Text style={styles.noaText}>{translate("NoaText")}</Text>
            </View>
          </View>
        );
      }
    } else {
      return (
        <View style={styles.dividerVicContainer}>
          <View style={styles.noaNswContainer}>
            <Text style={styles.noaText}>{translate("NoaText")}</Text>
          </View>
        </View>
      );
    }
  };

  const onRunnerPress = () => {
    setIsLoaderVisible(!isLoadervisible);
    if (isLoadervisible) {
      const runnerDescending = [...runnerData].sort((a, b) => a?.id - b?.id);
      setRunnerData(runnerDescending);
    } else {
      const runnerDescending = [...runnerData].sort((a, b) => b?.id - a?.id);
      setRunnerData(runnerDescending);
    }
  };

  const onExpandAllPress = () => {
    if (isAllExpand) {
      for (let i = 0; i < runnerData.length; i++) {
        runnerData[i].isExpanded = false;
      }
    } else {
      for (let i = 0; i < runnerData.length; i++) {
        runnerData[i].isExpanded = true;
      }
    }
    setIsAllExpand(!isAllExpand);
  };

  const fetchBookKeeper = async () => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setBookKeeperData(response?.body?.data?.result);
        }
      }
    } catch (error) {}
  };

  const renderItem = (item: any, index: any) => {
    return (
      <>
        {item?.runnerNumber === 1 && (
          <>
            <>
              <View style={styles.exoticsView} />
              <LinearGradient
                style={styles.racingView}
                colors={[Colors.linearColor1, Colors.linearColor2]}
              >
                <Text style={styles.raceText}>
                  {translate("Finalraceresults")}
                </Text>
              </LinearGradient>
              <View style={styles.resultsView}>
                <Text style={styles.dateText}>
                  {moment(props?.raceResultData?.updatedAt)
                    .utc(timezone)
                    .local()
                    .format("DD/MM/YYYY")}
                  {","}{" "}
                  {moment
                    .utc(props?.raceResultData?.updatedAt)
                    .local()
                    .format("hh:mm A")}
                </Text>

                <View style={styles.mainFinalRace}>
                  <Pressable
                    style={styles.oddTypeWidth}
                    onPress={() => setLeagueModalVisible(true)}
                  >
                    <CustomTextInput
                      editable={false}
                      pointerEvents="none"
                      textInputStyle={styles.textModelInputStyle(
                        selectedOddsText == translate("WinFixed")
                      )}
                      racingDropDown={true}
                      dropDownStyle={styles.dropDownArrow}
                      dropDownIconStyle={styles.dropDownContainer}
                      placeholderText={""}
                      inputTextStyle={styles.inputTextStyle}
                      placeholderTextColor={Colors.red}
                      onPressWheelPicker={() => setLeagueModalVisible(true)}
                      value={selectedOddsText}
                      activeOpacity={1}
                    />
                  </Pressable>
                </View>
                <>
                  {props?.dividendData?.length > 0 ? (
                    props?.dividendData
                      ?.slice(0, 4)
                      .map((obj: any, index: any) => {
                        let itemData = obj?.RunnerDetails?.[0];

                        return (
                          <View key={index}>
                            <>
                              <View
                                style={styles.commonRowWithArrow}
                                key={index}
                              >
                                {obj?.name ? (
                                  <Text style={styles.todayNumberTextStyle}>
                                    {obj?.runner_number}
                                    {"."} {obj?.name} ({obj?.barrier})
                                  </Text>
                                ) : (
                                  <Text style={styles.todayNumberTextStyle}>
                                    {itemData?.runnerNumber}
                                    {"."} {itemData?.animal?.name} (
                                    {itemData?.barrierNumber})
                                  </Text>
                                )}
                                <View
                                  style={
                                    obj?.Position === "1" || obj?.position === 1
                                      ? styles.PointView
                                      : styles.secondPointView
                                  }
                                >
                                  <Text style={styles.winText}>
                                    {obj?.Position
                                      ? Number(obj?.Position) === 1
                                        ? "1st"
                                        : Number(obj?.Position) === 2
                                        ? "2nd"
                                        : Number(obj?.Position) === 3
                                        ? "3rd"
                                        : `${Number(obj?.Position)}th`
                                      : Number(obj?.position) === 1
                                      ? "1st"
                                      : Number(obj?.position) === 2
                                      ? "2nd"
                                      : Number(obj?.position) === 3
                                      ? "3rd"
                                      : `${Number(obj?.position)}th`}
                                  </Text>
                                </View>
                              </View>
                              <View style={styles.fixedTextView}>
                                <View style={styles.fixedTextView1}>
                                  {props?.sportId == "1" && (
                                    <View style={styles.commonRowOnly}>
                                      <Text style={styles.fixedCommonStyle}>
                                        {translate("OddWeight")}
                                      </Text>
                                      <Text style={styles.valueTextStyle}>
                                        {Number(
                                          itemData?.JockeyWeight
                                            ? itemData?.JockeyWeight
                                            : item?.JockeyWeight
                                        ).toFixed(2) + translate("WeightKg")}
                                      </Text>
                                    </View>
                                  )}

                                  <View
                                    style={
                                      props?.sportId == "2"
                                        ? styles.commonRowOnly
                                        : styles.commonRowEndAlign
                                    }
                                  >
                                    <Text style={styles.fixedCommonStyle}>
                                      {props?.sportId == "2"
                                        ? translate("DriverTxt")
                                        : translate("Jockey")}
                                    </Text>
                                    <Text style={styles.valueTextStyle}>
                                      {itemData?.Jockey?.name
                                        ? itemData?.Jockey?.name
                                        : item?.Jockey?.name}
                                    </Text>
                                  </View>
                                </View>
                                {props?.sportId == "1" ||
                                props?.sportId == "2" ? (
                                  <View style={styles.commonRowOnly}>
                                    <Text style={styles.fixedCommonStyle}>
                                      {translate("Trainer")}
                                    </Text>
                                    <Text style={styles.valueTextStyle}>
                                      {itemData?.Trainer?.name
                                        ? itemData?.Trainer?.name
                                        : item?.Trainer?.name}
                                    </Text>
                                  </View>
                                ) : null}
                              </View>
                              <ScrollView
                                style={commonStyles.scrollViewStyle}
                                horizontal
                                showsHorizontalScrollIndicator={false}
                                nestedScrollEnabled={true}
                                onLayout={onLayout}
                                onScroll={Animated.event(
                                  [
                                    {
                                      nativeEvent: {
                                        contentOffset: { x: scrollIndicator },
                                      },
                                    },
                                  ],
                                  { useNativeDriver: false }
                                )}
                                scrollEventThrottle={16}
                                scrollEnabled={true}
                              >
                                <View style={styles.winMainContainer}>
                                  {/* {obj?.oddsData?.[0]?.data && (
                                    <>
                                      <View style={styles.openContainer}>
                                        <View style={styles.bestTextContiner}>
                                          <Text
                                            style={styles.bestTitleTextStyle}
                                          >
                                            {translate("TopeTote")}
                                          </Text>
                                        </View>
                                        <View style={styles.topToteContainer}>
                                          <Text
                                            style={styles.bestValueTextStyle}
                                          >
                                            {fetchCurrentBestValue(
                                              obj?.oddsData?.[0]?.data,
                                              0
                                            )}
                                          </Text>
                                          {fetchCurrentBestIcon(
                                            obj?.oddsData?.[0]?.data,
                                            0
                                          )}
                                        </View>
                                      </View>
                                    </>
                                  )} */}
                                  {/* 
                                  {obj?.oddsData?.[0]?.data && (
                                    <>
                                      <View style={styles.openContainer}>
                                        <View style={styles.topFluc}>
                                          <Text
                                            style={styles.bestTitleTextStyle}
                                          >
                                            {translate("TopFluc")}
                                          </Text>
                                        </View>
                                        <View style={styles.boxContainer}>
                                          <Text
                                            style={styles.bestValueTextStyle}
                                          >
                                            {fetchCurrentBestValue(
                                              obj?.oddsData?.[0]?.data,
                                              0
                                            )}
                                          </Text>
                                          {fetchCurrentBestIcon(
                                            obj?.oddsData?.[0]?.data,
                                            0
                                          )}
                                        </View>
                                      </View>
                                    </>
                                  )} */}
                                  {/* {obj?.oddsData?.[0]?.data && ( */}
                                  <View style={styles.sponsoredConainer}>
                                    <View style={styles.vicLeftView}>
                                      <Text style={styles.bestTitleTextStyle}>
                                        {translate("Vic")}
                                      </Text>
                                    </View>
                                    {/* <View style={styles.vicContainer}> */}
                                    {fetchDividendOddsValue(obj, "VIC")}
                                    {/* </View> */}
                                  </View>
                                  {/* )} */}
                                  {/* {obj?.oddsData?.[0]?.data && ( */}
                                  <View style={styles.sponsoredConainer}>
                                    <View style={styles.nswContainer}>
                                      <Text style={styles.bestTitleTextStyle}>
                                        {translate("Nsw")}
                                      </Text>
                                    </View>

                                    {fetchDividendOddsValue(obj, "NSW")}
                                  </View>
                                  {/* )} */}
                                  {/* {obj?.oddsData?.[0]?.data && ( */}
                                  <View style={styles.sponsoredConainer}>
                                    <View style={styles.nswContainer}>
                                      <Text style={styles.bestTitleTextStyle}>
                                        {translate("Qld")}
                                      </Text>
                                    </View>
                                    {fetchDividendOddsValue(obj, "QLD")}
                                  </View>
                                  {/* )} */}

                                  {/* {obj?.oddsData?.[0]?.data && (
                                    <View style={styles.sponsoredConainer}>
                                      <View style={styles.spListView}>
                                        <Text style={styles.bestTitleTextStyle}>
                                          {translate("SP")}
                                        </Text>
                                      </View>
                                      <View style={styles.spContainerView}>
                                        {fetchSponsoredOdds(
                                          obj?.oddsData?.[0]?.data
                                        )}
                                      </View>
                                    </View>
                                  )} */}
                                </View>
                              </ScrollView>
                              <View style={styles.itemSeparatorComponent}>
                                <Animated.View
                                  style={[
                                    styles.indicatorstyle,
                                    {
                                      width: scrollIndicatorSize,
                                      transform: [
                                        {
                                          translateX: scrollIndicatorPosition,
                                        },
                                      ],
                                    },
                                  ]}
                                ></Animated.View>
                              </View>
                              <View style={styles.winSeparatorComponent} />
                            </>
                          </View>
                        );
                      })
                  ) : (
                    <Text style={styles.noRaceText}>
                      {translate("NoDataAvailable")}
                    </Text>
                  )}
                </>
              </View>

              <LinearGradient
                style={styles.racingView}
                colors={[Colors.linearColor1, Colors.linearColor2]}
              >
                <Text style={styles.raceText}>{translate("RaceCard")}</Text>
              </LinearGradient>
            </>

            <View style={styles.mainPickerStyle}>
              <Pressable
                style={styles.oddTypeWidth}
                onPress={() => props?.setLeagueModalVisible(true)}
              >
                <CustomTextInput
                  editable={false}
                  pointerEvents="none"
                  textInputStyle={styles.textModelInputStyle(
                    props?.selectedOddsText == translate("OddsType")
                  )}
                  // dropDown={true}
                  racingDropDown={true}
                  dropDownStyle={styles.dropDownArrow}
                  dropDownIconStyle={styles.dropDownContainer}
                  placeholderText={""}
                  inputTextStyle={styles.inputTextStyle}
                  placeholderTextColor={Colors.red}
                  onPressWheelPicker={() => props?.setLeagueModalVisible(true)}
                  value={props?.selectedOddsText}
                  activeOpacity={1}
                />
              </Pressable>
            </View>
            <View style={styles.separatorStyle} />
            <View style={styles.runnerMainStyle}>
              <View style={styles.commonRow}>
                <Text style={styles.runnerText}>{translate("Runner")}</Text>
                <Pressable
                  style={styles.runnerArrowStyle}
                  onPress={() => onRunnerPress()}
                >
                  <BlackSmallUpArrow
                    width={Metrics.rfv(10)}
                    height={Metrics.rfv(12)}
                  />
                </Pressable>
              </View>
              <Pressable onPress={() => onExpandAllPress()}>
                <Text style={styles.expandFullForm}>
                  {translate("ExpandFullForm")}
                </Text>
              </Pressable>

              {isSeeAll == true ? (
                <Pressable onPress={() => setSeeAll(false)}>
                  <Text style={styles.expandFullForm}>
                    {translate("SeeBest")}
                  </Text>
                </Pressable>
              ) : (
                <Pressable onPress={() => setSeeAll(true)}>
                  <Text style={styles.expandFullForm}>
                    {translate("SeeAllRunner")}
                  </Text>
                </Pressable>
              )}
            </View>
          </>
        )}
        <SingleRaceItem
          seeAllOdds={isSeeAll}
          runnerData={props?.runnerData}
          itemData={item}
          itemIndex={index}
          sportId={props?.sportId}
          RaceResultData={props?.RaceResultData}
          raceId={props?.raceId}
          selectedOddsText={props?.selectedOddsText}
          runnerInfo={props?.runnersData}
          selectedOddsData={props?.oddsType}
          bookkeeperData={bookkeeperData}
          onRacingPress={onRacingPress}
        />
      </>
    );
  };

  return (
    <>
      <LeaguePicker
        isVisible={isLeaugeModalVisible}
        showModel={setLeagueModalVisible}
        data={oddsDataOption}
        onItemSelect={(selectedData) => {
          setSelectedOddsText(selectedData?.title);
          props?.onchangeResult(selectedData);
        }}
      />
      <FlatList
        data={props?.runnerData}
        extraData={props?.runnerData}
        nestedScrollEnabled={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.contentContainerStyle}
        renderItem={({ item, index }) => renderItem(item, index)}
        keyExtractor={(item, index) => index.toString()}
      />
    </>
  );
}

export const oddsDataOption = ["Win Fixed", "Place Fixed"];
