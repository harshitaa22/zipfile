import {
  View,
  Text,
  ScrollView,
  FlatList,
  Pressable,
  TextInput,
} from "react-native";
import React, { useEffect, useState } from "react";
import { useNavigation } from "@react-navigation/native";
import _ from "lodash";
import moment from "moment";
import RenderHTML from "react-native-render-html";
//component
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
import Header from "../../../../../../component/HeaderComponent";
import AddsCommonList from "../../../../../../component/AddsCommonApi";
import Loader from "../../../../../../component/ProgressBar";
import PartnersList from "../../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../../component/Text/index";
import ImageLoad from "../../../../../../component/ImageLoad";
//theme
import { Colors, Images, Metrics } from "../../../../../../theme";
import commonStyles from "../../../../../../theme/commonStyle";
//style
import styles from "./style";
//utils
import { translate } from "../../../../../../utils/Localize";
import { showToast } from "../../../../../../utils/commonFunction";
import { print_data } from "../../../../../../utils/Logs";
//theme
import { SearchIcon, TimeImg } from "../../../../../../theme/svg";
import { PartnersData } from "../../../../../../theme/dummyArray";
//api
import API_CONFIG from "../../../../../../api/api_url";
import { callApi } from "../../../../../../api";
//navigation
import { NAVIGATION } from "../../../../../../navigation";

const SearchNews = (props: any) => {
  const navigation = useNavigation();
  const { searchTitle } = props?.route?.params;
  const [isSelectIndex, setSelectIndex] = useState(0);
  const [search, setSearch] = useState(searchTitle);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [topSportSeriesData, setTopSportSeriesData] = useState([]);
  const [searchOffset, setSearchOffset] = useState(0);
  // const [searchCount, setSearchCount] = useState(0);
  const [allSportList, setAllSportList] = useState([]);

  useEffect(() => {
    setIsLoaderVisible(true);
    callGetAllNewsAPi(search, searchOffset);
    callGetAllCategoryAPi();
  }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const fetchNewsTime = (newsdate) => {
    const now = moment();
    const givenTime = moment(newsdate);
    const timeDiffMinutes = now.diff(givenTime, "minutes");
    const timeDiffHours = now.diff(givenTime, "hours");
    const timeDiffDays = now.diff(givenTime, "days");
    const timeDiffWeeks = now.diff(givenTime, "weeks");
    if (timeDiffMinutes > 60) {
      if (timeDiffMinutes / 60 > 24) {
        if (timeDiffDays > 7) {
          return `${timeDiffWeeks} ${
            timeDiffWeeks == 1 ? "week" : "weeks"
          } ago`;
        } else {
          return `${timeDiffDays} ${timeDiffDays == 1 ? "day" : "days"} ago`;
        }
      } else {
        return `${timeDiffHours} hours ago`;
      }
    } else {
      return `${timeDiffMinutes} minutes ago`;
    }
  };

  const renderNewsTagRelationsItem = (item, index) => {
    return (
      <View style={styles.championshipView}>
        <Text style={styles.footballText} numberOfLines={1}>
          {item?.NewsTag?.title}
        </Text>
      </View>
    );
  };

  const renderSportNewsItem = (item: any, index: any, title) => {
    const html = item?.data?.content;
    return (
      <Pressable
        key={index}
        onPress={() => {
          navigation.navigate(NAVIGATION.FOOTBALL_NEWS, {
            artclesCategory: title,
            articalId: item?.id,
            selectedCategory: isSelectIndex,
            onCategoryChange: (selctedIndex) => setSelectIndex(selctedIndex),
          });
        }}
      >
        <View style={commonStyles.alignCenterView}>
          <ImageLoad
            style={styles.blankImage}
            source={item?.mainMedia?.article?.url}
            resizeMode={"contain"}
          />
          <View style={styles.loremContainer}>
            {item?.id == 0 && (
              <View style={styles.exclusiveContainer}>
                <Text style={styles.exclusiveText}>
                  {translate("Exclusive")}
                </Text>
              </View>
            )}
            {html && (
              <RenderHTML
                contentWidth={100}
                source={{ html }}
                tagsStyles={{
                  p: { color: Colors.black },
                  h2: { color: Colors.black },
                }}
              />
            )}
            <Text numberOfLines={2} style={styles.title}>
              {item?.subTitle ? item?.subTitle : item?.title}
            </Text>
            <View style={commonStyles.centerView}>
              <View style={styles.listView}>
                <FlatList
                  horizontal
                  data={item?.NewsTagRelations.slice(0, 1)}
                  showsVerticalScrollIndicator={false}
                  contentContainerStyle={styles.width}
                  keyExtractor={(item, index) => index.toString()}
                  renderItem={({ item, index }) =>
                    renderNewsTagRelationsItem(item, index)
                  }
                />
              </View>
              <View style={commonStyles.alignCenterView}>
                <TimeImg
                  style={{ height: Metrics.rfv(12), width: Metrics.rfv(12) }}
                />
                <Text style={styles.timeText} numberOfLines={1}>
                  {fetchNewsTime(item?.rapidCreatedAt)}
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.grayWidth} />
      </Pressable>
    );
  };

  const callGetAllCategoryAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_ALL_CATEGORIES,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let sportList = response?.body?.data?.result;
          const allCategory = { initialTitle: "All", id: 0 };
          let allCategoryList = [allCategory, ...sportList];
          // let sortData = allCategoryList?.sort((a, b) => {
          //   return a.initialTitle > b.initialTitle ? 1 : -1;
          // });
          setAllSportList(allCategoryList);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);

      print_data("==GetAllCategory===exception=====" + error);
    }
  };

  const callGetAllNewsAPi = async (search, page) => {
    try {
      const response = await callApi(
        API_CONFIG.GET_ALL_NEWS +
          `articles?NewsCategoryId=${
            isSelectIndex == 0 ? "" : isSelectIndex
          }&limit=5&offset=${page}&search=${search}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setTopSportSeriesData(response?.body?.data?.result?.raw);
          // if (response?.body?.data?.result?.count > 20) {
          //   setSearchCount(Math.ceil(response?.body?.data?.result?.count / 20));
          // }

          setIsLoaderVisible(false);
          setSearch("");
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);

        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);

      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowSmartBIcon={true}
        isShowNewsBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        // onMomentumScrollEnd={(event) => {
        //   if (
        //     !isLoadervisible &&
        //     searchCount !== Math.ceil(searchOffset / 20)
        //   ) {
        //     setIsLoaderVisible(true);
        //     callGetAllNewsAPi(searchOffset + 20);
        //     setSearchOffset(searchOffset + 20);
        //   }
        // }}
      >
        <Header
          onPress={() => {}}
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalContainer}>
          <>
            <View style={styles.seconBannerStyle}>
              <AddsCommonList
                AfterHeader={"AfterHeader"}
                page={2}
                placeholder={Images.sportFirstImg}
                bannerStyle={styles.secondBannerStyle}
              />
            </View>
            <View style={styles.serchContainerStyle}>
              <TextInput
                style={styles.searchTextinputStyle}
                placeholder={translate("SearchBYName")}
                placeholderTextColor={Colors.borderDropDown}
                numberOfLines={1}
                value={search}
                onChangeText={(text) => {
                  setSearch(text);
                }}
              />
              <Pressable
                onPress={() => {
                  search?.trim()?.length > 0 && setIsLoaderVisible(true);
                  callGetAllNewsAPi(search, 0);
                }}
              >
                <SearchIcon style={styles.searchIconStyle} />
              </Pressable>
            </View>
            {topSportSeriesData?.length > 0 ? (
              <FlatList
                data={topSportSeriesData}
                scrollEnabled={false}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.topSeriesContainer}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) =>
                  renderSportNewsItem(
                    item,
                    index,
                    allSportList[item?.NewsCategoryId]?.initialTitle
                  )
                }
              />
            ) : (
              <Text style={styles.noRaceText}>
                {translate("NoDataAvailable")}
              </Text>
            )}
          </>
          <View style={styles.seconBannerStyle}>
            <AddsCommonList
              AfterHeader={"AfterHeader"}
              page={2}
              placeholder={Images.sportFirstImg}
              bannerStyle={styles.secondBannerStyle}
            />
          </View>
        </View>
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.textStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default SearchNews;
