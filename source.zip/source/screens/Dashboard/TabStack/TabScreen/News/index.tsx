import React, {
  createRef,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import {
  RefreshControl,
  ScrollView,
  Text,
  TextInput,
  View,
  FlatList,
  Pressable,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import RenderHTML from "react-native-render-html";
import _ from "lodash";
import moment from "moment";
//component
import AppSafeAreaView from "../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../component/AppStatusBar";
import Header from "../../../../../component/HeaderComponent/index";
import PartnersList from "../../../../../component/PartnersList/index";
import TextHeaderTitle from "../../../../../component/Text/index";
import Loader from "../../../../../component/ProgressBar";
import CommonHeaderComponent from "../../../../../component/CommonHeaderComponent";
import TrackProfileSectionPage from "../../../../../component/TrckProfilesSectionPage";
import AddsCommonList from "../../../../../component/AddsCommonApi";
import ImageLoad from "../../../../../component/ImageLoad";
//theme
import { PartnersData } from "../../../../../theme/dummyArray";
import {
  Colors,
  CommonStyle,
  Images,
  Metrics,
} from "../../../../../theme/index";
import {
  LeftUpArrow,
  RightUpArrow,
  SearchIcon,
  TimeImg,
} from "../../../../../theme/svg";
import commonStyles from "../../../../../theme/commonStyle";
//style
import styles from "./style";
//navigation
import { NAVIGATION } from "../../../../../navigation";
//utils
import { translate } from "../../../../../utils/Localize";
import { print_data } from "../../../../../utils/Logs";
import { showToast } from "../../../../../utils/commonFunction";
//api
import API_CONFIG from "../../../../../api/api_url";
import { callApi } from "../../../../../api";
import WebView from "react-native-webview";
import SweetPagination from "../../../../../component/PaginationComponent";

export default function NewsTab() {
  const navigation = useNavigation();
  const scrollToTopRef = useRef(null);
  const [search, setSearch] = useState("");
  const [isSelectIndex, setSelectIndex] = useState(0);
  const [selectedSportIndex, setselectedSportIndex] = useState(0);
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [allSportList, setAllSportList] = useState([]);
  const [topSeriesData, setTopSeriesData] = useState([]);
  const [topSportSeriesData, setTopSportSeriesData] = useState([]);
  const [featureData, setFeaturesData] = useState([]);
  const [homeArticles, setHomeArticlesData] = useState([]);
  const [allFeaturesData, setAllFeaturesData] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [sportId, setSportId] = useState(0);
  const [categoryCount, setCategoryCount] = useState();
  const [index, setIndex] = useState(1);
  const [newsCount, setNewsCount] = useState(0);
  const [page, setPage] = useState(null);
  const [categoriesData, setCategoriesData] = useState({});
  const [isLoadMore, setIsLoadMore] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  useEffect(() => {
    callGetAllCategoryAPi();
  }, []);

  useEffect(() => {
    setIsLoaderVisible(true);
    setIsLoadMore(false);
    if (isSelectIndex == 0) {
      // Used to show list of news for all category
      callGetTopStoriesAPI();
      // Used to show all list of news for all category
      callHomeArticleAPI();
      // Used to show horizontal slider in all category
      callAllFeatureArticlesAPi();
    } else {
      // Used to show horizontal slider in other sport category
      callFeatureArticlesAPi();

      // Used to show list of news for other category
      callGetAllNewsAPi(currentPage);
    }
  }, [isSelectIndex, selectedSportIndex]);

  const onRefresh = () => {
    setRefreshing(true);
    callGetAllNewsAPi(currentPage);
    callGetTopStoriesAPI();
    callHomeArticleAPI();
    callFeatureArticlesAPi();
  };

  const handleScrollEnd = (event) => {
    if (!isLoadMore && currentPage + 10 !== newsCount * 10) {
      setIsLoadMore(true);
      callGetAllNewsListAPi(currentPage + 10);
      setCurrentPage(currentPage + 10);
    }
  };

  const fetchNewsTime = (newsdate) => {
    const now = moment();
    const givenTime = moment(newsdate);
    const timeDiffMinutes = now.diff(givenTime, "minutes");
    const timeDiffHours = now.diff(givenTime, "hours");
    const timeDiffDays = now.diff(givenTime, "days");
    const timeDiffWeeks = now.diff(givenTime, "weeks");
    if (timeDiffMinutes > 60) {
      if (timeDiffMinutes / 60 > 24) {
        if (timeDiffDays > 7) {
          return `${timeDiffWeeks} ${
            timeDiffWeeks == 1 ? "week" : "weeks"
          } ago`;
        } else {
          return `${timeDiffDays} ${timeDiffDays == 1 ? "day" : "days"} ago`;
        }
      } else {
        return `${timeDiffHours} hours ago`;
      }
    } else {
      return `${timeDiffMinutes} minutes ago`;
    }
  };

  const renderFootballItem = (item: any, index: any, title: any) => {
    return (
      <Pressable
        style={styles.rightView}
        key={index}
        onPress={() =>
          navigation.navigate(NAVIGATION.FOOTBALL_NEWS, {
            artclesCategory: title,
            articalId: item?.NewsArticle ? item?.NewsArticle?.id : item?.id,
            selectedCategory: isSelectIndex,
            sportSelectedIndex: selectedSportIndex,
            onCategoryChange: (selectedId, selctedIndex) => {
              setSelectIndex(selectedId), setselectedSportIndex(selctedIndex);
            },
          })
        }
      >
        {item?.NewsArticle?.mainMedia?.article?.url?.length > 0 && (
          <ImageLoad
            source={item?.NewsArticle?.mainMedia?.article?.url}
            style={styles.newsBanner}
            resizeMode={"contain"}
          />
        )}

        <View style={styles.blurContainer}>
          <View style={styles.footballContainer}>
            <Text style={styles.footballSliderText}>
              {allSportList[item?.NewsArticle?.NewsCategoryId]?.initialTitle}
            </Text>
          </View>
          <View style={styles.bottomLoremView}>
            <Text style={styles.loremText}>{item?.NewsArticle?.title}</Text>
            <Text style={styles.updateText}>
              {fetchNewsTime(item?.NewsArticle?.rapidCreatedAt)}
            </Text>
          </View>
        </View>
      </Pressable>
    );
  };

  const renderNewsTagRelationsItem = (item, index) => {
    return (
      <View style={styles.championshipView}>
        <Text style={styles.footballText} numberOfLines={1}>
          {item?.NewsTag?.title}
        </Text>
      </View>
    );
  };

  const renderNewsItem = (item: any, index: any, title: any) => {
    const html = item?.data?.content;
    return (
      <Pressable
        key={index}
        onPress={() => {
          navigation.navigate(NAVIGATION.FOOTBALL_NEWS, {
            articalId: item?.NewsArticle ? item?.NewsArticle?.id : item?.id,
            artclesCategory: title,
            selectedCategory: isSelectIndex,
            sportSelectedIndex: selectedSportIndex,
            onCategoryChange: (selectedId, selctedIndex) => {
              setSelectIndex(selectedId), setselectedSportIndex(selctedIndex);
            },
          });
        }}
      >
        <View style={commonStyles.alignCenterView}>
          {item?.NewsArticle?.mainMedia?.article?.url?.length > 0 && (
            <ImageLoad
              style={styles.blankImage}
              source={item?.NewsArticle?.mainMedia?.article?.url}
              resizeMode={"contain"}
            />
          )}

          <View style={styles.loremContainer}>
            {item?.id == 0 && (
              <View style={styles.exclusiveContainer}>
                <Text style={styles.exclusiveText}>
                  {translate("Exclusive")}
                </Text>
              </View>
            )}
            {html && (
              <RenderHTML
                contentWidth={100}
                source={{ html }}
                tagsStyles={{
                  p: { color: Colors.black },
                  h2: { color: Colors.black },
                }}
              />
            )}
            <Text style={styles.title} numberOfLines={2}>
              {item?.NewsArticle?.subTitle
                ? item?.NewsArticle?.subTitle
                : item?.NewsArticle?.title}
            </Text>
            <View style={commonStyles.centerView}>
              <View style={styles.listView}>
                {item?.NewsArticle?.NewsCategoryId && (
                  <>
                    {item?.NewsArticle?.NewsTagRelations?.length > 0 && (
                      <View style={styles.footballView}>
                        <Text style={styles.footballText} numberOfLines={1}>
                          {item?.NewsArticle?.NewsTagRelations?.slice(0, 1).map(
                            (data) => {
                              return data?.NewsTag?.title;
                            }
                          )}
                        </Text>
                      </View>
                    )}
                  </>
                )}
              </View>
              <View style={commonStyles.alignCenterView}>
                <TimeImg
                  style={{ height: Metrics.rfv(12), width: Metrics.rfv(12) }}
                />
                <Text style={styles.timeText}>
                  {fetchNewsTime(item?.NewsArticle?.rapidCreatedAt)}
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.grayWidth} />
      </Pressable>
    );
  };

  const getSportTitle = () => {
    const filterdData = _.filter(allSportList, { id: isSelectIndex });
    if (filterdData?.length > 0) {
      return filterdData[0]?.initialTitle;
    } else {
      return "";
    }
  };

  const renderSportNewsItem = (item: any, index: any, title) => {
    const html = item?.data?.content;
    return (
      <Pressable
        key={index}
        onPress={() => {
          navigation.navigate(NAVIGATION.FOOTBALL_NEWS, {
            artclesCategory: title,
            articalId: item?.id,
            selectedCategory: isSelectIndex,
            sportSelectedIndex: selectedSportIndex,
            onCategoryChange: (selectedId, selctedIndex) => {
              setSelectIndex(selectedId), setselectedSportIndex(selctedIndex);
            },
          });
        }}
      >
        <View style={commonStyles.alignCenterView}>
          {item?.mainMedia?.article?.url?.length > 0 && (
            <ImageLoad
              style={styles.blankImage}
              source={item?.mainMedia?.article?.url}
              resizeMode={"contain"}
            />
          )}
          <View style={styles.loremContainer}>
            {/* {item?.id == 0 && (
              <View style={styles.exclusiveContainer}>
                <Text style={styles.exclusiveText}>
                  {translate("Exclusive")}
                </Text>
              </View>
            )} */}
            {html && (
              <RenderHTML
                contentWidth={100}
                source={{ html }}
                tagsStyles={{
                  p: { color: Colors.black },
                  h2: { color: Colors.black },
                }}
              />
            )}
            <Text style={styles.title} numberOfLines={2}>
              {item?.subTitle ? item?.subTitle : item?.title}
            </Text>
            <View style={commonStyles.centerView}>
              <View style={styles.rightTextView}>
                <FlatList
                  horizontal
                  data={item?.NewsTagRelations?.slice(0, 1)}
                  showsVerticalScrollIndicator={false}
                  keyExtractor={(item, index) => index.toString()}
                  contentContainerStyle={styles.width}
                  renderItem={({ item, index }) =>
                    renderNewsTagRelationsItem(item, index)
                  }
                />
              </View>
              <View style={commonStyles.alignCenterView}>
                <TimeImg
                  style={{ height: Metrics.rfv(12), width: Metrics.rfv(12) }}
                />
                <Text style={styles.timeText}>
                  {fetchNewsTime(item?.rapidCreatedAt)}
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.grayWidth} />
      </Pressable>
    );
  };

  const callGetAllCategoryAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_ALL_CATEGORIES,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let sportList = response?.body?.data?.result;
          const allCategory = { initialTitle: "All", id: 0 };
          let allCategoryList = [allCategory, ...sportList];
          // let sortData = allCategoryList?.sort((a, b) => {
          //   return a.initialTitle > b.initialTitle ? 1 : -1;
          // });
          setAllSportList(allCategoryList);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);

      print_data("==GetAllCategory===exception=====" + error);
    }
  };

  const callGetAllNewsAPi = async (currentPage) => {
    try {
      const response = await callApi(
        API_CONFIG.GET_ALL_NEWS +
          `articles?NewsCategoryId=` +
          isSelectIndex +
          `&limit=10&offset=${currentPage}&search=`,
        null,
        API_CONFIG.GET,
        null
      );
      print_data(
        API_CONFIG.GET_ALL_NEWS +
          `articles?NewsCategoryId=` +
          isSelectIndex +
          `&limit=10&offset=${currentPage}&search=`
      );
      print_data("1233======");
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let newsList = response?.body?.data?.result?.raw;
          // const itemData: any = [];
          // newsList?.map((item: any, index) => {
          //   itemData.push(item);
          // });
          // // print_data("topSerire====");
          // // print_data(topSeriesData);
          // // print_data("topSerire====");

          // const finalList = [...topSportSeriesData, ...itemData];

          setTopSportSeriesData(newsList);
          setSelectedIndex(isSelectIndex);
          // setTopSportSeriesData(response?.body?.data?.result?.raw);

          // setCategoriesData(response?.body?.data?.result);
          // response?.body?.data?.result?.raw?.map((item, index) => {
          //   print_data("item=====" + item?.id);
          //   setSportId(item?.id);
          // });

          setNewsCount(Math.ceil(response?.body?.data?.result?.count / 10));

          setIsLoaderVisible(false);

          setRefreshing(false);
          setIsLoadMore(false);
        }
      } else {
        setIsLoaderVisible(false);

        setRefreshing(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);

      setRefreshing(false);
      print_data("=callGetAllNewsAPi====exception=====" + error);
    }
  };

  const callGetAllNewsListAPi = async (currentPage) => {
    try {
      const response = await callApi(
        API_CONFIG.GET_ALL_NEWS +
          `articles?NewsCategoryId=` +
          selectedIndex +
          `&limit=10&offset=${currentPage}&search=`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let newsList = response?.body?.data?.result?.raw;
          const itemData: any = [];
          newsList?.map((item: any, index) => {
            itemData.push(item);
          });

          const finalList = [...topSportSeriesData, ...itemData];

          setTopSportSeriesData(finalList);

          setNewsCount(Math.ceil(response?.body?.data?.result?.count / 10));

          setIsLoadMore(false);

          setRefreshing(false);
        }
      } else {
        setIsLoadMore(false);
        setRefreshing(false);
      }
    } catch (error) {
      setIsLoadMore(false);
      setRefreshing(false);
      print_data("=callGetAllNewsAPi====exception=====" + error);
    }
  };

  const callGetTopStoriesAPI = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_ARTICALES_ID,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setTopSeriesData(response?.body?.data?.result?.slice(0, 6));
          setIsLoaderVisible(false);
          setRefreshing(false);
        } else {
          setIsLoaderVisible(false);
          setRefreshing(false);
        }
      } else {
        setIsLoaderVisible(false);
        setRefreshing(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setRefreshing(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const callHomeArticleAPI = async () => {
    try {
      const response = await callApi(
        API_CONFIG.HOME_ARTICALES,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setHomeArticlesData(response?.body?.data?.result);
          setIsLoaderVisible(false);
          setRefreshing(false);
        } else {
          setIsLoaderVisible(false);
          setRefreshing(false);
        }
      } else {
        setIsLoaderVisible(false);
        setRefreshing(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setRefreshing(false);
      print_data("=====exception==HomeArticle===" + error);
    }
  };

  const callAllFeatureArticlesAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_FEATURE_ARTICALES,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setAllFeaturesData(response?.body?.data?.result);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      print_data("=====exception===callAllFeatureArticlesAPi==" + error);
    }
  };

  const callFeatureArticlesAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_FEATURE_ARTICALES +
          `?NewsCategoryId=` +
          isSelectIndex +
          `&limit=5&offset=0&search=`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setFeaturesData(response?.body?.data?.result);

          setRefreshing(false);
        }
      } else {
        setRefreshing(false);
      }
    } catch (error) {
      setRefreshing(false);
      print_data("=====exception==Feature===" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent isShowSmartBIcon={true} />
      <ScrollView
        ref={scrollToTopRef}
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        onMomentumScrollEnd={handleScrollEnd}
        scrollEventThrottle={0.01}
      >
        <Header
          onPress={() => {}}
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <>
          <View style={styles.horizontalView}>
            <TextHeaderTitle
              title={translate("News")}
              textStyle={styles.headerNewsTitle}
            />
          </View>
          <View style={styles.searchView}>
            <View style={styles.serchContainerStyle}>
              <TextInput
                style={styles.searchTextinputStyle}
                placeholder={translate("SearchBYName")}
                placeholderTextColor={Colors.borderDropDown}
                numberOfLines={1}
                value={search}
                onChangeText={(text) => {
                  setSearch(text);
                }}
              />
              <Pressable
                onPress={() => {
                  {
                    search?.trim()?.length > 0 &&
                      (navigation.navigate(NAVIGATION.SEARCH_NEWS, {
                        searchTitle: search,
                      }),
                      setSearch(""));
                  }
                }}
              >
                <SearchIcon style={styles.searchIconStyle} />
              </Pressable>
            </View>
            {allSportList?.length > 0 && (
              <TrackProfileSectionPage
                data={allSportList}
                isSelectIndex={isSelectIndex}
                selectedItemIndex={selectedSportIndex}
                onItemClick={(itemId: any, index: any) => {
                  setSelectIndex(itemId);
                  setselectedSportIndex(index);
                  setCurrentPage(0);
                }}
                selectedId={isSelectIndex}
              />
            )}
          </View>
          <View style={styles.height} />
          <View style={styles.horizontalContainer}>
            {isSelectIndex == 0 ? (
              <>
                {isLoadervisible ? (
                  <View style={styles.loaderContainer}>
                    <View style={commonStyles.loader}>
                      <Loader size={"small"} />
                    </View>
                  </View>
                ) : (
                  <>
                    <Text style={styles.topTopSeries}>
                      {translate("TopStories")}
                    </Text>
                    <View style={styles.botoomwidth} />
                    <FlatList
                      data={isSelectIndex == 0 ? allFeaturesData : featureData}
                      horizontal
                      showsHorizontalScrollIndicator={false}
                      showsVerticalScrollIndicator={false}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item, index }) =>
                        renderFootballItem(
                          item,
                          index,
                          allSportList[item?.NewsArticle?.NewsCategoryId]
                            ?.initialTitle
                        )
                      }
                    />
                    <View style={styles.belowSlider}>
                      <AddsCommonList
                        BelowSlider={"BelowSlider"}
                        page={13}
                        placeholder={Images.sportFirstImg}
                        bannerStyle={styles.secondBannerStyle}
                      />
                    </View>

                    {topSeriesData?.length > 0 ? (
                      <FlatList
                        data={topSeriesData}
                        scrollEnabled={false}
                        showsVerticalScrollIndicator={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          renderNewsItem(item, index, "TopStories")
                        }
                      />
                    ) : (
                      <Text style={styles.noRaceText}>
                        {translate("NoDataAvailable")}
                      </Text>
                    )}
                    <AddsCommonList
                      AfterHeader={"AfterHeader"}
                      page={13}
                      placeholder={Images.sportFirstImg}
                      bannerStyle={styles.secondBannerStyle}
                    />
                  </>
                )}
              </>
            ) : (
              <>
                <View>
                  {isLoadervisible ? (
                    <View style={styles.loaderContainer}>
                      <View style={commonStyles.loader}>
                        <Loader size={"small"} />
                      </View>
                    </View>
                  ) : (
                    <FlatList
                      data={isSelectIndex == 0 ? allFeaturesData : featureData}
                      horizontal
                      showsHorizontalScrollIndicator={false}
                      showsVerticalScrollIndicator={false}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item, index }) =>
                        renderFootballItem(item, index, "football")
                      }
                    />
                  )}
                  <View style={styles.seconBannerStyle}>
                    <AddsCommonList
                      NewsPageCategory={"NewsPageCategory"}
                      page={14}
                      placeholder={Images.sportFirstImg}
                      bannerStyle={styles.secondBannerStyle}
                    />
                  </View>
                </View>
                {topSportSeriesData?.length > 0 ? (
                  <>
                    {!isLoadervisible && (
                      <>
                        <Text style={styles.topSeries}>
                          {getSportTitle()} {translate("News")}
                        </Text>
                        <View style={styles.botoomwidth} />
                        <FlatList
                          data={topSportSeriesData}
                          scrollEnabled={false}
                          showsVerticalScrollIndicator={false}
                          keyExtractor={(item, index) => index.toString()}
                          renderItem={({ item, index }) =>
                            renderSportNewsItem(item, index, getSportTitle())
                          }
                        />
                      </>
                    )}
                  </>
                ) : (
                  <View style={styles.noDataContainer}>
                    <Text style={styles.noRaceText}>
                      {translate("NoDataAvailable")}
                    </Text>
                  </View>
                )}
              </>
            )}
          </View>
          {isSelectIndex == 0 && (
            <>
              {homeArticles?.map((itemData, index) => (
                <View style={styles.horizontalContainer} key={index}>
                  <View style={styles.seconBannerStyle}>
                    {/* {index == 0 && (
                      <AddsCommonList
                        AfterHeader={"AfterHeader"}
                        page={13}
                        placeholder={Images.sportFirstImg}
                        bannerStyle={styles.secondBannerStyle}
                      />
                    )} */}
                    {/* ) : ( */}
                    {/* <AddsCommonList
                      index={index}
                      belowFootball={"BelowFootball"}
                      page={13}
                      placeholder={Images.sportFirstImg}
                      bannerStyle={styles.secondBannerStyle}
                    /> */}
                    {/* )} */}
                  </View>
                  <Pressable
                    onPress={() => {
                      setSelectIndex(itemData?.NewsCategory?.id);
                      scrollToTopRef?.current?.scrollTo({
                        y: 0,
                        animated: true,
                      });
                      setTimeout(() => {
                        setselectedSportIndex(
                          allSportList?.findIndex(
                            (obj) => obj?.id === itemData?.NewsCategory?.id
                          )
                        );
                      }, 1000);
                    }}
                  >
                    <Text style={styles.topSeries}>
                      {itemData?.NewsCategory?.title + " " + translate("News")}
                    </Text>
                  </Pressable>
                  <View style={styles.botoomwidth} />
                  <FlatList
                    data={itemData?.NewsHomeRelations?.slice(0, 3)}
                    scrollEnabled={false}
                    showsVerticalScrollIndicator={false}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({ item, index }) =>
                      renderNewsItem(item, index, itemData?.NewsCategory?.title)
                    }
                  />
                  <AddsCommonList
                    index={index}
                    belowFootball={"BelowFootball"}
                    page={13}
                    placeholder={Images.sportFirstImg}
                    bannerStyle={styles.secondBannerStyle}
                  />
                </View>
              ))}
            </>
          )}

          <View style={styles.horizontalView}>
            {isLoadMore && (
              <ActivityIndicator size={"small"} color={Colors.black} />
            )}
            <TextHeaderTitle
              title={translate("OurPartners")}
              textStyle={styles.textStyle}
            />
          </View>
          <View style={styles.partnerListBottom}>
            <PartnersList />
          </View>
        </>
      </ScrollView>
    </AppSafeAreaView>
  );
}
