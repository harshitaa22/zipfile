import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useRef, useState } from "react";
import {
  Dimensions,
  FlatList,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import AutoHeightWebView from "react-native-autoheight-webview";
import RenderHTML from "react-native-render-html";
import moment from "moment";
//component
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
import Header from "../../../../../../component/HeaderComponent";
import PartnersList from "../../../../../../component/PartnersList";
import Loader from "../../../../../../component/ProgressBar";
import TrackProfileSectionPage from "../../../../../../component/TrckProfilesSectionPage";
import ImageLoad from "../../../../../../component/ImageLoad";
import TextHeaderTitle from "../../../../../../component/Text/index";
//navigation
import { NAVIGATION } from "../../../../../../navigation";
//utils
import { print_data } from "../../../../../../utils/Logs";
import { showToast } from "../../../../../../utils/commonFunction";
import { translate } from "../../../../../../utils/Localize";
//theme
import { Colors, Images, Metrics } from "../../../../../../theme";
import { SearchIcon, TimeImg } from "../../../../../../theme/svg";
import { PartnersData } from "../../../../../../theme/dummyArray";
import commonStyles from "../../../../../../theme/commonStyle";
//style
import styles from "./style";
//api
import API_CONFIG from "../../../../../../api/api_url";
import { callApi } from "../../../../../../api";
import AddsCommonList from "../../../../../../component/AddsCommonApi";
import ResponsiveImage from "../../../../../../component/ResponsiveImage";

export default function NewsPageFootball(props: any) {
  const scrollRef = useRef(null);
  const navigation = useNavigation();
  const { articalId, selectedCategory, artclesCategory, sportSelectedIndex } =
    props?.route?.params;
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [isSelectIndex, setSelectIndex] = useState(selectedCategory);
  const [search, setSearch] = useState("");
  const [descriptionData, setDescriptionData] = useState({});
  const [allSportList, setAllSportList] = useState([]);

  const [selectedSportIndex, setselectedSportIndex] =
    useState(sportSelectedIndex);

  useEffect(() => {
    setIsLoaderVisible(true);
    callGetAllCategoryAPi();
    setSelectIndex(selectedCategory);
    setselectedSportIndex(sportSelectedIndex);
  }, [selectedSportIndex, isSelectIndex, sportSelectedIndex, selectedCategory]);

  useEffect(() => {
    setIsLoaderVisible(true);
    callFetchSingleNewsAPi();
  }, [articalId]);

  const fetchNewsTime = (newsdate) => {
    const now = moment();
    const givenTime = moment(newsdate);
    const timeDiffMinutes = now.diff(givenTime, "minutes");
    const timeDiffHours = now.diff(givenTime, "hours");
    const timeDiffDays = now.diff(givenTime, "days");
    const timeDiffWeeks = now.diff(givenTime, "weeks");
    if (timeDiffMinutes > 60) {
      if (timeDiffMinutes / 60 > 24) {
        if (timeDiffDays > 7) {
          return `${timeDiffWeeks} ${
            timeDiffWeeks == 1 ? "week" : "weeks"
          } ago`;
        } else {
          return `${timeDiffDays} ${timeDiffDays == 1 ? "day" : "days"} ago`;
        }
      } else {
        return `${timeDiffHours} hours ago`;
      }
    } else {
      return `${timeDiffMinutes} minutes ago`;
    }
  };

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const rendertopSeriesItem = (item: any, index: any) => {
    return (
      <Pressable
        key={index}
        style={styles.containerView}
        onPress={() => {
          setDescriptionData(item);
          scrollRef?.current?.scrollTo({
            y: 0,
            animated: true,
          });
        }}
      >
        {item?.NewsArticle?.mainMedia?.article?.url?.length > 0 && (
          <ImageLoad
            resizeMode={"contain"}
            style={styles.blankImage}
            source={item?.NewsArticle?.mainMedia?.article?.url}
          />
        )}
        <View style={styles.loremContainer}>
          <Text style={styles.title} numberOfLines={2}>
            {item?.NewsArticle?.title}
          </Text>
          <View style={styles.centerView}>
            <View style={styles.footballView}>
              <Text style={styles.footballText}>{artclesCategory}</Text>
            </View>
            <View style={commonStyles.alignCenterView}>
              <TimeImg
                style={{ height: Metrics.rfv(12), width: Metrics.rfv(12) }}
              />
              <Text style={styles.timeText}>
                {fetchNewsTime(item?.NewsArticle?.rapidCreatedAt)}
              </Text>
            </View>
          </View>
        </View>
      </Pressable>
    );
  };

  const renderNewsTagRelationsItem = (item, index) => {
    return (
      <View style={styles.championshipView} key={index}>
        <Text style={styles.footballText}>{item?.NewsTag?.title}</Text>
      </View>
    );
  };

  const renderDescriptionItem = (item: any, index: any) => {
    let JS =
      '<script type="text/javascript" src="https://platform.twitter.com/widgets.js"></script>';
    let data1 = `<blockquote class="twitter-tweet" data-lang="es"><a href="https://twitter.com/TEDTalks/status/${
      item?.type == "embed" && item?.data?.content?.slice(8)
    }">`;
    let data2 = `</a></blockquote>`;
    let source = JS + data1 + data2;
    const html = item?.data?.content;
    return (
      <View key={index} style={commonStyles.commonFlex}>
        {item?.type == "embed" && item?.data?.embed_type == "social" ? (
          <>
            {item?.data?.content?.length > 0 && (
              <AutoHeightWebView
                scalesPageToFit={false}
                scrollEnabled={false}
                style={{
                  width: Dimensions.get("window").width - 35,
                }}
                source={{ html: source }}
              />
            )}
          </>
        ) : (
          <>
            {item?.type == "embed" && item?.data?.embed_type == "other" ? (
              <>
                {item?.data?.content?.length > 0 && (
                  <AutoHeightWebView
                    scrollEnabled={false}
                    style={{
                      width: "100%",
                      overflow: "hidden",
                    }}
                    source={{ html: html }}
                  />
                )}
              </>
            ) : (
              <>
                {html && (
                  <RenderHTML
                    contentWidth={500}
                    tagsStyles={{
                      p: { color: Colors.black },
                      h2: { color: Colors.black },
                    }}
                    source={{ html }}
                  />
                )}
              </>
            )}

            {index == 5 && (
              <AddsCommonList
                SingleNewsPage={"SingleNewsPage"}
                page={15}
                placeholder={Images.sportFirstImg}
                bannerStyle={styles.secondBannerStyle}
              />
            )}
          </>
        )}

        {item?.data?.preview?.imageBlock?.image?.urls?.uploaded?.original && (
          <>
            <ResponsiveImage
              bannerStyle={styles.newsBanner}
              source={
                item?.data?.preview?.imageBlock?.image?.urls?.uploaded?.original
              }
            />
            <Text style={styles.descriptionImageText}>
              {item?.data?.description}
            </Text>
          </>
        )}
      </View>
    );
  };

  const callGetAllCategoryAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_ALL_CATEGORIES,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let sportList = response?.body?.data?.result;
          const allCategory = { initialTitle: "All", id: 0 };
          let allCategoryList = [allCategory, ...sportList];
          // let sortData = allCategoryList?.sort((a, b) => {
          //   return a.initialTitle > b.initialTitle ? 1 : -1;
          // });
          setAllSportList(allCategoryList);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);

      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const callFetchSingleNewsAPi = async () => {
    try {
      const response = await callApi(
        `v2/news/articles/${articalId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setDescriptionData(response?.body?.data?.result);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowSmartBIcon={true}
        isShowNewsBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        {!isLoadervisible && (
          <>
            <Header
              onPress={() => {}}
              onPressSignUp={() => onPressSignUp()}
              onPressSignIn={() => onPressSignIn()}
              isBackgroundSignUp={Colors.linearColor2}
              isBackgroundSignIn={Colors.white}
              colorUp={Colors.white}
              colorIn={Colors.linearColor2}
              sourceIcon={Images.adBannerIcon}
              isPasswordField={true}
              onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
              onBackPress={() => navigation.goBack()}
            />
            <View style={styles.horizontalView}>
              <TextHeaderTitle
                title={translate("News")}
                textStyle={styles.headerNewsTitle}
              />
            </View>
            <View style={styles.searchView}>
              <View style={styles.serchContainerStyle}>
                <TextInput
                  style={styles.searchTextinputStyle}
                  placeholder={translate("SearchBYName")}
                  placeholderTextColor={Colors.borderDropDown}
                  numberOfLines={1}
                  value={search}
                  onChangeText={(text) => {
                    setSearch(text);
                  }}
                />
                <Pressable
                  onPress={() => {
                    {
                      search?.trim()?.length > 0 &&
                        (navigation.navigate(NAVIGATION.SEARCH_NEWS, {
                          searchTitle: search,
                        }),
                        setSearch(""));
                    }
                  }}
                >
                  <SearchIcon style={styles.searchIconStyle} />
                </Pressable>
              </View>
              <TrackProfileSectionPage
                data={allSportList}
                selectedItemIndex={selectedSportIndex}
                isSelectIndex={isSelectIndex}
                onItemClick={(itemId: any, index: any) => {
                  if (props?.route?.params?.onCategoryChange) {
                    props?.route?.params?.onCategoryChange(itemId, index);
                  }
                  navigation.goBack();
                }}
              />
            </View>
            <View style={styles.container}>
              {descriptionData?.NewsArticle ? (
                <>
                  <View style={styles.height} />
                  <View style={styles.horizontalContainer}>
                    <Text style={styles.loremTitle}>
                      {descriptionData?.NewsArticle?.title}
                    </Text>

                    <View style={commonStyles.alignCenterView}>
                      {descriptionData?.NewsArticle?.publishedBy?.logo?.length >
                        0 && (
                        <ImageLoad
                          resizeMode={"contain"}
                          style={styles.profileIcon}
                          source={
                            "https://www.livescore.com" +
                            descriptionData?.NewsArticle?.publishedBy?.logo
                          }
                        />
                      )}

                      <View style={styles.titleLeftView}>
                        {descriptionData?.NewsArticle?.authors?.length > 0 && (
                          <Text style={styles.darioTitle}>
                            {descriptionData?.NewsArticle?.authors?.map(
                              (item, index) => {
                                return item?.name;
                              }
                            )}
                          </Text>
                        )}

                        <Text style={styles.liveScoreText}>
                          {descriptionData?.NewsArticle?.publishedBy?.name}
                        </Text>
                      </View>
                      <View>
                        {descriptionData?.NewsArticle?.rapidCreatedAt && (
                          <Text style={styles.dateTitle}>
                            {moment
                              .utc(descriptionData?.NewsArticle?.rapidCreatedAt)
                              .local()
                              .format("DD/MM/YYYY")}
                          </Text>
                        )}
                        {descriptionData?.NewsArticle?.rapidCreatedAt && (
                          <Text style={styles.liveScoreText}>
                            {moment
                              .utc(descriptionData?.NewsArticle?.rapidCreatedAt)
                              .local()
                              .format("hh:mm A")}
                          </Text>
                        )}
                      </View>
                    </View>
                    <ResponsiveImage
                      bannerStyle={styles.newsBanner}
                      source={
                        descriptionData?.NewsArticle?.mainMedia?.article?.url
                      }
                    />
                    <Text style={styles.descriptionImageText}>
                      {descriptionData?.NewsArticle?.mainMedia?.article?.alt}
                    </Text>
                    <FlatList
                      scrollEnabled={false}
                      data={descriptionData?.NewsArticle?.body}
                      showsVerticalScrollIndicator={false}
                      contentContainerStyle={styles.topSeriesContainer}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item, index }) =>
                        renderDescriptionItem(item, index)
                      }
                    />
                  </View>
                  {descriptionData?.NewsArticle?.NewsRelatedArticles?.length >
                    0 && (
                    <View style={styles.relatedArticalsContainer}>
                      <Text style={styles.relatedtext}>
                        {translate("RelatedArticles")}
                      </Text>
                      <View style={styles.botoomwidth} />
                      <View style={styles.horizontalList}>
                        <FlatList
                          horizontal
                          data={
                            descriptionData?.NewsArticle?.NewsRelatedArticles
                          }
                          showsVerticalScrollIndicator={false}
                          keyExtractor={(item, index) => index.toString()}
                          showsHorizontalScrollIndicator={false}
                          renderItem={({ item, index }) =>
                            rendertopSeriesItem(item, index)
                          }
                        />
                      </View>
                    </View>
                  )}
                </>
              ) : (
                <>
                  <View style={styles.height} />
                  <View style={styles.horizontalContainer}>
                    <Text style={styles.loremTitle}>
                      {descriptionData?.title}
                    </Text>

                    <View style={commonStyles.alignCenterView}>
                      {descriptionData?.publishedBy?.logo?.length > 0 && (
                        <ImageLoad
                          style={styles.profileIcon}
                          resizeMode={"contain"}
                          source={
                            "https://www.livescore.com" +
                            descriptionData?.publishedBy?.logo
                          }
                        />
                      )}
                      <View style={styles.titleLeftView}>
                        {descriptionData?.authors?.length > 0 && (
                          <Text style={styles.darioTitle}>
                            {descriptionData?.authors?.map((item, index) => {
                              return item?.name;
                            })}
                          </Text>
                        )}
                        <Text style={styles.liveScoreText}>
                          {descriptionData?.publishedBy?.name}
                        </Text>
                      </View>
                      <View>
                        {descriptionData?.rapidCreatedAt && (
                          <Text style={styles.dateTitle}>
                            {moment(descriptionData?.rapidCreatedAt).format(
                              "DD/MM/YYYY"
                            )}
                          </Text>
                        )}
                        {descriptionData?.rapidCreatedAt && (
                          <Text style={styles.liveScoreText}>
                            {moment
                              .utc(descriptionData?.rapidCreatedAt)
                              .local()
                              .format("hh:mm A")}
                          </Text>
                        )}
                      </View>
                    </View>
                    {descriptionData?.mainMedia?.article?.url && (
                      <ResponsiveImage
                        bannerStyle={styles.newsBanner}
                        source={descriptionData?.mainMedia?.article?.url}
                      />
                    )}
                    <Text style={styles.alertText}>
                      {descriptionData?.mainMedia?.article?.alt}
                    </Text>
                    <FlatList
                      scrollEnabled={false}
                      data={descriptionData?.body}
                      showsVerticalScrollIndicator={false}
                      contentContainerStyle={styles.topSeriesContainer}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item, index }) =>
                        renderDescriptionItem(item, index)
                      }
                    />
                    {descriptionData?.NewsTagRelations?.length > 0 && (
                      <View style={styles.tagsContainerView}>
                        <Text style={styles.tags}>{translate("Tags")}</Text>
                        <FlatList
                          numColumns={2}
                          style={styles.tagsContainer}
                          data={descriptionData?.NewsTagRelations}
                          showsHorizontalScrollIndicator={false}
                          keyExtractor={(item, index) => index.toString()}
                          renderItem={({ item, index }) =>
                            renderNewsTagRelationsItem(item, index)
                          }
                        />
                      </View>
                    )}
                  </View>
                  <View style={styles.relatedTopHeight} />
                  {descriptionData?.NewsRelatedArticles?.length > 0 && (
                    <View style={styles.relatedArticalsContainer}>
                      <Text style={styles.relatedtext}>
                        {translate("RelatedArticles")}
                      </Text>
                      <View style={styles.botoomwidth} />
                      <View style={styles.horizontalList}>
                        <FlatList
                          horizontal
                          data={descriptionData?.NewsRelatedArticles}
                          showsVerticalScrollIndicator={false}
                          keyExtractor={(item, index) => index.toString()}
                          showsHorizontalScrollIndicator={false}
                          renderItem={({ item, index }) =>
                            rendertopSeriesItem(item, index)
                          }
                        />
                      </View>
                    </View>
                  )}
                </>
              )}
            </View>
            <View style={styles.horizontalView}>
              <TextHeaderTitle
                title={translate("OurPartners")}
                textStyle={styles.textStyle}
              />
            </View>
            <View style={styles.partnerListBottom}>
              <PartnersList />
            </View>
          </>
        )}
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
}
