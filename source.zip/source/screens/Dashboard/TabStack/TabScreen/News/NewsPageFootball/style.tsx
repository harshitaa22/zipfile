import { Dimensions, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

export default StyleSheet.create({
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  twitterImag: {
    marginBottom: Metrics.rfv(2),
    width: "100%",
    // flex: 1,
    // height: 500,
    resizeMode: "contain",
    backgroundColor: "red",
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.cream,
    paddingTop: Metrics.rfv(10),
    paddingBottom: Metrics.rfv(5),
  },
  textStyle: {
    textAlign: "center",
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginTop: Metrics.rfv(20),
    marginBottom: Metrics.rfv(10),
    color: Colors.black,
  },
  headerNewsTitle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  contentContainerStyle: {
    marginHorizontal: Metrics.rfv(15),
  },
  profileIcon: {
    width: Metrics.rfv(51),
    height: Metrics.rfv(51),
  },
  searchIconStyle: {
    width: Metrics.rfv(20),
    height: Metrics.rfv(20),
  },
  searchTextinputStyle: {
    flex: 1,
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  searchView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    paddingTop: Metrics.rfv(10),
    marginTop: Metrics.rfv(5),
    paddingBottom: Metrics.rfv(5),
  },
  serchContainerStyle: {
    height: Metrics.rfv(40),
    borderColor: Colors.linearColor2,
    borderWidth: Metrics.rfv(0.5),
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: Metrics.rfv(10),
    backgroundColor: Colors.white,
  },
  height: {
    height: Metrics.rfv(15),
    backgroundColor: Colors.cream,
  },
  newsBanner: {
    // height: Metrics.rfv(260),
    width: "100%",
    // marginTop: Metrics.rfv(10),
    // marginBottom: Metrics.rfv(15),
    // backgroundColor: "red",
  },
  footballText: {
    color: Colors.white,
    fontSize: Metrics.rfv(11),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
  },
  footballView: {
    backgroundColor: Colors.grayLight,
    paddingVertical: Metrics.rfv(2),
    paddingHorizontal: Metrics.rfv(8),
    alignItems: "center",
    justifyContent: "center",
    borderRadius: Metrics.rfv(5),
  },
  horizontalContainer: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(15),
  },
  horizontalList: {
    marginHorizontal: Metrics.rfv(15),
    paddingTop: Metrics.rfv(20),
    paddingBottom: Metrics.rfv(15),
  },
  botoomwidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.linearColor2,
    marginTop: Metrics.rfv(5),
    marginBottom: Metrics.rfv(10),
  },
  topSeries: {
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
    color: Colors.black,
  },
  championshipView: {
    backgroundColor: Colors.grayLight,
    paddingVertical: Metrics.rfv(2),
    paddingHorizontal: Metrics.rfv(8),
    alignItems: "center",
    justifyContent: "center",
    borderRadius: Metrics.rfv(10),
    marginRight: Metrics.rfv(10),
    marginBottom: Metrics.rfv(5),
  },
  blankImage: {
    height: Metrics.rfv(144),
    width: Metrics.rfv(238),
  },
  title: {
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
    color: Colors.black,
    flex: 1,
  },
  darioTitle: {
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
    color: Colors.black,
  },
  dateTitle: {
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
    color: Colors.lightGrayComing,
  },
  centerView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: Metrics.rfv(10),
  },
  loremContainer: {
    marginTop: Metrics.rfv(11),
  },
  liveScoreText: {
    fontSize: Metrics.rfv(11),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    marginTop: Metrics.rfv(4),
    color: Colors.lightGrayComing,
  },
  timeText: {
    fontSize: Metrics.rfv(11),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.lightGrayComing,
    marginLeft: Metrics.rfv(5),
  },
  topSeriesContainer: {
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(30),
  },
  titleLeftView: {
    flex: 1,
    marginLeft: Metrics.rfv(5),
  },
  loremTitle: {
    fontSize: Metrics.rfv(18),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(25),
    color: Colors.black,
    marginBottom: Metrics.rfv(18),
  },
  alignCenterView: {
    flexDirection: "row",
  },
  relatedArticalsContainer: {
    backgroundColor: Colors.lightBlueBackground,
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(15),
  },
  relatedtext: {
    fontSize: Metrics.rfv(20),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    lineHeight: Metrics.rfv(22),
    color: Colors.black,
  },
  containerView: {
    marginRight: Metrics.rfv(20),
    width: Metrics.rfv(238),
  },
  sportImage: {
    height: Metrics.rfv(250),
    // width: Metrics.rfv(366),
    // width: "100%",
  },
  descriptionImageText: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.black,
    marginTop: Metrics.rfv(2),
  },
  alertText: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.black,
  },
  tags: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Bold,
  },
  tagsContainer: {
    marginLeft: Metrics.rfv(14),
  },
  tagsContainerView: {
    flexDirection: "row",
    marginBottom: Metrics.rfv(14),
  },
  relatedTopHeight: {
    height: Metrics.rfv(14),
    backgroundColor: Colors.cream,
  },
  container: {
    backgroundColor: Colors.white,
  },
  secondBannerStyle: {
    width: "100%",
    height: Metrics.rfv(63),
    resizeMode: "contain",
    marginTop: Metrics.rfv(5),
    marginBottom: Metrics.rfv(5),
  },
});
