import _ from "lodash";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";
//style
import commonStyles from "../../../../../../../theme/commonStyle";
import styles from "./style";
//thme
import { Colors, CommonStyle, Metrics } from "../../../../../../../theme";
//component
import DatePickerModel from "../../../../../../../component/DatePickerModel";
import PartnersList from "../../../../../../../component/PartnersList";
import Loader from "../../../../../../../component/ProgressBar";
import SportModel from "../../../../../../../component/SportsModelComponent";
import TeamSportTab from "../../../../../../../component/TeamSportTab";
import TextHeaderTitle from "../../../../../../../component/Text/index";
//utils
import { translate } from "../../../../../../../utils/Localize";
import { showToast } from "../../../../../../../utils/commonFunction";
//theme
import {
  BlackDropDownArrow,
  LeftUpArrow,
  RightUpArrow,
} from "../../../../../../../theme/svg";
//api
import { callApi } from "../../../../../../../api";
import API_CONFIG from "../../../../../../../api/api_url";
import { SPORTS } from "../../../../../../../utils/constant";

const SportTeam = (props: any) => {
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [teamOptions, setTeamOptions] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isTeamModalVisible, setIsTeamModalVisible] = useState(false);
  const [search, setSearch] = useState("");
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const [teamDataSource, setTeamDataSource] = useState([]);
  const [tournamentOptions, setTournamentOptions] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedseries, setselectedseries] = useState(0);
  const [stepperCount, setStepperCount] = useState(0);
  const [getUTCDate, setGetUTCDate] = useState(new Date());
  const [selectedTornaments, setSelectedTornaments] = useState({});
  const [selectedTeamData, setSelectedTeamData] = useState({});
  const [isShowDatePicker, showDatePicker] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(0);
  const [sportDetailsList, setSportDetailsList] = useState([]);
  const [matchupData, setMatchUpData] = useState([]);
  const [sportData, setSportData] = useState([]);

  useEffect(() => {
    setIsLoaderVisible(true);
    fetchMatchupDropDownData(0);
  }, [selectedDate]);
  useEffect(() => {
    setSearch("");
    setTournamentOptions([]);
    fetchAllEvents(0);
    fetchMatchUpData(0);
  }, [
    props?.sportData?.title,
    props?.sportId,
    props?.sportItem,
    selectedseries,
    selectedDate,
    selectedTeam,
    stepperCount,
  ]);

  const searchFilterFunction = (text, filterTournamentData) => {
    const newData = filterTournamentData.filter(function (item) {
      const itemData = item?.label
        ? item?.label?.toUpperCase()
        : "".toUpperCase();

      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    setFilteredDataSource(newData);
  };

  const searchTeamFilter = (text, filterTournamentData) => {
    const newData = filterTournamentData.filter(function (item) {
      const itemData = item?.label
        ? item?.label?.toUpperCase()
        : "".toUpperCase();

      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    setTeamDataSource(newData);
  };

  const onNextPress = () => {
    setselectedseries(selectedTornaments?.value);
    setIsModalVisible(false);
    setSearch("");
  };

  const onPressBack = () => {
    setIsModalVisible(false);
    setSearch("");
  };

  const onTeamNextPress = () => {
    setSelectedTeam(selectedTeamData?.value);
    setIsTeamModalVisible(false);
  };
  const onTeamBackPress = () => {
    setIsTeamModalVisible(false);
  };

  const onselectedPress = (item) => {
    setSelectedTornaments(item);
  };

  const onselectedTeamPress = (item) => {
    setSelectedTeamData(item);
  };

  const fetchUrlAllEvents = (eventPage) => {
    const utcDate = moment(getUTCDate).format("YYYY-MM-DD");
    const startDate = selectedDate === null ? utcDate : selectedDate;
    const endDate = selectedDate === null ? "" : selectedDate;
    const tournamentID = selectedseries === 0 ? "" : selectedseries;
    const teamID = selectedTeam === 0 ? "" : selectedTeam;
    const teamRound = stepperCount === 0 ? "" : stepperCount;

    if (
      props?.sportData?.title === SPORTS.CRICKET ||
      props?.homeData === SPORTS.CRICKET
    ) {
      return `public/crickets/event?startDate=${startDate}&endDate=${endDate}&CricketTournamentId=${tournamentID}&teamId=${teamID}&${eventPage}&timezone=${timezone}&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
      props?.homeData === SPORTS.RUBGY_LEAGUE
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=12&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.RUBGY_UNION ||
      props?.homeData === SPORTS.RUBGY_UNION
    ) {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=13&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.GOLF ||
      props?.homeData === SPORTS.GOLF
    ) {
      return `public/golf/event?startDate=${startDate}&endDate=${endDate}&GolfTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=16&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.TENNIS ||
      props?.homeData === SPORTS.TENNIS
    ) {
      return `public/tennis/event?startDate=${startDate}&endDate=${endDate}&TennisTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=7&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BASEBALL ||
      props?.homeData === SPORTS.BASEBALL
    ) {
      return `public/baseball/event?startDate=${startDate}&endDate=${endDate}&BaseballTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=11&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.ICE_HOCKEY ||
      props?.homeData === SPORTS.ICE_HOCKEY
    ) {
      return `public/icehockey/event?startDate=${startDate}&endDate=${endDate}&IceHockeyTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=17&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BOXING ||
      props?.homeData === SPORTS.BOXING
    ) {
      return `public/boxing/event?startDate=${startDate}&endDate=${endDate}&BoxingTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=6&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.MMA ||
      props?.homeData === SPORTS.MMA
    ) {
      return `public/mma/event?startDate=${startDate}&endDate=${endDate}&MMATournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=5&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.SOCCER ||
      props?.homeData === SPORTS.SOCCER
    ) {
      return `public/soccer/event?startDate=${startDate}&endDate=${endDate}&SoccerTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=8&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
      props?.homeData === SPORTS.AMERICAN_FOOTBALL
    ) {
      return `public/afl/event?startDate=${startDate}&endDate=${endDate}&AFLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=15&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
      props?.homeData === SPORTS.AUSTRALIAN_RULES
    ) {
      return `public/ar/event?startDate=${startDate}&endDate=${endDate}&ARTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=9&oddCheck=true`;
    } else if (
      props?.sportData?.title === SPORTS.BASKETBALL ||
      props?.homeData === SPORTS.BASKETBALL
    ) {
      return `public/nba/event?startDate=${startDate}&endDate=${endDate}&NBATournamentId=${tournamentID}&teamId=${teamID}&${eventPage}&timezone=${timezone}&oddCheck=true`;
    } else {
      return `public/rls/event?startDate=${startDate}&endDate=${endDate}&RLTournamentId=${tournamentID}&teamId=${teamID}&round=${teamRound}&${eventPage}&timezone=${timezone}&SportId=14&oddCheck=true`;
    }
  };

  const fetchAllEvents = async (eventPage) => {
    try {
      let passApi = fetchUrlAllEvents(eventPage);
      const response = await callApi(passApi, null, API_CONFIG.GET, null);

      if (response.body != null) {
        if (response.body?.status === 200) {
          let fullData = [];
          let itemData = response?.body?.data?.result?.rows;

          itemData?.map(async (item) => {
            let passApi =
              props?.sportData?.title === SPORTS.CRICKET ||
              props?.homeData === SPORTS.CRICKET
                ? `public/crickets/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.RUBGY_LEAGUE ||
                  props?.homeData === SPORTS.RUBGY_LEAGUE
                ? `public/rls/event/odd/${item?.id}?SportId=12`
                : props?.sportData?.title === SPORTS.RUBGY_UNION ||
                  props?.homeData === SPORTS.RUBGY_UNION
                ? `public/rls/event/odd/${item?.id}?SportId=13`
                : props?.sportData?.title === SPORTS.BASKETBALL ||
                  props?.homeData === SPORTS.BASKETBALL
                ? `public/nba/event/odd/${item?.id}`
                : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                  props?.homeData === SPORTS.AMERICAN_FOOTBALL
                ? `public/afl/event/odd/${item?.id}?SportId=15`
                : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                  props?.homeData === SPORTS.AUSTRALIAN_RULES
                ? `public/ar/event/odd/${item?.id}?SportId=9`
                : props?.sportData?.title === SPORTS.GOLF ||
                  props?.homeData === SPORTS.GOLF
                ? `public/golf/event/odd/${item?.id}?SportId=16`
                : props?.sportData?.title === SPORTS.TENNIS ||
                  props?.homeData === SPORTS.TENNIS
                ? `public/tennis/event/odd/${item?.id}?SportId=7`
                : props?.sportData?.title === SPORTS.BASEBALL ||
                  props?.homeData === SPORTS.BASEBALL
                ? `public/baseball/event/odd/${item?.id}?SportId=11`
                : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                  props?.homeData === SPORTS.ICE_HOCKEY
                ? `public/icehockey/event/odd/${item?.id}?SportId=17`
                : props?.sportData?.title === SPORTS.BOXING ||
                  props?.homeData === SPORTS.BOXING
                ? `public/boxing/event/odd/${item?.id}?SportId=6`
                : props?.sportData?.title === SPORTS.MMA ||
                  props?.homeData === SPORTS.MMA
                ? `public/mma/event/odd/${item?.id}?SportId=5`
                : props?.sportData?.title === SPORTS.SOCCER ||
                  props?.homeData === SPORTS.SOCCER
                ? `public/soccer/event/odd/${item?.id}?SportId=8`
                : `public/rls/event/odd/${item?.id}?SportId=14`;
            const response1 = await callApi(
              passApi,
              null,
              API_CONFIG.GET,
              null
            );
            if (response1?.body != null) {
              if (response1?.body?.status === 200) {
                let sportData = response1?.body?.data?.result;
                let newData =
                  sportData?.length > 0
                    ? props?.sportData?.title === SPORTS.CRICKET ||
                      props?.homeData === SPORTS.CRICKET
                      ? sportData?.[0]?.CricketOdds
                      : props?.sportData?.title === SPORTS.BASKETBALL ||
                        props?.homeData === SPORTS.BASKETBALL
                      ? sportData?.[0]?.NBAOdds
                      : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                        props?.homeData === SPORTS.AMERICAN_FOOTBALL
                      ? sportData?.[0]?.AFLOdds
                      : props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                        props?.homeData === SPORTS.AUSTRALIAN_RULES
                      ? sportData?.[0]?.AROdds
                      : props?.sportData?.title === SPORTS.BASEBALL ||
                        props?.homeData === SPORTS.BASEBALL
                      ? sportData?.[0]?.BaseballOdds
                      : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                        props?.homeData === SPORTS.ICE_HOCKEY
                      ? sportData?.[0]?.IceHockeyOdds
                      : props?.sportData?.title === SPORTS.TENNIS ||
                        props?.homeData === SPORTS.TENNIS
                      ? sportData?.[0]?.TennisOdds
                      : props?.sportData?.title === SPORTS.BOXING ||
                        props?.homeData === SPORTS.BOXING
                      ? sportData?.[0]?.BoxingOdds
                      : props?.sportData?.title === SPORTS.MMA ||
                        props?.homeData === SPORTS.MMA
                      ? sportData?.[0]?.MMAOdds
                      : props?.sportData?.title === SPORTS.SOCCER ||
                        props?.homeData === SPORTS.SOCCER
                      ? sportData?.[0]?.SoccerOdds
                      : sportData?.[0]?.RLOdds
                    : [];
                item.MarketNumber = response1?.body?.data?.result?.length;
                item.homeTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((homeTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? homeTeam?.CricketTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? homeTeam?.NBATeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? homeTeam?.AFLTeamId == item?.homeTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? homeTeam?.ARTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? homeTeam?.BaseballTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? homeTeam?.TennisTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? homeTeam?.IceHockeyTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? homeTeam?.BoxingTeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? homeTeam?.MMATeamId == item?.homeTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? homeTeam?.SoccerTeamId == item?.homeTeamId
                          : homeTeam?.RLTeamId == item?.homeTeamId;
                      })
                    : "";
                item.awayTeamOdds =
                  newData?.length > 0
                    ? newData?.filter((awayTeam) => {
                        return props?.sportData?.title === SPORTS.CRICKET ||
                          props?.homeData === SPORTS.CRICKET
                          ? awayTeam?.CricketTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASKETBALL ||
                            props?.homeData === SPORTS.BASKETBALL
                          ? awayTeam?.NBATeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AMERICAN_FOOTBALL ||
                            props?.homeData === SPORTS.AMERICAN_FOOTBALL
                          ? awayTeam?.AFLTeamId == item?.awayTeamId
                          : props?.sportData?.title ===
                              SPORTS.AUSTRALIAN_RULES ||
                            props?.homeData === SPORTS.AUSTRALIAN_RULES
                          ? awayTeam?.ARTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BASEBALL ||
                            props?.homeData === SPORTS.BASEBALL
                          ? awayTeam?.BaseballTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.TENNIS ||
                            props?.homeData === SPORTS.TENNIS
                          ? awayTeam?.TennisTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                            props?.homeData === SPORTS.ICE_HOCKEY
                          ? awayTeam?.IceHockeyTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.BOXING ||
                            props?.homeData === SPORTS.BOXING
                          ? awayTeam?.BoxingTeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.MMA ||
                            props?.homeData === SPORTS.MMA
                          ? awayTeam?.MMATeamId == item?.awayTeamId
                          : props?.sportData?.title === SPORTS.SOCCER ||
                            props?.homeData === SPORTS.SOCCER
                          ? awayTeam?.SoccerTeamId == item?.awayTeamId
                          : awayTeam?.RLTeamId == item?.awayTeamId;
                      })
                    : "";
              }
            }

            fullData.push(item);
          });
          // let tournaments = [];
          // itemData?.map((item) => {
          //   props?.sportData?.title === SPORTS.CRICKET
          //     ? tournaments.push({
          //         label: item?.CricketTournament?.name,
          //         value: item?.CricketTournament?.id,
          //       })
          //     : props?.sportData?.title === SPORTS.BASKETBALL
          //     ? tournaments.push({
          //         label: item?.NBATournament?.name,
          //         value: item?.NBATournament?.id,
          //       })
          //     : tournaments.push({
          //         label: item?.RLTournament?.name,
          //         value: item?.RLTournament?.id,
          //       });
          // });

          // let filterTournamentData = _.uniqBy(tournaments, function (e) {
          //   return e.value;
          // })
          //   ?.filter((a) => a?.value !== undefined)
          //   .sort((a, b) => {
          //     return a?.label.localeCompare(b?.label);
          //   });
          // filterTournamentData?.unshift({
          //   label: "All Tournaments",
          //   value: 0,
          // });

          // setTournamentOptions(
          //   _.uniqBy(
          //     [...tournamentOptions, ...filterTournamentData],
          //     function (e) {
          //       return e?.value;
          //     }
          //   )
          // );
          // setFilteredDataSource(
          //   _.uniqBy(
          //     [...tournamentOptions, ...filterTournamentData],
          //     function (e) {
          //       return e?.value;
          //     }
          //   )
          // );

          // if (search.length > 0) {
          //   searchFilterFunction(search, filterTournamentData);
          // }

          // let teams = [];
          // itemData?.map((item) => {
          //   teams.push({
          //     label: item?.homeTeam?.name,
          //     value: item?.homeTeam?.id,
          //   });
          //   teams.push({
          //     label: item?.awayTeam?.name,
          //     value: item?.awayTeam?.id,
          //   });
          // });
          // let filterTeamData = _.uniqBy(teams, function (e) {
          //   return e.value;
          // })
          //   ?.filter((a) => a?.value !== undefined)
          //   ?.sort((a, b) => {
          //     return a?.label.localeCompare(b?.label);
          //   });
          // filterTeamData?.unshift({
          //   label: "All Teams",
          //   value: 0,
          // });

          // setTeamOptions(
          //   _.uniqBy([...teamOptions, ...filterTeamData], function (e) {
          //     return e?.value;
          //   })
          // );
          // setTeamDataSource(
          //   _.uniqBy([...teamOptions, ...filterTeamData], function (e) {
          //     return e?.value;
          //   })
          // );
          // if (search.length > 0) {
          //   searchTeamFilter(search, filterTeamData);
          // }
          // setTimeout(() => {
          //   if (props?.sportId) {
          //     setSportDetailsList([props?.sportItem]);
          //   } else {
          //     setSportDetailsList(fullData);
          //   }
          // }, 1000);
          setTimeout(() => {
            setSportDetailsList(fullData);
            setIsLoaderVisible(false);
          }, 30000);

          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.success == false) {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
    // setEventPage(eventPage + 20);
  };
  const fetchUrlMatchupDropDownData = (eventPage) => {
    const utcDate = moment(getUTCDate).format("YYYY-MM-DD");
    const startDate = selectedDate === null ? utcDate : selectedDate;
    const endDate = selectedDate === null ? "" : selectedDate;
    if (
      props?.sportData?.title === SPORTS.BASKETBALL ||
      props?.homeData == SPORTS.BASKETBALL
    ) {
      return `public/nba/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&type=matchup`;
    } else if (
      props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
      props?.homeData == SPORTS.AMERICAN_FOOTBALL
    ) {
      return `public/afl/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&type=matchup`;
    } else if (
      props?.sportData?.title === SPORTS.BASEBALL ||
      props?.homeData == SPORTS.BASEBALL
    ) {
      return `public/baseball/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&type=matchup`;
    } else if (
      props?.sportData?.title === SPORTS.ICE_HOCKEY ||
      props?.homeData == SPORTS.ICE_HOCKEY
    ) {
      return `public/icehockey/event?startDate=${startDate}&endDate=${endDate}&${eventPage}&timezone=${timezone}&type=matchup`;
    } else {
      return null;
    }
  };

  const fetchMatchupDropDownData = async (eventPage) => {
    let passApi = fetchUrlMatchupDropDownData(eventPage);
    const response = await callApi(passApi, null, API_CONFIG.GET, null);
    if (response.body != null) {
      if (response.body?.status === 200) {
        let itemData = response?.body?.data?.result?.rows;
        // let newData = itemData?.filter((item) => item?.NBAMatchups?.length > 0 ||item?.AFLMatchups?.length > 0  );
        let tournaments = [];
        itemData?.map((item) => {
          props?.sportData?.title === SPORTS.BASKETBALL ||
          props?.homeData === SPORTS.BASKETBALL
            ? tournaments.push({
                label:
                  item?.NBATournament?.name +
                  " " +
                  item?.NBATournament?.NBACategory?.name,
                value: item?.NBATournament?.id,
              })
            : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
              props?.homeData === SPORTS.AMERICAN_FOOTBALL
            ? tournaments.push({
                label: item?.AFLTournament?.name,
                value: item?.AFLTournament?.id,
              })
            : props?.sportData?.title === SPORTS.BASEBALL ||
              props?.homeData === SPORTS.BASEBALL
            ? tournaments.push({
                label: item?.BaseballTournament?.name,
                value: item?.BaseballTournament?.id,
              })
            : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
              props?.homeData === SPORTS.ICE_HOCKEY
            ? tournaments.push({
                label: item?.IceHockeyTournament?.name,
                value: item?.IceHockeyTournament?.id,
              })
            : null;
        });
        let filterTournamentData = _.uniqBy(tournaments, function (e) {
          return e.value;
        })
          ?.filter((a) => a?.value !== undefined)
          .sort((a, b) => {
            return a?.label.localeCompare(b?.label);
          });
        filterTournamentData?.unshift({
          label: "All Tournaments",
          value: 0,
        });
        setTournamentOptions(filterTournamentData);
        setFilteredDataSource(filterTournamentData);
        if (search.length > 0) {
          searchFilterFunction(search, filterTournamentData);
        }
        let teams = [];
        itemData?.map((item) => {
          teams.push({
            label: item?.homeTeam?.name,
            value: item?.homeTeam?.id,
          });
          teams.push({
            label: item?.awayTeam?.name,
            value: item?.awayTeam?.id,
          });
        });
        let filterTeamData = _.uniqBy(teams, function (e) {
          return e.value;
        })
          ?.filter((a) => a?.value !== undefined)
          ?.sort((a, b) => {
            return a?.label.localeCompare(b?.label);
          });
        filterTeamData?.unshift({
          label: "All Teams",
          value: 0,
        });

        setTeamOptions(filterTeamData);
        setTeamDataSource(filterTeamData);
        if (search.length > 0) {
          searchTeamFilter(search, filterTeamData);
        }
      }
    }
  };

  const fetchMatchUpData = async (eventPage) => {
    try {
      let passApi =
        props?.sportData?.title === SPORTS.BASKETBALL ||
        props?.homeData === SPORTS.BASKETBALL
          ? `public/nba/event?startDate=${
              selectedDate === null
                ? moment(getUTCDate).format("YYYY-MM-DD")
                : selectedDate
            }&endDate=${
              selectedDate === null ? "" : selectedDate
            }&NBATournamentId=${
              selectedseries === 0 ? "" : selectedseries
            }&teamId=${
              selectedTeam === 0 ? "" : selectedTeam
            }&${eventPage}&timezone=${timezone}&type=matchup`
          : props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
            props?.homeData === SPORTS.AMERICAN_FOOTBALL
          ? `public/afl/event?startDate=${
              selectedDate === null
                ? moment(getUTCDate).format("YYYY-MM-DD")
                : selectedDate
            }&endDate=${
              selectedDate === null ? "" : selectedDate
            }&AFLTournamentId=${
              selectedseries === 0 ? "" : selectedseries
            }&teamId=${
              selectedTeam === 0 ? "" : selectedTeam
            }&${eventPage}&timezone=${timezone}&type=matchup`
          : props?.sportData?.title === SPORTS.BASEBALL ||
            props?.homeData === SPORTS.BASEBALL
          ? `public/baseball/event?startDate=${
              selectedDate === null
                ? moment(getUTCDate).format("YYYY-MM-DD")
                : selectedDate
            }&endDate=${
              selectedDate === null ? "" : selectedDate
            }&BaseballTournamentId=${
              selectedseries === 0 ? "" : selectedseries
            }&teamId=${
              selectedTeam === 0 ? "" : selectedTeam
            }&${eventPage}&timezone=${timezone}&type=matchup`
          : props?.sportData?.title === SPORTS.ICE_HOCKEY ||
            props?.homeData === SPORTS.ICE_HOCKEY
          ? `public/icehockey/event?startDate=${
              selectedDate === null
                ? moment(getUTCDate).format("YYYY-MM-DD")
                : selectedDate
            }&endDate=${
              selectedDate === null ? "" : selectedDate
            }&IceHockeyTournamentId=${
              selectedseries === 0 ? "" : selectedseries
            }&teamId=${
              selectedTeam === 0 ? "" : selectedTeam
            }&${eventPage}&timezone=${timezone}&type=matchup`
          : null;

      const response = await callApi(passApi, null, API_CONFIG.GET, null);
      if (response.body != null) {
        if (response.body?.status === 200) {
          let itemData = response?.body?.data?.result?.rows;
          let newData = itemData?.filter(
            (item) =>
              item?.NBAMatchups?.length > 0 ||
              item?.AFLMatchups?.length > 0 ||
              item?.BaseballMatchups?.length > 0 ||
              item?.IceHockeyMatchups?.length > 0
          );
          setMatchUpData(newData);
          setSportData(itemData);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.success == false) {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
          // else {
          //   setTimeout(() => {
          //     showToast(translate("SomethingWrong"));
          //   }, 10);
          // }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  const renderItem = (item, index) => {
    return (
      <Pressable onPress={() => onselectedPress(item)} key={index}>
        <Text
          style={
            selectedTornaments?.value == item?.value
              ? styles.selectedItem
              : styles.labelText
          }
        >
          {item.label}
        </Text>
      </Pressable>
    );
  };

  const teamRenderItem = (item, index) => {
    return (
      <Pressable onPress={() => onselectedTeamPress(item)} key={index}>
        <Text
          style={
            selectedTeamData?.value == item?.value
              ? styles.selectedItem
              : styles.labelText
          }
        >
          {item?.label}
        </Text>
      </Pressable>
    );
  };
  return (
    <>
      {isLoadervisible && (
        <View style={styles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}

      <View style={commonStyles.commonFlex}>
        <DatePickerModel
          isVisible={isShowDatePicker}
          date={getUTCDate ? getUTCDate : new Date()}
          showModel={showDatePicker}
          onDateSelect={() => {
            setSelectedDate(moment(getUTCDate).format("YYYY-MM-DD"));
            showDatePicker(false);
          }}
          getUtcDate={(date) => {
            setGetUTCDate(date);
          }}
        />
        <SportModel
          search={search}
          onchangeText={(text: any) => {
            setSearch(text);
            searchFilterFunction(text, tournamentOptions);
          }}
          isVisible={isModalVisible}
          showModel={setIsModalVisible}
          data={filteredDataSource}
          onPressBack={() => onPressBack()}
          onNextPress={() => onNextPress()}
          renderItem={(item, index) => renderItem(item, index)}
        />
        <SportModel
          search={search}
          onchangeText={(text: any) => {
            setSearch(text);
            searchTeamFilter(text, teamOptions);
          }}
          renderItem={teamRenderItem}
          isVisible={isTeamModalVisible}
          showModel={setIsTeamModalVisible}
          data={teamDataSource}
          onPressBack={() => onTeamBackPress()}
          onNextPress={() => onTeamNextPress()}
        />
        <View style={commonStyles.commonFlex}>
          {isLoadervisible ? null : (
            <>
              <View style={styles.horizontalView}>
                <Pressable
                  onPress={() => {
                    setIsModalVisible(true);
                    setSelectedTornaments({});
                  }}
                  style={styles.commonContainerView}
                >
                  <Text style={styles.textInputStyle} numberOfLines={1}>
                    {selectedTornaments?.label
                      ? selectedTornaments?.label
                      : translate("AllTournaments")}
                  </Text>
                  <BlackDropDownArrow style={styles.dropdownIcon} />
                </Pressable>
                <View style={styles.containerView}>
                  <Pressable
                    style={styles.commonContainerView}
                    onPress={() => showDatePicker(true)}
                  >
                    <Text style={styles.textInputStyle} numberOfLines={1}>
                      {selectedDate
                        ? moment(selectedDate).format("DD/MM/YYYY")
                        : translate("RoundThree")}
                    </Text>
                    <BlackDropDownArrow style={styles.dropdownIcon} />
                  </Pressable>
                  <View style={styles.commonWidth} />
                  <Pressable
                    onPress={() => {
                      setIsTeamModalVisible(true), setSelectedTeamData({});
                      showDatePicker(false);
                    }}
                    style={styles.commonContainerView}
                  >
                    <Text style={styles.textInputStyle} numberOfLines={1}>
                      {selectedTeamData?.label
                        ? selectedTeamData?.label
                        : translate("AllTeams")}
                    </Text>
                    <BlackDropDownArrow style={styles.dropdownIcon} />
                  </Pressable>
                </View>
                {!(
                  props?.sportData?.title === SPORTS.CRICKET ||
                  props?.homeData === SPORTS.CRICKET ||
                  props?.sportData?.title === SPORTS.BASKETBALL ||
                  props?.homeData === SPORTS.BASKETBALL ||
                  props?.homeData === SPORTS.AMERICAN_FOOTBALL ||
                  props?.sportData?.title === SPORTS.AMERICAN_FOOTBALL ||
                  props?.homeData === SPORTS.AUSTRALIAN_RULES ||
                  props?.sportData?.title === SPORTS.AUSTRALIAN_RULES ||
                  props?.homeData === SPORTS.BASEBALL ||
                  props?.sportData?.title === SPORTS.BASEBALL ||
                  props?.homeData === SPORTS.ICE_HOCKEY ||
                  props?.sportData?.title === SPORTS.ICE_HOCKEY ||
                  props?.homeData === SPORTS.TENNIS ||
                  props?.sportData?.title === SPORTS.TENNIS ||
                  props?.homeData === SPORTS.BOXING ||
                  props?.sportData?.title === SPORTS.BOXING ||
                  props?.homeData === SPORTS.MMA ||
                  props?.sportData?.title === SPORTS.MMA ||
                  props?.homeData === SPORTS.SOCCER ||
                  props?.sportData?.title === SPORTS.SOCCER
                ) && (
                  <View style={styles.renderStyle}>
                    <Pressable
                      onPress={() => props?.handleStepper("left")}
                      style={CommonStyle.commonRow}
                    >
                      <View style={styles.leftUpArrow}>
                        <LeftUpArrow
                          width={Metrics.rfv(9)}
                          height={Metrics.rfv(15)}
                        />
                      </View>
                      <View style={styles.rightVertical} />
                    </Pressable>
                    <Text style={styles.routeName}>
                      {props?.stepperCount === 0
                        ? translate("RoundOne")
                        : translate("RoundOne") +
                          " " +
                          `${props?.stepperCount}`}
                    </Text>
                    <Pressable
                      style={CommonStyle.commonRow}
                      onPress={() => props?.handleStepper("right")}
                    >
                      <View style={styles.leftVertical}></View>
                      <View style={styles.leftUpArrow}>
                        <RightUpArrow
                          width={Metrics.rfv(9)}
                          height={Metrics.rfv(15)}
                        />
                      </View>
                    </Pressable>
                  </View>
                )}
              </View>
              {matchupData?.length > 0 ? (
                <TeamSportTab
                  sportData={sportData}
                  sportDetailsList={matchupData}
                  visible={!isLoadervisible}
                />
              ) : (
                <>
                  <View style={styles.container}>
                    <Text style={styles.noRaceText}>
                      {translate("NoDataAvailable")}
                    </Text>
                    <View style={styles.textCenter}>
                      <TextHeaderTitle
                        title={translate("OurPartners")}
                        textStyle={styles.sportStyle}
                      />
                    </View>
                    <View style={styles.partnerListBottom}>
                      <PartnersList />
                    </View>
                  </View>
                </>
              )}
            </>
          )}

          {/* {nbaVisible ? (
          <TeamSportTab sportDetailsList={matchupData} />
        ) : (
          <BettingTrend />
        )} */}
        </View>
      </View>
    </>
  );
};

export default SportTeam;
