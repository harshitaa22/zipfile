import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../../theme/index";

export default StyleSheet.create({
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(21),
    lineHeight: Metrics.rfv(26),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(15),
  },
});
