import moment from "moment";
import React from "react";
import { FlatList, ScrollView, Text, View } from "react-native";
//style
import styles from "./style";
//utils
import { translate } from "../../../../../../../../utils/Localize";
//theme
import commonStyles from "../../../../../../../../theme/commonStyle";
//component
import ImageLoad from "../../../../../../../../component/ImageLoad";
import PartnersList from "../../../../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../../../../component/Text/index";
import { SPORTS } from "../../../../../../../../utils/constant";

const BetsTab = (props: any) => {
  const renderItem = (item: any, index: any) => {
    return (
      <View key={index} style={commonStyles.commonFlex}>
        <View style={styles.listContainer}>
          {/* <View style={CommonStyle.commonFlex}> */}
          <View style={commonStyles.center}>
            <Text style={styles.timeText}>
              {moment
                .utc(props?.sportData[0]?.startTime)
                .local()
                .format("hh:mm A")}
            </Text>
            {(props?.sportData[0]?.Sport?.sportName == SPORTS.BASKETBALL ||
              props?.sportData[0]?.Sport?.sportName ==
                SPORTS.AMERICAN_FOOTBALL ||
              props?.sportData[0]?.Sport?.sportName == SPORTS.BASEBALL ||
              props?.sportData[0]?.Sport?.sportName == SPORTS.ICE_HOCKEY) && (
              <View style={styles.sportContainer}>
                <Text style={styles.sportTitle}>
                  {props?.sportData[0]?.NBATournament
                    ? props?.sportData[0]?.NBATournament?.name
                    : props?.sportData[0]?.AFLTournament
                    ? props?.sportData[0]?.AFLTournament?.name
                    : props?.sportData[0]?.IceHockeyTournament
                    ? props?.sportData[0]?.IceHockeyTournament?.name
                    : props?.sportData[0]?.BaseballTournament
                    ? props?.sportData[0]?.BaseballTournament?.name
                    : props?.sportData[0]?.NBATournament?.name}
                </Text>
              </View>
            )}
          </View>
          {/* <View style={styles.liveContainer}>
              <Text style={styles.liveText}>{translate("LiveText")}</Text>
            </View> */}
          {/* </View> */}
          <Text style={styles.spreadText}>{translate("Spread")}</Text>
          <View style={styles.height} />
          <Text style={styles.spreadText}>{translate("Total")}</Text>
          <View style={styles.height} />
          <Text style={styles.spreadText}>{translate("MlText")}</Text>
        </View>
        <View style={styles.seprateWidth} />
        <View style={styles.sportConatainer}>
          <View style={styles.listContainerView}>
            <View style={commonStyles.center}>
              <ImageLoad
                resizeMode={"stretch"}
                style={styles.mileIcon}
                source={item?.homeRecord?.logo}
              />
              <View style={styles.miileView}>
                <Text style={styles.titleText}>
                  {item?.homeRecord?.shortName}
                </Text>
                {item?.homeRecord?.rotation && (
                  <Text style={styles.spreadTitle}>
                    {item?.homeRecord?.rotation}
                  </Text>
                )}
              </View>
            </View>
            <View style={styles.commonFlex}>
              <Text style={styles.spreadWins}>
                {item?.homeRecord?.records?.spread}
                {/* {translate("AtsText")} */}
              </Text>
              <View
                style={
                  item?.bettingTrendsConsensus?.spread?.homeOrUnderBettingVolume
                    ? item?.bettingTrendsConsensus?.spread
                        ?.homeOrUnderBettingVolume >
                      item?.bettingTrendsConsensus?.spread
                        ?.awayOrOverBettingVolume
                      ? styles.percentageView
                      : styles.grayPercentageView
                    : styles.grayPercentageView
                }
              >
                <Text
                  style={
                    item?.bettingTrendsConsensus?.spread
                      ?.homeOrUnderBettingVolume
                      ? item?.bettingTrendsConsensus?.spread
                          ?.homeOrUnderBettingVolume >
                        item?.bettingTrendsConsensus?.spread
                          ?.awayOrOverBettingVolume
                        ? styles.percentageText
                        : styles.grayConatinerText
                      : styles.grayConatinerText
                  }
                >
                  {item?.bettingTrendsConsensus?.spread
                    ?.homeOrUnderBettingVolume
                    ? item?.bettingTrendsConsensus?.spread
                        ?.homeOrUnderBettingVolume
                    : translate("NaText")}
                </Text>
              </View>
            </View>
            <View style={styles.listHeight} />
            <View style={styles.commonFlex}>
              <Text style={styles.spreadWins}>
                {item?.homeRecord?.records?.total}
              </Text>
              <View
                style={
                  item?.bettingTrendsConsensus?.total?.homeOrUnderBettingVolume
                    ? item?.bettingTrendsConsensus?.total
                        ?.homeOrUnderBettingVolume >
                      item?.bettingTrendsConsensus?.total
                        ?.awayOrOverBettingVolume
                      ? styles.percentageView
                      : styles.grayPercentageView
                    : styles.grayPercentageView
                }
              >
                <Text
                  style={
                    item?.bettingTrendsConsensus?.total
                      ?.homeOrUnderBettingVolume
                      ? item?.bettingTrendsConsensus?.total
                          ?.homeOrUnderBettingVolume >
                        item?.bettingTrendsConsensus?.total
                          ?.awayOrOverBettingVolume
                        ? styles.percentageText
                        : styles.grayConatinerText
                      : styles.grayConatinerText
                  }
                >
                  {item?.bettingTrendsConsensus?.total?.homeOrUnderBettingVolume
                    ? item?.bettingTrendsConsensus?.total
                        ?.homeOrUnderBettingVolume
                    : translate("NaText")}
                </Text>
              </View>
            </View>
            <View style={styles.listHeight} />
            <View style={styles.commonFlex}>
              <Text style={styles.spreadWins}>
                {item?.homeRecord?.records?.moneyline}
              </Text>
              <View
                style={
                  item?.bettingTrendsConsensus?.moneyline
                    ?.homeOrUnderBettingVolume
                    ? item?.bettingTrendsConsensus?.moneyline
                        ?.homeOrUnderBettingVolume >
                      item?.bettingTrendsConsensus?.moneyline
                        ?.awayOrOverBettingVolume
                      ? styles.percentageView
                      : styles.grayPercentageView
                    : styles.grayPercentageView
                }
              >
                <Text
                  style={
                    item?.bettingTrendsConsensus?.moneyline
                      ?.homeOrUnderBettingVolume
                      ? item?.bettingTrendsConsensus?.moneyline
                          ?.homeOrUnderBettingVolume >
                        item?.bettingTrendsConsensus?.moneyline
                          ?.awayOrOverBettingVolume
                        ? styles.percentageText
                        : styles.grayConatinerText
                      : styles.grayConatinerText
                  }
                >
                  {item?.bettingTrendsConsensus?.moneyline
                    ?.homeOrUnderBettingVolume
                    ? item?.bettingTrendsConsensus?.moneyline
                        ?.homeOrUnderBettingVolume
                    : translate("NaText")}
                </Text>
              </View>
            </View>
          </View>
          <View style={styles.itemSeparatorComponent} />
          <View style={styles.listContainerView} key={index}>
            <View style={commonStyles.center}>
              <ImageLoad
                resizeMode={"contain"}
                style={styles.mileIcon}
                source={item?.awayRecord?.logo}
              />
              <View style={styles.miileView}>
                <Text style={styles.titleText}>
                  {item?.awayRecord?.shortName}
                </Text>
                {item?.awayRecord?.rotation && (
                  <Text style={styles.spreadTitle}>
                    {item?.awayRecord?.rotation}
                  </Text>
                )}
              </View>
            </View>
            <View style={styles.commonFlex}>
              <Text style={styles.spreadWins}>
                {item?.awayRecord?.records?.spread}
              </Text>
              <View
                style={
                  item?.bettingTrendsConsensus?.spread?.awayOrOverBettingVolume
                    ? item?.bettingTrendsConsensus?.spread
                        ?.awayOrOverBettingVolume >
                      item?.bettingTrendsConsensus?.spread
                        ?.homeOrUnderBettingVolume
                      ? styles.percentageView
                      : styles.grayPercentageView
                    : styles.grayPercentageView
                }
              >
                <Text
                  style={
                    item?.bettingTrendsConsensus?.spread
                      ?.awayOrOverBettingVolume
                      ? item?.bettingTrendsConsensus?.spread
                          ?.awayOrOverBettingVolume >
                        item?.bettingTrendsConsensus?.spread
                          ?.homeOrUnderBettingVolume
                        ? styles.percentageText
                        : styles.grayConatinerText
                      : styles.grayConatinerText
                  }
                >
                  {item?.bettingTrendsConsensus?.spread?.awayOrOverBettingVolume
                    ? item?.bettingTrendsConsensus?.spread
                        ?.awayOrOverBettingVolume
                    : translate("NaText")}
                </Text>
              </View>
            </View>
            <View style={styles.listHeight} />
            <View style={styles.commonFlex}>
              <Text style={styles.spreadWins}>
                {item?.awayRecord?.records?.total}
              </Text>
              <View
                style={
                  item?.bettingTrendsConsensus?.total?.awayOrOverBettingVolume
                    ? item?.bettingTrendsConsensus?.total
                        ?.awayOrOverBettingVolume >
                      item?.bettingTrendsConsensus?.total
                        ?.homeOrUnderBettingVolume
                      ? styles.percentageView
                      : styles.grayPercentageView
                    : styles.grayPercentageView
                }
              >
                <Text
                  style={
                    item?.bettingTrendsConsensus?.total?.awayOrOverBettingVolume
                      ? item?.bettingTrendsConsensus?.total
                          ?.awayOrOverBettingVolume >
                        item?.bettingTrendsConsensus?.total
                          ?.homeOrUnderBettingVolume
                        ? styles.percentageText
                        : styles.grayConatinerText
                      : styles.grayConatinerText
                  }
                >
                  {item?.bettingTrendsConsensus?.total?.awayOrOverBettingVolume
                    ? item?.bettingTrendsConsensus?.total
                        ?.awayOrOverBettingVolume
                    : translate("NaText")}
                </Text>
              </View>
            </View>
            <View style={styles.listHeight} />
            <View style={styles.commonFlex}>
              <Text style={styles.spreadWins}>
                {" "}
                {item?.awayRecord?.records?.moneyline}
              </Text>
              <View
                style={
                  item?.bettingTrendsConsensus?.moneyline
                    ?.awayOrOverBettingVolume
                    ? item?.bettingTrendsConsensus?.moneyline
                        ?.awayOrOverBettingVolume >
                      item?.bettingTrendsConsensus?.moneyline
                        ?.homeOrUnderBettingVolume
                      ? styles.percentageView
                      : styles.grayPercentageView
                    : styles.grayPercentageView
                }
              >
                <Text
                  style={
                    item?.bettingTrendsConsensus?.moneyline
                      ?.awayOrOverBettingVolume
                      ? item?.bettingTrendsConsensus?.moneyline
                          ?.awayOrOverBettingVolume >
                        item?.bettingTrendsConsensus?.moneyline
                          ?.homeOrUnderBettingVolume
                        ? styles.percentageText
                        : styles.grayConatinerText
                      : styles.grayConatinerText
                  }
                >
                  {item?.bettingTrendsConsensus?.moneyline
                    ?.awayOrOverBettingVolume
                    ? item?.bettingTrendsConsensus?.moneyline
                        ?.awayOrOverBettingVolume
                    : translate("NaText")}
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.bottomContainer}>
          <View style={commonStyles.commonFlex}>
            <Text style={styles.bottomConsensusTitle}>
              {translate("Consensus")}
            </Text>
            <Text style={styles.bottomOpenDescription}>
              {translate("Open")}
            </Text>
          </View>
          <View style={styles.commonFlex}>
            <Text style={styles.bottomTitle}>
              {/* {item?.consensus?.spread?.awayOrOverLine
                ? item?.awayRecord?.fullName +
                  " " +
                  item?.consensus?.spread?.awayOrOverLine
                : translate("NaText")} */}
              {item?.consensus?.consensusMoney?.spread
                ? item?.consensus?.consensusMoney?.spread
                : translate("NaText")}
            </Text>
            <Text style={styles.bottomDescription}>
              {item?.openline?.openMoney?.spread
                ? item?.openline?.openMoney?.spread
                : translate("NaText")}
            </Text>
          </View>
          <View style={styles.commonFlex}>
            <Text style={styles.bottomTitle}>
              {item?.consensus?.consensusMoney?.total
                ? item?.consensus?.consensusMoney?.total
                : translate("NaText")}
            </Text>
            <Text style={styles.bottomDescription}>
              {item?.openline?.openMoney?.total
                ? item?.openline?.openMoney?.total
                : translate("NaText")}
            </Text>
          </View>
          <View style={styles.commonFlex}>
            <Text style={styles.bottomTitle}>
              {item?.consensus?.consensusMoney?.moneyline
                ? item?.consensus?.consensusMoney?.moneyline
                : translate("NaText")}
            </Text>
            <Text style={styles.bottomDescription}>
              {item?.openline?.openMoney?.moneyline
                ? item?.openline?.openMoney?.moneyline
                : translate("NaText")}
            </Text>
          </View>
        </View>
      </View>
    );
  };
  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      {props.visible && (
        <>
          {props?.sportBetsDetails?.map((item, index) => {
            return (
              <View style={styles.creamBgColor} key={index}>
                <FlatList
                  data={
                    item?.NBAMatchups
                      ? item?.NBAMatchups
                      : item?.AFLMatchups
                      ? item?.AFLMatchups
                      : item?.BaseballMatchups
                      ? item?.BaseballMatchups
                      : item?.IceHockeyMatchups
                      ? item?.IceHockeyMatchups
                      : null
                  }
                  scrollEnabled={false}
                  contentContainerStyle={styles.contentContainerStyle}
                  renderItem={({ item, index }) => renderItem(item, index)}
                  ListEmptyComponent={() => {
                    return (
                      <View style={styles.noDataFoundMainStyle}>
                        <Text style={styles.noDataFoundText}>
                          {translate("NoDataFound")}
                        </Text>
                      </View>
                    );
                  }}
                  keyExtractor={(item, index) => index.toString()}
                />
              </View>
            );
          })}
          <View style={styles.bottomOurPartnerView}>
            <View style={styles.textCenter}>
              <TextHeaderTitle
                title={translate("OurPartners")}
                textStyle={styles.sportStyle}
              />
            </View>
            <View style={styles.partnerListBottom}>
              <PartnersList />
            </View>
          </View>
        </>
      )}
    </ScrollView>
  );
};

export default BetsTab;
