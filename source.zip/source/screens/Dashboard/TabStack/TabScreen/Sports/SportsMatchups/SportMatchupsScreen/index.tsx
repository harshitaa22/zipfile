import React from "react";
import { View } from "react-native";
import AppSafeAreaView from "../../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../../component/AppStatusBar";
import Header from "../../../../../../../component/HeaderComponent";
import TextHeaderTitle from "../../../../../../../component/Text";
import { Colors, CommonStyle, Images } from "../../../../../../../theme/index";
import styles from "./style";
import { NAVIGATION } from "../../../../../../../navigation";
import { translate } from "../../../../../../../utils/Localize";
import { useNavigation } from "@react-navigation/native";
import SportTeam from "../SportTeam";
import CommonHeaderComponent from "../../../../../../../component/CommonHeaderComponent";

const SportMatchupsScreen = () => {
  const navigation = useNavigation();

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <Header
        onPressSignUp={() => onPressSignUp()}
        onPressSignIn={() => onPressSignIn()}
        isBackgroundSignUp={Colors.linearColor2}
        isBackgroundSignIn={Colors.white}
        colorUp={Colors.white}
        colorIn={Colors.linearColor2}
        sourceIcon={Images.adBannerIcon}
        isPasswordField={true}
      />
      <View style={CommonStyle.commonFlex}>
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("NbaTitle")}
            textStyle={styles.textStyle}
          />
        </View>
        <SportTeam />
      </View>
    </AppSafeAreaView>
  );
};

export default SportMatchupsScreen;
