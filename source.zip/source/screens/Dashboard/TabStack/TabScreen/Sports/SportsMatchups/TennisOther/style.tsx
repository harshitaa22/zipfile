import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../../../../../../theme/index";

export default StyleSheet.create({
  tabViewStyle: {
    width: Metrics.rfp(180),
    height: Metrics.rfv(3),
    marginTop: Metrics.rfv(50),
    backgroundColor: Colors.linearColor2,
  },
  indicatorStyle: {
    backgroundColor: Colors.linearColor2,
    marginHorizontal: Metrics.rfv(20),
    width: Metrics.rfv(95),
    height: Metrics.rfv(6),
  },
  tabBarMainStyle: {
    backgroundColor: Colors.white,
    shadowOffset: {
      height: Metrics.rfv(0),
      width: Metrics.rfv(0),
    },
    shadowColor: "transparent",
    shadowOpacity: Metrics.rfv(0),
    elevation: Metrics.rfv(0),
    marginBottom: Metrics.rfv(8),
  },
  contentContainerStyle: {
    justifyContent: "center",
  },
  renderTabStyle: {
    elevation: Metrics.rfv(0),
    width: Metrics.rfv(140),
  },
  labelStyle: {
    fontSize: Metrics.rfv(14),
    textTransform: "capitalize",
  },
  adStyle: {
    marginBottom: Metrics.rfv(5),
  },
  adImage: {
    width: Metrics.rfv(390),
    height: Metrics.rfv(95),
  },
  australianText: {
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.IN_Regular,
    color: Colors.black,
    marginTop: Metrics.rfv(13),
  },
  sportTitle: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(10),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  containerStyle: {
    marginTop: Metrics.rfv(10),
    backgroundColor: Colors.creamBg,
    paddingTop: Metrics.rfv(15),
    paddingBottom: Metrics.rfv(15),
  },
  sportText: {
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_SemiBold,
    color: Colors.black,
    marginLeft: Metrics.rfv(10),
  },
  rightArraow: {
    width: Metrics.rfv(20),
    height: Metrics.rfv(18),
  },
  centerView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: Metrics.rfv(25),
  },
  textCenter: {
    alignSelf: "center",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
    flex: 1,
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.drownDownBackground,
    marginHorizontal: Metrics.rfv(15),
  },
  sportContainer: {
    paddingTop: Metrics.rfv(13),
    paddingBottom: Metrics.rfv(13),
    flex: 1,
    backgroundColor: Colors.creamBg,
  },
});
