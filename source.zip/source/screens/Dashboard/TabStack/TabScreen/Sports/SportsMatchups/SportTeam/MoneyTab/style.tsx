import { Platform, StyleSheet } from "react-native";
//theme
import { Colors, Fonts, Metrics } from "../../../../../../../../theme/index";

export default StyleSheet.create({
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(18),
  },
  creamBgColor: {
    backgroundColor: Colors.cream,
    paddingTop: Metrics.rfv(15),
    flex: 1,
  },
  listContainer: {
    backgroundColor: Colors.white,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: Metrics.rfv(8),
  },
  liveContainer: {
    backgroundColor: Colors.orange,
    borderRadius: Metrics.rfv(5),
    alignSelf: "flex-start",
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(5),
  },
  liveText: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(14),
    color: Colors.white,
  },
  whiteBackground: {
    backgroundColor: Colors.white,
  },
  height: {
    paddingVertical: Metrics.rfv(25),
    borderRightWidth: Metrics.rfv(0.5),
    backgroundColor: Colors.borderDropDown,
    borderColor: Colors.borderDropDown,
  },
  listHeight: {
    paddingVertical: Metrics.rfv(35),
    borderRightWidth: Metrics.rfv(0.5),
    backgroundColor: Colors.borderDropDown,
    borderColor: Colors.borderDropDown,
  },

  spreadText: {
    flex: 0.7,
    paddingHorizontal: Metrics.rfv(2),
    fontSize: Metrics.rfv(11),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(14),
    color: Colors.black,
    textAlign: "center",
  },
  timeText: {
    fontSize: Metrics.rfv(11),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(14),
    color: Colors.black,
    textAlign: "center",
  },
  mileIcon: {
    height: Metrics.rfv(35),
    width: Metrics.rfv(35),
  },
  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  contentContainerStyle: {
    backgroundColor: Colors.white,
    marginBottom: Metrics.rfv(5),
  },
  itemSeparatorComponent: {
    backgroundColor: Colors.grayColor,
    height: Metrics.rfv(1),
    width: "80%",
    alignSelf: "flex-end",
  },
  listContainerView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  listSecondContainerView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: Metrics.rfv(5),
  },
  sportConatainer: {
    paddingHorizontal: Metrics.rfv(8),
    backgroundColor: Colors.white,
  },
  miileView: {
    marginLeft: Metrics.rfv(5),
    flex: 1,
  },
  seprateWidth: {
    borderBottomWidth: Metrics.rfv(0.8),
    // opacity: Metrics.rfv(0.2),
    borderBottomColor: Colors.lineBreak,
    width: "100%",
  },
  titleText: {
    fontSize: Metrics.rfv(9),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    lineHeight: Metrics.rfv(11),
    color: Colors.black,
  },
  spreadTitle: {
    fontSize: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.lightGrayComing,
    marginTop: Metrics.rfv(3),
  },
  spreadWins: {
    fontSize: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.lightGrayComing,
    marginTop: Metrics.rfv(3),
    textAlign: "center",
  },
  percentageView: {
    backgroundColor: Colors.linearColor2,
    borderRadius: Metrics.rfv(15),
    alignSelf: "center",
    marginTop: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(8),
    paddingVertical: Metrics.rfv(4),
  },
  grayPercentageView: {
    backgroundColor: Colors.drownDownBackground,
    borderRadius: Metrics.rfv(15),
    alignSelf: "center",
    marginTop: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(8),
    paddingVertical: Metrics.rfv(4),
  },
  percentageText: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.white,
  },
  grayConatinerText: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.grayLight,
  },
  bottomTitle: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Bold,
    lineHeight: Metrics.rfv(14),
    color: Colors.black,
    textAlign: "center",
  },
  bottomConsensusTitle: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Bold,
    lineHeight: Metrics.rfv(14),
    color: Colors.black,
  },
  bottomDescription: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.lightGrayComing,
    marginTop: Metrics.rfv(3),
    textAlign: "center",
  },
  bottomOpenDescription: {
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    color: Colors.lightGrayComing,
    marginTop: Metrics.rfv(3),
  },
  bottomContainer: {
    backgroundColor: Colors.lightblueColor,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
  },
  seconBannerStyle: {
    paddingTop: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.cream,
  },
  secondBannerStyle: {
    width: "100%",
    height: Metrics.rfv(63),
    resizeMode: "contain",
  },
  bottomView: {
    backgroundColor: Colors.cream,
    paddingTop: Metrics.rfv(15),
    flex: 1,
    marginBottom: Metrics.rfv(30),
  },
  creamBgContainer: {
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(15),
    backgroundColor: Colors.cream,
  },
  textCenter: {
    alignSelf: "center",
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
    alignItems: "center",
  },
  commonFlex: {
    flex: 0.7,
    paddingHorizontal: Metrics.rfv(2),
  },
  bottomOurPartnerView: {
    paddingBottom:
      Platform.OS === "android" ? Metrics.rfv(60) : Metrics.rfv(90),
  },
  sportContainer: {
    backgroundColor: Colors.linearColor2,
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(4),
    borderRadius: Metrics.rfv(10),
    alignItems: "center",
    justifyContent: "center",
    marginLeft: Metrics.rfv(5),
  },
  sportTitle: {
    color: Colors.white,
    fontSize: Metrics.rfv(11),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    lineHeight: Metrics.rfv(15),
  },
});
