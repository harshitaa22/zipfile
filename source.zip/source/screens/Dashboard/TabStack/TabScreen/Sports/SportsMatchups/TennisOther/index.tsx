import { View, Text } from "react-native";
import React from "react";

const TennisOtherScreen = () => {
  return (
    <View>
      <Text>TennisOtherScreen</Text>
    </View>
  );
};

export default TennisOtherScreen;
