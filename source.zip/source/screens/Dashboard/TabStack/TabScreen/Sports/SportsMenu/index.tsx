import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { FlatList, Pressable, ScrollView, Text, View } from "react-native";
import SkeletonPlaceholder from "react-native-skeleton-placeholder";
//component
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
import Header from "../../../../../../component/HeaderComponent/index";
import PartnersList from "../../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../../component/Text/index";
//theme
import commonStyles from "../../../../../../theme/commonStyle";
import { SportMenuList } from "../../../../../../theme/dummyArray";
import {
  Colors,
  CommonStyle,
  Images,
  Metrics,
} from "../../../../../../theme/index";
//style
import styles from "./style";
//navigation
import { NAVIGATION } from "../../../../../../navigation";
//utils
import { useSelector } from "react-redux";
import { RightUpArrow } from "../../../../../../theme/svg";
import { translate } from "../../../../../../utils/Localize";
import { print_data } from "../../../../../../utils/Logs";

export default function SportsMenu() {
  const navigation = useNavigation();

  let sportData = useSelector(
    (state: any) => state.UserDataReducer.is_sport_data
  );

  const [loading, setLoading] = useState(true);
  print_data("sportDat=======");
  print_data(sportData);

  useEffect(() => {
    if (sportData == true) {
      setLoading(true);
    } else {
      setLoading(false);
    }
  }, [sportData]);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const sportItemPress = (item: any) => {
    navigation.navigate(NAVIGATION.SPORT_PAGE, {
      sportData: item,
    });
  };

  const renderItem = (item: any, index: any) => {
    print_data(item?.title);
    return (
      <>
        {loading ? (
          <>
            <SkeletonPlaceholder>
              <View style={commonStyles.commonFlex} key={index}>
                <>
                  <View style={styles.horizontalView}>
                    <SkeletonPlaceholder.Item width={"100%"} height={40} />
                  </View>
                </>
              </View>
            </SkeletonPlaceholder>
            <View style={styles.bottomWidthSketon} />
          </>
        ) : (
          <>
            {(item?.title == "Tennis" && sportData?.tennis == 0) ||
            (item?.title == "Australian Rules" && sportData?.ausRules == 0) ||
            (item?.title == "Baseball" && sportData?.baseBall == 0) ||
            (item?.title == "Basketball" && sportData?.basketball == 0) ||
            (item?.title == "Boxing" && sportData?.boxing == 0) ||
            (item?.title == "Cricket" && sportData?.cricket == 0) ||
            (item?.title == "Ice Hockey" && sportData?.iceHockey == 0) ||
            (item?.title == "Mixed Martial Arts" && sportData?.mma == 0) ||
            (item?.title == "Rugby League" && sportData?.rugbyLeague == 0) ||
            (item?.title == "Rugby Union" && sportData?.rugbyUnion == 0) ||
            (item?.title == "Soccer" && sportData?.soccer == 0) ? null : (
              <>
                <Pressable
                  onPress={() => sportItemPress(item)}
                  style={styles.sportContainer}
                >
                  <View style={styles.centerView}>
                    <View style={CommonStyle.alignCenterView}>
                      <View>{item?.iconImage}</View>
                      <Text style={styles.sportText}>{item?.title}</Text>
                    </View>
                    <RightUpArrow
                      width={Metrics.rfv(9)}
                      height={Metrics.rfv(15)}
                    />
                  </View>
                </Pressable>
                <View style={styles.bottomWidth} />
              </>
            )}
          </>
        )}
      </>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.cream}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent isShowSmartBIcon={true} />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.sportTitle}>
          <TextHeaderTitle
            title={translate("SportsTab")}
            textStyle={styles.australianText}
          />
        </View>

        <FlatList
          data={SportMenuList}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.containerStyle}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => renderItem(item, index)}
        />

        <View style={styles.sportTitle}>
          <View style={styles.textCenter}>
            <TextHeaderTitle
              title={translate("OurPartners")}
              textStyle={styles.sportStyle}
            />
          </View>
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}
