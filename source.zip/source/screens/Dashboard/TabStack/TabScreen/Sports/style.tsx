import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../../../../theme/index";

export default StyleSheet.create({
  tabViewStyle: {
    width: Metrics.rfp(180),
    height: Metrics.rfv(3),
    marginTop: Metrics.rfv(50),
    backgroundColor: Colors.linearColor2,
  },
  indicatorStyle: {
    backgroundColor: Colors.linearColor2,
    alignSelf: "flex-start",
    width: Metrics.rfv(120),
    height: Metrics.rfv(5),
  },
  tabBarMainStyle: {
    backgroundColor: Colors.white,
    shadowOffset: { height: Metrics.rfv(0), width: Metrics.rfv(0) },
    shadowColor: "transparent",
    shadowOpacity: Metrics.rfv(0),
    elevation: Metrics.rfv(0),
    marginBottom: Metrics.rfv(8),
  },
  indicator: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "center",
    height: Metrics.rfv(4),
  },
  contentContainerStyle: {
    justifyContent: "center",
  },
  renderTabStyle: {
    elevation: Metrics.rfv(0),
    width: Metrics.rfv(120),
  },
  labelStyle: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    color: Colors.black,

    textTransform: "capitalize",
  },
  bottomBorder: {
    borderBottomWidth: Metrics.rfv(3),
    borderBottomColor: Colors.linearColor2,
    elevation: 0,
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  adStyle: {
    marginBottom: Metrics.rfv(5),
  },
  adImage: {
    width: Metrics.rfv(390),
    height: Metrics.rfv(95),
  },
  australianText: {
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    color: Colors.black,
    marginTop: Metrics.rfv(20),
    marginBottom: Metrics.rfv(10),
  },
  sportTitle: {
    marginHorizontal: Metrics.rfv(10),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  box: {
    height: 250,
    width: "100%",
  },
  boxA: {
    backgroundColor: "white",
  },
  boxB: {
    backgroundColor: "#D8D8D8",
  },
});
