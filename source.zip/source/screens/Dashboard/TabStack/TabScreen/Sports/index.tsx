import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useRef, useState } from "react";
import { Animated, View } from "react-native";
import { MaterialTabBar, Tabs } from "react-native-collapsible-tab-view";
import AppSafeAreaView from "../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../component/CommonHeaderComponent";
import Header from "../../../../../component/HeaderComponent/index";
import TextHeaderTitle from "../../../../../component/Text/index";
import { NAVIGATION } from "../../../../../navigation";
import {
  Colors,
  CommonStyle,
  Images,
  Metrics,
} from "../../../../../theme/index";
import GolfOutRightTab from "../../../TopStack/GolfOutRight";
import MatchesTab from "../../../TopStack/MatchesSports/index";
import SportTeam from "./SportsMatchups/SportTeam";
import styles from "./style";
import { SPORTS } from "../../../../../utils/constant";

export default function SportsTab(props: any) {
  const navigation = useNavigation();
  const [routes, setRoutes] = useState("");
  const [layout, setLayout] = useState(0);
  const title = props?.route?.params?.sportData?.title;
  const sportName = props?.route?.params?.sportItem?.Sport?.sportName;
  const sportId = props?.route?.params?.sportId;
  const sportItemData = props?.route?.params?.sportItem;
  const scrollOffsetY = useRef(new Animated.Value(0)).current;
  const HEADER_HEIGHT = layout;
  const MINHEADER_HEIGHT = 0;
  const SCROLL_DISTANCE = HEADER_HEIGHT - MINHEADER_HEIGHT;
  const headerScrollHeight = scrollOffsetY.interpolate({
    inputRange: [0, SCROLL_DISTANCE],
    outputRange: [HEADER_HEIGHT, MINHEADER_HEIGHT],
    extrapolate: "clamp",
  });

  useEffect(() => {
    if (
      title === SPORTS.BASKETBALL ||
      sportName === SPORTS.BASKETBALL ||
      title == SPORTS.AMERICAN_FOOTBALL ||
      sportName == SPORTS.AMERICAN_FOOTBALL ||
      title == SPORTS.BASEBALL ||
      sportName == SPORTS.BASEBALL ||
      title == SPORTS.ICE_HOCKEY ||
      sportName == SPORTS.ICE_HOCKEY
    ) {
      setRoutes("Odds");
    } else {
      setRoutes("Matches");
    }
  }, [title, sportName]);

  // useEffect(() => {
  //   BackHandler.addEventListener("hardwareBackPress", handleBackButtonClick);
  //   return () => {
  //     BackHandler.removeEventListener(
  //       "hardwareBackPress",
  //       handleBackButtonClick
  //     );
  //   };
  // }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const handleBackButtonClick = () => {
    navigation.navigate(NAVIGATION.SPRTS_MENU);
    return true;
  };

  const myHeader = () => {
    return (
      <>
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.sportTitle}>
          <TextHeaderTitle
            title={
              props?.route?.params?.sportItem
                ? props?.route?.params?.sportItem?.Sport?.sportName
                : props?.route?.params?.sportData?.title
            }
            textStyle={styles.australianText}
          />
        </View>
      </>
    );
  };
  const tabBar = (props: any) => {
    return (
      <MaterialTabBar
        {...props}
        scrollEnabled={true}
        activeColor={Colors.linearColor2}
        inactiveColor={Colors.black}
        labelStyle={styles.labelStyle}
        width={
          title === SPORTS.BASKETBALL ||
          sportName === SPORTS.BASKETBALL ||
          title === SPORTS.AMERICAN_FOOTBALL ||
          sportName === SPORTS.AMERICAN_FOOTBALL ||
          title === SPORTS.BASEBALL ||
          sportName === SPORTS.BASEBALL ||
          title === SPORTS.ICE_HOCKEY ||
          sportName === SPORTS.ICE_HOCKEY
            ? 230
            : 130
        }
        tabStyle={{
          alignSelf: "center",
          justifyContent: "center",
          flexDirection: "row",
          padding: 0,
        }}
        indicatorStyle={{
          backgroundColor: Colors.linearColor1,
          alignSelf: "center",
          height: Metrics.rfv(4),
          width:
            title === SPORTS.BASKETBALL ||
            sportName === SPORTS.BASKETBALL ||
            title === SPORTS.AMERICAN_FOOTBALL ||
            sportName === SPORTS.AMERICAN_FOOTBALL ||
            title === SPORTS.BASEBALL ||
            sportName === SPORTS.BASEBALL ||
            title === SPORTS.ICE_HOCKEY ||
            sportName === SPORTS.ICE_HOCKEY
              ? 230
              : 130,
        }}
        style={styles.bottomBorder}
      />
    );
  };

  const find_dimesions = (layout) => {
    const { height } = layout;
    setLayout(height);
  };

  return (
    <View
      style={CommonStyle.commonFlex}
      onLayout={(event) => {
        find_dimesions(event.nativeEvent.layout);
      }}
    >
      <AppSafeAreaView
        firstSafeAreaViewStyle={styles.safeAreaViewStyle}
        backgroundColor={Colors.cream}
      >
        <AppStatusBar
          backgroundColor={Colors.white}
          isTransperent={false}
          barStyle={"dark-content"}
        />
        <CommonHeaderComponent
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
        />
        <Animated.View
          style={{
            position: "relative",
            left: 0,
            right: 0,
            top: 0,
            height: headerScrollHeight,
            width: "100%",
            overflow: "hidden",
            zIndex: 1,
          }}
        >
          <Tabs.Container
            renderHeader={myHeader}
            renderTabBar={tabBar}
            lazy={true}
            headerHeight={HEADER_HEIGHT}
            minHeaderHeight={MINHEADER_HEIGHT}
          >
            <Tabs.Tab name="Odds" label={routes}>
              <MatchesTab
                individualTeamdata={props?.route?.params?.individualTeamdata}
                homeData={props?.route?.params?.sportItem?.Sport?.sportName.trim(
                  ""
                )}
                sportData={props?.route?.params?.sportData}
                sportItem={sportItemData}
                sportId={sportId}
                isSeeAll={props?.route?.params?.isSeeAll}
              />
            </Tabs.Tab>
            {(title === SPORTS.BASKETBALL ||
              sportName === SPORTS.BASKETBALL ||
              title === SPORTS.AMERICAN_FOOTBALL ||
              sportName === SPORTS.AMERICAN_FOOTBALL ||
              title === SPORTS.BASEBALL ||
              sportName === SPORTS.BASEBALL ||
              title === SPORTS.ICE_HOCKEY ||
              sportName === SPORTS.ICE_HOCKEY) && (
              <Tabs.Tab name="Matchups" label="Matchups">
                <Tabs.ScrollView
                  showsVerticalScrollIndicator={false}
                  scrollEnabled={true}
                >
                  <SportTeam
                    individualTeamdata={
                      props?.route?.params?.individualTeamdata
                    }
                    homeData={props?.route?.params?.sportItem?.Sport?.sportName.trim(
                      ""
                    )}
                    sportData={props?.route?.params?.sportData}
                    sportItem={sportItemData}
                    sportId={sportId}
                  />
                </Tabs.ScrollView>
              </Tabs.Tab>
            )}

            <Tabs.Tab name="OutRight" label="OutRight">
              <GolfOutRightTab
                individualTeamdata={props?.route?.params?.individualTeamdata}
                homeData={props?.route?.params?.sportItem?.Sport?.sportName.trim(
                  ""
                )}
                sportData={props?.route?.params?.sportData}
                sportItem={sportItemData}
                sportId={sportId}
              />
            </Tabs.Tab>
          </Tabs.Container>
        </Animated.View>
      </AppSafeAreaView>
    </View>
  );
}
