import React, { useState } from "react";
import {
  FlatList,
  Image,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import Header from "../../../../../../component/HeaderComponent";
import TextHeaderTitle from "../../../../../../component/Text";
import {
  BlogList,
  CategoriesList,
  RecentPosts,
} from "../../../../../../theme/dummyArray";
import { Colors, Images, Metrics } from "../../../../../../theme";
import styles from "./style";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import commonStyles from "../../../../../../theme/commonStyle";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../../utils/Localize";
import { NAVIGATION } from "../../../../../../navigation";
import { EmptyImg, NextIcon, PreviousIcon } from "../../../../../../theme/svg";
import Button from "../../../../../../component/Button";
import CustomTextInput from "../../../../../../component/TextInput";
import CardView from "react-native-cardview";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

const BlogDetails = () => {
  const navigation = useNavigation();
  const [email, setEmail] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const renderResentPostItem = (item, index) => {
    return (
      <Pressable>
        {index == 0 ? null : <View style={commonStyles.bottomWidth} />}
        <Text style={styles.blogHeadingText}>{item?.listTitle}</Text>
        <View style={styles.timeView}>
          <View>{item?.iconImage}</View>
          <Text style={styles.subTitleText}>{item?.subTitle}</Text>
        </View>
      </Pressable>
    );
  };

  const renderCategoriesItem = (item, index) => {
    return (
      <Pressable>
        {index == 0 ? null : <View style={commonStyles.bottomWidth} />}
        <View style={styles.rowView}>
          <Text style={styles.categoriesTextStyle}>{item?.listTitle}</Text>
          <View style={styles.numberView}>
            <Text style={styles.numberText}>{item?.numberText}</Text>
          </View>
        </View>
      </Pressable>
    );
  };
  const renderItem = (item, index) => {
    return (
      <Pressable
        onPress={() => navigation.navigate(NAVIGATION.BLOG_DETAILS)}
        style={styles.rightView}
      >
        {/* {index == 0 ? null : <View style={styles.bottomWidth} />} */}
        <View>{item?.iconImage}</View>
        <Text style={styles.loremTextStyle}>{item?.listTitle}</Text>
        <Text style={styles.dateText}>June 24th, 2020 | 0 Comments</Text>
      </Pressable>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View>
          <View style={styles.horizontalView}>
            <TextHeaderTitle
              title={translate("LoremIpsujmText")}
              textStyle={styles.textStyle}
            />
            <Image style={styles.profileIcon} source={Images.profile} />
            <Text style={styles.userText}>Dario Pineda</Text>
            <Text style={styles.yearText}>Jun 16, 2020</Text>
            <EmptyImg style={styles.emptyImage} />
            <Text style={styles.blogDetailsText}>
              {translate("BlogDetailsText")}
            </Text>
            <View style={styles.leftView}>
              <Text style={styles.blogDetailsText}>
                {translate("NuncText")}
              </Text>
            </View>
          </View>
          <View style={styles.conatinerStyle}>
            <Text style={styles.publisedText}>
              Published On: Jun 16, 2020 |Categories: Category 1, Category 2,
              Category 3
            </Text>
          </View>
          <View style={styles.horizontalView}>
            <CardView
              style={styles.boxWithShadow}
              cardElevation={5}
              cardMaxElevation={2}
              cornerRadius={4}
            >
              <View>
                <Text style={styles.subscribeText}>
                  {translate("SubscribeNews")}
                </Text>
                <Text>{translate("LoremConsecteturText")}</Text>
                <View style={styles.textInputContainer}>
                  <CustomTextInput
                    textInputStyle={styles.textInputStyle}
                    //   containerStyle={commonStyles.inputTextContainerStyle}
                    placeholderTextColor={Colors.gray}
                    placeholderText={translate("EnterEmail")}
                    inputTextStyle={styles.inputTextStyle}
                    value={email}
                    maxLength={12}
                    keyboardType={"number-pad"}
                    returnKeyType={"done"}
                    onChangeText={(text: string) => {
                      setEmail(text);
                    }}
                  />
                </View>
                <View style={commonStyles.commonFlex}>
                  <Button
                    disabled={false}
                    // onPress={() => onSavePress()}
                    title={translate("Continue")}
                    borderColor={Colors.white}
                    color={Colors.white}
                    fontSize={Metrics.rfv(14)}
                    backgroundColor={Colors.linearColor2}
                  />
                </View>
              </View>
            </CardView>
            <Text style={styles.titleText}>{translate("RelatedPosts")}</Text>

            <FlatList
              data={BlogList}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.containerStyle}
              showsHorizontalScrollIndicator={false}
              horizontal
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item, index }) => renderItem(item, index)}
            />

            <Text style={styles.titleText}>{translate("RecentPosts")}</Text>
            <FlatList
              data={RecentPosts}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.containerCategoriesStyle}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item, index }) =>
                renderResentPostItem(item, index)
              }
            />
            <Text style={styles.titleText}>{translate("Categories")}</Text>
            <FlatList
              data={CategoriesList}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.containerCategoriesStyle}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item, index }) =>
                renderCategoriesItem(item, index)
              }
            />
          </View>
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
};

export default BlogDetails;
