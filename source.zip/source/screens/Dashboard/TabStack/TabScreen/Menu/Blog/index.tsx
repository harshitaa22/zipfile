import React, { useState } from "react";
import {
  FlatList,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import CardView from "react-native-cardview";
//component
import Header from "../../../../../../component/HeaderComponent";
import PartnersList from "../../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../../component/Text";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import CustomTextInput from "../../../../../../component/TextInput";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";
import Button from "../../../../../../component/Button";
//theme
import {
  BlogList,
  CategoriesList,
  RecentPosts,
} from "../../../../../../theme/dummyArray";
import { Colors, Images, Metrics } from "../../../../../../theme";
import { StatisticsSearchIcon } from "../../../../../../theme/svg";
import commonStyles from "../../../../../../theme/commonStyle";
//utils
import { translate } from "../../../../../../utils/Localize";
//style
import styles from "./style";
//navigation
import { NAVIGATION } from "../../../../../../navigation";

const BlogScreen = () => {
  const navigation = useNavigation();
  const [search, setSearch] = useState("");
  const [email, setEmail] = useState("");

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const renderItem = (item, index) => {
    return (
      <Pressable onPress={() => navigation.navigate(NAVIGATION.BLOG_DETAILS)}>
        <View>{item?.iconImage}</View>
        <Text style={styles.loremTextStyle}>{item?.listTitle}</Text>
        <View style={styles.rowView}>
          <Text style={styles.dateText}>{item?.date}</Text>
          <Text style={styles.dateText}>{item?.categoryText}</Text>
        </View>
        <View style={commonStyles.bottomWidth} />
        <Text style={styles.textDolorStyle}>{item?.dolorText}</Text>
        {item?.id == 2 && (
          <CardView
            style={styles.boxWithShadow}
            cardElevation={5}
            cardMaxElevation={2}
            cornerRadius={4}
          >
            <View>
              <Text style={styles.subscribeText}>
                {translate("SubscribeNews")}
              </Text>
              <Text>{translate("LoremConsecteturText")}</Text>
              <View style={styles.textInputContainer}>
                <CustomTextInput
                  textInputStyle={styles.textInputStyle}
                  placeholderTextColor={Colors.gray}
                  placeholderText={translate("EnterEmail")}
                  inputTextStyle={styles.inputTextStyle}
                  value={email}
                  maxLength={12}
                  keyboardType={"number-pad"}
                  returnKeyType={"done"}
                  onChangeText={(text: string) => {
                    setEmail(text);
                  }}
                />
              </View>
              <View style={commonStyles.commonFlex}>
                <Button
                  disabled={false}
                  title={translate("Continue")}
                  borderColor={Colors.white}
                  color={Colors.white}
                  fontSize={Metrics.rfv(14)}
                  backgroundColor={Colors.linearColor2}
                />
              </View>
            </View>
          </CardView>
        )}
      </Pressable>
    );
  };

  const renderResentPostItem = (item, index) => {
    return (
      <Pressable>
        {index == 0 ? null : <View style={commonStyles.bottomWidth} />}
        <Text style={styles.blogHeadingText}>{item?.listTitle}</Text>
        <View style={styles.timeView}>
          <View>{item?.iconImage}</View>
          <Text style={styles.subTitleText}>{item?.subTitle}</Text>
        </View>
      </Pressable>
    );
  };

  const renderCategoriesItem = (item, index) => {
    return (
      <Pressable>
        {index == 0 ? null : <View style={commonStyles.bottomWidth} />}
        <View style={styles.rowView}>
          <Text style={styles.categoriesTextStyle}>{item?.listTitle}</Text>
          <View style={styles.numberView}>
            <Text style={styles.numberText}>{item?.numberText}</Text>
          </View>
        </View>
      </Pressable>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("SmartBBlogs")}
            textStyle={styles.textStyle}
          />
          <Text style={styles.loremStyle}>{translate("LoremBlogText")}</Text>

          <View style={styles.serchContainerStyle}>
            <StatisticsSearchIcon style={styles.searchIconStyle} />

            <TextInput
              style={styles.searchTextinputStyle}
              placeholder={translate("SearchBlogs")}
              placeholderTextColor={Colors.borderDropDown}
              numberOfLines={1}
              value={search}
              onChangeText={(text) => {
                setSearch(text);
              }}
            />
          </View>
          <FlatList
            data={BlogList}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.containerStyle}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => renderItem(item, index)}
          />
          <Text style={styles.titleText}>{translate("RecentPosts")}</Text>
          <FlatList
            data={RecentPosts}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.containerCategoriesStyle}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => renderResentPostItem(item, index)}
          />
          <Text style={styles.titleText}>{translate("Categories")}</Text>
          <FlatList
            data={CategoriesList}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.containerCategoriesStyle}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => renderCategoriesItem(item, index)}
          />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
};

export default BlogScreen;
