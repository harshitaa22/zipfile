import React, { useEffect, useState } from "react";
import {
  FlatList,
  Image,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import Header from "../../../../../../component/HeaderComponent";
import TextHeaderTitle from "../../../../../../component/Text";
import {
  BlogList,
  CategoriesList,
  FaqList,
  faqList,
  RecentPosts,
} from "../../../../../../theme/dummyArray";
import { Colors, CommonStyle, Images, Metrics } from "../../../../../../theme";
import styles from "./style";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import commonStyles from "../../../../../../theme/commonStyle";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../../utils/Localize";
import { NAVIGATION } from "../../../../../../navigation";
import {
  EmptyImg,
  MinusIcon,
  NextIcon,
  PlusIcon,
  PreviousIcon,
} from "../../../../../../theme/svg";
import Button from "../../../../../../component/Button";
import CustomTextInput from "../../../../../../component/TextInput";
import CardView from "react-native-cardview";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

const FaqScreen = () => {
  const navigation = useNavigation();
  //   const [faqVi, setGeneralVisible] = useState(true);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [faqData, setFaqData] = useState([]);

  useEffect(() => {
    let faqItem = [...FaqList];
    setFaqData(faqItem);
  }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const renderItem = (item, index) => (
    <View>
      <Pressable
        onPress={() => onFaqItemPress(item, index)}
        style={styles.generalContainer}
      >
        <Text style={styles.titleText}>{item?.title}</Text>

        {item.isExpanded ? (
          <MinusIcon style={styles.plusIcon} />
        ) : (
          <PlusIcon style={styles.plusIcon} />
        )}
      </Pressable>
      {item.isExpanded ? (
        <View style={styles.questionContainer}>
          <Text style={styles.desText}>{item?.Description}</Text>

          {/* <Text style={styles.descriptionText}>{item.Description}</Text> */}
        </View>
      ) : null}
    </View>
  );

  const onFaqItemPress = (item, index) => {
    if (item.isExpanded) {
      item.isExpanded = false;
    } else {
      faqData.forEach((item, _index) => {
        let obj = { ...item }; //Remember to copy Object
        if (_index === index) {
          obj.isExpanded = true;
        } else {
          obj.isExpanded = false;
        }
        faqData[_index] = obj;
      });
    }
    setDataUpdated(!dataUpdated);
    setFaqData(faqData);
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("SmartBFAQs")}
            textStyle={styles.textStyle}
          />
          <Text style={styles.loremStyle}>{translate("LoremBlogText")}</Text>
          <View style={styles.bottomWidth} />
          <FlatList
            contentContainerStyle={styles.bottomView}
            data={faqData}
            renderItem={({ item, index }) => renderItem(item, index)}
            keyExtractor={(item, index) => index.toString()}
            extraData={dataUpdated}
          />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
};

export default FaqScreen;
