import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginTop: Metrics.rfv(28),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
  },
  loremStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginTop: Metrics.rfv(10),
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
  },
  bottomView: {
    paddingBottom: Metrics.rfv(50),
  },
  plusIcon: {
    height: Metrics.rfv(15),
    width: Metrics.rfv(15),
  },
  titleText: {
    color: Colors.linearColor2,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  desText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  generalContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(10),
  },
  questionContainer: {
    marginBottom: Metrics.rfv(10),
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(20),
    marginBottom: Metrics.rfv(5),
  },
});
