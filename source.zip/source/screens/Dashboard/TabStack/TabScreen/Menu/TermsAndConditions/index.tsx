import React from "react";
import { Alert, ScrollView, Text, View } from "react-native";
import Header from "../../../../../../component/HeaderComponent";
import PartnersList from "../../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../../component/Text";
import { PartnersData } from "../../../../../../theme/dummyArray";
import { Colors, Images } from "../../../../../../theme";
import styles from "./style";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import commonStyles from "../../../../../../theme/commonStyle";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../../../../../navigation";
import { translate } from "../../../../../../utils/Localize";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

type Props = {
  loading?: boolean;
  navigation?: any;
};

export default function TermsConditionsScreen(props: Props) {
  const navigation = useNavigation();

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const BoldText = (props: any) => {
    return <Text style={styles.boldText}>{props.children}</Text>;
  };

  const UnderLineText = (props: any) => {
    return <Text style={styles.underLineText}>{props.children}</Text>;
  };

  // const onProfilePress = () => {
  //   navigation.navigate(NAVIGATION.PROFILE);
  // };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("SmartBTerms")}
            textStyle={styles.textStyle}
          />
          <Text style={styles.ModifiedText}>{translate("WelcomeTitle")}</Text>
          <BoldText>{translate("SmartB")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>
              {translate("SmartBPlatforms")}
            </Text>
          </View>
          <BoldText>{translate("UseServices")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>
              {translate("IndividualsText")}
            </Text>
          </View>
          <BoldText>{translate("ContentFunctionality")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>
              {translate("SmartBReceives")}
            </Text>
          </View>
          <BoldText>{translate("Intellectual")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>
              {translate("AllIntellectualTitle")}
            </Text>
          </View>
          <BoldText>{translate("NoAdviceTitle")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>
              {translate("ContentIncluded")}
            </Text>
          </View>
          <BoldText>{translate("LiabilityIndemnity")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>{translate("SmartBDoes")}</Text>
          </View>
          <View style={styles.leftContainerView}>
            <Text style={styles.ModifiedText}>{translate("YouAccept")}</Text>
          </View>
          <BoldText>{translate("ContributingContentTitle")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>{translate("WhenSubmit")}</Text>
          </View>
          <BoldText>{translate("GeneralTitle")}</BoldText>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>
              {translate("UsersMustTitle")}
            </Text>
          </View>
          <View style={styles.leftContainerStyle}>
            <Text style={styles.ModifiedText}>
              {translate("tag")}
              {translate("ExceptOtherwise")}
              <UnderLineText>{translate("SiteTitle")}</UnderLineText>
            </Text>
          </View>
          <View style={styles.leftView}>
            <Text style={styles.ModifiedText}>{translate("Headings")}</Text>
          </View>
          <BoldText>{translate("SmartbText")}</BoldText>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.ourPatnersStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}
