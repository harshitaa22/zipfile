import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  partnerListBottom: {
    marginBottom: Metrics.rfv(50),
  },
  text1Created: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
  },
  textStyle: {
    color: Colors.black,

    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(25),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  ourPatnersStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,

    marginTop: Metrics.rfv(25),
    marginBottom: Metrics.rfv(10),
    textAlign: "center",
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
  },
  ModifiedText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  sensitiveView: {
    marginLeft: Metrics.rfv(15),
  },
  ExcludeView: {
    marginLeft: Metrics.rfv(30),
  },
  boldText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
  },
  leftView: {
    marginLeft: Metrics.rfv(15),
  },
  leftContainerView: {
    marginLeft: Metrics.rfv(25),
  },
  underLineText: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
    textDecorationLine: "underline",
    textDecorationColor: Colors.linearColor2,
  },
  leftContainerStyle: {
    marginLeft: Metrics.rfv(15),
    marginTop: Metrics.rfv(15),
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
});
