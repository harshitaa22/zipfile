import React, { useState } from "react";
import { ScrollView, Text, View } from "react-native";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import Header from "../../../../../../component/HeaderComponent";
import PartnersList from "../../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../../component/Text";
import { PartnersData } from "../../../../../../theme/dummyArray";
import { Colors, Images } from "../../../../../../theme";
import styles from "./style";
import commonStyles from "../../../../../../theme/commonStyle";
import { NAVIGATION } from "../../../../../../navigation";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../../utils/Localize";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

export default function PolicyScreen() {
  const navigation = useNavigation();

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const BoldText = (props) => {
    return <Text style={styles.boldText}>{props.children}</Text>;
  };

  const UnderLineText = (props) => {
    return <Text style={styles.underLineText}>{props.children}</Text>;
  };

  // const onProfilePress = () => {
  //   navigation.navigate(NAVIGATION.PROFILE);
  // };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("SmartBPrivacyPolicy")}
            textStyle={styles.textStyle}
          />
          <Text style={styles.ModifiedText}>{translate("WhenAccessText")}</Text>
          <View style={styles.rowContainer}>
            <Text style={styles.ModifiedText}>{translate("PrivacyText")}</Text>
            <BoldText>{translate("JanuaryText")}</BoldText>
          </View>
          <Text style={styles.ModifiedText}>{translate("EffectiveDate")}</Text>
          <BoldText>{translate("Introduction")}</BoldText>
          <Text style={styles.ModifiedText}>{translate("ThirdPartyText")}</Text>
          <BoldText>{translate("CollectIt")}</BoldText>
          <Text style={styles.ModifiedText}>
            {translate("collectPersonal")}
          </Text>
          <View style={styles.RegistrationInformationView}>
            <BoldText>{translate("RegistrationInformation")}</BoldText>
            <Text style={styles.ModifiedText}>
              {translate("InformationProvide")}
            </Text>
            <View style={styles.accountLeftView}>
              <Text style={styles.ModifiedText}>
                {translate("createAccount")}
              </Text>
            </View>
            <Text style={styles.ModifiedText}>
              {translate("RegistrationInfo")}
            </Text>
            <BoldText>{translate("DeviceInformation")}</BoldText>
            <Text style={styles.ModifiedText}>{translate("DeviceInfo")}</Text>
            <BoldText>{translate("PublicInformation")}</BoldText>
            <Text style={styles.ModifiedText}>{translate("ThisIncludes")}</Text>
            <BoldText>{translate("InformationFrom")}</BoldText>
            <Text style={styles.ModifiedText}>{translate("IfYouAccess")}</Text>
            <View style={styles.accountLeftView}>
              <Text style={styles.ModifiedText}>
                {translate("yourUserName")}
              </Text>
            </View>
            <Text style={styles.ModifiedText}>{translate("WeCollect")}</Text>
            <BoldText>{translate("ActivityInformation")}</BoldText>
            <Text style={styles.ModifiedText}>{translate("WhenServices")}</Text>
            <BoldText>{translate("InformationOtherSources")}</BoldText>
            <Text style={styles.ModifiedText}>
              {translate("WhereReasonable")}
            </Text>
            <BoldText>{translate("InformationRelation")}</BoldText>
            <Text style={styles.ModifiedText}>{translate("WhenApply")}</Text>
            <View style={styles.accountLeftView}>
              <Text style={styles.ModifiedText}>
                {translate("WeHoldAbout")}
              </Text>
            </View>
            <Text style={styles.ModifiedText}>
              {translate("CollectsPersonal")}
            </Text>
          </View>
          <BoldText>{translate("SensitiveInformation")}</BoldText>
          <Text style={styles.ModifiedText}>{translate("SensitiveInfo")}</Text>
          <View style={styles.accountLeftView}>
            <Text style={styles.ModifiedText}>
              {translate("ForThePrimary")}
            </Text>
          </View>
          <BoldText>{translate("HowCookies")}</BoldText>
          <Text style={styles.ModifiedText}>{translate("WhenAccess")}</Text>
          <View style={styles.accountLeftView}>
            <Text style={styles.ModifiedText}>
              {translate("RecogniseText")}
            </Text>
          </View>
          <Text style={styles.ModifiedText}>{translate("YouFree")}</Text>
          <BoldText>{translate("YourInformation")}</BoldText>
          <Text style={styles.ModifiedText}>{translate("UseInformation")}</Text>
          <View style={styles.accountLeftView}>
            <Text style={styles.ModifiedText}>
              {translate("OperateMaintain")}
            </Text>
          </View>
          <Text style={styles.ModifiedText}>{translate("WhenWeCollect")}</Text>
          <View style={styles.RegistrationInformationView}>
            <BoldText>{translate("OtherWays")}</BoldText>
            <View style={styles.accountLeftView}>
              <Text style={styles.ModifiedText}>
                {translate("AllowServiceText")}
              </Text>
            </View>
            <View style={styles.enforceText}>
              <Text style={styles.ModifiedText}>
                {translate("ProtectText")}
              </Text>
            </View>
          </View>
          <BoldText>{translate("ProtectYourInformation")}</BoldText>
          <Text style={styles.ModifiedText}>{translate("ProtectInfo")}</Text>
          <View style={styles.RegistrationInformationView}>
            <Text style={styles.ModifiedText}>
              {translate("WeTakeReasonable")}
            </Text>
          </View>
          <BoldText>{translate("YourRights")}</BoldText>
          <Text style={styles.ModifiedText}>{translate("YourRightsText")}</Text>
          <View style={styles.AcessContainer}>
            <Text style={styles.ModifiedText}>
              <Text>{translate("tag")}</Text>
              <UnderLineText>{translate("Access")}</UnderLineText>
              {translate("AccessProvide")}
            </Text>
          </View>
          <View style={styles.AcessContainer}>
            <Text style={styles.ModifiedText}>
              <Text>{translate("tag")}</Text>
              <UnderLineText>{translate("Device")}</UnderLineText>
              {translate("AccessProvide")}
            </Text>
          </View>
          <View style={styles.AcessContainer}>
            <Text style={styles.ModifiedText}>
              <Text>{translate("tag")}</Text>
              <UnderLineText>{translate("Uninstall")}</UnderLineText>
              {translate("UninstallTitle")}
            </Text>
          </View>
          <View style={styles.AcessContainer}>
            <Text style={styles.ModifiedText}>
              <Text>{translate("tag")}</Text>
              <UnderLineText>{translate("AccountClosure")}</UnderLineText>
              {translate("AccountClosureTitle")}
            </Text>
          </View>
          <Text style={styles.ModifiedText}>{translate("Remember")}</Text>
          <View style={styles.AcessContainer}>
            <Text style={styles.ModifiedText}>
              <Text>{translate("tag")}</Text>
              <UnderLineText>{translate("ReviewingYourInfo")}</UnderLineText>
              {translate("Applicable")}
            </Text>
          </View>
          <View style={styles.AcessContainer}>
            <Text style={styles.ModifiedText}>
              <Text>{translate("tag")}</Text>
              <UnderLineText>{translate("Updating")}</UnderLineText>
              {translate("IfYourBelieve")}
            </Text>
          </View>
          <Text style={styles.ModifiedText}>{translate("YourProtection")}</Text>
          <BoldText>{translate("SmartbText")}</BoldText>
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.ourPatnersStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}
