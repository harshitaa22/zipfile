import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  text1Created: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),

    marginTop: Metrics.rfv(25),
    marginBottom: Metrics.rfv(15),
  },
  ourPatnersStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginTop: Metrics.rfv(25),
    marginBottom: Metrics.rfv(10),
    textAlign: "center",
  },
  ModifiedText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  sensitiveView: {
    marginLeft: Metrics.rfv(15),
  },
  boldText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
  },
  rowContainer: {
    flexDirection: "row",
    marginTop: Metrics.rfv(20),
  },
  RegistrationInformationView: {
    // marginLeft: Metrics.rfv(20),
  },
  accountLeftView: {
    marginLeft: Metrics.rfv(22),
  },
  enforceText: {
    marginLeft: Metrics.rfv(30),
  },
  underLineText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
    textDecorationLine: "underline",
  },
  AcessContainer: {
    flexDirection: "row",
    marginTop: Metrics.rfv(20),
    marginLeft: Metrics.rfv(20),
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
});
