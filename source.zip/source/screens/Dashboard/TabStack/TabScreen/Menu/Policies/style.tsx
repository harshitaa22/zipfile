import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  policesTitle: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_SemiBold,
  },
  partnerListBottom: {
    marginBottom: Metrics.rfv(30),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(14),
  },
  OurPartnersStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    textAlign: "center",
    marginTop: Metrics.rfv(20),
    marginBottom: Metrics.rfv(5),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(10),
  },
  privacyTitle: {
    padding: Metrics.rfv(15),
    borderWidth: Metrics.rfv(1),
    borderColor: Colors.lightGrayBoxGray,
    borderRadius: Metrics.rfv(10),
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(10),
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  bottomView: {
    marginTop: Metrics.rfv(10),
    backgroundColor: Colors.creamBg,
    // paddingTop: Metrics.rfv(15),
    paddingBottom: Metrics.rfv(15),
  },
  sportText: {
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_SemiBold,
    color: Colors.black,
    marginLeft: Metrics.rfv(10),
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.drownDownBackground,
  },
  centerView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  menuContainer: {
    paddingTop: Metrics.rfv(13),
    paddingBottom: Metrics.rfv(13),
    flex: 1,
  },
});
