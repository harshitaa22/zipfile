import React from "react";
import { FlatList, Pressable, ScrollView, Text, View } from "react-native";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import Header from "../../../../../../component/HeaderComponent/index";
import TextHeaderTitle from "../../../../../../component/Text/index";
import { NAVIGATION } from "../../../../../../navigation";
import { PoliciesList } from "../../../../../../theme/dummyArray";
import { Colors, CommonStyle, Images } from "../../../../../../theme/index";
import styles from "./style";
import commonStyles from "../../../../../../theme/commonStyle";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../../utils/Localize";
import { RightUpArrow } from "../../../../../../theme/svg";
import Metrics from "../../../../../../theme/metrics";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

export default function PoliciesScreen(props: any) {
  const navigation = useNavigation();

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  // const onProfilePress = () => {
  //   navigation.navigate(NAVIGATION.PROFILE);
  // };

  const onMenuPress = (item: any) => {
    if (item?.id === 0) {
      navigation.navigate(NAVIGATION.PRIVACY_PAGE2);
    } else if (item?.id === 1) {
      navigation.navigate(NAVIGATION.PRIVACY_PAGE1);
    } else {
      navigation.navigate(NAVIGATION.PRIVACY_PAGE3);
    }
  };

  const renderItem = (item, index) => {
    return (
      <>
        <Pressable
          style={styles.menuContainer}
          onPress={() => onMenuPress(item)}
          key={index}
        >
          <View style={styles.centerView}>
            <View style={CommonStyle.alignCenterView}>
              <Text style={styles.sportText}>{item?.title}</Text>
            </View>
            <RightUpArrow width={Metrics.rfv(9)} height={Metrics.rfv(15)} />
          </View>
        </Pressable>
        <View style={styles.bottomWidth} />
      </>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.creamBg}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />

      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("Policies")}
            textStyle={styles.textStyle}
          />
          <FlatList
            contentContainerStyle={styles.bottomView}
            data={PoliciesList}
            renderItem={({ item, index }) => renderItem(item, index)}
            keyExtractor={(item, index) => index.toString()}
          />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}
