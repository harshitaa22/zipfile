import React from "react";
import {
  FlatList,
  Linking,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import Header from "../../../../../../component/HeaderComponent";
import PartnersList from "../../../../../../component/PartnersList";
import TextHeaderTitle from "../../../../../../component/Text";
import { PartnersData } from "../../../../../../theme/dummyArray";
import { Colors, Images } from "../../../../../../theme";
import { Constant } from "../../../../../../utils";
import styles from "./style";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import commonStyles from "../../../../../../theme/commonStyle";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../../utils/Localize";
import { NAVIGATION } from "../../../../../../navigation";
import GamblingComponent from "../../../../../../component/GamblingComponent";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

export default function GamblingScreen() {
  const navigation = useNavigation();

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const SiteText = (props: any) => {
    return (
      <Pressable onPress={() => Linking.openURL(props.url)}>
        <Text style={styles.siteText}>{props.children}</Text>
      </Pressable>
    );
  };

  const BoldSmallText = (props: any) => {
    return <Text style={styles.boldText}>{props.children}</Text>;
  };

  const BoldBigText = (props) => {
    return <Text style={styles.boldTitle}>{props.children}</Text>;
  };

  const onProfilePress = () => {
    navigation.navigate(NAVIGATION.PROFILE);
  };

  const renderItem = (item, index) => {
    return (
      <View style={styles.tableView}>
        <Text style={styles.sportText}>{item.title}</Text>

        <Text style={styles.emailText}>{item.email}</Text>

        <Text style={styles.numberText}>{item.number}</Text>
      </View>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          onBackPress={() => navigation.goBack()}
          isShowBack={true}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("ResponsibleGamblingCodePrint")}
            textStyle={styles.textStyle}
          />
          <BoldSmallText>{translate("ResponsibleGamblingGuide")}</BoldSmallText>
          <Text style={styles.ModifiedText}>{translate("CreatedOn")}</Text>

          <Text style={styles.ModifiedText}>{translate("YouCanComplete")}</Text>
          <SiteText url={Constant.GAMBLING_CODE}>
            {translate("GambilinSiteText")}
          </SiteText>
          <BoldBigText>{translate("ResponsibleGambling")}</BoldBigText>
          <Text style={styles.ModifiedText}>
            {translate("IndividualsMeans")}
          </Text>
          <View style={styles.sensitiveView}>
            <Text style={styles.ModifiedText}>
              {translate("IndividualText")}
            </Text>
          </View>
          <Text style={styles.ModifiedText}>
            {translate("BroaderCommunity")}
          </Text>
          <View style={styles.sensitiveView}>
            <Text style={styles.ModifiedText}>
              {translate("SharedResponsibility")}
            </Text>
          </View>
          <BoldBigText>{translate("WhatProblemGambling")}</BoldBigText>
          <Text style={styles.ModifiedText}>
            {translate("ProblemGamblingText")}
          </Text>
          <View style={styles.sensitiveView}>
            <Text style={styles.ModifiedText}>{translate("PunterText")}</Text>
          </View>

          <Text style={styles.ModifiedText}>{translate("AssistText")}</Text>
          <View style={styles.sensitiveView}>
            <Text style={styles.ModifiedText}>
              {translate("ImplementingPre")}
            </Text>
          </View>
          <Text style={styles.ModifiedText}>{translate("BelowSome")}</Text>
          <View style={styles.sensitiveView}>
            <Text style={styles.ModifiedText}>{translate("SeparateWork")}</Text>
          </View>
          <BoldBigText>{translate("ClientCarePrinciples")}</BoldBigText>
          <Text style={styles.ModifiedText}>{translate("WeConsistently")}</Text>
          <View style={styles.sensitiveView}>
            <Text style={styles.ModifiedText}>
              {translate("RequiringGambling")}
            </Text>
          </View>
          <Text style={styles.ModifiedText}>{translate("OutcomesText")}</Text>
          <View style={styles.sensitiveView}>
            <Text style={styles.ModifiedText}>{translate("WeAchieve")}</Text>
          </View>
          <BoldBigText>{translate("GamblingSelfText")}</BoldBigText>
          <Text style={styles.ModifiedText}>{translate("ConcernedAbout")}</Text>
          <BoldSmallText>{translate("TakeNow")}</BoldSmallText>
          <SiteText url={Constant.GAMBLING_URL}>
            {translate("LinkGambling")}
          </SiteText>
          <BoldBigText>{translate("SelfExclusion")}</BoldBigText>
          <Text style={styles.ModifiedText}>{translate("LosingControl")}</Text>
          <SiteText url={Constant.SELFEXICUTIONURL}>
            {translate("GovLink")}
          </SiteText>
          <View style={styles.tableTopView}>
            <FlatList
              data={eventData}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item, index }) => renderItem(item, index)}
            />
          </View>
          <BoldBigText>{translate("PreCommitment")}</BoldBigText>
          <Text style={styles.ModifiedText}>
            {translate("OurResponsibility")}
          </Text>
          <BoldBigText>{translate("GamblingHelp")}</BoldBigText>
          <Text style={styles.ModifiedText}>
            {translate("GamblingHelpline")}
          </Text>
          <SiteText url={Constant.HELP_ONLINE}>
            {translate("SiteGamblingText")}
          </SiteText>
          <SiteText url={Constant.GAMBLING_AWARE}>
            {translate("SiteHelpText")}
          </SiteText>
          <Text style={styles.ModifiedText}>
            {translate("AlternativelyText")}
          </Text>
          <BoldSmallText>{translate("SomeoneClose")}</BoldSmallText>

          <GamblingComponent
            boldTitleText={translate("GamblingOnline")}
            simpleText={translate("Counselling")}
            siteText={translate("GamblinghelpLine")}
            numberText={translate("numberGamblingHelpLine")}
            url={Constant.GAMBLINGHELPLINE}
          />
          <GamblingComponent
            boldTitleText={translate("GamblersAnonymous")}
            simpleText={translate("locationPerson")}
            siteText={translate("Gaaustralia")}
            url={Constant.GAMBLER_ANNOUNCE}
          />
          <GamblingComponent
            boldTitleText={translate("GamblingTherapy")}
            simpleText={translate("PracticalAdvise")}
            siteText={translate("GamblingtherapyText")}
            url={Constant.GORDON_MOODY}
          />
          <GamblingComponent
            boldTitleText={translate("DayChallenge")}
            simpleText={translate("AnonymousSupport")}
            siteText={translate("comAu")}
            url={Constant.DAY_CHALLENGE}
          />
          <GamblingComponent
            boldTitleText={translate("NationalDebtHelpline")}
            simpleText={translate("FreeFrom")}
            siteText={translate("NdhSite")}
            numberText={translate("numberGamblingHelpLine")}
            url={Constant.NATIONAL_DEBT}
          />
          <GamblingComponent
            boldTitleText={translate("GoodShepherd")}
            simpleText={translate("AddressingIssuesv")}
            siteText={translate("ServicesText")}
            url={Constant.GOOD_SHEPHERD}
          />
          <GamblingComponent
            boldTitleText={translate("Lifeline")}
            simpleText={translate("EmotionalDistress")}
            siteText={translate("LifeLineSite")}
            numberText={translate("NumberSite")}
            url={Constant.LIFELINEURL}
          />
          <GamblingComponent
            boldTitleText={translate("RuOk")}
            simpleText={translate("ConversationThat")}
            siteText={translate("RuOkSite")}
            url={Constant.RUOK}
          />
          <GamblingComponent
            boldTitleText={translate("BeyondBlue")}
            simpleText={translate("MentalHealth")}
            siteText={translate("BeyoundBlue")}
            numberText={translate("NumberBeyond")}
            url={Constant.BEYOND_BLUE}
          />
          <GamblingComponent
            boldTitleText={translate("RelationshipsAustralia")}
            simpleText={translate("RelationshipSupport")}
            siteText={translate("relationshipsText")}
            numberText={translate("relationNumber")}
            url={Constant.RELATION_SHIP}
          />
          <GamblingComponent
            boldTitleText={translate("RespectText")}
            simpleText={translate("SupportForPeople")}
            siteText={translate("RespectSite")}
            numberText={translate("RespectNumberSite")}
            url={Constant.RESPECT_URL}
          />
          <TextHeaderTitle
            title={translate("OurPartners")}
            textStyle={styles.ourPatnersStyle}
          />
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}

const eventData = [
  {
    id: 0,
    title: translate("Bet"),
    email: translate("SupprotCom"),
    number: translate("BetNumber"),
  },
  {
    id: 1,
    title: translate("Betfair"),
    email: translate("ServiceBetfair"),
    number: translate("BetFairNumber"),
  },
  {
    id: 2,
    title: translate("UniBet"),
    email: translate("CustomerService"),
    number: translate("UniBetNumber"),
  },
  {
    id: 3,
    title: translate("Ubet"),
    email: translate("SupportUnibet"),
    number: translate("UbetNumber"),
  },
  {
    id: 4,
    title: translate("TabCom"),
    email: translate("BetCare"),
    number: translate("TabNumber"),
  },
  {
    id: 5,
    title: translate("ClassicBet"),
    email: translate("SupportClasic"),
    number: translate("ClassicBetNumber"),
  },
  {
    id: 6,
    title: translate("Draftstars"),
    email: translate("SupportDrafts"),
    number: translate("DraftStars"),
  },
  {
    id: 7,
    title: translate("Ladbrokes"),
    email: translate("SupportLadBrokes"),
    number: translate("LadbrokesNumber"),
  },
  {
    id: 8,
    title: translate("BetEasy"),
    email: translate("SupportBetEasy"),
    number: translate("BetEasyNumber"),
  },
  {
    id: 9,
    title: translate("Sportsbet"),
    email: translate("SupportRsg"),
    number: translate("SupportBet"),
  },
];
