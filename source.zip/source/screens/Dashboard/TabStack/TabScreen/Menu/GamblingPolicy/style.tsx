import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  partnerListBottom: {
    marginBottom: Metrics.rfv(50),
  },
  text1Created: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  ModifiedText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  sportText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
    borderWidth: Metrics.rfv(0.5),
    paddingHorizontal: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(5),
    borderColor: Colors.gray,
    flex: 1,
  },
  emailText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
    flex: 1,
    borderWidth: Metrics.rfv(0.5),
    borderColor: Colors.gray,
    paddingHorizontal: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(5),
  },
  numberText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
    flex: 1,
    borderWidth: Metrics.rfv(0.5),
    paddingHorizontal: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(5),
    borderColor: Colors.gray,
  },
  tableView: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginTop: Metrics.rfv(28),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  ourPatnersStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginTop: Metrics.rfv(25),
    marginBottom: Metrics.rfv(10),
    textAlign: "center",
  },
  siteText: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
  },
  sensitiveView: {
    marginLeft: Metrics.rfv(15),
  },
  boldText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Bold,
    lineHeight: Metrics.rfv(20),
  },
  boldTitle: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
  },
  rowContainer: {
    flexDirection: "row",
    marginTop: Metrics.rfv(20),
  },
  tableTopView: {
    marginTop: Metrics.rfv(20),
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
});
