import React from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import Header from "../../../../../../component/HeaderComponent/index";
import TextHeaderTitle from "../../../../../../component/Text/index";
import { NAVIGATION } from "../../../../../../navigation";
import { HelpList } from "../../../../../../theme/dummyArray";
import { Colors, CommonStyle, Images } from "../../../../../../theme/index";
import styles from "./style";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../../utils/Localize";
import { RightUpArrow } from "../../../../../../theme/svg";
import Metrics from "../../../../../../theme/metrics";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

export default function HelpScreen(props: any) {
  const navigation = useNavigation();

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const onMenuPress = (item: any) => {
    if (item?.id === 0) {
      navigation.navigate(NAVIGATION.PRIVACY_PAGE1);
    } else {
      navigation.navigate(NAVIGATION.BOOK_MARKER_MENU);
    }
  };

  const renderItem = (item, index) => {
    return (
      <Pressable
        style={CommonStyle.commonFlex}
        onPress={() => onMenuPress(item)}
        key={index}
      >
        <View style={styles.centerView}>
          <View style={CommonStyle.alignCenterView}>
            <Text style={styles.sportText}>{item?.title}</Text>
          </View>
          <RightUpArrow width={Metrics.rfv(9)} height={Metrics.rfv(15)} />
        </View>
        <View style={styles.bottomWidth} />
      </Pressable>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent isShowSmartBIcon={true} />
      <Header
        onPressSignUp={() => onPressSignUp()}
        onPressSignIn={() => onPressSignIn()}
        isBackgroundSignUp={Colors.linearColor2}
        isBackgroundSignIn={Colors.white}
        colorUp={Colors.white}
        colorIn={Colors.linearColor2}
        sourceIcon={Images.adBannerIcon}
        isPasswordField={true}
        onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
      />
      <View style={styles.horizontalView}>
        <TextHeaderTitle
          title={translate("MenuTab")}
          textStyle={styles.textStyle}
        />
        <FlatList
          contentContainerStyle={styles.bottomView}
          data={HelpList}
          renderItem={({ item, index }) => renderItem(item, index)}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    </AppSafeAreaView>
  );
}
