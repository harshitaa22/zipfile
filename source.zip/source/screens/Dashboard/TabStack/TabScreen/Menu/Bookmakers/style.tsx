import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../../../../theme/index";

export default StyleSheet.create({
  partnerListBottom: {
    marginBottom: Metrics.rfv(50),
  },
  text1Created: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(25),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
  },
  containerCategoriesStyle: {
    paddingBottom: Metrics.rfv(25),
    marginTop: Metrics.rfv(25),
  },
  rowView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  numberView: {
    flexDirection: "row",
    alignItems: "center",
  },
  reviewText: {
    color: Colors.linearColor2,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(11),
    lineHeight: Metrics.rfv(16),
    textDecorationLine: "underline",
  },
  bookmarkerTitle: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    marginLeft: Metrics.rfv(10),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  iconStyle: {
    width: Metrics.rfv(80),
    height: Metrics.rfv(30),
    borderRadius: Metrics.rfv(5),
  },
});
