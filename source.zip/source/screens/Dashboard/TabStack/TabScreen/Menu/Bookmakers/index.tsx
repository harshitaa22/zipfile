import React, { useState } from "react";
import {
  FlatList,
  Image,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import Header from "../../../../../../component/HeaderComponent";
import TextHeaderTitle from "../../../../../../component/Text";
import {
  BlogList,
  BookmarkerData,
  bookmarkerData,
  CategoriesList,
  RecentPosts,
} from "../../../../../../theme/dummyArray";
import { Colors, Images, Metrics } from "../../../../../../theme";
import styles from "./style";
import AppSafeAreaView from "../../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../../component/AppStatusBar";
import commonStyles from "../../../../../../theme/commonStyle";
import { useNavigation } from "@react-navigation/native";
import { translate } from "../../../../../../utils/Localize";
import { NAVIGATION } from "../../../../../../navigation";
import { EmptyImg, NextIcon, PreviousIcon } from "../../../../../../theme/svg";
import Button from "../../../../../../component/Button";
import CustomTextInput from "../../../../../../component/TextInput";
import CardView from "react-native-cardview";
import CommonHeaderComponent from "../../../../../../component/CommonHeaderComponent";

const BookMarkerScreen = () => {
  const navigation = useNavigation();

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const renderbookmarkerItem = (item, index) => {
    return (
      <Pressable>
        {index == 0 ? null : <View style={commonStyles.bottomWidth} />}
        <View style={styles.rowView}>
          <View style={styles.numberView}>
            <Image source={item?.img} style={styles.iconStyle} />
            <Text style={styles.bookmarkerTitle}>{item?.title}</Text>
          </View>
          <Text style={styles.reviewText}>{item?.reView}</Text>
        </View>
      </Pressable>
    );
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          isShowBack={true}
          onBackPress={() => navigation.goBack()}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View>
          <View style={styles.horizontalView}>
            <TextHeaderTitle
              title={translate("Bookmakers")}
              textStyle={styles.textStyle}
            />

            <FlatList
              data={BookmarkerData}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.containerCategoriesStyle}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item, index }) =>
                renderbookmarkerItem(item, index)
              }
            />
          </View>
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
};

export default BookMarkerScreen;
