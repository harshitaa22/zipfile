import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";
import React from "react";
import { FlatList, Pressable, ScrollView, Text, View } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { callApi } from "../../../../../api";
import API_CONFIG from "../../../../../api/api_url";
import AppSafeAreaView from "../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../component/CommonHeaderComponent";
import Header from "../../../../../component/HeaderComponent/index";
import TextHeaderTitle from "../../../../../component/Text/index";
import { NAVIGATION } from "../../../../../navigation";
import commonStyles from "../../../../../theme/commonStyle";
import { MenuList } from "../../../../../theme/dummyArray";
import { Colors, CommonStyle, Images } from "../../../../../theme/index";
import Metrics from "../../../../../theme/metrics";
import { RightUpArrow } from "../../../../../theme/svg";
import { Constant } from "../../../../../utils";
import { translate } from "../../../../../utils/Localize";
import { print_data } from "../../../../../utils/Logs";
import styles from "./style";

export default function MenuTab(props: any) {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  // useEffect(() => {
  //   BackHandler.addEventListener("hardwareBackPress", handleBackButtonClick);
  //   return () => {
  //     BackHandler.removeEventListener(
  //       "hardwareBackPress",
  //       handleBackButtonClick
  //     );
  //   };
  // }, []);

  let userToken = useSelector(
    (state: any) => state.UserDataReducer.is_token_saved
  );
  let saveToken = JSON.parse(userToken);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };
  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  // const handleBackButtonClick = () => {
  //   navigation.navigate(NAVIGATION.MENU_TAB);
  //   return true;
  // };

  // const onProfilePress = () => {
  //   navigation.navigate(NAVIGATION.PROFILE);
  // };

  const onMenuPress = (item: any) => {
    if (item?.id === 0) {
      if (saveToken) {
        callProfileAPi();
      } else {
        navigation.navigate(NAVIGATION.LOGIN);
      }
    } else if (item?.id == 4) {
      navigation.navigate(NAVIGATION.TRACK_PROFILES);
    }
    //  else if (item?.id === 1) {
    //   navigation.navigate(NAVIGATION.PRIVACY_PAGE2);
    // } else if (item?.id === 2) {
    //   navigation.navigate(NAVIGATION.PRIVACY_PAGE2);
    // } else if (item?.id === 3) {
    //   navigation.navigate(NAVIGATION.QUICK_LINKS);
    // } else if (item?.id === 4) {
    //   navigation.navigate(NAVIGATION.STASTICS);
    // } else if (item?.id === 5) {
    //   navigation.navigate(NAVIGATION.HELP);
    // }
    else {
      navigation.navigate(NAVIGATION.POLICIES);
    }
    return true;
  };

  const renderItem = (item: any, index: any) => {
    return (
      <>
        <Pressable
          style={styles.menuContainer}
          onPress={() => {
            onMenuPress(item);
          }}
          key={index}
        >
          <View style={styles.centerView}>
            <View style={CommonStyle.alignCenterView}>
              <View>{item?.iconImage}</View>
              <Text style={styles.sportText}>{item?.title}</Text>
            </View>
            <RightUpArrow width={Metrics.rfv(9)} height={Metrics.rfv(15)} />
          </View>
        </Pressable>
        <View style={styles.bottomWidth} />
      </>
    );
  };

  const clearAndNavigate = async () => {
    try {
      dispatch({
        type: Constant.SAVE_TOKEN,
        payload: null,
      });
    } catch (e) {
      print_data(e);
    }
    try {
      await AsyncStorage.clear();
    } catch (e) {}

    setTimeout(() => {
      navigation.navigate(NAVIGATION.LOGIN);
    }, 10);
  };

  const callProfileAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.POFILE,
        null,
        API_CONFIG.GET,
        saveToken?.token
      );
      print_data(response);
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          if (response?.body?.data?.data?.status == "active") {
            navigation.navigate(NAVIGATION.PROFILE);
          } else {
            navigation.navigate(NAVIGATION.LOGIN);
          }
        } else {
          if (response?.body?.status == 404) {
            clearAndNavigate();
          } else {
            navigation.navigate(NAVIGATION.LOGIN);
          }

          // setIsLoaderVisible(false);
        }
      } else {
        navigation.navigate(NAVIGATION.LOGIN);
      }
    } catch (error) {
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.creamBg}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent isShowSmartBIcon={true} />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          showBannerIcon={true}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("MenuTab")}
            textStyle={styles.textStyle}
          />
          <FlatList
            contentContainerStyle={styles.bottomView}
            data={MenuList}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => renderItem(item, index)}
            keyExtractor={(item, index) => index.toString()}
          />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}
