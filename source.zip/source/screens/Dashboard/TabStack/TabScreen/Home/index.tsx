import { useNavigation } from "@react-navigation/native";
import moment, { utc } from "moment";
import React, { useEffect, useState } from "react";
import Countdown from "react-countdown";
import {
  FlatList,
  Image,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
} from "react-native";
import CardView from "react-native-cardview";
//component
import AppSafeAreaView from "../../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../../component/AppStatusBar";
import CommonHeaderComponent from "../../../../../component/CommonHeaderComponent";
import Header from "../../../../../component/HeaderComponent";
import ImageLoad from "../../../../../component/ImageLoad";
import PartnersList from "../../../../../component/PartnersList";
import Loader from "../../../../../component/ProgressBar";
import TextHeaderTitle from "../../../../../component/Text/index";
//theme
import { Colors, Images } from "../../../../../theme";
import commonStyles from "../../../../../theme/commonStyle";
//utils
import { showToast } from "../../../../../utils/commonFunction";
import { translate } from "../../../../../utils/Localize";
import { print_data } from "../../../../../utils/Logs";
//style
import styles from "./style";
//navigation
import { NAVIGATION } from "../../../../../navigation";
//api
import { callApi } from "../../../../../api";
import API_CONFIG from "../../../../../api/api_url";
//env
import { useDispatch } from "react-redux";
import { API_URL } from "../../../../../../env.json";
import { Constant } from "../../../../../utils";

export default function HomeTab() {
  const navigation = useNavigation();
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const dispatch = useDispatch();
  const [getUTCDate] = useState(new Date());
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [sportLoaderVisible, setSportLoaderVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [eventData, setEventData] = useState([]);
  const [greyhoundsData, setGreyHoundsData] = useState([]);
  const [harness, setHarness] = useState([]);
  const [cricketData, setCricketData] = useState([]);
  const [rugbyLeague, setRugbyLeague] = useState([]);
  const [rugbyUnion, setRugbyUnion] = useState([]);
  const [nbaData, setNbaData] = useState([]);
  const [boxingData, setBoxingData] = useState([]);
  const [mixedMaterialData, setMixedMaterialData] = useState([]);
  const [soccerData, setSoccerData] = useState([]);
  const [americanFootballData, setAmericanFootballData] = useState([]);
  const [austrilanRulesData, setAustrilanRulesData] = useState([]);
  const [baseBall, setBaseBall] = useState([]);
  const [tennisData, setTennisData] = useState([]);
  const [iceHockeyData, setIceHockeyData] = useState([]);
  const [apicalling, setApiCalling] = useState(true);

  useEffect(() => {
    saveSportData(apicalling);
    fetchMultipleData();
    setSportLoaderVisible(true);
    setIsLoaderVisible(true);
    callRacingAPi();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    saveSportData(true);
    callRacingAPi();
    fetchMultipleData();
  };

  const onHorseItemPress = (item: any) => {
    navigation.navigate(NAVIGATION.SINGLE_RACE_PAGE, {
      sportId: item?.sportId,
      id: item?.id,
      trackId: item?.event?.trackId,
      eventId: item?.eventId,
      startTimeDate: item?.startTimeDate,
      intl:
        item?.event?.track?.countryId === 13 ||
        item?.event?.track?.countryId === 157
          ? false
          : true,
    });
  };

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const fetchMultipleData = async () => {
    Promise.all([
      await callApi(
        `public/afl/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&AFLTournamentId=&teamId=&timezone=${timezone}&SportId=15&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/ar/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&ARTournamentId=&teamId=&timezone=${timezone}&SportId=9&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/baseball/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&BaseballTournamentId=&teamId=&timezone=${timezone}&SportId=11&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/nba/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&NBATournamentId=&teamId=&timezone=${timezone}&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/boxing/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&BoxingTournamentId=&teamId=&timezone=${timezone}&SportId=6&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/crickets/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&CricketTournamentId=&teamId=&timezone=${timezone}&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/icehockey/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&IceHockeyTournamentId=&teamId=&timezone=${timezone}&SportId=17&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/mma/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&MMATournamentId=&teamId=&timezone=${timezone}&SportId=5&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/rls/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&RLTournamentId=&teamId=&timezone=${timezone}&SportId=12&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/rls/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&RLTournamentId=&teamId=&timezone=${timezone}&SportId=13&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/soccer/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&SoccerTournamentId=&teamId=&timezone=${timezone}&SportId=8&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
      await callApi(
        `public/tennis/event?startDate=${moment(getUTCDate).format(
          "YYYY-MM-DD"
        )}&endDate=&TennisTournamentId=&teamId=&timezone=${timezone}&SportId=7&oddCheck=true&marketId=1&limit=5&liveOdd=true`,
        null,
        API_CONFIG.GET,
        null
      ),
    ])
      .then(function (data) {
        let response = data;
        setApiCalling(false);
        setAmericanFootballData(
          response[0]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setAustrilanRulesData(
          response[1]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setBaseBall(
          response[2]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setNbaData(
          response[3]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setBoxingData(
          response[4]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setCricketData(
          response[5]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setIceHockeyData(
          response[6]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setMixedMaterialData(
          response[7]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setRugbyLeague(
          response[8]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setRugbyUnion(
          response[9]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setSoccerData(
          response[10]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setTennisData(
          response[11]?.body?.data?.result?.rows
            ?.sort((a: any, b: any) =>
              moment(a?.startTime).diff(moment(b?.startTime))
            )
            ?.slice(0, 5)
        );
        setSportLoaderVisible(false);

        let count = [];
        response?.map((item) => count?.push(item?.body?.data?.result?.count));
        saveSportData(count);
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  const listHeader = () => {
    return (
      <Text style={styles.noRaceText}>{translate("NoRaceAvailable")}</Text>
    );
  };
  const listSportHeader = () => {
    return (
      <Text style={styles.noRaceText}>{translate("NoMatchAvailable")}</Text>
    );
  };

  const saveSportData = async (response) => {
    try {
      const customData = {
        americalFootball: response[0],
        ausRules: response[1],
        baseBall: response[2],
        basketball: response[3],
        boxing: response[4],
        cricket: response[5],
        iceHockey: response[6],
        mma: response[7],
        rugbyLeague: response[8],
        rugbyUnion: response[9],
        soccer: response[10],
        tennis: response[11],
      };
      dispatch({
        type: Constant.SAVE_SPORT_DATA,
        payload: response == true ? true : customData,
      });
      print_data(customData);
    } catch (e) {
      print_data("========exception in login data save=========" + e);
    }
  };

  const fetchTeamlogo = (item: any, type: any) => {
    if (type === "hometeam") {
      if (item?.homeTeam) {
        let TeamLogo = item?.homeTeam?.flag?.includes("uploads") ? (
          <ImageLoad
            source={API_URL + "/" + item?.homeTeam?.flag}
            style={styles.imageCommonLeftStyle}
            resizeMode={"contain"}
          />
        ) : (
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.brisbaneLionsIcon}
          />
        );
        return TeamLogo;
      } else {
        return (
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.brisbaneLionsIcon}
          />
        );
      }
    } else {
      if (item?.awayTeam) {
        let TeamLogo = item?.awayTeam?.flag?.includes("uploads") ? (
          <ImageLoad
            source={API_URL + "/" + item?.awayTeam?.flag}
            style={styles.imageCommonLeftStyle}
            resizeMode={"contain"}
          />
        ) : (
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.melbourne}
          />
        );
        return TeamLogo;
      } else {
        return (
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.melbourne}
          />
        );
      }
    }
  };

  const renderItem = (item: any, index: any, imageType: any) => {
    const startTimeDate = utc(item?.startTimeDate);
    const renderer = ({ days, hours, minutes, seconds }) => {
      return (
        <View
          style={
            hours === 0 && minutes < 5
              ? styles.timeButtonStyle
              : styles.timeStyle
          }
        >
          <Text style={styles.textMinStyle}>
            {days > 0 ? days + "d" : ""}{" "}
            {days > 0
              ? hours + "h"
              : hours > 0
              ? hours + "h"
              : days === 0 && minutes <= 5
              ? ""
              : ""}{" "}
            {minutes > 0 ? minutes + "m" : "0m"}{" "}
            {hours === 0 && minutes <= 5
              ? seconds > 0
                ? seconds + "s"
                : "0s"
              : ""}
          </Text>
        </View>
      );
    };
    return (
      <Pressable onPress={() => onHorseItemPress(item)}>
        {index == 0 ? null : <View style={styles.bottomWidth} />}
        <View style={styles.renderListStyle}>
          <Image
            style={styles.imageStyle}
            source={
              imageType == 1
                ? Images.racingIcon
                : imageType == 2
                ? Images.houndsIcon
                : imageType == 3
                ? Images.harnessIcon
                : Images.racingIcon
            }
          />
          <Text style={styles.textRacingStyle}>
            R{item?.raceNumber + " " + item.event.eventName}
          </Text>
          <View style={styles.timeStyle}>
            <Countdown
              date={startTimeDate.toString()}
              renderer={renderer}
              onComplete={() => {
                setTimeout(() => {
                  setIsLoaderVisible(true);
                  callRacingAPi();
                }, 100);
              }}
            />
          </View>
        </View>
      </Pressable>
    );
  };

  const sportRenderItem = (item: any, index: any, imageType: any) => {
    return (
      <Pressable
        key={imageType}
        onPress={() => {
          navigation.navigate(NAVIGATION.SPORT_PAGE, {
            // screen: NAVIGATION.SPORT_PAGE,
            // params: {
            //   sportData: {
            //     title: item?.Sport?.sportName,
            //   },
            // },
            sportId: 1,
            individualTeamdata: true,
            sportItem: item,
            title: item?.Sport?.sportName,
            isSeeAll: true,
          });
        }}
      >
        {index == 0 ? null : <View style={styles.bottomSportWidth} />}
        <View style={commonStyles.centerView}>
          <View style={styles.eventTitleContainer}>
            <Text style={styles.eventNameText} numberOfLines={1}>
              {item?.AFLTournament
                ? item?.AFLTournament?.name
                : item?.ARTournament
                ? item?.ARTournament?.name
                : item?.NBATournament
                ? item?.NBATournament?.name
                : item?.CricketTournament
                ? item?.CricketTournament?.name
                : item?.BoxingTournament
                ? item?.BoxingTournament?.name
                : item?.MMATournament
                ? item?.MMATournament?.name
                : item?.RLTournament
                ? item?.RLTournament?.name
                : item?.SoccerTournament
                ? item?.SoccerTournament?.name
                : item?.IceHockeyTournament
                ? item?.IceHockeyTournament?.name
                : item?.BaseballTournament
                ? item?.BaseballTournament?.name
                : item?.TennisTournament
                ? item?.TennisTournament?.name
                : item?.NBATournament?.name}
            </Text>
          </View>
          <View style={commonStyles.commonFlex} />
        </View>
        <Text style={styles.eventName}>{item?.eventName}</Text>
        <View style={styles.centerView}>
          <View style={commonStyles.alignCenterView}>
            <View>{fetchTeamlogo(item, "hometeam")}</View>
            <Text style={styles.vsText}> {translate("VsBackSplash")} </Text>
            <View>{fetchTeamlogo(item, "awayteam")}</View>
          </View>
          <View style={styles.centerTextView}>
            <Text style={styles.dateText}>
              {moment.utc(item?.startTime).local().format("DD/MM/YYYY")}
            </Text>
            <Text style={styles.startTimeStyle}>
              {moment.utc(item?.startTime).local().format("hh:mma")}
            </Text>
          </View>
        </View>
      </Pressable>
    );
  };

  const callRacingAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_HORSES_RACING,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setEventData(response?.body?.data?.data?.races[1]);
          setGreyHoundsData(response?.body?.data?.data?.races[2]);
          setHarness(response?.body?.data?.data?.races[3]);
          setIsLoaderVisible(false);
          setRefreshing(false);
        } else {
          setIsLoaderVisible(false);
          setRefreshing(false);
        }
      } else {
        setIsLoaderVisible(false);
        setRefreshing(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setRefreshing(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception===callRacingAPi==" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent isShowSmartBIcon={true} />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          pageId={1}
          isshowSmartBitle={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        {/* <View style={styles.seconBannerStyle}>
          <AddsCommonList
            AfterHeader={"AfterHeader"}
            page={1}
            placeholder={Images.sportFirstImg}
            bannerStyle={styles.secondBannerStyle}
          />
        </View> */}
        <View style={styles.horizontalView}>
          <TextHeaderTitle
            title={translate("Racing")}
            textStyle={styles.textStyle}
          />
          <View style={styles.listTitle}>
            <Text style={styles.nextTopicTextStyle}>
              {translate("NextToJumpHorses")}
            </Text>
            <Pressable
              onPress={() =>
                navigation.navigate(NAVIGATION.RACING_TAB, {
                  screen: NAVIGATION.SEE_ALL_PAGE,
                  params: {
                    sportId: eventData?.length > 0 ? eventData[0]?.sportId : 1,
                  },
                })
              }
            >
              <Text style={styles.seeAllStyle}>{translate("SeeAll")}</Text>
            </Pressable>
          </View>
          <CardView
            style={styles.boxWithShadow}
            cardElevation={5}
            cardMaxElevation={4}
            cornerRadius={7}
          >
            {isLoadervisible ? (
              <View style={styles.loaderContainer}>
                <View style={commonStyles.loader}>
                  <Loader size={"small"} />
                </View>
              </View>
            ) : (
              <FlatList
                data={eventData}
                scrollEnabled={false}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => renderItem(item, index, 1)}
                ListEmptyComponent={() => listHeader()}
              />
            )}
          </CardView>
          <View style={styles.listTitle}>
            <Text style={styles.nextTopicTextStyle}>
              {translate("NextToJumpGreyhounds")}
            </Text>
            <Pressable
              onPress={() =>
                navigation.navigate(NAVIGATION.RACING_TAB, {
                  screen: NAVIGATION.SEE_ALL_PAGE,
                  params: {
                    sportId: harness?.length > 0 ? harness[0]?.sportId : 3,
                  },
                })
              }
            >
              <Text style={styles.seeAllStyle}>{translate("SeeAll")}</Text>
            </Pressable>
          </View>
          <CardView
            style={styles.boxWithShadow}
            cardElevation={5}
            cardMaxElevation={4}
            cornerRadius={7}
          >
            {isLoadervisible ? (
              <View style={styles.loaderContainer}>
                <View style={commonStyles.loader}>
                  <Loader size={"small"} />
                </View>
              </View>
            ) : (
              <FlatList
                data={harness}
                scrollEnabled={false}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => renderItem(item, index, 2)}
                ListEmptyComponent={() => listHeader()}
              />
            )}
          </CardView>
          <View style={styles.listTitle}>
            <Text style={styles.nextTopicTextStyle}>
              {translate("NextToJumpHarness")}
            </Text>
            <Pressable
              onPress={() =>
                navigation.navigate(NAVIGATION.RACING_TAB, {
                  screen: NAVIGATION.SEE_ALL_PAGE,
                  params: {
                    sportId:
                      greyhoundsData?.length > 0
                        ? greyhoundsData[0]?.sportId
                        : 2,
                  },
                })
              }
            >
              <Text style={styles.seeAllStyle}>{translate("SeeAll")}</Text>
            </Pressable>
          </View>
          <CardView
            style={styles.boxWithShadow}
            cardElevation={5}
            cardMaxElevation={4}
            cornerRadius={7}
          >
            {isLoadervisible ? (
              <View style={styles.loaderContainer}>
                <View style={commonStyles.loader}>
                  <Loader size={"small"} />
                </View>
              </View>
            ) : (
              <FlatList
                data={greyhoundsData}
                scrollEnabled={false}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => renderItem(item, index, 3)}
                ListEmptyComponent={() => listHeader()}
              />
            )}
          </CardView>
          {/* <AddsCommonList
            BeforeSports={"BeforeSports"}
            page={1}
            placeholder={Images.sportFirstImg}
            bannerStyle={styles.secondBannerStyle}
          /> */}
          <TextHeaderTitle
            title={translate("Sports")}
            textStyle={styles.sportStyle}
          />
          {nbaData?.length > 0 ||
          cricketData?.length > 0 ||
          rugbyLeague?.length > 0 ||
          rugbyUnion?.length > 0 ||
          austrilanRulesData?.length > 0 ||
          baseBall?.length > 0 ||
          americanFootballData?.length > 0 ||
          boxingData?.length > 0 ||
          mixedMaterialData?.length > 0 ||
          soccerData?.length > 0 ||
          tennisData?.length > 0 ? (
            <>
              {americanFootballData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingAmericanFootball")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("AmericanFootball"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={americanFootballData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 1)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {austrilanRulesData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingAustralianRules")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("australianRules"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={austrilanRulesData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 2)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {baseBall?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingBaseball")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("Baseball"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={baseBall}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 3)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {nbaData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingBasketball")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("BasketballMenu"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={nbaData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 4)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {boxingData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingBoxing")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("Boxing"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={boxingData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 5)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {cricketData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingMatchesCricket")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("Cricket"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={cricketData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 7)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {iceHockeyData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingIceHockey")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("SportIceHockey"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={iceHockeyData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 6)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {mixedMaterialData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingMixedMartial")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("MixedArts"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={mixedMaterialData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 8)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {rugbyLeague?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingRugbyLeague")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("RugbyLeague"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={rugbyLeague}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 9)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {rugbyUnion?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingRugbyUnion")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("RugbyUnion"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={rugbyUnion}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 10)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {soccerData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingSoccer")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("Soccer"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={soccerData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 11)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
              {tennisData?.length > 0 && (
                <>
                  <View style={styles.listTitle}>
                    <Text style={styles.nextTopicTextStyle}>
                      {translate("UpcomingTennis")}
                    </Text>
                    <Pressable
                      onPress={() =>
                        navigation.navigate(NAVIGATION.SPORTS_TAB, {
                          screen: NAVIGATION.SPORT_PAGE,
                          params: {
                            sportData: {
                              title: translate("Tennis"),
                            },
                          },
                        })
                      }
                    >
                      <Text style={styles.seeAllStyle}>
                        {translate("SeeAll")}
                      </Text>
                    </Pressable>
                  </View>
                  <CardView
                    style={styles.boxWithShadow}
                    cardElevation={5}
                    cardMaxElevation={4}
                    cornerRadius={7}
                  >
                    {sportLoaderVisible ? (
                      <View style={styles.loaderContainer}>
                        <View style={commonStyles.loader}>
                          <Loader size={"small"} />
                        </View>
                      </View>
                    ) : (
                      <FlatList
                        data={tennisData}
                        scrollEnabled={false}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) =>
                          sportRenderItem(item, index, 12)
                        }
                        ListEmptyComponent={() => listSportHeader()}
                      />
                    )}
                  </CardView>
                </>
              )}
            </>
          ) : (
            <Text style={styles.noMatchAvailbleText}>
              {translate("NoMatchAvailable")}
            </Text>
          )}
          <View style={styles.textCenter}>
            <TextHeaderTitle
              title={translate("OurPartners")}
              textStyle={styles.sportStyle}
            />
          </View>
        </View>
        <View style={styles.partnerListBottom}>
          <PartnersList />
        </View>
      </ScrollView>
    </AppSafeAreaView>
  );
}
