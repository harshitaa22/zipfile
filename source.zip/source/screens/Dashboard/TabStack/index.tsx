import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import React from "react";
import { View } from "react-native";
import { NAVIGATION } from "../../../navigation";
import {
  HomeStack,
  MenuStack,
  NewsStack,
  RacingStack,
  SportStack,
} from "../../../route/stack";
import { Metrics } from "../../../theme/index";
import {
  HomeBlueIcon,
  HomeGrayIcon,
  MenuBlueIcon,
  MenuGrayIcon,
  NewsBlueIcon,
  NewsGrayIcon,
  RacingBlueIcon,
  RacingGrayIcon,
  SportsBlueIcon,
  SportsGrayIcon,
} from "../../../theme/svg";

import styles from "./style";
import Colors from "../../../theme/colors";
import { translate } from "../../../utils/Localize";

type Props = {
  loading?: boolean;
  navigation?: any;
};

const Tab = createBottomTabNavigator();

export default function BottomPage(props: Props) {
  return (
    <View style={styles.tabContainerStyle}>
      <Tab.Navigator
        // tabBarOptions={{
        //   activeTintColor: Colors.linearColor2,
        //   inactiveTintColor: Colors.gray,
        // }}
        initialRouteName={NAVIGATION.HOME_TAB}
        screenOptions={{
          tabBarActiveTintColor: Colors.orangeTabTextClr,
          tabBarInactiveTintColor: Colors.gray,
          headerShown: false,
          tabBarHideOnKeyboard: true,
          tabBarStyle: styles.tabHeight,
        }}
      >
        <Tab.Screen
          name={NAVIGATION.HOME_TAB}
          component={HomeStack}
          options={{
            tabBarShowLabel: true,

            tabBarLabel: translate("HomeTab"),
            // gestureEnabled: false,
            tabBarLabelStyle: styles.labelStyle,

            tabBarIcon: ({ focused }) =>
              focused ? (
                <HomeBlueIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ) : (
                <HomeGrayIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ),
          }}
        />
        <Tab.Screen
          name={NAVIGATION.RACING_TAB}
          component={RacingStack}
          options={{
            tabBarShowLabel: true,
            tabBarLabel: translate("RacingTab"),
            tabBarLabelStyle: styles.labelStyle,

            // gestureEnabled: false,

            tabBarIcon: ({ focused }) =>
              focused ? (
                <RacingBlueIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ) : (
                <RacingGrayIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ),
          }}
        />
        <Tab.Screen
          name={NAVIGATION.SPORTS_TAB}
          component={SportStack}
          options={{
            tabBarShowLabel: true,
            // unmountOnBlur: true,
            tabBarLabel: translate("SportsTab"),
            tabBarLabelStyle: styles.labelStyle,
            // gestureEnabled: false,
            tabBarIcon: ({ focused }) =>
              focused ? (
                <SportsBlueIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ) : (
                <SportsGrayIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ),
          }}
        />
        <Tab.Screen
          name={NAVIGATION.NEWS_TAB}
          component={NewsStack}
          options={{
            tabBarShowLabel: true,
            tabBarLabel: translate("NewsTab"),
            // gestureEnabled: false,
            tabBarLabelStyle: styles.labelStyle,
            tabBarIcon: ({ focused }) =>
              focused ? (
                <NewsBlueIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ) : (
                <NewsGrayIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ),
          }}
        />
        <Tab.Screen
          name={NAVIGATION.MENU_TAB}
          component={MenuStack}
          options={{
            tabBarShowLabel: true,
            tabBarLabel: translate("MenuTab"),
            // gestureEnabled: false,
            tabBarLabelStyle: styles.labelStyle,
            tabBarIcon: ({ focused }) =>
              focused ? (
                <MenuBlueIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ) : (
                <MenuGrayIcon
                  width={Metrics.rfv(22)}
                  height={Metrics.rfv(22)}
                />
              ),
          }}
        />
      </Tab.Navigator>
    </View>
  );
}
