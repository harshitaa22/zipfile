import { Platform, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../../theme/index";

export default StyleSheet.create({
  tabBarStyle: {
    height: Platform.OS === "android" ? Metrics.rfv(55) : Metrics.rfv(80),
  },
  tabBarLabelStyle: {
    fontSize: Metrics.rfv(12),
    marginBottom: Metrics.rfv(5),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
  },
  tabContainerStyle: {
    flex: 1,
    width: "100%",
    backgroundColor: Colors.transparent,
  },
  tabHeight: {
    width: "100%",
    height: Platform.OS === "ios" ? Metrics.rfv(80) : Metrics.rfv(60),
    borderTopWidth: 2,
    elevation: Metrics.rfv(10),
    paddingTop: Platform.OS === "ios" ? Metrics.rfv(5) : Metrics.rfv(5),
    paddingBottom: Platform.OS === "ios" ? Metrics.rfv(30) : Metrics.rfv(10),
    backgroundColor: Colors.cream,
  },
  labelStyle: {
    textAlignVertical: "center",
    fontSize: Metrics.rfv(9),
    lineHeight: Metrics.rfv(11),
    width: "100%",
    fontFamily: Fonts.IN_Regular,
  },
});
