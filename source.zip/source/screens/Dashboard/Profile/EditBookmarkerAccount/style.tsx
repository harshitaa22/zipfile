import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../../../theme/index";

export default StyleSheet.create({
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(20),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  profileText: {
    color: Colors.black,
    fontSize: Metrics.rfv(25),
    lineHeight: Metrics.rfv(28),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(10),
  },
  editUserDetails: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    textDecorationLine: "underline",
    marginBottom: Metrics.rfv(10),
  },
  addBookmarkerText: {
    color: Colors.red,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    marginTop: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
  },
  bookMarkTextStyle: {
    color: Colors.notSelectedColor,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
  },
  selectedBookMarkTextStyle: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    textAlign: "center",
  },
  selectItem: {
    borderRadius: Metrics.rfv(20),

    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.lightblue,

    paddingHorizontal: Metrics.rfv(15),
    height: Metrics.rfv(37),
  },
  notSelectItem: {
    borderRadius: Metrics.rfv(20),
    backgroundColor: Colors.stepColor,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    paddingHorizontal: Metrics.rfv(15),
    height: Metrics.rfv(37),
  },
  otherwidth: {
    marginLeft: Metrics.rfv(8),
  },
  inputStyle: {
    flex: 1,
    padding: 0,
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  flex: {
    flex: 1,
  },
  textInputStyle: {
    height: Metrics.rfv(25),
    backgroundColor: Colors.white,
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    width: Metrics.rfv(100),
    padding: 0,
  },
  renderListStyle: {
    marginRight: Metrics.rfv(6),
    marginTop: Metrics.rfv(10),
  },
  inputTextContainerStyle: {
    width: "100%",
  },
  commonRow: {
    marginHorizontal: Metrics.rfv(15),
    flexDirection: "row",
    alignItems: "flex-end",
    marginBottom: Metrics.rfv(25),
    flex: 1,
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  sucessViewStyle: {
    paddingVertical: Metrics.rfv(5),
    backgroundColor: Colors.green,
    marginHorizontal: Metrics.rfv(15),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(20),
  },
  sucessText: {
    color: Colors.white,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    marginLeft: Metrics.rfv(10),
  },
  sucessIcon: {
    height: Metrics.rfv(19),
    width: Metrics.rfv(19),
  },
});
