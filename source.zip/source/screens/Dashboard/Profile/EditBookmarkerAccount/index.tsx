import {
  View,
  Text,
  ScrollView,
  FlatList,
  Pressable,
  Image,
  Platform,
} from "react-native";
import React, { useEffect, useState } from "react";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import { Colors, CommonStyle, Images, Metrics } from "../../../../theme";
import AppStatusBar from "../../../../component/AppStatusBar";
import Header from "../../../../component/HeaderComponent";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../../../navigation";
import commonStyles from "../../../../theme/commonStyle";
import Loader from "../../../../component/ProgressBar";
import styles from "./style";
import { translate } from "../../../../utils/Localize";
import CustomTextInput from "../../../../component/TextInput";
import { BookMarkData } from "../../../../theme/dummyArray";
import Button from "../../../../component/Button";
import KeyboardSpacer from "react-native-keyboard-spacer";
import { print_data } from "../../../../utils/Logs";
import API_CONFIG from "../../../../api/api_url";
import { callApi } from "../../../../api";
import { showToast } from "../../../../utils/commonFunction";
import { useSelector } from "react-redux";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";

const EditBookMarkerAccount = (props: any) => {
  const { userDetails, refreshUserData } = props?.route?.params;
  const navigation = useNavigation();
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [addbookMarker, setAddbookMarker] = useState(
    userDetails?.bookMakerOther[0]
  );
  const [data, setData] = useState([]);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [sucessVisible, setSucessVisible] = useState(false);
  const [otherSelectedVisible, setOtherSelectedVisible] = useState(false);
  const [otherSelected, setOtherSelected] = useState(false);

  let userToken = useSelector(
    (state: any) => state.UserDataReducer.is_token_saved
  );
  let saveToken = JSON.parse(userToken);

  useEffect(() => {
    let bookmarkerData = [...BookMarkData];
    bookmarkerData.forEach((item, _index) => {
      if (
        userDetails?.bookMaker.includes(item?.textBookMark) ||
        userDetails?.bookMakerOther.includes(item?.textBookMark)
      ) {
        item.isSelected = true;
      } else {
        item.isSelected = false;
      }
    });
    setData(bookmarkerData);
    setDataUpdated(!dataUpdated);
  }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const onPressBack = () => {
    navigation.goBack();
  };

  const itemSelected = (item: any, index: any) => {
    let temp = [...data];
    temp[index].isSelected = !item.isSelected;
    setData(temp);
    if (
      item?.isSelected == false &&
      item.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setAddbookMarker("");
      setOtherSelected(false);
      setOtherSelectedVisible(false);
    } else if (
      item?.isSelected == true &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setOtherSelected(true);
    }
  };

  const onSavePress = () => {
    if (otherSelected) {
      if (addbookMarker?.length > 0) {
        setOtherSelectedVisible(false);
        const bookMarkData = BookMarkData.filter((item) => {
          return item.isSelected;
        });

        let bookMakersData = [];

        bookMarkData.map((item, index) => {
          let data = item?.textBookMark;
          bookMakersData.push(data);
        });
        userDetails.bookMaker = bookMakersData;
        userDetails.bookMakerOther =
          addbookMarker?.length > 0 ? [addbookMarker] : [];

        setIsLoaderVisible(true);

        calleditProfileApi();
      } else {
        setOtherSelectedVisible(true);
      }
    } else {
      const bookMarkData = BookMarkData.filter((item) => {
        return item.isSelected;
      });

      let bookMakersData = [];

      bookMarkData.map((item, index) => {
        let data = item?.textBookMark;
        bookMakersData.push(data);
      });
      userDetails.bookMaker = bookMakersData;
      userDetails.bookMakerOther =
        addbookMarker?.length > 0 ? [addbookMarker] : [];

      setIsLoaderVisible(true);

      calleditProfileApi();
    }
  };
  const redirectToProfile = () => {
    setSucessVisible(true);
    setTimeout(() => {
      refreshUserData(userDetails);
      navigation.navigate(NAVIGATION.PROFILE);
    }, 2000);
  };

  const renderItem = (item: any, index: any) => {
    return (
      <View key={index}>
        <View style={styles.renderListStyle}>
          <Pressable
            onPress={() => itemSelected(item, index)}
            style={!item.isSelected ? styles.selectItem : styles.notSelectItem}
          >
            <Text
              style={
                !item.isSelected
                  ? styles.bookMarkTextStyle
                  : styles.selectedBookMarkTextStyle
              }
            >
              {item.textBookMark}
            </Text>
            {item.textBookMark == translate("OtherPleaseSpecify") &&
            item?.isSelected == true ? (
              <View style={styles.otherwidth}>
                <CustomTextInput
                  textInputStyle={styles.inputStyle}
                  containerStyle={styles.inputTextContainerStyle}
                  lableTextStyle={commonStyles.labelTextStyle}
                  inputTextStyle={styles.textInputStyle}
                  value={addbookMarker}
                  onChangeText={(text: string) => {
                    setAddbookMarker(text);
                  }}
                />
              </View>
            ) : null}
          </Pressable>
        </View>
        {item.textBookMark == translate("OtherPleaseSpecify") &&
        item?.isSelected == true ? (
          <>
            {otherSelectedVisible && (
              <Text style={styles.addBookmarkerText}>
                {translate("AddBookmarker")}
              </Text>
            )}
          </>
        ) : null}
      </View>
    );
  };

  const calleditProfileApi = async () => {
    try {
      var param_data = {
        sportOrEvent: userDetails?.sportOrEvent,
        offerings: userDetails?.offerings,
        offeringsOther: userDetails?.offeringsOther,
        sportOrEventOther: userDetails?.sportOrEventOther,
        bookMaker: userDetails?.bookMaker ? userDetails?.bookMaker : "",
        bookMakersOther: userDetails?.bookMaker?.includes(
          translate("OtherPleaseSpecify")
        )
          ? userDetails?.bookMakerOther
            ? userDetails?.bookMakerOther
            : []
          : [],
      };
      const response = await callApi(
        API_CONFIG.EDIT_PROFILE,
        param_data,
        API_CONFIG.PUT,
        saveToken?.token
      );

      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.success == true
        ) {
          redirectToProfile();
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <Text style={styles.profileText}>{translate("EditProfile")}</Text>
          <Text style={styles.editUserDetails}>
            {translate("EditBookmakerAccountsTitle")}
          </Text>
          <FlatList
            data={data}
            numColumns={2}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => renderItem(item, index)}
            keyExtractor={(item, index) => index.toString()}
            extraData={dataUpdated}
          />
        </View>
        {sucessVisible ? (
          <View style={styles.sucessViewStyle}>
            <Image
              style={styles.sucessIcon}
              source={Images.profileSucessIcon}
            />
            <Text style={styles.sucessText}>
              {translate("SavedSuccessfully")}
            </Text>
          </View>
        ) : null}

        <View style={styles.commonRow}>
          <View style={commonStyles.commonFlex}>
            <Button
              disabled={false}
              onPress={() => onPressBack()}
              title={translate("Cancel")}
              borderColor={Colors.linearColor2}
              color={Colors.linearColor2}
              fontSize={Metrics.rfv(14)}
              backgroundColor={Colors.white}
            />
          </View>
          <View style={styles.gapViewStyle} />
          <View style={commonStyles.commonFlex}>
            <Button
              disabled={false}
              onPress={() => onSavePress()}
              title={translate("Save")}
              borderColor={Colors.white}
              color={Colors.white}
              fontSize={Metrics.rfv(14)}
              backgroundColor={Colors.linearColor2}
            />
          </View>
        </View>
        {Platform.OS == "ios" ? (
          <KeyboardSpacer />
        ) : (
          <View style={CommonStyle.bottomContainer} />
        )}
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default EditBookMarkerAccount;
