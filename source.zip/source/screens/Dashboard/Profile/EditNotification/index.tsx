import {
  View,
  Text,
  ScrollView,
  FlatList,
  Pressable,
  Image,
  Platform,
} from "react-native";
import React, { useEffect, useState } from "react";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import { Colors, CommonStyle, Images, Metrics } from "../../../../theme";
import AppStatusBar from "../../../../component/AppStatusBar";
import Header from "../../../../component/HeaderComponent";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../../../navigation";
import commonStyles from "../../../../theme/commonStyle";
import Loader from "../../../../component/ProgressBar";
import styles from "./style";
import { translate } from "../../../../utils/Localize";
import Button from "../../../../component/Button";
import CustomTextInput from "../../../../component/TextInput";
import { ReceivingData } from "../../../../theme/dummyArray";
import KeyboardSpacer from "react-native-keyboard-spacer";
import { showToast } from "../../../../utils/commonFunction";
import { print_data } from "../../../../utils/Logs";
import API_CONFIG from "../../../../api/api_url";
import { callApi } from "../../../../api";
import { useSelector } from "react-redux";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";

const EditNotification = (props: any) => {
  const { userDetails, refreshUserData } = props.route.params;
  const navigation = useNavigation();
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [data, setData] = useState([]);
  const [offeringData, setOfferingData] = useState(
    userDetails?.offeringsOther[0]
  );
  const [otherSelectedVisible, setOtherSelectedVisible] = useState(false);
  const [otherSelected, setOtherSelected] = useState(false);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [sucessVisible, setSucessVisible] = useState(false);

  let userToken = useSelector(
    (state: any) => state.UserDataReducer.is_token_saved
  );
  let saveToken = JSON.parse(userToken);

  useEffect(() => {
    let notificationData = [...ReceivingData];

    notificationData.forEach((item, _index) => {
      if (
        userDetails?.offerings.includes(item?.textBookMark) ||
        userDetails?.offeringsOther.includes(item?.textBookMark)
      ) {
        item.isSelected = true;
      } else {
        item.isSelected = false;
      }
    });
    setData(notificationData);
    setDataUpdated(!dataUpdated);
  }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressBack = () => {
    navigation.goBack();
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const redirectToProfile = () => {
    setSucessVisible(true);
    setTimeout(() => {
      refreshUserData(userDetails);
      navigation.navigate(NAVIGATION.PROFILE);
    }, 2000);
  };

  const itemSelected = (item, index) => {
    let temp = [...data];

    temp[index].isSelected = !item.isSelected;
    setData(temp);

    if (
      item?.isSelected == false &&
      item.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setOfferingData("");
      setOtherSelected(false);
      setOtherSelectedVisible(false);
    } else if (
      item?.isSelected == true &&
      item?.textBookMark == translate("OtherPleaseSpecify")
    ) {
      setOtherSelected(true);
    }
  };

  const onSavePress = () => {
    if (otherSelected) {
      if (offeringData?.length > 0) {
        setOtherSelectedVisible(false);
        const receivedSelected = ReceivingData.filter((item) => {
          return item?.isSelected;
        });

        let offeringsEventData = [];
        receivedSelected.map((item, index) => {
          let data = item.textBookMark;
          offeringsEventData.push(data);
        });

        userDetails.offerings = offeringsEventData;

        userDetails.offeringsOther =
          offeringData?.length > 0 ? [offeringData] : [];

        setIsLoaderVisible(true);
        calleditProfileApi();
      } else {
        setOtherSelectedVisible(true);
      }
    } else {
      const receivedSelected = ReceivingData.filter((item) => {
        return item?.isSelected;
      });

      let offeringsEventData = [];
      receivedSelected.map((item, index) => {
        let data = item.textBookMark;
        offeringsEventData.push(data);
      });

      userDetails.offerings = offeringsEventData;

      userDetails.offeringsOther =
        offeringData?.length > 0 ? [offeringData] : [];

      setIsLoaderVisible(true);
      calleditProfileApi();
    }
  };

  const renderItem = (item: any, index: any) => {
    return (
      <View>
        <View style={styles.renderListStyle}>
          <Pressable
            onPress={() => itemSelected(item, index)}
            style={item.isSelected ? styles.selectItem : styles.notSelectedItem}
          >
            <Text
              style={
                item.isSelected
                  ? styles.selectedBookMarkTextStyle
                  : styles.bookMarkTextStyle
              }
            >
              {item.textBookMark}
            </Text>
            {item.textBookMark == translate("OtherPleaseSpecify") &&
            item?.isSelected == true ? (
              <View style={styles.otherwidth}>
                <CustomTextInput
                  textInputStyle={styles.inputStyle}
                  containerStyle={styles.inputTextContainerStyle}
                  lableTextStyle={commonStyles.labelTextStyle}
                  inputTextStyle={styles.textInputStyle}
                  value={offeringData}
                  onChangeText={(text: string) => {
                    setOfferingData(text);
                  }}
                />
              </View>
            ) : null}
          </Pressable>
        </View>
        {item.textBookMark == translate("OtherPleaseSpecify") &&
        item?.isSelected == true ? (
          <>
            {otherSelectedVisible && (
              <Text style={styles.addBookmarkerText}>
                {translate("AddOffering")}
              </Text>
            )}
          </>
        ) : null}
      </View>
    );
  };

  const calleditProfileApi = async () => {
    try {
      var param_data = {
        bookMaker: userDetails?.bookMaker,
        sportOrEvent: userDetails?.sportOrEvent,
        sportOrEventOther: userDetails?.sportOrEventOther,
        bookMakersOther: userDetails?.bookMakerOther,
        offerings: userDetails?.offerings ? userDetails?.offerings : "",
        offeringsOther: userDetails?.offerings?.includes(
          translate("OtherPleaseSpecify")
        )
          ? userDetails?.offeringsOther
            ? userDetails?.offeringsOther
            : []
          : [],
      };

      const response = await callApi(
        API_CONFIG.EDIT_PROFILE,
        param_data,
        API_CONFIG.PUT,
        saveToken?.token
      );

      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.success == true
        ) {
          redirectToProfile();
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <Text style={styles.profileText}>{translate("EditProfile")}</Text>
          <Text style={styles.editUserDetails}>
            {translate("EditNotification")}
          </Text>
          <FlatList
            data={data}
            numColumns={2}
            renderItem={({ item, index }) => renderItem(item, index)}
            keyExtractor={(item, index) => index.toString()}
            extraData={dataUpdated}
          />
          <View>
            {sucessVisible ? (
              <View style={styles.sucessViewStyle}>
                <Image
                  style={styles.sucessIcon}
                  source={Images.profileSucessIcon}
                />
                <Text style={styles.sucessText}>
                  {translate("SavedSuccessfully")}
                </Text>
              </View>
            ) : null}
            <View style={styles.commonRow}>
              <View style={commonStyles.commonFlex}>
                <Button
                  disabled={false}
                  onPress={() => onPressBack()}
                  title={translate("Cancel")}
                  borderColor={Colors.linearColor2}
                  color={Colors.linearColor2}
                  fontSize={Metrics.rfv(14)}
                  backgroundColor={Colors.white}
                />
              </View>
              <View style={styles.gapViewStyle} />
              <View style={commonStyles.commonFlex}>
                <Button
                  disabled={false}
                  onPress={() => onSavePress()}
                  title={translate("Save")}
                  borderColor={Colors.white}
                  color={Colors.white}
                  fontSize={Metrics.rfv(14)}
                  backgroundColor={Colors.linearColor2}
                />
              </View>
            </View>
          </View>
        </View>
        {Platform.OS == "ios" ? (
          <KeyboardSpacer />
        ) : (
          <View style={CommonStyle.bottomContainer} />
        )}
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default EditNotification;
