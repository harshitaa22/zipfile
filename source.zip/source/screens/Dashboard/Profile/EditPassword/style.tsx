import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../../../theme/index";

export default StyleSheet.create({
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(20),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  profileText: {
    color: Colors.black,
    fontSize: Metrics.rfv(25),
    lineHeight: Metrics.rfv(28),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(10),
  },
  userPasswordStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.IN_SemiBold,
    marginTop: Metrics.rfv(7),
  },
  fullWidthStyle: {
    width: "100%",
  },
  commonRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    marginHorizontal: Metrics.rfv(15),
    marginBottom: Metrics.rfv(25),
  },
  endView: {
    flex: 1,
    justifyContent: "flex-end",
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  emailTextStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
  },
  labelTextStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  inputTextStyle: {
    height: Metrics.rfv(44),
    backgroundColor: Colors.white,
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    paddingHorizontal: Metrics.rfv(10),
    width: "100%",
    padding: 0,
    color: Colors.black,
    marginTop: Metrics.rfv(5),
  },
  textInputStyle: {
    flex: 1,
    padding: 0,
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  errorTextStyle: {
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    color: Colors.red,
    marginTop: Metrics.rfv(5),
  },
  sucessViewStyle: {
    paddingVertical: Metrics.rfv(5),
    backgroundColor: Colors.green,
    marginHorizontal: Metrics.rfv(15),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(20),
  },
  sucessText: {
    color: Colors.white,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    marginLeft: Metrics.rfv(10),
  },
  sucessIcon: {
    height: Metrics.rfv(19),
    width: Metrics.rfv(19),
  },
  editUserDetails: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    textDecorationLine: "underline",
    marginBottom: Metrics.rfv(10),
  },
});
