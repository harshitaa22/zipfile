import {
  View,
  Text,
  ScrollView,
  Keyboard,
  Image,
  Platform,
} from "react-native";
import React, { createRef, useState } from "react";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import { Colors, CommonStyle, Images, Metrics } from "../../../../theme";
import AppStatusBar from "../../../../component/AppStatusBar";
import Header from "../../../../component/HeaderComponent";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../../../navigation";
import commonStyles from "../../../../theme/commonStyle";
import Loader from "../../../../component/ProgressBar";
import styles from "./style";
import { translate } from "../../../../utils/Localize";
import { print_data } from "../../../../utils/Logs";
import CustomTextInput from "../../../../component/TextInput";
import ErrorText from "../../../../component/ErrorText";
import Button from "../../../../component/Button";
import {
  isConnectionAvailable,
  showToast,
} from "../../../../utils/commonFunction";
import KeyboardSpacer from "react-native-keyboard-spacer";
import API_CONFIG from "../../../../api/api_url";
import { callApi } from "../../../../api";
import { useSelector } from "react-redux";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";

const EditPassword = (props: any) => {
  const navigation = useNavigation();
  const userCurrentRef = createRef();
  const usePasswordRef = createRef();
  const useRetypeRef = createRef();

  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [userCurrentPassword, setUserCureentPassword] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const [isShowCurrentPasswordError, showCurrentPassError] = useState(false);
  const [isShowPassError, showPassError] = useState(false);
  const [currentPassErrorText, setCurrentPassErrorText] = useState("");

  const [repeatPassword, setRepeatPassword] = useState("");
  const [isShowReTypePassError, showReTypePassError] = useState(false);
  const [reTypeassErrorText, setRetypePassErrorText] = useState("");
  const [passErrorText, setPassErrorText] = useState("");
  const [sucessVisible, setSucessVisible] = useState(false);
  const [invalidePassword, setInvalidePassword] = useState(false);
  const [invalidText, setInvalidText] = useState("");

  const { userDetails, refreshUserData } = props.route.params;

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const onPressBack = () => {
    navigation.goBack();
  };
  const redirectToProfile = () => {
    setInvalidePassword(false);
    setSucessVisible(true);

    setTimeout(() => {
      refreshUserData(userDetails);
      navigation.navigate(NAVIGATION.PROFILE);
    }, 2000);
  };

  const onSavePress = async () => {
    Keyboard.dismiss();
    let is_validate = true;
    if (await isConnectionAvailable()) {
      if (userCurrentPassword?.length == 0) {
        is_validate = false;
        showCurrentPassError(true);
        setCurrentPassErrorText(translate("EmptyError"));
      } else if (userCurrentPassword?.length < 6) {
        is_validate = false;
        showCurrentPassError(true);
        setCurrentPassErrorText(translate("PasswordNotValidError"));
      }

      if (userPassword?.length == 0) {
        is_validate = false;
        showPassError(true);
        setPassErrorText(translate("EmptyError"));
      } else if (userPassword?.length < 6) {
        is_validate = false;
        showPassError(true);
        setPassErrorText(translate("PasswordNotValidError"));
      }
      if (repeatPassword?.length == 0) {
        is_validate = false;
        showReTypePassError(true);
        setRetypePassErrorText(translate("EmptyError"));
      } else if (repeatPassword?.length < 6) {
        is_validate = false;
        showReTypePassError(true);
        setRetypePassErrorText(translate("PasswordNotValidError"));
      } else if (userPassword != repeatPassword) {
        is_validate = false;
        showReTypePassError(true);
        setRetypePassErrorText(translate("DoesNotMatch"));
      }
      if (is_validate) {
        setIsLoaderVisible(true);
        calleditProfileApi();
      }
    } else {
      showToast(translate("InternetConnection"));
    }
  };

  let userToken = useSelector(
    (state: any) => state.UserDataReducer.is_token_saved
  );
  let saveToken = JSON.parse(userToken);

  const calleditProfileApi = async () => {
    try {
      var param_data = {
        currentPassword: userCurrentPassword,
        password: userPassword,
        bookMakers: userDetails?.bookMaker,
        sportOrEvent: userDetails?.sportOrEvent,
        offerings: userDetails?.offerings,
        offeringsOther: userDetails?.offeringsOther,
        sportOrEventOther: userDetails?.sportOrEventOther,
        bookMakersOther: userDetails?.bookMakerOther,
      };
      const response = await callApi(
        API_CONFIG.EDIT_PROFILE,
        param_data,
        API_CONFIG.PUT,
        saveToken?.token
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.success == true
        ) {
          redirectToProfile();
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setInvalidePassword(true);
            setInvalidText(response?.body?.data?.message);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <View style={commonStyles.commonFlex}>
        <ScrollView
          contentContainerStyle={commonStyles.scrollViewStyle}
          overScrollMode={"never"}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={"handled"}
          nestedScrollEnabled={true}
        >
          <Header
            onPressSignUp={() => onPressSignUp()}
            onPressSignIn={() => onPressSignIn()}
            isBackgroundSignUp={Colors.linearColor2}
            isBackgroundSignIn={Colors.white}
            colorUp={Colors.white}
            colorIn={Colors.linearColor2}
            sourceIcon={Images.adBannerIcon}
            isPasswordField={true}
            onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
          />
          <View style={styles.horizontalView}>
            <Text style={styles.profileText}>{translate("EditProfile")}</Text>
            <Text style={styles.editUserDetails}>
              {translate("EditPasswordText")}
            </Text>
            <View style={commonStyles.commonFlex}>
              <CustomTextInput
                ref={userCurrentRef}
                textInputStyle={styles.textInputStyle}
                placeholderTextColor={Colors.white}
                containerStyle={commonStyles.inputTextContainerStyle}
                lableText={translate("CurrentPassword")}
                lableTextStyle={styles.labelTextStyle}
                inputTextStyle={styles.inputTextStyle}
                value={userCurrentPassword}
                returnKeyType={"next"}
                keyboardType={"email-address"}
                onChangeText={(text: string) => {
                  setUserCureentPassword(text);
                  showCurrentPassError(false);
                }}
                onSubmitEditing={() => {
                  if (usePasswordRef) {
                    usePasswordRef.current.focus();
                  }
                }}
              />
              <View style={styles.fullWidthStyle}>
                <ErrorText
                  errorText={currentPassErrorText}
                  is_visible={isShowCurrentPasswordError}
                />
              </View>
              {invalidePassword ? (
                <Text style={styles.errorTextStyle}>{invalidText}</Text>
              ) : null}
              <CustomTextInput
                ref={usePasswordRef}
                textInputStyle={styles.textInputStyle}
                isPasswordField={true}
                secureTextEntry={true}
                containerStyle={commonStyles.inputTextContainerStyle}
                lableText={translate("NewPasswordText")}
                lableTextStyle={styles.labelTextStyle}
                inputTextStyle={styles.inputTextStyle}
                value={userPassword}
                fillColor={Colors.borderLightGrey}
                showFillColor={Colors.linearColor2}
                onChangeText={(text: string) => {
                  setUserPassword(text);
                  showPassError(false);
                }}
                returnKeyType={"next"}
                onSubmitEditing={() => {
                  if (useRetypeRef) {
                    useRetypeRef.current.focus();
                  }
                }}
              />
              <View style={styles.fullWidthStyle}>
                <ErrorText
                  errorText={passErrorText}
                  is_visible={isShowPassError}
                />
              </View>
              <CustomTextInput
                ref={useRetypeRef}
                textInputStyle={styles.textInputStyle}
                isPasswordField={true}
                secureTextEntry={true}
                fillColor={Colors.borderLightGrey}
                showFillColor={Colors.linearColor2}
                containerStyle={commonStyles.inputTextContainerStyle}
                lableText={translate("RetypeNewPassword")}
                lableTextStyle={styles.labelTextStyle}
                inputTextStyle={styles.inputTextStyle}
                value={repeatPassword}
                returnKeyType={"done"}
                onChangeText={(text: string) => {
                  setRepeatPassword(text);
                  showReTypePassError(false);
                }}
                onSubmitEditing={() => onSavePress()}
              />
              <View style={styles.fullWidthStyle}>
                <ErrorText
                  errorText={reTypeassErrorText}
                  is_visible={isShowReTypePassError}
                />
              </View>
            </View>
          </View>
          <View style={styles.endView}>
            {sucessVisible ? (
              <View style={styles.sucessViewStyle}>
                <Image
                  style={styles.sucessIcon}
                  source={Images.profileSucessIcon}
                />
                <Text style={styles.sucessText}>
                  {translate("SavedSuccessfully")}
                </Text>
              </View>
            ) : null}
            <View style={styles.commonRow}>
              <View style={commonStyles.commonFlex}>
                <Button
                  disabled={false}
                  onPress={() => onPressBack()}
                  title={translate("Cancel")}
                  borderColor={Colors.linearColor2}
                  color={Colors.linearColor2}
                  fontSize={Metrics.rfv(14)}
                  backgroundColor={Colors.white}
                />
              </View>
              <View style={styles.gapViewStyle} />
              <View style={commonStyles.commonFlex}>
                <Button
                  disabled={false}
                  onPress={() => onSavePress()}
                  title={translate("Save")}
                  borderColor={Colors.white}
                  color={Colors.white}
                  fontSize={Metrics.rfv(14)}
                  backgroundColor={Colors.linearColor2}
                />
              </View>
            </View>
          </View>
          {Platform.OS == "ios" ? (
            <KeyboardSpacer />
          ) : (
            <View style={CommonStyle.bottomContainer} />
          )}
        </ScrollView>
      </View>

      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default EditPassword;
