import {
  View,
  Text,
  ScrollView,
  Pressable,
  Platform,
  Modal,
  Button,
} from "react-native";
import React, { useEffect, useState } from "react";
import { Colors, CommonStyle, Images } from "../../../../theme";
import { CommonActions, useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../../../navigation";
import Header from "../../../../component/HeaderComponent";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import AppStatusBar from "../../../../component/AppStatusBar";
import styles from "./style";
import { translate } from "../../../../utils/Localize";
import commonStyles from "../../../../theme/commonStyle";
import API_CONFIG from "../../../../api/api_url";
import { callApi } from "../../../../api";
import { print_data } from "../../../../utils/Logs";
import { showToast } from "../../../../utils/commonFunction";
import Loader from "../../../../component/ProgressBar";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import KeyboardSpacer from "react-native-keyboard-spacer";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Constant } from "../../../../utils";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";
import DeleteModal from "../../../../component/DeleteAccountModal";

const ProfileScreen = (props: any) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [userDetails, setUserDetails] = useState({});
  const [isModalVisible, setIsModalVisible] = useState(false);

  let userToken = useSelector(
    (state: any) => state.UserDataReducer.is_token_saved
  );
  let saveToken = JSON.parse(userToken);
  print_data(saveToken);

  useEffect(() => {
    setIsLoaderVisible(true);
    callProfileAPi();
  }, []);

  const clearFieldsAndNavigate = async () => {
    try {
      dispatch({
        type: Constant.SAVE_TOKEN,
        payload: null,
      });
    } catch (e) {
      print_data(e);
    }
    try {
      await AsyncStorage.clear();
    } catch (e) {}

    setTimeout(() => {
      props.navigation.dispatch(
        CommonActions.reset({
          routes: [{ name: NAVIGATION.TAB_STACK }],
        })
      );
    }, 10);
  };
  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const onLogOutPress = () => {
    clearFieldsAndNavigate();
  };

  const onBackPress = () => {
    navigation.goBack();
  };
  const noPress = () => {
    setIsModalVisible(false);
  };
  const yesPress = () => {
    setIsModalVisible(false);
    setIsLoaderVisible(true);
    callDeleteAPi();
  };

  const onUserDetailsPress = (navigationData) => {
    navigation.navigate(navigationData, {
      userDetails,
      refreshUserData: (userDetails) => {
        setIsLoaderVisible(true);
        setTimeout(() => {
          setUserDetails(userDetails);
          setIsLoaderVisible(false);
        }, 1000);
      },
    });
  };

  const callProfileAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.POFILE,
        null,
        API_CONFIG.GET,
        saveToken?.token
      );
      print_data(response);
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setUserDetails(response?.body?.data?.data);
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setTimeout(() => {
              showToast(response?.body?.data?.message);
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const callDeleteAPi = async () => {
    try {
      const response = await callApi(
        `user/${userDetails?.id}`,
        null,
        API_CONFIG.DELETE,
        saveToken?.token
      );
      print_data("callDeleteAPi=====");
      print_data(response);
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.success == true
        ) {
          setIsLoaderVisible(false);
          setIsModalVisible(false);
          clearFieldsAndNavigate();
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setTimeout(() => {
              showToast(response?.body?.data?.message);
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />

      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          isShowBack={true}
          onBackPress={() => onBackPress()}
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <Text style={styles.profileText}>{translate("EditProfile")}</Text>

          <Text style={styles.userDetailStyle}>{translate("UserDetails")}</Text>
          <Pressable
            onPress={() => onUserDetailsPress(NAVIGATION.USER_DETAILS)}
          >
            <Text style={styles.editText}>{translate("Edit")}</Text>
          </Pressable>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("Title")}:</Text>
            <Text style={styles.userDetailsText}>
              {userDetails?.titlePrefix}
            </Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("FirstNameTitle")}</Text>
            <Text style={styles.userDetailsText}>{userDetails?.firstName}</Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("LastNameTitle")}</Text>
            <Text style={styles.userDetailsText}>{userDetails?.lastName}</Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("DateOfBirth")}:</Text>
            <Text style={styles.userDetailsText}>
              {moment(userDetails?.dob).format("DD/MM/YYYY")}
            </Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("CountryTitle")}</Text>
            <Text style={styles.userDetailsText}>
              {userDetails?.address?.Country?.country
                ? userDetails?.address?.Country?.country
                : userDetails?.address?.selectedCountryName}
            </Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("State")}:</Text>
            <Text style={styles.userDetailsText}>
              {userDetails?.address?.State?.state
                ? userDetails?.address?.State?.state
                : userDetails?.address?.selectedStateName}
            </Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("PhoneNumber")}:</Text>

            <Text style={styles.userDetailsText}>{userDetails?.phone}</Text>
          </View>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("Email")}:</Text>
            <Text style={styles.userDetailsText}>{userDetails?.username}</Text>
          </View>
          <View style={styles.widthStyle} />
          <Text style={styles.userDetailStyle}>{translate("Password")}</Text>
          <Pressable
            onPress={() => onUserDetailsPress(NAVIGATION.EDIT_PASSWORD)}
          >
            <Text style={styles.editText}>{translate("Edit")}</Text>
          </Pressable>
          <View style={commonStyles.alignCenterView}>
            <Text style={styles.subtitle}>{translate("Password")}:</Text>
            <Text style={styles.userDetailsText}>***********</Text>
          </View>
          <View style={styles.widthStyle} />
          <Text style={styles.userDetailStyle}>
            {translate("BookmakerAccountsText")}
          </Text>
          <Pressable onPress={() => onUserDetailsPress(NAVIGATION.BOOK_MARKER)}>
            <Text style={styles.editText}>{translate("Edit")}</Text>
          </Pressable>

          {(userDetails?.bookMaker || userDetails?.bookMakerOther) &&
          (userDetails?.bookMaker?.length != 0 ||
            userDetails?.bookMakerOther?.length != 0) ? (
            <View style={commonStyles.alignCenterView}>
              <Text style={styles.subtitle}>{translate("BookmakerText")}:</Text>
              <Text style={styles.userDetailsText}>
                {userDetails?.bookMaker?.filter(
                  (item) => item !== translate("OtherPleaseSpecify")
                ).length == 0 || userDetails?.bookMakerOther?.length == 0
                  ? userDetails?.bookMaker?.filter(
                      (item) => item !== translate("OtherPleaseSpecify")
                    ) + userDetails?.bookMakerOther
                  : userDetails?.bookMaker?.filter(
                      (item) => item !== translate("OtherPleaseSpecify")
                    ) +
                    ", " +
                    userDetails?.bookMakerOther}
              </Text>
            </View>
          ) : null}

          <View style={styles.widthStyle} />
          <Text style={styles.userDetailStyle}>{translate("SportsIbet")}</Text>
          <Pressable onPress={() => onUserDetailsPress(NAVIGATION.EDIT_SPORTS)}>
            <Text style={styles.editText}>{translate("Edit")}</Text>
          </Pressable>
          {(userDetails?.sportOrEvent || userDetails?.sportOrEventOther) &&
          (userDetails?.sportOrEvent?.length != 0 ||
            userDetails?.sportOrEventOther?.length != 0) ? (
            <View style={commonStyles.alignCenterView}>
              <Text style={styles.subtitle}>{translate("SportsTab")}:</Text>
              <Text style={styles.userDetailsText}>
                {userDetails?.sportOrEvent?.filter(
                  (item) => item !== translate("OtherPleaseSpecify")
                ).length == 0 || userDetails?.sportOrEventOther?.length == 0
                  ? userDetails?.sportOrEvent?.filter(
                      (item) => item !== translate("OtherPleaseSpecify")
                    ) + userDetails?.sportOrEventOther
                  : userDetails?.sportOrEvent?.filter(
                      (item) => item !== translate("OtherPleaseSpecify")
                    ) +
                    ", " +
                    userDetails?.sportOrEventOther}
              </Text>
            </View>
          ) : null}
          <View style={styles.widthStyle} />
          <Text style={styles.userDetailStyle}>
            {translate("ReceiveNotifications")}
          </Text>
          <Pressable
            onPress={() => onUserDetailsPress(NAVIGATION.EDIT_NOTIFICATION)}
          >
            <Text style={styles.editText}>{translate("Edit")}</Text>
          </Pressable>
          {(userDetails?.offerings || userDetails?.offeringsOther) &&
          (userDetails?.offerings?.length != 0 ||
            userDetails?.offeringsOther?.length != 0) ? (
            <View style={commonStyles.alignCenterView}>
              <Text style={styles.subtitle}>
                {translate("NotificationsTitle")}:
              </Text>
              <Text style={styles.userDetailsText}>
                {userDetails?.offerings?.filter(
                  (item) => item !== translate("OtherPleaseSpecify")
                ).length == 0 || userDetails?.offeringsOther?.length == 0
                  ? userDetails?.offerings?.filter(
                      (item) => item !== translate("OtherPleaseSpecify")
                    ) + userDetails?.offeringsOther
                  : userDetails?.offerings?.filter(
                      (item) => item !== translate("OtherPleaseSpecify")
                    ) +
                    ", " +
                    userDetails?.offeringsOther}
              </Text>
            </View>
          ) : null}
          <View style={styles.widthStyle} />
          <Text style={styles.userDetailStyle}>
            {translate("DeleteAccount")}
          </Text>
          <Pressable
            onPress={() => {
              setIsModalVisible(!isModalVisible);
            }}
          >
            <Text style={styles.editText}>{translate("Delete")}</Text>
          </Pressable>
          <DeleteModal
            isVisible={isModalVisible}
            showModel={setIsModalVisible}
            onPressBack={() => noPress()}
            onNextPress={() => yesPress()}
          />
          <View style={styles.widthStyle} />
          <Pressable
            style={styles.logOutButton}
            onPress={() => onLogOutPress()}
          >
            <Text style={styles.logOutextStyle}>{translate("LogOut")}</Text>
          </Pressable>
        </View>
        {Platform.OS == "ios" ? (
          <KeyboardSpacer />
        ) : (
          <View style={CommonStyle.bottomContainer} />
        )}
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default ProfileScreen;
