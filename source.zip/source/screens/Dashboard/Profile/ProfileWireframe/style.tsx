import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../../../theme/index";

export default StyleSheet.create({
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(20),
  },
  sportStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    marginBottom: Metrics.rfv(8),
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
    marginTop: Metrics.rfv(20),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  profileText: {
    color: Colors.black,
    fontSize: Metrics.rfv(25),
    lineHeight: Metrics.rfv(28),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    marginBottom: Metrics.rfv(10),
  },
  userDetailStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.IN_SemiBold,
    marginTop: Metrics.rfv(7),
  },
  editText: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(11),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    textDecorationLine: "underline",
    marginTop: Metrics.rfv(6),
  },
  subtitle: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(17),
    fontFamily: Fonts.IN_Regular,
    marginTop: Metrics.rfv(6),
    flex: 1,
  },
  userDetailsText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(17),
    fontFamily: Fonts.IN_SemiBold,
    marginTop: Metrics.rfv(6),
    flex: 1,
  },
  widthStyle: {
    width: "100%",
    borderBottomColor: Colors.borderLightGrey,
    borderBottomWidth: Metrics.rfv(1),
    marginTop: Metrics.rfv(10),
    opacity: Metrics.rfv(0.4),
  },
  profileIcon: {
    width: Metrics.rfv(30),
    height: Metrics.rfv(25),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(10),
  },
  logOutButton: {
    height: Metrics.rfv(35),
    width: Metrics.rfv(95),
    backgroundColor: Colors.linearColor2,
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    marginTop: Metrics.rfv(20),
    marginBottom: Metrics.rfv(20),
  },
  logOutextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(17),
    fontFamily: Fonts.IN_Regular,
  },
});
