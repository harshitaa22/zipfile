import {
  View,
  Text,
  ScrollView,
  Keyboard,
  Pressable,
  Image,
  Platform,
} from "react-native";
import React, { createRef, useEffect, useState } from "react";
import Modal from "react-native-modal";
import AppSafeAreaView from "../../../../component/AppSafeAreaView";
import { Colors, CommonStyle, Images, Metrics } from "../../../../theme";
import AppStatusBar from "../../../../component/AppStatusBar";
import Header from "../../../../component/HeaderComponent";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../../../navigation";
import commonStyles from "../../../../theme/commonStyle";
import Loader from "../../../../component/ProgressBar";
import styles from "./style";
import { translate } from "../../../../utils/Localize";
import DropDownPicker from "react-native-dropdown-picker";
import ErrorText from "../../../../component/ErrorText";
import { BlackDropDownArrow, DownArrow, UpArrow } from "../../../../theme/svg";
import CustomTextInput from "../../../../component/TextInput";
import { print_data } from "../../../../utils/Logs";
import { callApi } from "../../../../api";
import API_CONFIG from "../../../../api/api_url";
import Button from "../../../../component/Button";
import moment from "moment";
import { APP_CONSTANT } from "../../../../utils/appConstant";
import {
  isConnectionAvailable,
  showToast,
} from "../../../../utils/commonFunction";
import DatePicker from "react-native-date-picker";
import KeyboardSpacer from "react-native-keyboard-spacer";
import { useSelector } from "react-redux";
import _ from "lodash";
import CommonHeaderComponent from "../../../../component/CommonHeaderComponent";
import DatePickerModel from "../../../../component/DatePickerModel";

const EditUserDetails = (props: any) => {
  const navigation = useNavigation();
  const userNameRef = createRef();
  const userLastNameRef = createRef();
  const useMobileRef = createRef();
  const userEmailRef = createRef();

  const [titleList, setTitleList] = useState([
    { label: "Mr", value: "Mr" },
    { label: "Mrs", value: "Mrs" },
    { label: "Ms", value: "Ms" },
    { label: "Miss", value: "Miss" },
    { label: "Dr", value: "Dr" },
  ]);
  const { userDetails, refreshUserData } = props?.route?.params;
  const [isLoadervisible, setIsLoaderVisible] = useState(false);
  const [titleOpen, setTitleOpen] = useState(false);
  const [selectedTitle, setSelectedTitle] = useState("");

  const [userName, setUserName] = useState("");
  const [userLastName, setUserLastName] = useState("");
  const [userPhoneNumber, setUserPhoneNumber] = useState("");
  const [isDropDownBorder, setIsDropDownBorder] = useState(false);
  const [countryOpen, setCountryOpen] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState(
    userDetails?.address?.country
  );
  const [isCountryBorder, setIsCountryBorder] = useState(false);
  const [stateOpen, setStateOpen] = useState(false);
  const [selectedState, setSelectedState] = useState(
    userDetails?.address?.state
  );
  const [isStateBorder, setIsStateBorder] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [getUTCDate, setGetUTCDate] = useState(new Date(userDetails?.dob));
  const [isDateBirth, setIsDateBirth] = useState(false);
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [isShowNameError, showNameError] = useState(false);
  const [isShowLastNameError, showLastNameError] = useState(false);
  const [isTitleErrorShow, setIsTitleErrorShow] = useState(false);
  const [isDateOfBirthValid, setIsDateOfBirthValid] = useState(false);
  const [isCountryErrorShow, setIsCountryErrorShow] = useState(false);
  const [isStateErrorShow, setIsStateErrorShow] = useState(false);
  const [isShowMobileError, showMobileError] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [countryId, setCountryId] = useState(0);
  const [stateId, setStateId] = useState(0);
  const [checkYear, setCheckYear] = useState(false);
  const [userYear, setUserYear] = useState("");
  const [mobileError, setMobileError] = useState(false);
  const [numericError, setNumericError] = useState(false);
  const [countryOffset, setCountryOffset] = useState(0);
  const [counryCount, setCountryCount] = useState(0);
  const [stateCount, setStateCount] = useState(0);
  const [stateOffset, setStateOffset] = useState(0);
  const [countryData, setCountryData] = useState(0);
  const [selectedCountryName, setSelectedCountryName] = useState(
    userDetails?.address?.Country?.country
  );
  const [selectedStateName, setSelectedStateName] = useState(
    userDetails?.address?.State?.state
  );
  const [isLoadMore, setIsLoadMore] = useState(false);
  const [sucessVisible, setSucessVisible] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [isShowEmailError, showEmailError] = useState(false);
  const [emailErrorText, setEmailErrorText] = useState("");

  let userToken = useSelector(
    (state: any) => state.UserDataReducer.is_token_saved
  );
  let saveToken = JSON.parse(userToken);

  useEffect(() => {
    setSelectedTitle(userDetails?.titlePrefix);
    setUserName(userDetails?.firstName);
    setUserLastName(userDetails?.lastName);
    setUserEmail(userDetails?.username);
    setDateOfBirth(moment(userDetails?.dob).format("DD/MM/YYYY"));
    setUserPhoneNumber(userDetails?.phone);
    setSelectedState(userDetails?.address?.state);
    setIsLoaderVisible(true);
    callCountryAPi(countryOffset);
  }, []);

  const onPressSignUp = () => {
    navigation.navigate(NAVIGATION.REGISTER);
  };

  const onPressSignIn = () => {
    navigation.navigate(NAVIGATION.LOGIN);
  };

  const redirectToProfile = () => {
    setSucessVisible(true);
    setTimeout(() => {
      refreshUserData(userDetails);
      navigation.navigate(NAVIGATION.PROFILE);
    }, 4000);
  };

  const onPressBack = () => {
    navigation.goBack();
  };

  const onSavePress = async () => {
    Keyboard.dismiss();
    let is_validate = true;
    if (await isConnectionAvailable()) {
      if (
        selectedTitle?.length == 0 ||
        selectedTitle == "- Select -" ||
        !selectedTitle
      ) {
        is_validate = false;
        setIsTitleErrorShow(true);
      }
      if (userName?.trim().length == 0) {
        is_validate = false;
        showNameError(true);
      }
      if (userLastName?.trim().length == 0) {
        is_validate = false;
        showLastNameError(true);
      }
      if (userPhoneNumber?.trim().length == 0) {
        is_validate = false;
        showMobileError(true);
      } else if (userPhoneNumber?.length > 12 || userPhoneNumber?.length < 10) {
        is_validate = false;
        setMobileError(true);
      } else if (!APP_CONSTANT.PHONE_PATTERN.test(userPhoneNumber)) {
        is_validate = false;
        setNumericError(true);
      }
      if (userEmail?.length == 0) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("EmptyError"));
      } else if (!APP_CONSTANT.EMAIL_PATTERN.test(userEmail)) {
        is_validate = false;
        showEmailError(true);
        setEmailErrorText(translate("EmailNotValidError"));
      }

      if (dateOfBirth?.length == 0 || dateOfBirth == "Invalid date") {
        is_validate = false;
        setIsDateOfBirthValid(true);
      } else if (moment(getUTCDate) >= moment().subtract(18, "years")) {
        is_validate = false;
        setCheckYear(true);
        setUserYear(translate("GraterThanYear"));
      }

      if (selectedCountry?.length == 0 || !selectedCountry) {
        is_validate = false;
        setIsCountryErrorShow(true);
      }

      // if (selectedState?.length == 0 || selectedState == 0 || !selectedState) {
      //   is_validate = false;
      //   setIsStateErrorShow(true);
      // }

      if (is_validate) {
        userDetails.username = userEmail;
        userDetails.dob = moment(getUTCDate).format("YYYY-MM-DD");
        userDetails.firstName = userName;
        userDetails.lastName = userLastName;
        userDetails.titlePrefix = selectedTitle;
        userDetails.phone = userPhoneNumber;

        if (userDetails.address != null && userDetails.address.state != null) {
          userDetails.address.country = countryId;
          userDetails.address.state = stateId;
          userDetails.address.Country.country = selectedCountryName;
          userDetails.address.State.state = selectedStateName;
        } else {
          let customData = {
            countryId: countryId == 0 ? null : countryId,
            stateId: stateId == 0 ? null : stateId,
            selectedCountryName:
              selectedCountryName?.length > 0 ? selectedCountryName : null,
            selectedStateName:
              selectedStateName?.length > 0 ? selectedStateName : null,
          };
          userDetails.address = customData;
        }

        redirectToProfile();
        setIsLoaderVisible(true);
        calleditProfileApi();
      }
    } else {
      showToast(translate("InternetConnection"));
    }
  };

  const calleditProfileApi = async () => {
    try {
      var param_data = {
        firstName: userName,

        lastName: userLastName,
        dob: moment(getUTCDate).format("YYYY-MM-DD"),
        phone: userPhoneNumber,
        email: userEmail,
        titlePrefix: selectedTitle,
        address: {
          country: countryId,
          state: stateId == 0 ? null : stateId,
          Country: {
            country: selectedCountryName,
          },
          State: {
            state: selectedStateName?.length > 0 ? selectedStateName : null,
          },
        },
        bookMakers: userDetails?.bookMaker,
        sportOrEvent: userDetails?.sportOrEvent,
        offerings: userDetails?.offerings,
        offeringsOther: userDetails?.offeringsOther,
        sportOrEventOther: userDetails?.sportOrEventOther,
        bookMakersOther: userDetails?.bookMakerOther,
      };
      const response = await callApi(
        API_CONFIG.EDIT_PROFILE,
        param_data,
        API_CONFIG.PUT,
        saveToken?.token
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.success == true
        ) {
          redirectToProfile();
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
          if (response?.body?.data?.status === false) {
            setTimeout(() => {
              showToast(response?.body?.data?.message);
            }, 10);
          } else {
            setTimeout(() => {
              showToast(translate("SomethingWrong"));
            }, 10);
          }
        }
      } else {
        setIsLoaderVisible(false);
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  const callCountryAPi = async (countryOffset) => {
    try {
      const response = await callApi(
        API_CONFIG.COUNTRY + countryOffset,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let countryAPIList = response?.body?.data?.result?.rows;
          const itemData: any = [];
          countryAPIList.map((item: any, index) => {
            itemData.push({
              label: item?.country,
              value: item?.id,
              key: index,
            });
          });
          const finalList = [...countryList, ...itemData];
          setCountryList(finalList);
          setCountryCount(Math.ceil(response?.body?.data?.result?.count / 20));
          setIsLoadMore(false);
          setIsLoaderVisible(false);
        } else {
          setIsLoadMore(false);
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoadMore(false);
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoadMore(false);
      setIsLoaderVisible(false);
      print_data("=====exception=====" + error);
    }
  };

  const callStateAPi = async (selectedCountry, page, type) => {
    try {
      const response = await callApi(
        API_CONFIG.STATE + `/${selectedCountry}?limit=20&offset=${page}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let stateAPIList = response?.body?.data?.result?.rows;
          let itemData = [];
          for (let i = 0; i < stateAPIList.length; i++) {
            itemData.push({
              label: stateAPIList[i].state,
              value: stateAPIList[i].id,
            });
          }

          setStateCount(Math.ceil(response?.body?.data?.result?.count / 20));

          if (type) {
            setStateList(itemData);
          } else {
            let finalList = _.unionBy(stateList, itemData);
            let sortData = finalList?.sort((a, b) => {
              return a.label > b.label ? 1 : -1;
            });
            setStateList(
              _.uniqBy(sortData, function (e) {
                return e.value;
              })
            );
          }
          setIsLoaderVisible(false);
        } else {
          setIsLoaderVisible(false);
        }
      } else {
        setIsLoaderVisible(false);
      }
    } catch (error) {
      setIsLoaderVisible(false);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.white}
    >
      <AppStatusBar
        backgroundColor={Colors.white}
        isTransperent={false}
        barStyle={"dark-content"}
      />

      <Modal
        isVisible={isModalVisible}
        onBackButtonPress={() => isModalVisible}
        testID={"modal"}
        style={styles.modal}
        onBackdropPress={() => {
          setIsModalVisible(false);
        }}
      >
        <View style={styles.dateView}>
          <Pressable
            onPress={() => {
              setIsModalVisible(false);
            }}
          >
            <Text style={[styles.dialogCancelStyle]}>
              {translate("Cancel")}
            </Text>
          </Pressable>
          <Pressable
            onPress={() => {
              if (getUTCDate) {
                setDateOfBirth(moment(getUTCDate).format("DD/MM/YYYY"));
                setIsDateBirth(false);
                setIsModalVisible(false);
              } else {
                setIsModalVisible(false);
              }
            }}
          >
            <Text style={[styles.dialogDoneStyle]}>{translate("Done")}</Text>
          </Pressable>
        </View>
        <View>
          <DatePicker
            style={styles.dataPicker}
            mode={"date"}
            maximumDate={new Date()}
            textColor={Colors.black}
            date={getUTCDate ? getUTCDate : new Date()}
            onDateChange={(date) => {
              setGetUTCDate(date);
              setIsDateOfBirthValid(false);
              setCheckYear(false);
            }}
          />
        </View>
      </Modal>
      <CommonHeaderComponent
        isShowBack={true}
        onBackPress={() => navigation.goBack()}
      />
      <ScrollView
        contentContainerStyle={commonStyles.scrollViewStyle}
        overScrollMode={"never"}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps={"handled"}
        nestedScrollEnabled={true}
      >
        <Header
          onPressSignUp={() => onPressSignUp()}
          onPressSignIn={() => onPressSignIn()}
          isBackgroundSignUp={Colors.linearColor2}
          isBackgroundSignIn={Colors.white}
          colorUp={Colors.white}
          colorIn={Colors.linearColor2}
          sourceIcon={Images.adBannerIcon}
          isPasswordField={true}
          onbannerPress={() => navigation.navigate(NAVIGATION.ADVERTISING)}
        />
        <View style={styles.horizontalView}>
          <Text style={styles.profileText}>{translate("EditProfile")}</Text>
          <Text style={styles.editUserDetails}>{translate("EditDetails")}</Text>
          <View>
            <Text style={styles.titleTextStyle}>{translate("Title")}:</Text>
            <View style={styles.halfWidth}>
              <DropDownPicker
                textStyle={styles.labelSelectStyle}
                open={titleOpen}
                value={selectedTitle}
                labelExtractor={({ label }) => label}
                valueExtractor={({ selectedTitle }) => selectedTitle}
                items={titleList}
                scrollViewProps={{
                  nestedScrollEnabled: true,
                  showsVerticalScrollIndicator: false,
                  showsHorizontalScrollIndicator: false,
                }}
                setOpen={(isOpen) => {
                  setTitleOpen(isOpen);
                  setCountryOpen(false);
                  setStateOpen(false);
                }}
                listMode="SCROLLVIEW"
                dropDownContainerStyle={styles.dropDownContainerStyle}
                setValue={setSelectedTitle}
                onChangeValue={(selectedTitle) => {
                  setIsDropDownBorder(false);
                  setIsTitleErrorShow(false);
                }}
                setItems={setTitleList}
                dropDownDirection="BOTTOM"
                autoScroll={true}
                style={
                  isDropDownBorder
                    ? styles.dropDownStyleRed
                    : styles.dropDownStyleWhite
                }
                placeholder={userDetails?.titlePrefix}
                ArrowUpIconComponent={({}) => (
                  <UpArrow
                    width={Metrics.rfv(11)}
                    height={Metrics.rfv(6)}
                    fill={Colors.black}
                  />
                )}
                ArrowDownIconComponent={({}) => (
                  <BlackDropDownArrow style={styles.dropDownIcon} />
                )}
                selectedItemContainerStyle={styles.selectedItemContainerStyle}
                placeholderStyle={styles.dropDownPlaceholder}
              />
            </View>
          </View>
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("EmptyError")}
              is_visible={isTitleErrorShow}
            />
          </View>

          <CustomTextInput
            ref={userNameRef}
            textInputStyle={styles.textInputStyle}
            placeholderTextColor={Colors.black}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("FirstNameTitle")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.inputTextStyle}
            value={userName}
            returnKeyType={"next"}
            onChangeText={(text: string) => {
              setUserName(text);
              showNameError(false);
            }}
            onSubmitEditing={() => {
              if (userLastNameRef) {
                userLastNameRef.current?.focus();
              }
            }}
          />
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("EmptyError")}
              is_visible={isShowNameError}
            />
          </View>
          <CustomTextInput
            ref={userLastNameRef}
            textInputStyle={styles.textInputStyle}
            placeholderTextColor={Colors.black}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("LastNameTitle")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.inputTextStyle}
            value={userLastName}
            returnKeyType={"next"}
            onChangeText={(text: string) => {
              setUserLastName(text);
              showLastNameError(false);
            }}
          />
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("EmptyError")}
              is_visible={isShowLastNameError}
            />
          </View>
          <Text style={styles.dobStyle}>{translate("DateOfBirth")}:</Text>
          <View style={styles.bottomView}>
            <CustomTextInput
              editable={false}
              textInputStyle={styles.textInputStyle}
              backgroundColor={Colors.lightblue}
              width={Metrics.rfp(45)}
              borderColor={
                isDateBirth ? Colors.textRed : Colors.validationBorder
              }
              inputTextStyle={styles.inputTextStyle}
              keyboardType="email-address"
              placeholderTextColor={Colors.black}
              onChangeText={(text: string) => {
                setDateOfBirth(text);
                setIsDateOfBirthValid(false);
                setCheckYear(false);
              }}
              value={dateOfBirth}
              datePickerProfileVisible={true}
              datePickerPress={() => {
                Keyboard.dismiss();
                setIsModalVisible(true);
              }}
              returnKeyType="next"
              placeholder={translate("DatePickerPlaceHolder")}
              activeOpacity={1}
            />
            {checkYear ? (
              <Text style={styles.errorTextStyle}>{userYear}</Text>
            ) : null}
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("EmptyError")}
                is_visible={isDateOfBirthValid}
              />
            </View>
          </View>
          <View style={styles.countryIndex}>
            <Text style={styles.emailTextStyle}>
              {translate("CountryTitle")}
            </Text>

            <DropDownPicker
              onSelectItem={(item) => setSelectedCountryName(item?.label)}
              autoScroll={true}
              textStyle={styles.labelSelectStyle}
              open={countryOpen}
              value={selectedCountry}
              placeholder={userDetails?.address?.Country?.country}
              scrollViewProps={{
                nestedScrollEnabled: true,
                showsVerticalScrollIndicator: false,
                showsHorizontalScrollIndicator: false,

                onMomentumScrollEnd(event) {
                  if (
                    !isLoadMore &&
                    counryCount !== Math.ceil(countryOffset / 20)
                  ) {
                    callCountryAPi(countryOffset + 20);
                    setCountryOffset(countryOffset + 20);
                  }
                },
              }}
              labelExtractor={({ country }) => country}
              valueExtractor={({ selectedCountry }) => selectedCountry}
              items={countryList}
              setOpen={(isOpen) => {
                setCountryOpen(isOpen);
                setStateOpen(false);
                setTitleOpen(false);
              }}
              listMode="SCROLLVIEW"
              dropDownContainerStyle={styles.dropDownContainerStyle}
              setValue={setSelectedCountry}
              onChangeValue={(selectedCountry) => {
                setIsCountryBorder(false);
                setIsCountryErrorShow(false);
                setCountryId(selectedCountry);

                if (selectedCountry?.toString().length > 0) {
                  setIsLoaderVisible(true);
                  if (userDetails?.address?.country != selectedCountry) {
                    setSelectedState(0);
                    setStateId(0);
                    setSelectedStateName("");
                    setStateList([]);
                    setStateCount(0);
                    callStateAPi(selectedCountry, 0, true);
                  } else {
                    callStateAPi(selectedCountry, 0, true);
                  }
                }
              }}
              setItems={setCountryList}
              dropDownDirection="BOTTOM"
              style={
                isCountryBorder
                  ? styles.dropDownStyleRed
                  : styles.dropDownStyleWhite
              }
              ArrowUpIconComponent={({}) => (
                <UpArrow
                  width={Metrics.rfv(11)}
                  height={Metrics.rfv(6)}
                  fill={Colors.black}
                />
              )}
              ArrowDownIconComponent={({}) => (
                <BlackDropDownArrow style={styles.dropDownIcon} />
              )}
              selectedItemContainerStyle={styles.selectedItemContainerStyle}
              placeholderStyle={styles.dropDownPlaceholder}
            />
          </View>
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("EmptyError")}
              is_visible={isCountryErrorShow}
            />
          </View>
          <View>
            <Text style={styles.stateTextStyle}>{translate("State")}:</Text>
            <DropDownPicker
              onSelectItem={(item) => setSelectedStateName(item?.label)}
              textStyle={styles.labelSelectStyle}
              zIndex={3000}
              open={stateOpen}
              autoScroll={true}
              scrollViewProps={{
                showsVerticalScrollIndicator: false,
                showsHorizontalScrollIndicator: false,

                onMomentumScrollEnd(event) {
                  if (stateCount !== Math.ceil(stateOffset / 20)) {
                    callStateAPi(countryId, stateOffset + 20, false);
                    setStateOffset(stateOffset + 20);
                  }
                },
              }}
              value={selectedState}
              labelExtractor={({ label }) => label}
              valueExtractor={({ selectedState }) => selectedState}
              items={stateList}
              setOpen={(isOpen) => {
                setStateOpen(isOpen);
                setCountryOpen(false);
                setTitleOpen(false);
              }}
              listMode="SCROLLVIEW"
              dropDownContainerStyle={styles.dropDownContainerStyle}
              setValue={setSelectedState}
              onChangeValue={(selectedState) => {
                setStateId(selectedState);
                setIsStateBorder(false);
                // setIsStateErrorShow(false);
              }}
              setItems={setStateList}
              dropDownDirection="BOTTOM"
              style={
                isStateBorder
                  ? styles.dropDownStyleRed
                  : styles.dropDownStyleWhite
              }
              placeholder={translate("PlaceHolder")}
              ArrowUpIconComponent={({}) => (
                <UpArrow
                  width={Metrics.rfv(11)}
                  height={Metrics.rfv(6)}
                  fill={Colors.black}
                />
              )}
              ArrowDownIconComponent={({}) => (
                <BlackDropDownArrow style={styles.dropDownIcon} />
              )}
              selectedItemContainerStyle={styles.selectedItemContainerStyle}
              placeholderStyle={styles.dropDownPlaceholder}
            />
          </View>
          {/* <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={translate("EmptyError")}
              is_visible={isStateErrorShow}
            />
          </View> */}
          <View style={styles.numberStyle}>
            <CustomTextInput
              textInputStyle={styles.textInputStyle}
              ref={useMobileRef}
              containerStyle={commonStyles.inputTextContainerStyle}
              placeholderTextColor={Colors.black}
              lableText={translate("PhoneNumberTitle")}
              lableTextStyle={styles.labelTextStyle}
              inputTextStyle={styles.inputTextStyle}
              value={userPhoneNumber}
              maxLength={12}
              keyboardType={"number-pad"}
              returnKeyType={"done"}
              onChangeText={(text: string) => {
                setUserPhoneNumber(text);
                showMobileError(false);
                setMobileError(false);
                setNumericError(false);
              }}
              onSubmitEditing={() => {
                if (userEmailRef) {
                  userEmailRef.current.focus();
                }
              }}
            />
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("EmptyError")}
                is_visible={isShowMobileError}
              />
            </View>
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("NumberDigit")}
                is_visible={mobileError}
              />
            </View>
            <View style={styles.fullWidthStyle}>
              <ErrorText
                errorText={translate("NumericalText")}
                is_visible={numericError}
              />
            </View>
          </View>
          <CustomTextInput
            editable={false}
            ref={userEmailRef}
            textInputStyle={styles.textInputStyle}
            placeholderTextColor={Colors.white}
            containerStyle={commonStyles.inputTextContainerStyle}
            lableText={translate("EmailTitle")}
            lableTextStyle={styles.labelTextStyle}
            inputTextStyle={styles.inputTextStyle}
            value={userEmail}
            returnKeyType={"next"}
            keyboardType={"email-address"}
            onChangeText={(text: string) => {
              setUserEmail(text);
              showEmailError(false);
            }}
            onSubmitEditing={() => onSavePress()}
          />
          <View style={styles.fullWidthStyle}>
            <ErrorText
              errorText={emailErrorText}
              is_visible={isShowEmailError}
            />
          </View>
        </View>
        <View>
          {sucessVisible ? (
            <View style={styles.sucessViewStyle}>
              <Image
                style={styles.sucessIcon}
                source={Images.profileSucessIcon}
              />
              <Text style={styles.sucessText}>
                {translate("SavedSuccessfully")}
              </Text>
            </View>
          ) : null}
          <View style={styles.commonRow}>
            <View style={commonStyles.commonFlex}>
              <Button
                disabled={false}
                onPress={() => onPressBack()}
                title={translate("Cancel")}
                borderColor={Colors.linearColor2}
                color={Colors.linearColor2}
                fontSize={Metrics.rfv(14)}
                backgroundColor={Colors.white}
              />
            </View>
            <View style={styles.gapViewStyle} />
            <View style={commonStyles.commonFlex}>
              <Button
                disabled={false}
                onPress={() => onSavePress()}
                title={translate("Save")}
                borderColor={Colors.white}
                color={Colors.white}
                fontSize={Metrics.rfv(14)}
                backgroundColor={Colors.linearColor2}
              />
            </View>
          </View>
        </View>
        {Platform.OS == "ios" ? (
          <KeyboardSpacer />
        ) : (
          <View style={CommonStyle.bottomContainer} />
        )}
      </ScrollView>
      {isLoadervisible && (
        <View style={commonStyles.loader}>
          <Loader color={Colors.black} />
        </View>
      )}
    </AppSafeAreaView>
  );
};

export default EditUserDetails;
