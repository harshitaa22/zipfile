import { StyleSheet } from "react-native";
import { Colors, Metrics } from "../../theme";

export default StyleSheet.create({
  svgIconStyle: {
    width: Metrics.rfv(183),
    height: Metrics.rfv(72),
    resizeMode: "contain",
  },
  mainContainer: {
    width: "100%",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  safeAreaViewStyle: {
    color: Colors.white,
    flex: 0,
    backgroundColor: Colors.linearColor1,
  },
});
