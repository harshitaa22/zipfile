import React, { useEffect } from "react";
import { Image, Text } from "react-native";
import styles from "./style";
import { SmartBAppIcon } from "../../theme/svg";
import Colors from "../../theme/colors";
import LinearGradient from "react-native-linear-gradient";
import { NAVIGATION } from "../../navigation/index";
import { useNavigation } from "@react-navigation/native";
import AppSafeAreaView from "../../component/AppSafeAreaView";
import AppStatusBar from "../../component/AppStatusBar";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Constant } from "../../utils";
import { useDispatch } from "react-redux";
import { showToast } from "../../utils/commonFunction";
import { translate } from "../../utils/Localize";
import { print_data } from "../../utils/Logs";
import API_CONFIG from "../../api/api_url";
import { callApi } from "../../api";
import { Images } from "../../theme";

const SplashScreen = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();

  useEffect(() => {
    callGeoLocationAPi();
    // redirectToHome();
  }, []);

  const redirectToHome = async () => {
    AsyncStorage.getItem(Constant.SAVE_TOKEN).then((response) => {
      if (response != null) {
        let userSaveTokendata = JSON.parse(response);
        dispatch({
          type: Constant.SAVE_TOKEN,
          payload: JSON.stringify(userSaveTokendata),
        });
        navigation.replace(NAVIGATION.TAB_STACK);
      } else {
        navigation.replace(NAVIGATION.TAB_STACK);
      }
    });
  };

  const callGeoLocationAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GEOLOCATION,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          if (response?.body?.data?.data?.country_code === "AU") {
            redirectToHome();
          } else {
            navigation.navigate(NAVIGATION.GEOLOCATION);
          }
        } else {
          setTimeout(() => {
            showToast(translate("SomethingWrong"));
          }, 10);
        }
      } else {
        setTimeout(() => {
          showToast(translate("SomethingWrong"));
        }, 10);
      }
    } catch (error) {
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
      print_data("=====exception=====" + error);
    }
  };

  return (
    <AppSafeAreaView
      firstSafeAreaViewStyle={styles.safeAreaViewStyle}
      backgroundColor={Colors.linearColor2}
    >
      <AppStatusBar
        backgroundColor={Colors.linearColor1}
        isTransperent={false}
        barStyle={"light-content"}
      />
      <LinearGradient
        colors={[Colors.linearColor1, Colors.linearColor2]}
        style={styles.mainContainer}
      >
        {/* <SmartBAppIcon style={styles.svgIconStyle} /> */}

        <Image source={Images.splashLogo} style={styles.svgIconStyle} />
        {/* <SvgUri uri={Images.splashLogo} width={1000} height={396} /> */}
      </LinearGradient>
    </AppSafeAreaView>
  );
};

export default SplashScreen;
