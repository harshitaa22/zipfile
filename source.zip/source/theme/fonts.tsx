const Fonts = {
  IN_Regular: "Inter-Regular",
  IN_Bold: "Inter-Bold",
  IN_Medium: "Inter-Medium",
  IN_SemiBold: "Inter-SemiBold",
  VENEER_CLEAN_SOFT: "VeneerClean-Soft",
};
export default Fonts;
