import AppTranslations from "./translations.json";

export const de = {
  ...AppTranslations,
};
