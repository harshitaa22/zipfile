import AppTranslations from "./translations.json";

export const en = {
  ...AppTranslations,
};
