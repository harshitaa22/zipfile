import UserDataReducer from "./userDataReducer";
import { combineReducers } from "redux";
import { createStore } from "redux";

const AppReducers = combineReducers({
  UserDataReducer,
});
const RootReducer = (state, action) => {
  return AppReducers(state, action);
};
const store = createStore(RootReducer);
export default store;
