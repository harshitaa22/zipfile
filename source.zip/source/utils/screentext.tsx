export const ScreenText = {
  Smart: `
    <p style=
     "color:#FC4714;font-size:31px;
      font-family:Inter;"
      >
      SMARTB
   </p>`,

  SmartBTitle: `
    <p style=
     "color:#191919;font-size:31px;font-family:Inter;"
      >
    FOR SMARTER BETS
   </p>`,

  SmartBMessageOne: `
    <p style=
     "color:#191919;font-size:16px;font-family:Inter;"
      >
     It looks like you've come to a page that isn't quite ready yet.
     <b style="color:#003764">We are building it and it will be available soon.</b>
   </p>`,

  SmartBMessageThree: `
    <p style=
     "color:#191919;font-size:16px;font-family:Inter;"
      >
       Make sure you follow our social media channels so you can see new features when we add them.
      <b style="color:#FC4714">SmartB</b> will soon display comparisons and information for all sports around the world.
   </p>`,
};
