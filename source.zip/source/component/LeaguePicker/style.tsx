import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  modal: {
    margin: Metrics.rfv(0),
    justifyContent: "flex-end",
  },
  dialogCancelTextStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    alignSelf: "flex-end",
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(10),
  },
  pickerDoneTextStyle: {
    backgroundColor: Colors.lightGrayColor,
    justifyContent: "center",
  },
  commonFlex: {
    flex: 1,
  },
  dateDialogStyle: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-between",
    zIndex: Metrics.rfv(5),
    padding: Metrics.rfv(10),
    backgroundColor: Colors.white,
  },
  background: {
    width: "100%",
    backgroundColor: Colors.white,
  },
  wheelPickerStyle: {
    width: "100%",
    height: Metrics.rfv(180),
  },
});
