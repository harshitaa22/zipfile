import { Platform, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  modalView: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
    margin: Metrics.rfv(0),
    backgroundColor: Colors.dialogBack,
  },
  dataPicker: {
    backgroundColor: Colors.white,
    width: Metrics.rfv(450),
  },
  dialogDoneStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    marginHorizontal: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
    paddingVertical: Metrics.rfv(10),
  },

  dialogCancelStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(18),
    marginHorizontal: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
  },
  dateView: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.borderGrey,
    justifyContent: "space-between",
    backgroundColor: Colors.cream,
    width: "100%",
  },
  datePickerStyle: {
    height: Metrics.rfv(44),
    backgroundColor: Colors.white,
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    width: "95%",
    padding: 0,
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    marginTop: Metrics.rfv(5),
    alignSelf: "center",
  },
  width: {
    width: "100%",
  },
});
