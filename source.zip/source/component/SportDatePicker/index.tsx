import { View, Text, Pressable } from "react-native";
import React, { useState } from "react";
import Modal from "react-native-modal";
import styles from "./style";
import { translate } from "../../utils/Localize";
import DatePicker from "react-native-date-picker";
import moment from "moment";
import { Colors, Metrics } from "../../theme";
import CustomTextInput from "../TextInput";
import commonStyles from "../../theme/commonStyle";

const SportDatePicker = () => {
  const [isShowDatePicker, showDatePicker] = useState(false);
  const [getUTCDate, setGetUTCDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);

  return (
    <>
      <Modal
        isVisible={isShowDatePicker}
        onBackButtonPress={() => showDatePicker(false)}
        testID={"modal"}
        style={styles.modalView}
        onBackdropPress={() => {
          showDatePicker(false);
        }}
      >
        <View style={styles.dateView}>
          <Pressable
            onPress={() => {
              showDatePicker(false);
            }}
          >
            <Text style={[styles.dialogCancelStyle]}>
              {translate("Cancel")}
            </Text>
          </Pressable>

          <Pressable
            onPress={() => {
              if (getUTCDate) {
                setSelectedDate(moment(getUTCDate).format("DD/MM/YYYY"));

                showDatePicker(false);
              } else {
                showDatePicker(false);
              }
            }}
          >
            <Text style={[styles.dialogDoneStyle]}>{translate("Done")}</Text>
          </Pressable>
        </View>
        <View>
          <DatePicker
            style={styles.dataPicker}
            mode={"date"}
            textColor={Colors.black}
            date={getUTCDate ? getUTCDate : new Date()}
            onDateChange={(date) => {
              setGetUTCDate(date);
            }}
          />
        </View>
      </Modal>
      <Pressable
        style={styles.width}
        onPress={() => {
          showDatePicker(true);
        }}
      >
        {/* <CustomTextInput
          editable={false}
          textInputStyle={styles.textInputStyle}
          backgroundColor={Colors.white}
          placeholderText={translate("RoundThree")}
          width={Metrics.rfp(45)}
          borderColor={Colors.validationBorder}
          inputTextStyle={styles.inputTextStyle}
          dropDown={true}
          onChangeText={(text: string) => {
            setSelectedDate(text);
          }}
          placeholderTextColor={Colors.black}
          onPressWheelPicker={() => showDatePicker(true)}
          value={selectedDate}
          returnKeyType="next"
          placeholder={translate("DatePickerPlaceHolder")}
          activeOpacity={1}
        /> */}

        <CustomTextInput
          editable={false}
          textInputStyle={commonStyles.datePickerTextInputStyle}
          backgroundColor={Colors.white}
          placeholderText={translate("DatePickerPlaceHolder")}
          width={Metrics.rfp(45)}
          borderColor={Colors.validationBorder}
          inputTextStyle={styles.datePickerStyle}
          placeholderTextColor={Colors.lightGrayBoxGray}
          onChangeText={(text: string) => {
            setSelectedDate(text);
          }}
          value={selectedDate}
          datePickerVisibleBlue={true}
          datePickerPress={() => showDatePicker(true)}
          returnKeyType="next"
          placeholder={translate("DatePickerPlaceHolder")}
          activeOpacity={1}
        />
      </Pressable>
    </>
  );
};

export default SportDatePicker;
