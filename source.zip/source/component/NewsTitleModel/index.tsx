import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";
import { translate } from "../../utils/Localize";
import styles from "./style";
import Modal from "react-native-modal";
import { Platform } from "react-native";
import { WheelPicker } from "react-native-wheel-picker-android";
import { Metrics } from "../../theme";
import { Picker } from "@react-native-picker/picker";

export default function LeaguePicker(props: any) {
  const wheelPickerData = [
    translate("AdaminabyName"),
    translate("NewsPickerText"),
    translate("AlburyPickerText"),
    translate("ArmidaleText"),
    translate("BallinaText"),
  ];

  const [isModalVisible, setIsModalVisible] = useState(props.isVisible);
  const [selctedIndex, setIsSelectedIndex] = useState(0);
  const [isSelectedTextPicker, setIsSelectedTextPicker] = useState(
    wheelPickerData[0]
  );

  useEffect(() => {
    setIsModalVisible(props.isVisible);
  }, [props.isVisible]);

  const onCloseModal = (buttonType: number) => {
    if (props.showModel !== null) {
      props.showModel(false);
    } else {
      setIsModalVisible(false);
    }
    if (buttonType == 1) {
      const selectedData = {
        id: selctedIndex + 1,
        title:
          Platform.OS == "android"
            ? wheelPickerData[selctedIndex]
            : isSelectedTextPicker,
      };
      props.onItemSelect(selectedData);
    }
  };
  return (
    <Modal
      isVisible={isModalVisible}
      onBackButtonPress={() => onCloseModal(0)}
      testID={"modal"}
      style={styles.modal}
      onBackdropPress={() => {
        onCloseModal(0);
      }}
    >
      <View style={styles.pickerDoneTextStyle}>
        <Text
          style={[styles.dialogCancelTextStyle]}
          onPress={() => onCloseModal(1)}
        >
          {translate("ModalDonePicker")}
        </Text>
      </View>

      <View style={styles.dateDialogStyle}>
        <View style={styles.commonFlex}>
          {Platform.OS === "android" ? (
            <WheelPicker
              initPosition={selctedIndex}
              data={wheelPickerData}
              onItemSelected={(item) => setIsSelectedIndex(item)}
              selectedItemTextSize={Metrics.rfv(20)}
              itemTextSize={Metrics.rfv(20)}
              style={styles.wheelPickerStyle}
            />
          ) : (
            <Picker
              selectedValue={isSelectedTextPicker}
              style={styles.background}
              onValueChange={(item, index) => {
                setIsSelectedTextPicker(item);
                setIsSelectedIndex(index);
              }}
            >
              {wheelPickerData.map((item) => (
                <Picker.Item label={item} value={item} key={item} />
              ))}
            </Picker>
          )}
        </View>

        <View />
      </View>
    </Modal>
  );
}
