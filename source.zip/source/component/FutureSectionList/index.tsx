import React, { useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import styles from "./style";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../navigation";
import { translate } from "../../utils/Localize";

export default function FuturesRacingSectionList(props: any) {
  const navigation = useNavigation();

  const onItemClick = (item) => {
    navigation.navigate(NAVIGATION.FUTURE_RACE, { name: item?.event });
  };

  const renderFuturesItem = (item, index) => {
    return (
      <>
        <Pressable
          style={styles.itemViewStyle}
          onPress={() => {
            onItemClick(item);
          }}
        >
          <View style={styles.commonRow}>
            <View style={styles.itemView}>
              <Text style={styles.locationText}>{item?.date}</Text>
              <Text style={styles.locationText}>{item?.location}</Text>
            </View>
            <View style={styles.separatorWidth} />
            <View style={styles.eventView}>
              <Text style={styles.locationText}>{item?.event}</Text>
            </View>
          </View>
          <View style={styles.separator} />
        </Pressable>
      </>
    );
  };
  return (
    <View style={styles.itemViewStyle}>
      <View style={styles.commonRow}>
        <Text style={styles.dateText}>{translate("Date/Location")}</Text>
        <Text style={styles.eventText}>{translate("Event")}</Text>
      </View>
      <View style={styles.separator} />
      <FlatList
        scrollEnabled={false}
        data={props?.listData}
        showsVerticalScrollIndicator={false}
        renderItem={({ item, index }) => renderFuturesItem(item, index)}
        keyExtractor={(item, index) => index.toString()}
        extraData={props?.listData}
      />
    </View>
  );
}
