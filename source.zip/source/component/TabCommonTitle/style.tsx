import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  commonRow: {
    marginTop: Metrics.rfv(8),
  },
  detailsText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    marginBottom: Metrics.rfv(5),
  },
  subTitleText: {
    color: Colors.LoremText,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
  },
});
