import React from "react";
import { Text, View } from "react-native";

import styles from "./style";

export default function TabCommonTitle(props: any) {
  return (
    <View style={styles.commonRow}>
      <Text style={styles.detailsText}>{props?.title}</Text>
      {props?.subTitle && (
        <Text style={styles.subTitleText}>{props?.subTitle}</Text>
      )}
    </View>
  );
}
