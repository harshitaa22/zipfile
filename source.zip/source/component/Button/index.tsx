import React from "react";
import { GestureResponderEvent, Pressable, Text, View } from "react-native";
import { Colors, Metrics } from "../../theme/index";
import styles from "./style";

type ButtonProps = {
  onPress?: (event: GestureResponderEvent) => void;
  title?: string;
  disabled?: boolean;
  backgroundColor: any;
  fontSize?: number;
  color?: string;
  width?: number;
  height?: number;
  borderColor?: string;
  marginTop?: number;
  borderRadius?: number;
};

export default function Button(props: ButtonProps) {
  const {
    onPress,
    disabled = true,
    backgroundColor = "",
    width = Metrics.rfv(45),
    height = Metrics.rfv(45),
    fontSize = Metrics.rfv(0),
    borderColor = Colors.appColor,
    marginTop = Metrics.rfv(25),
    title = "",
    color = "",
    borderRadius = Metrics.rfv(10),
  } = props;

  return (
    <View>
      <Pressable
        onPress={onPress}
        disabled={disabled}
        style={[
          styles.buttonStyle,
          {
            height: height,
            backgroundColor: backgroundColor,
            borderRadius: borderRadius,
            borderColor: borderColor,
            marginTop: marginTop,
          },
        ]}
      >
        <Text
          style={[{ fontSize: fontSize, color: color }, styles.buttonTextStyle]}
        >
          {title}
        </Text>
      </Pressable>
    </View>
  );
}
