import { StyleSheet } from "react-native";
import { Metrics, Fonts } from "../../theme/index";

export default StyleSheet.create({
  buttonStyle: {
    width: "100%",
    height: Metrics.rfv(52),
    justifyContent: "center",
    alignItems: "center",
    borderWidth: Metrics.rfv(1),
  },
  buttonTextStyle: {
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
});
