import React, { useEffect, useState } from "react";
import { FlatList, Pressable, Text, TextInput, View } from "react-native";
import { translate } from "../../utils/Localize";
import styles from "./style";
import Modal from "react-native-modal";
import { Colors, Metrics } from "../../theme";
import commonStyles from "../../theme/commonStyle";
import { StatisticsSearchIcon } from "../../theme/svg";
import Button from "../Button";

export default function SportModel(props: any) {
  const [isModalVisible, setIsModalVisible] = useState(props.isVisible);

  useEffect(() => {
    setIsModalVisible(props.isVisible);
  }, [props.isVisible]);

  const onCloseModal = () => {
    if (props.showModel !== null) {
      props.showModel(false);
    } else {
      setIsModalVisible(false);
    }
  };

  return (
    <Modal
      isVisible={isModalVisible}
      onBackButtonPress={() => onCloseModal()}
      testID={"modal"}
      style={styles.modal}
      onBackdropPress={() => onCloseModal()}
    >
      <View style={styles.dialogStyle}>
        <View style={commonStyles.commonFlex}>
          {props?.isSearchVisible && (
            <View style={styles.serchContainerStyle}>
              <StatisticsSearchIcon style={styles.searchIconStyle} />
              <TextInput
                style={styles.searchTextinputStyle}
                placeholder={translate("SearchLeagues")}
                placeholderTextColor={Colors.lightGray}
                numberOfLines={1}
                value={props.search}
                onChangeText={props.onchangeText}
                returnKeyType={"done"}
              />
            </View>
          )}

          <FlatList
            data={props.data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => props.renderItem(item, index)}
            keyExtractor={(item, index) => index.toString()}
          />
          <View style={styles.bottomWidth} />
          <View style={styles.commonRow}>
            <View style={commonStyles.commonFlex}>
              <Button
                marginTop={0}
                disabled={false}
                onPress={props.onPressBack}
                title={translate("Cancel")}
                borderColor={Colors.linearColor2}
                color={Colors.linearColor2}
                fontSize={Metrics.rfv(14)}
                backgroundColor={Colors.white}
              />
            </View>
            <View style={styles.gapViewStyle} />
            <View style={commonStyles.commonFlex}>
              <Button
                marginTop={0}
                disabled={false}
                onPress={props.onNextPress}
                title={translate("Next")}
                borderColor={Colors.white}
                color={Colors.white}
                fontSize={Metrics.rfv(14)}
                backgroundColor={Colors.linearColor2}
              />
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
}
