import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../theme";

export default StyleSheet.create({
  modal: {
    justifyContent: "center",
    alignItems: "center",
    margin: Metrics.rfv(0),

    paddingHorizontal: Metrics.rfv(15),
  },
  dialogCancelTextStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    alignSelf: "flex-end",
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(10),
  },
  pickerDoneTextStyle: {
    backgroundColor: Colors.lightGrayColor,
    justifyContent: "center",
  },
  commonFlex: {
    flex: 1,
  },
  dateDialogStyle: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-between",
    zIndex: Metrics.rfv(5),
    padding: Metrics.rfv(10),
    backgroundColor: Colors.white,
  },
  background: {
    width: "100%",
    backgroundColor: Colors.white,
  },
  wheelPickerStyle: {
    width: "100%",
    height: Metrics.rfv(180),
  },

  dateView: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.borderGrey,
    justifyContent: "space-between",
    backgroundColor: Colors.cream,
    width: "100%",
  },
  dialogCancelStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(18),
    marginHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
  },
  dialogDoneStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(15),
    marginHorizontal: Metrics.rfv(10),
    margin: Metrics.rfv(4),
    fontFamily: Fonts.IN_Regular,
  },
  dataPicker: {
    backgroundColor: Colors.white,
    width: Metrics.rfv(600),
  },
  commonRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },

  serchContainerStyle: {
    height: Metrics.rfv(45),
    borderColor: Colors.drownDownBackground,
    borderWidth: Metrics.rfv(0.5),
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: Metrics.rfv(10),
    backgroundColor: Colors.white,
  },
  searchIconStyle: {
    width: Metrics.rfv(20),
    height: Metrics.rfv(20),
  },
  searchTextinputStyle: {
    flex: 1,
    marginLeft: Metrics.rfv(10),
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  dropDownContainerStyle: {
    backgroundColor: Colors.lightblue,
    width: "100%",
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    top: Metrics.rfv(-7),
    textAlign: "center",
    position: "relative", // It was absolute
  },
  contryContainer: {
    zIndex: Metrics.rfv(2000),
  },
  dropDownStyleRed: {
    width: "100%",
    backgroundColor: Colors.lightblue,
  },
  dropDownStyleWhite: {
    height: Metrics.rfv(44),
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    marginTop: Metrics.rfv(5),
    backgroundColor: Colors.lightblue,
    width: "100%",
    marginBottom: Metrics.rfv(5),
    padding: 0,
  },
  signUpAgeStyle: {
    fontSize: Metrics.rfv(11),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    color: Colors.lightGrayBoxGray,
  },
  selectedItemContainerStyle: {
    backgroundColor: Colors.lightGray,
    color: Colors.white,
  },
  dropDownPlaceholder: {
    color: Colors.placeholder,
  },
  labelSelectStyle: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    color: Colors.white,
  },
  dialogStyle: {
    flexDirection: "row",
    width: "100%",

    height: Metrics.rfv(400),
    paddingVertical: Metrics.rfv(15),
    paddingHorizontal: Metrics.rfv(15),
    justifyContent: "center",
    // padding: Metrics.rfv(10),
    borderRadius: Metrics.rfv(5),
    backgroundColor: Colors.white,
  },

  selectedItem: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
    backgroundColor: Colors.cream,
    borderRadius: Metrics.rfv(10),
  },
  labelText: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(15),
  },
});
