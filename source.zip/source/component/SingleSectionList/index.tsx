import React, { useState } from "react";
import { FlatList, Pressable, Text } from "react-native";
import styles from "./style";

type SectionRoundListProps = {
  raceTrackData?: [];
  onTrackSelected?:any;
  selectedRaceID?:string;
};

export default function SectionRoundList(props: SectionRoundListProps) {
  const {raceTrackData,selectedRaceID}=props
  const [selectedID, setSelectedID] = useState(selectedRaceID);

  const onTabClick = (item) => {
    setSelectedID(item?.id);
      props.onTrackSelected(item)
  };

  const renderItem = (item) => {
    return (
      <Pressable
        onPress={() => onTabClick(item)}
        style={
          item?.id === selectedID
            ? styles.raceTabTextSelectedTrue
            : styles.raceTabTextSelectedFalse
        }
      >
        <Text
          style={
            item?.id === selectedID
              ? styles.racingTabTextTrue
              : styles.racingTabTextFalse
          }
        >
          {item?.raceNumber}
        </Text>
      </Pressable>
    );
  };

  return (
    <FlatList
      data={raceTrackData}
      horizontal={true}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.contentContainerStyle}
      renderItem={({ item, index }) => renderItem(item)}
      keyExtractor={(item, index) => index.toString()}
    />
  );
}
