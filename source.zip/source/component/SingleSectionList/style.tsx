import { Platform, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  raceTabTextSelectedTrue: {
    width: Metrics.rfv(34),
    height: Metrics.rfv(34),
    borderRadius: Metrics.rfv(17),
    borderColor: Colors.linearColor1,
    borderWidth: Metrics.rfv(1),
    backgroundColor: Colors.linearColor2,
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal:Metrics.rfv(3),
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
  },
  raceTabTextSelectedFalse: {
    width: Metrics.rfv(34),
    height: Metrics.rfv(34),
    borderRadius: Metrics.rfv(17),
    borderColor: Colors.linearColor1,
    borderWidth: Metrics.rfv(1),
    backgroundColor: Colors.white,
    marginHorizontal:Metrics.rfv(3),
    alignItems: "center",
    justifyContent: "center",
    color: Colors.black,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
  },
  contentContainerStyle: {
    paddingHorizontal: Metrics.rfv(10),
  },
  racingTabTextTrue: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    margin: Metrics.rfv(1),
    fontFamily: Fonts.IN_SemiBold,
    padding: Platform.OS === "ios" ? Metrics.rfv(4) : 0,
    textAlign: "center",
  },
  racingTabTextFalse: {
    color: Colors.linearColor1,
    fontSize: Metrics.rfv(12),
    margin: Metrics.rfv(1),
    fontFamily: Fonts.IN_SemiBold,
    padding: Platform.OS === "ios" ? Metrics.rfv(4) : 0,
    textAlign: "center",
  },
});
