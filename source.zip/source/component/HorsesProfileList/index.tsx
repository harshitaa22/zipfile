import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import { NAVIGATION } from "../../navigation";
import styles from "./style";

export default function HorsesProfileList(props: any) {
  const [data] = useState(props.data);
  const navigation = useNavigation();

  const renderItem = (item: any, index: any) => {
    return (
      <Pressable style={styles.container} onPress={props.onClick}>
        {index == 0 ? null : <View style={styles.bottomWidth} />}
        <Pressable
          onPress={() =>
            navigation.navigate(NAVIGATION.HORSES_TAB, {
              listTitle: item?.listTitle,
            })
          }
        >
          <Text style={styles.listTitle}>{item?.listTitle}</Text>
        </Pressable>
        <View style={styles.containerView}>
          <View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>{item?.nextRace}</Text>
              <Text style={styles.detailsText}>{item?.date}</Text>
            </View>
            <Text style={styles.nextRaceText}>{item?.caulifield}</Text>
            <Text style={styles.detailsText}>{item?.shamus}</Text>
            <Text style={styles.detailsText}>{item?.distrustful}</Text>
          </View>
          <View style={styles.separateLine} />
          <View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>{item?.career}</Text>
              <Text style={styles.detailsText}>{item?.careerData}</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>{item?.earnings}</Text>
              <Text style={styles.detailsText}>{item?.earrningsData}</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>{item?.win}</Text>
              <Text style={styles.detailsText}>{item?.winData}</Text>
            </View>
            <View style={styles.commonRowContainer}>
              <Text style={styles.nextRaceText}>{item?.place}</Text>
              <Text style={styles.detailsText}>{item?.placeData}</Text>
            </View>
          </View>
        </View>
      </Pressable>
    );
  };
  return (
    <FlatList
      data={data}
      scrollEnabled={true}
      contentContainerStyle={styles.containerStyle}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    />
  );
}
