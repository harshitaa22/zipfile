import React, { useEffect, useState } from "react";
import { Image, Pressable, Text, View } from "react-native";
import { Colors, CommonStyle, Images } from "../../theme/index";
import { translate } from "../../utils/Localize";
import styles from "./style";
import {
  CloudIcon,
  DownBlueArrow,
  RainIcon,
  ShowerIcon,
  UpBlueArrow,
  WeatherIcon,
} from "../../theme/svg";
import moment from "moment";
import RaceCountDown from "../RaceDetailsCountDown";
import AddsCommonList from "../AddsCommonApi";

type CountryDetailsPageListProps = {
  raceData?: {};
};

export default function CountryDetailsPageList(
  props: CountryDetailsPageListProps
) {
  const { raceData } = props;
  const [raceCommentVisible, setRaceCommentVisible] = useState(false);

  const getWeatherIcon = (type) => {
    if (type === "showers") {
      return <ShowerIcon style={styles.weatherIconStyle} />;
    } else if (type === "Rain") {
      return <RainIcon style={styles.weatherIconStyle} />;
    } else if (type === "fine" || type === "FINE" || type === "Good") {
      return <WeatherIcon style={styles.weatherIconStyle} />;
    } else if (type === "Cloudy") {
      return <CloudIcon style={styles.weatherIconStyle} />;
    } else {
      return <WeatherIcon style={styles.weatherIconStyle} />;
    }
  };

  return (
    <View>
      <View style={styles.mainDetailsView}>
        <View style={CommonStyle.commonRow}>
          <Text style={styles.commonRightText}>{translate("Track")}</Text>
          <Text style={styles.commonRightFetchText}>
            {raceData?.trackCondition?.replace(/"/g, "")}
          </Text>
        </View>
        <View>
          {raceData?.Weather && raceData?.Weather?.weatherType ? (
            <View style={CommonStyle.alignCenterView}>
              <Text style={styles.commonRightText}>{translate("Weather")}</Text>

              <View style={styles.horizontalStyle}>
                {getWeatherIcon(raceData?.Weather?.weatherType)}
                <Text style={styles.commonRightFetchText}>
                  {" " + raceData?.Weather?.weatherType}
                </Text>
              </View>
            </View>
          ) : null}
        </View>
      </View>

      <View style={styles.separatorStyle} />

      <View style={styles.margin5}>
        <View style={styles.commonViewStyle}>
          <Text style={styles.raceTitle}>{raceData?.raceName}</Text>
          <View style={styles.commonRow}>
            <Text style={styles.commonRightFetchText}>
              {translate("Distance")}
            </Text>
            <Text style={styles.commonRightFetchText}>
              {" " + raceData?.Distance?.name + "m"}
            </Text>
          </View>
        </View>

        <View style={styles.commonViewStyle}>
          <View style={styles.jumpTimeCommonRow}>
            <Text style={styles.commonRightFetchText}>
              {translate("JumpTime")}
            </Text>
            <Text style={styles.commonRightFetchText}>
              {" "}
              {moment(moment().format("YYYY-MM-DD")).isSame(
                moment(raceData?.startTimeDate).format("YYYY-MM-DD")
              )
                ? moment.utc(raceData?.startTimeDate).local().format("hh:mm a")
                : moment
                    .utc(raceData?.startTimeDate)
                    .local()
                    .format("YYYY/MM/DD hh:mm a")}
            </Text>
          </View>

          <View style={styles.commonRow}>
            <Text style={styles.commonRightFetchText}>{translate("Time")}</Text>
            {raceData?.startTimeDate && (
              <RaceCountDown
                expiryTimestamp={new Date(raceData?.startTimeDate).getTime()}
              />
            )}
          </View>
        </View>
        {/* <View style={styles.commonViewStyle}> */}
        <Pressable
          onPress={() => setRaceCommentVisible(!raceCommentVisible)}
          style={styles.commonViewStyle}
        >
          <Text style={styles.commonRightFetchTextSemi}>
            {translate("RaceComments")}
          </Text>
          {raceCommentVisible ? (
            <UpBlueArrow color={Colors.black} style={styles.arrowStyle} />
          ) : (
            <DownBlueArrow color={Colors.black} style={styles.arrowStyle} />
          )}
        </Pressable>
        {/* </View> */}
        {raceCommentVisible && (
          <Text style={styles.commonRightFetchLoremText}>
            {raceData?.comment == "{}"
              ? translate("NoComment")
              : raceData?.comment
              ? raceData?.comment
              : translate("NoComment")}
          </Text>
        )}

        <View style={styles.separatorGrayStyle} />
        {raceData?.sportId == 1 && (
          <AddsCommonList
            AboveRunnerTable={"AboveRunnerTable"}
            page={3}
            placeholder={Images.sportFirstImg}
            bannerStyle={styles.secondBannerStyle}
          />
        )}
        {raceData?.sportId == 2 && (
          <AddsCommonList
            AboveRunnerTable={"AboveRunnerTable"}
            page={5}
            placeholder={Images.sportFirstImg}
            bannerStyle={styles.secondBannerStyle}
          />
        )}
        {raceData?.sportId == 3 && (
          <AddsCommonList
            AboveRunnerTable={"AboveRunnerTable"}
            page={4}
            placeholder={Images.sportFirstImg}
            bannerStyle={styles.secondBannerStyle}
          />
        )}
      </View>
    </View>
  );
}
