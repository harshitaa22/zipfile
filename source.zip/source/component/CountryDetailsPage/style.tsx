import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    lineHeight: Metrics.rfv(24),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  contentContainerStyle: {
    marginHorizontal: Metrics.rfv(18),
    flex: 1,
    marginTop: Metrics.rfv(25),
  },
  itemSeparatorComponent: {
    backgroundColor: Colors.gray,
    marginVertical: Metrics.rfv(15),
    height: Metrics.rfv(1),
  },
  arrowStyle: {
    height: Metrics.rfv(12),
    width: Metrics.rfv(12),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(15),
  },
  countryName: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(18),
    lineHeight: Metrics.rfv(24),
    fontFamily: Fonts.IN_SemiBold,
  },
  currentCountry: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_SemiBold,
  },
  currentInfo: {
    color: Colors.black,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_SemiBold,
    marginTop: Metrics.rfv(15),
  },
  mainDetailsView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: Metrics.rfv(10),
    marginHorizontal: Metrics.rfv(15),
  },
  separatorGrayStyle: {
    height: Metrics.rfv(1),
    backgroundColor: Colors.gray,
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(5),
  },
  commonViewStyle: {
    flexDirection: "row",
    marginTop: Metrics.rfv(5),
    marginBottom: Metrics.rfv(5),
    alignItems: "center",
  },
  separatorStyle: {
    height: Metrics.rfv(1),
    backgroundColor: Colors.linearColor2,
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(5),
  },
  margin5: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(10),
  },
  commonRightText: {
    color: Colors.black,
    marginRight: Metrics.rfv(5),
    fontSize: Metrics.rfv(10),
    lineHeight: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
  },
  commonRightFetchText: {
    color: Colors.black,
    fontSize: Metrics.rfv(10),
    lineHeight: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
  },
  imageStyle: {
    resizeMode: "contain",
  },
  commonRightFetchTextSemi: {
    color: Colors.black,
    fontSize: Metrics.rfv(11),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(13),
    // flex: 1,
  },
  raceTitle: {
    color: Colors.black,
    fontSize: Metrics.rfv(11),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(13),
    flex: 1,
  },
  commonRightFetchLoremText: {
    color: Colors.LoremText,
    fontSize: Metrics.rfv(10),
    lineHeight: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
  },
  weatherIconStyle: {
    height: Metrics.rfv(20),
    width: Metrics.rfv(20),
  },
  horizontalStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  commonRow: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  jumpTimeCommonRow: {
    flex: 1,
    flexDirection: "row",
  },
  secondBannerStyle: {
    width: "100%",
    height: Metrics.rfv(63),
    resizeMode: "contain",
  },
});
