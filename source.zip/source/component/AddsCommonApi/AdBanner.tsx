import { useNavigation } from "@react-navigation/core";
import React, { useState } from "react";
import { Dimensions, Image, Linking, Pressable, View } from "react-native";
import FastImage from "react-native-fast-image";
import WebView from "react-native-webview";
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import { NAVIGATION } from "../../navigation";
import { Images } from "../../theme";
import { print_data } from "../../utils/Logs";
import InViewport from "../ViewPortComponent/InView";

const AdBannner = ({ addetails, placeholder, bannerStyle, position }) => {
  const [isImpressionSubmitted, setIsImpressionSubmitted] = useState(false);
  const [isApiCalling, setApiCalling] = useState(false);
  const [aspectRatio, setAspectRatio] = useState(0.6);
  const [defaultHeight, setDefaultHeight] = useState(100);
  const navigation = useNavigation();
  const width = Dimensions.get("window").width;

  const checkVisibility = (isVisible) => {
    print_data("");
    if (isVisible && !isImpressionSubmitted && !isApiCalling && position) {
      print_data(position + "position=====");
      setApiCalling(true);
      handleAdsImression();
    }
  };

  const handleAdsImression = async () => {
    var param_data = {
      ids: [addetails?.id],
    };
    try {
      const response = await callApi(
        API_CONFIG.ADDIMPRESSION,
        param_data,
        API_CONFIG.POST,
        null
      );
      print_data("impression=======");
      print_data(response);
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          setApiCalling(false);
          setIsImpressionSubmitted(true);
        }
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const onBannerClick = async (id, addetails) => {
    var param_data = {
      id: id,
    };
    try {
      const response = await callApi(
        API_CONFIG.ADDCLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.success == true
        ) {
          Linking.openURL(addetails?.url);
        }
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const onLoadMethod = (e) => {
    if (e) {
      const aspectRatio =
        parseInt(e?.nativeEvent?.height) / parseInt(e?.nativeEvent?.width);

      setDefaultHeight(width * aspectRatio);
      setAspectRatio(aspectRatio);
    }
  };
  if (addetails) {
    const html = addetails?.text;

    return addetails?.type === "image" && addetails?.filePath !== "" ? (
      <InViewport onChange={(isVisible) => checkVisibility(isVisible)}>
        <Pressable
          onPress={() => {
            onBannerClick(addetails?.id, addetails);
            // Linking.openURL(addetails?.url);
          }}
        >
          {addetails?.position_id == 0 ? (
            <View style={{ height: defaultHeight, marginBottom: 10 }}>
              <FastImage
                source={{
                  uri: API_URL + "/" + addetails?.filePath,
                }}
                style={[
                  {
                    width: width,
                    height: width * aspectRatio,
                  },
                ]}
                onLoad={(e) => onLoadMethod(e)}
                resizeMode={"contain"}
              />
            </View>
          ) : (
            <>
              {addetails?.position_id == 2 ? (
                <View style={{ height: defaultHeight, marginBottom: 10 }}>
                  <FastImage
                    source={{
                      uri: API_URL + "/" + addetails?.filePath,
                    }}
                    style={[
                      {
                        width: "100%",
                        height: width * aspectRatio,
                      },
                    ]}
                    onLoad={(e) => onLoadMethod(e)}
                    resizeMode={"contain"}
                  />
                </View>
              ) : (
                <View style={{ height: defaultHeight, marginBottom: 10 }}>
                  {/* <ImageLoad
            resizeMode={"contain"}
            // style={bannerStyle}
            style={[
              {
                width: width,
                height: width * aspectRatio,
              },
            ]}
            source={API_URL + "/" + addetails?.filePath}
          /> */}
                  <FastImage
                    source={{
                      uri: API_URL + "/" + addetails?.filePath,
                    }}
                    style={[
                      {
                        width: width - 30,
                        height: (width - 30) * aspectRatio,
                      },
                      // bannerStyle,
                    ]}
                    onLoad={(e) => onLoadMethod(e)}
                    resizeMode={"contain"}
                  />
                </View>
              )}
            </>
          )}
        </Pressable>
      </InViewport>
    ) : addetails?.type === "script" ? (
      <InViewport onChange={(isVisible) => checkVisibility(isVisible)}>
        <Pressable
          onPress={() => {
            Linking.openURL(addetails?.url);
          }}
        >
          <WebView
            javaScriptEnabled={true}
            originWhitelist={["*"]}
            mixedContentMode="always"
            // source={{
            //   html: `<script>
            //   alert("ok")
            // </script>`,
            // }}
            style={{ width: "100%", height: 60 }}
            source={{ html }}
          />
        </Pressable>
      </InViewport>
    ) : (
      <Pressable
        onPress={() => {
          navigation.navigate(NAVIGATION.ADVERTISING);
        }}
      >
        <Image
          source={placeholder}
          style={bannerStyle}
          onLoad={(e) => onLoadMethod(e)}
        />
      </Pressable>
    );
  } else {
    return (
      <Pressable
        onPress={() => {
          navigation.navigate(NAVIGATION.ADVERTISING);
        }}
      >
        <Image
          source={Images.adBannerIcon}
          style={bannerStyle}
          onLoad={(e) => onLoadMethod(e)}
        />
      </Pressable>
    );
  }
};

export default AdBannner;
