import { StyleSheet } from "react-native";
import { Metrics } from "../../theme/index";

export default StyleSheet.create({
  imageCommonStyle: {
    width: Metrics.rfv(45),
    height: Metrics.rfv(45),
    marginLeft: Metrics.rfp(5),
    margin: Metrics.rfv(15),
  },
  imageCommonRightStyle: {
    width: Metrics.rfv(45),
    height: Metrics.rfv(45),
  },
  imageCommonLeftStyle: {
    width: "100%",
    height: Metrics.rfv(100),
    marginTop: Metrics.rfv(2),
    resizeMode: "contain",
  },
  bannerStyle: {
    // width: Dimensions.get("window").width,
    width: "100%",
    resizeMode: "contain",
  },
  defaultBanner: {
    width: "100%",
    height: Metrics.rfv(50),
  },
});
