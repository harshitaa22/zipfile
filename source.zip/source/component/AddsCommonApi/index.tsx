import React, { useEffect, useState } from "react";
import { View } from "react-native";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import { print_data } from "../../utils/Logs";
import AdBannner from "./AdBanner";

export default function AddsCommonList(props: any) {
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  // const options = { timeZone: "Asia/Calcutta" };
  // const resolvedOptions = Intl.DateTimeFormat(
  //   undefined,
  //   options
  // ).resolvedOptions();
  // let timezone = resolvedOptions.timeZone;
  // console.log(resolvedOptions.timeZone);

  // let dStr=timezone.toLocaleString("en-US", {timeZone: "Asia/Kolkata"})
  const [adData, setAdData] = useState([]);
  const [callApiVisible, setCallApiVisible] = useState(false);
  useEffect(() => {
    setCallApiVisible(true);
    callAddsAPi();
  }, []);

  const fetchAds = (position) => {
    if (!callApiVisible) {
      if (adData?.length > 0) {
        let ad = adData?.filter((item) => {
          return item?.position_id === position;
        });

        if (ad?.length > 0) {
          return (
            <AdBannner
              position={position}
              // adId={adId}
              addetails={ad?.[0]}
              placeholder={props.placeholder}
              bannerStyle={props.bannerStyle}
            />
          );
        } else {
          return (
            <AdBannner
              // adId={adId}
              addetails={[]}
              placeholder={props.placeholder}
              bannerStyle={props.bannerStyle}
            />
          );
        }
      } else {
        return (
          <AdBannner
            // adId={adId}
            addetails={[]}
            placeholder={props.placeholder}
            bannerStyle={props.bannerStyle}
          />
        );
      }
    }
  };

  const callAddsAPi = async () => {
    try {
      const response = await callApi(
        API_CONFIG.ADDS +
          props.page +
          `&timeZone=${timezone}&Advertisetype=app`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.success == true
        ) {
          setAdData(response?.body?.data?.data?.[0]?.pageAdLists);
          setCallApiVisible(false);
        }
      }
    } catch (error) {
      print_data("=====exception=====" + error);
    }
  };

  return (
    <View>
      {props.topLongBanner && <View>{fetchAds(0)}</View>}
      {props.headerTopImage && <View>{fetchAds(0)}</View>}
      {props.AfterHeader && <View>{fetchAds(2)}</View>}
      {props.BeforeSports && <View>{fetchAds(3)}</View>}
      {/* {props.AboveSports && <View>{fetchAds(4)}</View>} */}
      {props.AboveEventList && <View>{fetchAds(2)}</View>}
      {props.AboveEventFirstList && <View>{fetchAds(3)}</View>}
      {props.belowFootball && <View>{fetchAds(props?.index + 101)}</View>}
      {props.SingleNewsPage && <View>{fetchAds(1)}</View>}
      {props.NewsPageCategory && <View>{fetchAds(1)}</View>}
      {props.AboveGreyhounds && <View>{fetchAds(3)}</View>}
      {props.AboveHarness && <View>{fetchAds(4)}</View>}
      {props.AboveHorses && <View>{fetchAds(2)}</View>}
      {props.AboveRunnerTable && <View>{fetchAds(2)}</View>}
      {props.BelowSlider && <View>{fetchAds(1)}</View>}
      {props.BelowTopStories && <View>{fetchAds(2)}</View>}
    </View>
  );
}
