import React, { useState } from "react";
import { TextInput, Text, View, Pressable } from "react-native";
import { Colors, Metrics } from "../../theme";
import {
  BlackDropDownArrow,
  DatePickerIcon,
  DatePickerRacingIcon,
  DownBlueArrow,
  EfitProfileDatePickerIcon,
  ErrorIcon,
  EyeHiddenIcon,
  EyeShowIcon,
} from "../../theme/svg";
import styles from "./style";

const CustomTextInput = React.forwardRef((props: any, ref) => {
  const [isPassVisible, setPassVisible] = useState(false);
  return (
    <View style={props.containerStyle}>
      {props.lableText && props.lableText?.length != 0 ? (
        <Text style={props.lableTextStyle}>
          {props.lableText}
          {props.extraLabel ? (
            <Text style={props.extraLabelTextStyle}>{props.extraLabel}</Text>
          ) : null}
        </Text>
      ) : null}

      <View
        style={[
          props.inputTextStyle,
          { flexDirection: "row", alignItems: "center" },
        ]}
      >
        <TextInput
          ref={ref}
          pointerEvents={props.pointerEvents}
          autoCorrect={false}
          autoCompleteType="off"
          style={[
            props.textInputStyle,
            {
              marginLeft: props.isCountryField ? 10 : 0,
            },
          ]}
          numberOfLines={props.numberOfLines}
          underlineColorAndroid={Colors.transparent}
          placeholder={props.placeholderText}
          placeholderTextColor={props.placeholderTextColor}
          maxLength={props.maxLength}
          editable={props.editable}
          value={props.value}
          secureTextEntry={
            props.secureTextEntry
              ? props.isPasswordField && isPassVisible
                ? false
                : true
              : false
          }
          keyboardType={props.keyboardType}
          onChangeText={(text) => {
            props.onChangeText(text);
          }}
          spellCheck={false}
          onSubmitEditing={props.onSubmitEditing}
          clearTextOnFocus={false}
          blurOnSubmit={false}
          returnKeyType={props.returnKeyType}
          multiline={props.multiLine}
          autoCapitalize={"none"}
        />

        {props.isPasswordField ? (
          <Pressable
            style={styles.eye_Touchable_style}
            onPress={() => setPassVisible(!isPassVisible)}
          >
            {isPassVisible ? (
              <EyeShowIcon
                style={styles.eye_icon_style}
                showFillColor={
                  props?.showFillColor ? props?.showFillColor : Colors.white
                }
              />
            ) : (
              <EyeHiddenIcon
                style={styles.eye_icon}
                fillColor={props.fillColor ? props.fillColor : Colors.white}
              />
            )}
          </Pressable>
        ) : null}

        {props.datePickerVisible && (
          <Pressable
            onPress={props.onPressDatePicker}
            activeOpacity={props.activeOpacity}
            style={styles.datePickerIcon}
          >
            <DatePickerIcon width={Metrics.rfv(19)} height={Metrics.rfv(19)} />
          </Pressable>
        )}

        {props.actionError && (
          <Pressable
            onPress={props.onPress}
            activeOpacity={props.activeOpacity}
            style={styles.eyeIcon}
          >
            <ErrorIcon width={Metrics.rfv(21)} height={Metrics.rfv(21)} />
          </Pressable>
        )}

        {props.datePickerVisibleBlue && (
          <Pressable
            onPress={props.datePickerPress}
            activeOpacity={props.activeOpacity}
            style={styles.eyeIcon}
          >
            <DatePickerRacingIcon style={styles.datePickerRacingIcon} />
          </Pressable>
        )}
        {props.datePickerProfileVisible && (
          <Pressable
            onPress={props.datePickerPress}
            activeOpacity={props.activeOpacity}
            style={styles.eyeIcon}
          >
            <EfitProfileDatePickerIcon style={styles.datePickervisibleIcon} />
          </Pressable>
        )}

        {props.dropDown && (
          <Pressable
            onPress={props.onPressWheelPicker}
            style={props.dropDownIconStyle}
          >
            <BlackDropDownArrow style={styles.dropIcon} />
          </Pressable>
        )}
        {props.racingDropDown && (
          <Pressable
            onPress={props.onPressWheelPicker}
            style={
              props.dropDownIconStyle
                ? props.dropDownIconStyle
                : styles.leftView
            }
          >
            <DownBlueArrow
              style={
                props?.dropDownStyle
                  ? props?.dropDownStyle
                  : styles.dropDownIcon
              }
            />
          </Pressable>
        )}
      </View>
    </View>
  );
});
export default CustomTextInput;
