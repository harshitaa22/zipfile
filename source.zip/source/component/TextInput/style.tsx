import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  textInput: {
    borderWidth: Metrics.rfv(2),
    height: Metrics.rfv(45),
    borderRadius: Metrics.rfv(8),
    paddingHorizontal: Metrics.rfv(12),
    fontSize: Metrics.rfv(16),
    backgroundColor: Colors.lightblue,
    borderColor: Colors.white,
    opacity: 0.8,
    placeholderTextColor: Colors.white,
    fontFamily: Fonts.IN_Regular,
  },
  commonMargin30: {
    margin: Metrics.rfv(30),
  },
  container: {
    backgroundColor: Colors.linearColor2,
    flex: 1,
  },
  outerView: {
    borderWidth: Metrics.rfv(2),
    height: Metrics.rfv(45),
    borderRadius: Metrics.rfv(8),
    paddingHorizontal: Metrics.rfv(12),
    flexDirection: "row",
  },
  eyeIcon: {
    // marginLeft: Metrics.rfv(-30),
    // justifyContent: "center",
    flex: 1,
    alignItems: "flex-end",
  },
  dropDown: {
    paddingLeft: Metrics.rfv(10),
    justifyContent: "center",
  },
  datePickerIcon: {
    flex: 1,
    alignItems: "flex-end",
  },
  eye_icon_style: {
    height: Metrics.rfv(18),
    width: Metrics.rfv(21),
  },
  eye_icon: {
    height: Metrics.rfv(20),
    width: Metrics.rfv(21),
    resizeMode: "contain",
  },
  eye_Touchable_style: {
    // height: Metrics.rfv(40),
    // width: Metrics.rfv(40),
    justifyContent: "center",
    alignItems: "center",
  },
  dropIcon: {
    width: Metrics.rfv(11),
    height: Metrics.rfv(7),
    resizeMode: "contain",
  },
  datePickerRacingIcon: {
    width: Metrics.rfv(19),
    height: Metrics.rfv(19),
    resizeMode: "contain",
  },
  datePickervisibleIcon: {
    width: Metrics.rfv(22),
    height: Metrics.rfv(22),
  },
  dropDownIcon: {
    width: Metrics.rfv(15),
    height: Metrics.rfv(8),
    resizeMode: "contain",
  },
  leftView: {
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(5),
  },
});
