import React, { useState } from "react";
import { FlatList, Text, View } from "react-native";
import { EmptyImage } from "../../theme/svg";
import styles from "./style";

export default function TrackNewsCommonList(props: any) {
  const [data] = useState(props.data);

  const renderItem = (item, index) => {
    return (
      <View>
        {index == 0 ? null : <View style={styles.bottomWidth} />}
        <Text style={styles.detailsText}>{item?.title}</Text>
        <EmptyImage style={styles.emptyImage} />
        <Text style={styles.subTitleText}>{item?.subTitle}</Text>
      </View>
    );
  };

  return (
    <FlatList
      data={data}
      scrollEnabled={false}
      contentContainerStyle={styles.containerStyle}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    />
  );
}
