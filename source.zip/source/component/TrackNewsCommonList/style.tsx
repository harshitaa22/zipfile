import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  detailsText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    marginBottom: Metrics.rfv(5),
  },
  subTitleText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
  },
  emptyImage: {
    height: Metrics.rfv(80),
    width: "100%",
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(4),
    marginBottom: Metrics.rfv(6),
  },
  containerStyle: {
    marginTop: Metrics.rfv(15),
    marginBottom: Metrics.rfv(20),
  },
});
