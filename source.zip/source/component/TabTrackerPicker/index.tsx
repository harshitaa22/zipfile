import React, { useState } from "react";
import { Text, View } from "react-native";
import DropDownPicker from "react-native-dropdown-picker";
import { Colors, Metrics } from "../../theme";
import { DownBlueArrow, UpBlueArrow } from "../../theme/svg";
import { translate } from "../../utils/Localize";

import styles from "./style";

export default function TabTrackerPicker(props: any) {
  const [titleOpen, setTitleOpen] = useState(false);
  const [selectedTitle, setSelectedTitle] = useState("");
  const [isDropDownBorder, setIsDropDownBorder] = useState(false);
  const [titleList, setTitleList] = useState([
    { label: "Adaminaby, NSW, Australia", value: "Adaminaby, NSW, Australia" },
    { label: "Ardlethan, NSW, Australia", value: "Ardlethan, NSW, Australia" },
    { label: "Albury, NSW, Australia", value: "Albury, NSW, Australia" },
    { label: "Armidale, NSW, Australia", value: "Armidale, NSW, Australia" },
    { label: "Ballina, NSW, Australia", value: "Ballina, NSW, Australia" },
  ]);

  return (
    <View style={styles.bgColorStyle}>
      <DropDownPicker
        textStyle={styles.labelSelectStyle}
        open={titleOpen}
        value={selectedTitle}
        labelStyle={styles.labelNewsStyle}
        items={titleList}
        scrollViewProps={{
          nestedScrollEnabled: true,
          showsVerticalScrollIndicator: false,
          showsHorizontalScrollIndicator: false,
        }}
        setOpen={(isOpen) => {
          setTitleOpen(isOpen);
        }}
        listMode="SCROLLVIEW"
        dropDownContainerStyle={styles.dropDownContainerStyle}
        setValue={setSelectedTitle}
        onChangeValue={(selectedTitle) => {}}
        setItems={setTitleList}
        dropDownDirection="BOTTOM"
        autoScroll={true}
        style={
          isDropDownBorder ? styles.dropDownStyleRed : styles.dropDownStyleWhite
        }
        placeholder={translate("AdaminabyName")}
        ArrowUpIconComponent={({}) => (
          <UpBlueArrow
            width={Metrics.rfv(15)}
            height={Metrics.rfv(10)}
            fill={Colors.black}
          />
        )}
        ArrowDownIconComponent={({}) => (
          <DownBlueArrow
            width={Metrics.rfv(15)}
            height={Metrics.rfv(10)}
            fill={Colors.black}
          />
        )}
        selectedItemContainerStyle={styles.selectedItemContainerStyle}
        placeholderStyle={styles.dropDownPlaceholder}
      />
    </View>
  );
}
