import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  titleTextStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    fontFamily: Fonts.IN_Regular,
    alignSelf: "flex-start",
    marginTop: Metrics.rfv(5),
  },
  labelSelectStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  labelNewsStyle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  dropDownContainerStyle: {
    backgroundColor: Colors.white,
    width: "70%",
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    top: Metrics.rfv(-7),
    position: "relative",
    color: Colors.black,
  },
  dropDownStyleRed: {
    width: "100%",
    backgroundColor: Colors.white,
  },
  dropDownStyleWhite: {
    borderWidth: Metrics.rfv(0),
    borderRadius: Metrics.rfv(7),
    marginTop: Metrics.rfv(10),
    backgroundColor: Colors.cream,
    width: "70%",
    marginBottom: Metrics.rfv(5),
    padding: 0,
  },
  selectedItemContainerStyle: {
    backgroundColor: Colors.gray,
    color: Colors.black,
  },
  dropDownPlaceholder: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  fullWidthStyle: {
    width: "100%",
  },
  bgColorStyle: {
    backgroundColor: Colors.cream,
  },
});
