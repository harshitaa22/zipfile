import React from "react";
import { SafeAreaView } from "react-native";

export default function AppSafeAreaView(props: any) {
  const {
    children = "",
    backgroundColor = "",
    firstSafeAreaViewStyle = {},
  } = props;
  return (
    <>
      <SafeAreaView style={firstSafeAreaViewStyle} />
      <SafeAreaView style={{ flex: 1, backgroundColor: backgroundColor }}>
        {children}
      </SafeAreaView>
    </>
  );
}
