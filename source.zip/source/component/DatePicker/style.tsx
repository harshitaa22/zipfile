import { StyleSheet } from "react-native";
import { Colors,Metrics, Fonts} from "../../theme";

export default StyleSheet.create({
    modal: {
        flex:1,
        justifyContent: "flex-end",
        alignItems: "center",
        margin: Metrics.rfv(0),
        backgroundColor:Colors.dialogBack
      },
      dateView: {
        flexDirection: "row",
        alignItems: "center",
        borderBottomWidth: Metrics.rfv(1),
        borderBottomColor: Colors.borderGrey,
        justifyContent: "space-between",
        backgroundColor: Colors.cream,
        width: "100%",
      },
      dialogCancelStyle: {
        color: Colors.doneText,
        fontSize: Metrics.rfv(15),
        lineHeight: Metrics.rfv(18),
        marginHorizontal: Metrics.rfv(10),
        paddingVertical:Metrics.rfv(10),
        fontFamily: Fonts.IN_Regular,
      },
      dialogDoneStyle: {
        color: Colors.doneText,
        fontSize: Metrics.rfv(15),
        marginHorizontal: Metrics.rfv(10),
        margin: Metrics.rfv(4),
        fontFamily: Fonts.IN_Regular,
      },
      dataPicker: {
        backgroundColor: Colors.white,
        width: Metrics.rfv(600),
      },
});
