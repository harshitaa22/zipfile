import React, { useEffect, useState } from "react";
import { Modal, Pressable, Text, View } from "react-native";
import { translate } from "../../utils/Localize";
import styles from "./style";
import { Colors } from "../../theme";
import DatePicker from "react-native-date-picker";

export default function DatePickerDialog(props) {
  const [isModalVisible, setIsModalVisible] = useState(props.isVisible);
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    setIsModalVisible(props.isVisible);
  }, [props.isVisible]);

  const handleContinuePress = (buttonType: number) => {
    if (props.showModel !== null) {
      props.showModel(false);
    } else {
      setIsModalVisible(false);
    }
    if (buttonType == 1) {
      props.onDateSelect(selectedDate);
    }
  };
  return (
    <Modal
      visible={isModalVisible}
      transparent={true}
      onRequestClose={() => handleContinuePress(0)}
    >
      <View style={styles.modal}>
        <View style={styles.dateView}>
          <Pressable onPress={() => handleContinuePress(0)}>
            <Text style={styles.dialogCancelStyle}>{translate("Cancel")}</Text>
          </Pressable>

          <Pressable onPress={() => handleContinuePress(1)}>
            <Text style={[styles.dialogDoneStyle]}>{translate("Done")}</Text>
          </Pressable>
        </View>
        <View>
          <DatePicker
            style={styles.dataPicker}
            mode={"date"}
            maximumDate={props.tabIndex == 9 ? new Date() : null}
            minimumDate={props.tabIndex == 8 ? new Date() : null}
            textColor={Colors.black}
            date={selectedDate ? selectedDate : new Date()}
            onDateChange={(date) => {
              setSelectedDate(date);
            }}
          />
        </View>
      </View>
    </Modal>
  );
}
