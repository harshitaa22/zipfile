import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  detailsText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    marginBottom: Metrics.rfv(5),
  },
  subTitleText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
  emptyImage: {
    height: Metrics.rfv(80),
    width: "100%",
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(8),
    marginBottom: Metrics.rfv(8),
  },
  containerStyle: {
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(20),
  },
  dateText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
  descriptionText: {
    color: Colors.LoremText,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(11),
    lineHeight: Metrics.rfv(20),
    marginTop: Metrics.rfv(2),
  },
  reviewText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
  },
  orengeView: {
    backgroundColor: Colors.orange,
    paddingHorizontal: Metrics.rfv(7),
    borderRadius: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(2),
    alignItems: "center",
    justifyContent: "center",
  },
  softView: {
    backgroundColor: Colors.linearColor2,
    paddingHorizontal: Metrics.rfv(7),
    borderRadius: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(2),
    alignItems: "center",
    justifyContent: "center",
  },
  goodView: {
    backgroundColor: Colors.green,
    paddingHorizontal: Metrics.rfv(7),
    borderRadius: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(2),
  },
});
