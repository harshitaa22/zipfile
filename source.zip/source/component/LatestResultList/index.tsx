import React, { useState } from "react";
import { FlatList, Text, View } from "react-native";
import { CommonStyle } from "../../theme";

import styles from "./style";

export default function LatestResultList(props: any) {
  const [data] = useState(props.data);

  const renderItem = (item: any, index: any) => {
    return (
      <View key={index}>
        <View style={CommonStyle.centerView}>
          <View>
            <Text style={styles.dateText}>{item?.title}</Text>
            <Text style={styles.descriptionText}>{item?.subTitle}</Text>
          </View>
          <View
            style={
              (item?.reviewText.includes("Heavy") && styles.orengeView) ||
              (item?.reviewText.includes("Soft") && styles.softView) ||
              (item?.reviewText.includes("Good") && styles.goodView)
            }
          >
            <Text style={styles.reviewText}>{item?.reviewText}</Text>
          </View>
        </View>
        <View style={CommonStyle.bottomWidth} />
      </View>
    );
  };

  return (
    <FlatList
      data={data}
      scrollEnabled={false}
      contentContainerStyle={styles.containerStyle}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    />
  );
}
