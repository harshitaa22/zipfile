import React, { useState } from "react";
import { Text, View } from "react-native";
import { translate } from "../../utils/Localize";
import styles from "./style";

export default function TrackSummaryResult(props) {
  const raceResultSummaryData = props.raceData?.RaceResultSummary?.summary
    ? JSON.parse(props.raceData?.RaceResultSummary?.summary)
    : [];
  const resultData = raceResultSummaryData?.filter(
    (obj) => obj?.Position == 1 || obj?.Position == 2 || obj?.Position == 3
  );
  return (
    <View style={styles.containerStyle}>
      {resultData?.length > 0 ? (
        <View style={styles.trackResultcontainer}>
          {resultData.map((obj, index) => (
            <Text key={index + ""} style={styles.runnerNumberStyle}>
              {obj?.RunnerNumber}
              {index != 2 ? "," : ""}
            </Text>
          ))}
        </View>
      ) : (
        <Text style={styles.closeTextStyle}>{translate("ClosedTxt")}</Text>
      )}
    </View>
  );
}
