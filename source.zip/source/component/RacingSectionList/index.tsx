import React, { useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import styles from "./style";
import AllRacingSectionList from "../AllRacingSectionPage/index";
import { RaceSectionData } from "../../theme/dummyArray";
import TrackSummaryResult from "../TrackSummaryResult";
import TrackCountDown from "../TrackCountDown/index";
import moment from "moment";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../navigation";
import { CommonStyle } from "../../theme";

export default function RacingSectionList(props) {
  const navigation = useNavigation();
  const [racePosition, setRacePosition] = useState(0);

  const renderItem = (item, index) => {
    const raceData = item?.race[racePosition];
    return (
      <Pressable
        style={styles.itemViewStyle}
        onPress={() => onRaceItemClick(item)}
      >
        <View style={styles.commonRow}>
          <View style={CommonStyle.commonFlex}>
            <Text style={styles.countryName}>{item?.eventName}</Text>
            <Text style={styles.currentCountry}>
              {item?.track?.Country?.countryCode}
            </Text>
          </View>

          {raceData?.startTimeDate !== null &&
          moment(new Date(raceData?.startTimeDate)).isBefore(new Date()) ? (
            <TrackSummaryResult raceData={raceData} />
          ) : (
            <TrackCountDown
              raceData={raceData}
              expiryTimestamp={
                raceData?.startTimeDate !== null
                  ? new Date(
                      new Date(raceData?.startTimeDate).toUTCString()
                    ).getTime()
                  : new Date().getTime()
              }
            />
          )}
        </View>
        <View style={styles.separator} />
      </Pressable>
    );
  };

  const onRaceItemClick = (clickedItem) => {
    let upnextRaces = clickedItem?.race?.filter(
      (item) =>
        item?.startTimeDate !== null &&
        moment(new Date()).isBefore(new Date(item?.startTimeDate))
    );
    if (upnextRaces?.length > 0) {
      navigation.navigate(NAVIGATION.SINGLE_RACE_PAGE, {
        sportId: clickedItem?.sportId,
        id: upnextRaces[0]?.id,
        trackId: clickedItem?.track?.id,
        eventId: clickedItem?.id,
        startTimeDate: props.selectedDate,
        intl: props.isIntl,
      });
    } else {
      let haveRace = clickedItem?.race?.filter(
        (data) => data?.startTimeDate !== null
      );
      navigation.navigate(NAVIGATION.SINGLE_RACE_PAGE, {
        sportId: clickedItem?.sportId,
        id: haveRace[0]?.id,
        trackId: clickedItem?.track?.id,
        eventId: clickedItem?.id,
        startTimeDate: props.selectedDate,
        intl: props.isIntl,
      });
    }
  };

  return (
    <View style={styles.listContainerStyle}>
      <AllRacingSectionList
        data={RaceSectionData}
        onItemClick={(itemData) => {
          setRacePosition(itemData?.id);
        }}
      />

      <View style={styles.contentContainerStyle}>
        <FlatList
          data={props.listData}
          extraData={props.listData}
          renderItem={({ item, index }) => renderItem(item, index)}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    </View>
  );
}
