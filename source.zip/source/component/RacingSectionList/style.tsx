import { Platform, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  listContainerStyle: {
    width: "100%",
  },
  contentContainerStyle: {
    marginTop: Metrics.rfv(15),
  },
  itemViewStyle: {
    width: "100%",
  },
  commonRow: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
  },
  countryName: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
  },
  currentCountry: {
    color: Colors.black,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    marginTop: Metrics.rfv(5),
  },
  separator: {
    width: "100%",
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.lightGrayBoxGray,
    marginTop: Metrics.rfv(5),
    marginBottom: Metrics.rfv(8),
  },
});
