import React, { useState } from "react";
import { FlatList, Text, View } from "react-native";
import styles from "./style";

export default function JockeyDetailsList(props: any) {
  const [data] = useState(props.data);

  const renderItem = (item: any, index: any) => {
    return (
      <View style={styles.container}>
        <Text style={styles.listTitle}>{item?.listTitle}</Text>
        <View style={styles.bottomWidth} />

        <Text style={styles.detailsTitle}>{item?.starts}</Text>
        <View style={styles.bottomWidth} />
        {/* <Text style={styles.detailsTitle}>{item?.firstData}</Text>
        {item?.secondData ? (
          <>
            <View style={styles.bottomWidth} />
            <Text style={styles.detailsTitle}>{item?.secondData}</Text>
          </>
        ) : null}
        {item?.thirdData ? (
          <>
            <View style={styles.bottomWidth} />
            <Text style={styles.detailsTitle}>{item?.thirdData}</Text>
          </>
        ) : null}

        {item?.winData ? (
          <>
            <View style={styles.bottomWidth} />
            <Text style={styles.detailsTitle}>{item?.winData}</Text>
          </>
        ) : null}
        {item?.placeData ? (
          <>
            <View style={styles.bottomWidth} />
            <Text style={styles.detailsTitle}>{item?.placeData}</Text>
          </>
        ) : null}
        {item?.avgData ? (
          <>
            <View style={styles.bottomWidth} />
            <Text style={styles.detailsTitle}>{item?.avgData}</Text>
          </>
        ) : null}
        {item?.rolData ? (
          <>
            <View style={styles.bottomWidth} />
            <Text style={styles.detailsTitle}>{item?.rolData}</Text>
          </>
        ) : null}
        {item?.bowenData ? (
          <>
            <View style={styles.bottomWidth} />
            <Text style={styles.detailsTitle}>{item?.bowenData}</Text>
          </>
        ) : null} */}
      </View>
    );
  };

  return (
    <FlatList
      data={data}
      scrollEnabled={true}
      horizontal
      contentContainerStyle={styles.containerStyle}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    />
  );
}
