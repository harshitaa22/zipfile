export const colors = [
  'cyan',
  'green',
  'orange',
  'purple',
  '#bbff00',
  'red',
  'blue',
  'pink',
];
