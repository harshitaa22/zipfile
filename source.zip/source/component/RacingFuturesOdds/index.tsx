import React, { useRef, useState } from "react";
import {
  Animated,
  FlatList,
  Image,
  Linking,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import { Colors, Images, Metrics } from "../../theme/index";
import {
  BetFairIcon,
  DownBlueArrow,
  DownOrangeArrow,
  UpBlueArrow,
  UpOrangeArrow,
} from "../../theme/svg";
import { Constant } from "../../utils";
import { translate } from "../../utils/Localize";
import { print_data } from "../../utils/Logs";
import ImageLoad from "../ImageLoad";
import styles from "./style";

export default function FuturesOddsNextList(props: any) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isBestOddsExpanded, setIsBestOddsExpanded] = useState(false);
  const scrollViewRef = useRef(null);
  const [visibleScrollBarWidth, setVisibleScrollBarWidth] = useState(0);
  const scrollIndicatorSize = visibleScrollBarWidth / 2.7;
  const difference = visibleScrollBarWidth - scrollIndicatorSize;
  const scrollIndicator = useRef(new Animated.Value(0)).current;

  const scrollIndicatorPosition = scrollIndicator.interpolate({
    extrapolate: "clamp",
    inputRange: [0, visibleScrollBarWidth / 6],
    outputRange: [0, difference],
  });
  const onLayout = (event: { nativeEvent: { layout: { width: any } } }) => {
    const { width } = event.nativeEvent.layout;
    setVisibleScrollBarWidth(width);
  };
  // const handleBookkeeperCounter = async (BookKeeperId, type) => {
  //   var param_data = {
  //     BookKeeperId: BookKeeperId,
  //     type: type,
  //     SportId: Number(props?.sportId),
  //   };
  //   try {
  //     const response = await callApi(
  //       API_CONFIG.COUNTER_CLICK,
  //       param_data,
  //       API_CONFIG.POST,
  //       null
  //     );
  //     print_data("=====Counter=====");
  //     print_data(response);
  //     if (response.body?.status === 200) {
  //     }
  //   } catch (error) {
  //     print_data("=====handleAdsImression=====" + error);
  //   }
  // };

  //   const oddsIcon = (BookKeeperId: number, type: any) => {
  //     let icon = props?.bookkeeperData?.filter(
  //       (obj) => obj?.BookKeeperId === BookKeeperId
  //     );
  //     let iconData = icon?.[0]?.BookKeeper;
  //     print_data("helo====");
  //     print_data(BookKeeperId);
  //     return (
  //       <Pressable
  //         onPress={() => {
  //           Linking.openURL(iconData?.affiliate_link);
  //           handleBookkeeperCounter(BookKeeperId, type);
  //         }}
  //         style={styles.oddsImageContainer}
  //       >
  //         {BookKeeperId === 15 ? (
  //           <Image
  //             style={styles.oddsImageIcon}
  //             // resizeMode={"stretch"}
  //             source={Images.playUpIcon}
  //             // source={
  //             //   iconData?.small_logo?.includes("uploads")
  //             //     ? API_URL + "/" + iconData?.small_logo
  //             //     : iconData?.small_logo
  //             // }
  //           />
  //         ) : (
  //           <ImageLoad
  //             style={styles.oddsImageIcon}
  //             resizeMode={"stretch"}
  //             source={
  //               iconData?.small_logo?.includes("uploads")
  //                 ? API_URL + "/" + iconData?.small_logo
  //                 : iconData?.small_logo
  //             }
  //           />
  //         )}
  //       </Pressable>
  //     );
  //   };

  //   const renderOddsItem = (providerId: number) => {
  //     let datas = oddsData
  //       ?.map((obj) => {
  //         if (obj?.ApiProviderId === providerId) {
  //           return obj?.RaceOdds?.[0]?.intValue !== 0
  //             ? obj?.RaceOdds?.[0]?.intValue
  //             : translate("SP");
  //         }
  //       })
  //       .filter((x) => x !== undefined);
  //     if (datas?.length > 0) {
  //       // return props?.fetchClickableOdds(datas?.[0]?.odds, datas?.[0]?.provider);
  //       return (
  //         <Pressable onPress={() => onClickOpne(providerId)}>
  //           <View style={styles.iconContainerStyle}>
  //             {/* <Text style={styles.bestValueTextStyle}>
  //             {getOddsTextValue(providerId)}
  //           </Text> */}

  //             <View>{getOddsTextValue(providerId)}</View>
  //             {/* {getOddsIcon(providerId)} */}
  //             {oddsIconData}
  //           </View>
  //         </Pressable>
  //       );
  //     }
  //   };

  const renderPageHeadingDataItem = () => {
    return (
      <View style={styles.iconContainerStyle}>
        <View style={styles.oddsContainer}>
          <View style={styles.oddView}>
            <Text style={styles.bestValueTextStyle}>1.06</Text>
            <Image source={Images.bet365} style={styles.oddsImageIcon}></Image>
          </View>
          <View style={styles.oddView}>
            <Text style={styles.bestValueTextStyle}>1.04</Text>
            <Image
              source={Images.unibetBmIcon}
              style={styles.oddsImageIcon}
            ></Image>
          </View>
          <View style={styles.oddView}>
            <Text style={styles.bestValueTextStyle}>1.05</Text>
            <Image
              source={Images.nedImageIcon}
              style={styles.oddsImageIcon}
            ></Image>
          </View>
          <View style={styles.oddView}>
            <Text style={styles.bestValueTextStyle}>1.05</Text>
            <Image source={Images.bet365} style={styles.oddsImageIcon}></Image>
          </View>
          <View style={styles.oddView}>
            <Text style={styles.bestValueTextStyle}>1.05</Text>
            <Image
              source={Images.playUpIcon}
              style={styles.oddsImageIcon}
            ></Image>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.containerStyle}>
      <>
        <Pressable
          style={styles.OddsTypeNExtList}
          onPress={() => setIsExpanded(!isExpanded)}
        >
          <Text style={styles.todayTitleTextStyle}>{props?.runnerName}</Text>
          {isExpanded ? (
            <UpBlueArrow
              width={Metrics.rfv(15)}
              height={Metrics.rfv(10)}
              color={Colors.orange}
            />
          ) : (
            <DownBlueArrow
              width={Metrics.rfv(15)}
              height={Metrics.rfv(10)}
              color={Colors.orange}
            />
          )}
        </Pressable>
        {isExpanded && (
          <View style={styles.listContainerStyle}>
            <ScrollView
              ref={scrollViewRef}
              style={styles.contentContainerStyle}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              nestedScrollEnabled={true}
              onLayout={onLayout}
              onScroll={Animated.event(
                [{ nativeEvent: { contentOffset: { x: scrollIndicator } } }],
                { useNativeDriver: false }
              )}
              scrollEventThrottle={16}
              scrollEnabled={true}
            >
              {renderPageHeadingDataItem()}
              {/* <FlatList
                data={props?.pageHeadingData}
                scrollEnabled={false}
                horizontal
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.contentContainerStyle}
                renderItem={({ item, index }) =>
                  renderPageHeadingDataItem(item, index)
                }
                keyExtractor={(item, index) => index.toString()}
              /> */}
            </ScrollView>
            {props?.pageHeadingData?.length > 5 && (
              <View style={styles.itemSeparatorComponent}>
                <Animated.View
                  style={[
                    styles.indicatorstyle,
                    {
                      width: scrollIndicatorSize,
                      transform: [{ translateX: scrollIndicatorPosition }],
                    },
                  ]}
                ></Animated.View>
              </View>
            )}
          </View>
        )}
      </>
    </View>
  );
}
