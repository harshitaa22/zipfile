import { Dimensions } from "react-native";
import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  todayTitleTextStyle: {
    flex: 1,
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(16),
  },
  OddsTypeNExtList: {
    flexDirection: "row",
    // paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(8),
    alignItems: "center",
  },
  betFairIcon: {
    height: Metrics.rfv(32),
    width: Metrics.rfv(48),
  },
  betFairContainer: {
    borderRadius: Metrics.rfv(10),
    height: Metrics.rfv(32),
    width: Metrics.rfv(48),
    marginTop: Metrics.rfv(10),
    overflow: "hidden",
  },
  containerStyle: {
    width: "100%",
  },
  listContainerStyle: {
    width: "100%",
  },
  iconContainerStyle: {
    // width: (Dimensions.get("window").width - 30) / 5,
    // marginTop: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
  },
  topView: {
    marginBottom: Metrics.rfv(5),
  },
  bestValueTextStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
    textAlign: "center",
    marginBottom: Metrics.rfv(5),
  },
  contentContainerStyle: {
    width: "100%",
  },
  oddsImageIcon: {
    height: Metrics.rfv(28),
    width: Metrics.rfv(40),
    borderRadius: Metrics.rfv(5),
    // resizeMode: "contain",
  },
  oddsImageContainer: {
    justifyContent: "center",
    borderRadius: Metrics.rfv(5),
    height: Metrics.rfv(30),
    width: Metrics.rfv(30),
    overflow: "hidden",
  },
  oddsIconStyle: {
    height: Metrics.rfv(30),
    width: Metrics.rfv(45),
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(8),
  },
  betRightIcon: {
    height: Metrics.rfv(30),
    width: Metrics.rfv(45),
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(8),
    resizeMode: "stretch",
  },
  bet365IconStyle: {
    height: Metrics.rfv(30),
    width: Metrics.rfv(45),
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(8),
    resizeMode: "contain",
  },
  noaContainer: {
    backgroundColor: Colors.gray,
    paddingVertical: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(10),
    borderRadius: Metrics.rfv(15),
    alignItems: "center",
  },
  noaText: {
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    color: Colors.white,
  },
  datasContainer: {
    backgroundColor: Colors.white,
    paddingVertical: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(8),
    borderRadius: Metrics.rfv(15),
    alignItems: "center",
  },
  oddsContainer: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    flexDirection: "row",
    marginBottom: Metrics.rfv(10),
  },
  itemSeparatorComponent: {
    backgroundColor: Colors.lineBreak,
    marginTop: Metrics.rfv(15),
    height: Metrics.rfv(5),
    justifyContent: "center",
  },
  indicatorstyle: {
    height: Metrics.rfv(5),
    backgroundColor: Colors.linearColor2,
  },
  oddView: {
    marginRight: Metrics.rfv(15),
  },
});
