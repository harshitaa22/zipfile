import { Dimensions, Platform, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  height: {
    marginTop: Metrics.rfv(10),
    backgroundColor: Colors.cream,
    height: Metrics.rfv(20),
  },
  endView: {
    justifyContent: "flex-end",

    backgroundColor: "white",
    marginTop: Metrics.rfv(20),
    marginBottom: Metrics.rfv(20),
    borderStartColor: Colors.white,
  },
  dropDownContainerStyle: {
    backgroundColor: Colors.lightblue,
    width: "100%",
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    top: Metrics.rfv(-7),
    textAlign: "center",
    position: "relative", // It was absolute
  },
  commonRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  dataPicker: {
    backgroundColor: Colors.white,
    width: Metrics.rfv(450),
  },
  dialogCancelStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(18),
    marginHorizontal: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
  },
  clearText: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
  },
  dialogDoneStyle: {
    color: Colors.doneText,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    marginHorizontal: Metrics.rfv(10),
    fontFamily: Fonts.IN_Regular,
    paddingVertical: Metrics.rfv(10),
  },
  dateView: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.borderGrey,
    justifyContent: "space-between",
    backgroundColor: Colors.cream,
    width: "100%",
  },
  modalView: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
    margin: Metrics.rfv(0),
    backgroundColor: Colors.dialogBack,
  },
  selectedItemContainerStyle: {
    backgroundColor: Colors.lightGray,
    color: Colors.white,
  },
  labelText: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
  },
});
