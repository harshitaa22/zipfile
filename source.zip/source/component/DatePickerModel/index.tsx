import React, { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { translate } from "../../utils/Localize";
import styles from "./style";
import { Colors } from "../../theme";
import DatePicker from "react-native-date-picker";
import Modal from "react-native-modal";
import { print_data } from "../../utils/Logs";

export default function DatePickerModel(props: any) {
  const [isShowDatePicker, showDatePicker] = useState(props?.isVisible);
  const [getUTCDate, setGetUTCDate] = useState(new Date());

  useEffect(() => {
    showDatePicker(props?.isVisible);
  }, [props?.isVisible]);

  const handleContinuePress = (buttonType: number) => {
    if (props?.showModel !== null) {
      props?.showModel(false);
    } else {
      showDatePicker(false);
    }
  };
  return (
    <Modal
      isVisible={isShowDatePicker}
      onBackButtonPress={() => showDatePicker(false)}
      testID={"modal"}
      style={styles.modalView}
      onBackdropPress={() => {
        showDatePicker(false);
      }}
    >
      <View style={styles.dateView}>
        <Pressable onPress={() => handleContinuePress(0)}>
          <Text style={[styles.dialogCancelStyle]}>{translate("Cancel")}</Text>
        </Pressable>
        {props?.showClearButton && (
          <Pressable onPress={props?.clearPress}>
            <Text style={[styles.clearText]}>{translate("Clear")}</Text>
          </Pressable>
        )}

        <Pressable onPress={props.onDateSelect}>
          <Text style={[styles.dialogDoneStyle]}>{translate("Done")}</Text>
        </Pressable>
      </View>
      <View>
        <DatePicker
          style={styles.dataPicker}
          mode={"date"}
          textColor={Colors.black}
          // date={getUTCDate ? getUTCDate : new Date()}
          date={props.date}
          onDateChange={(date) => {
            // setGetUTCDate(date);
            props.getUtcDate(date);
          }}
        />
      </View>
    </Modal>
  );
}
