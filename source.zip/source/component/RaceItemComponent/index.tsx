import moment from "moment";
import React, { useEffect, useState } from "react";
import { Image, Linking, Pressable, Text, View } from "react-native";
import { useDispatch } from "react-redux";
//style
import styles from "./style";
//utils
import { translate } from "../../utils/Localize";
//theme
import { Colors, CommonStyle, Metrics } from "../../theme";
import Images from "../../theme/images";
import { DownBlueArrow, RunnerHeader, UpBlueArrow } from "../../theme/svg";
//component
import Button from "../Button";
import OddsShortFrom from "../OddsShortFromList";
import OddsTypeNextList from "../OddsTypeNextList";
//api
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
//utils
import { API_URL } from "../../../env.json";
import { print_data } from "../../utils/Logs";
import ImageLoad from "../ImageLoad";

export default function SingleRaceItem(props: any) {
  const dispatch = useDispatch();
  let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const {
    runnerInfo,
    itemData,
    itemIndex,
    onRacingPress,
    sportId,
    raceData,
    selectedOddsText,
    RaceResultData,
    raceId,
    runnerData,
    loadervisible,
    selectedOddsData,
    bookkeeperData,
  } = props;
  const [oddsData, setOddsData] = useState([]);
  const [sponsoredData, setSponsoredData] = useState(null);
  const [timeinterval, setTimeInterval] = useState();
  const [apiTimeout, setAPiTimeout] = useState();
  const [pageHeadingData, setPageHeadingData] = useState([]);
  const [raceLoader, setRaceLoader] = useState(false);

  // useEffect(() => {
  //   clearInterval(timeinterval);
  //   clearTimeout(apiTimeout);
  // }, [raceId]);
  useEffect(() => {
    callSponsoredDataAPI();
    // if (raceId) {
    callOddsDataAPI(raceId);
    fetchLatestOdds(raceId);
    // }

    // setTimeInterval(Interval);

    //   dispatch({
    //     type: Constant.SET_INTERVAL,
    //     payload: JSON.stringify(Interval),
    //   });
    // }, 15000);
    // setAPiTimeout(timeout);
    // dispatch({
    //   type: Constant.SET_INTERVAL,
    //   payload: JSON.stringify(timeout),
  }, [selectedOddsText, raceId, runnerData, RaceResultData, sportId]);

  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(props?.sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const oddsIcon = (BookKeeperId: number, type: any) => {
    let icon = bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsImageContainer}
      >
        {BookKeeperId === 15 ? (
          <Image
            style={styles.oddsImageIcon}
            // resizeMode={"stretch"}
            source={Images.playUpIcon}
            // source={
            //   iconData?.small_logo?.includes("uploads")
            //     ? API_URL + "/" + iconData?.small_logo
            //     : iconData?.small_logo
            // }
          />
        ) : (
          <ImageLoad
            style={styles.oddsImageIcon}
            resizeMode={"stretch"}
            source={
              iconData?.small_logo?.includes("uploads")
                ? API_URL + "/" + iconData?.small_logo
                : iconData?.small_logo
            }
          />
        )}
      </Pressable>
    );
  };

  const callSponsoredDataAPI = async () => {
    try {
      const response = await callApi(
        API_CONFIG.SPONSORED + `timeZone=${timezone}&SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          let providerIDs = [];
          let Ids = response?.body?.data?.result?.map((item) =>
            providerIDs?.push(item?.bookKeepersId)
          );
          setSponsoredData(providerIDs);
        } else {
          setSponsoredData([]);
        }
      }
    } catch (error) {}
  };

  const fetchTableHeading = async (provider) => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders?SportId=1,2,3`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          let filteredHeading = response?.body?.data?.result?.filter((item) =>
            provider?.includes(item?.BookKeeperId)
          );
          setPageHeadingData(filteredHeading);
        }
      }
    } catch (error) {}
  };

  const fetchLatestOdds = async (raceId) => {
    try {
      const response = await callApi(
        `sync/oddOnDemand/${raceId}`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
        }
      }
    } catch (error) {}
  };

  const callOddsDataAPI = async (raceId) => {
    try {
      const response = await callApi(
        `events/getOddsByrace/${raceId}?marketId=${selectedOddsData?.marketId}&oddKey=${selectedOddsData?.oddKey}`,
        null,
        API_CONFIG.GET,
        null
      );
      print_data(response);
      if (response.body != null) {
        if (
          response.body?.status === 200 &&
          response?.body?.data?.status == true
        ) {
          const oddsList = response?.body?.data?.marketRelation;
          let provider = [];
          let ProviderList = oddsList?.[0]?.data?.map((element) => {
            return provider?.push(element?.BookKeeperId);
          });
          fetchTableHeading(provider);
          const filteredList = oddsList
            ?.map((item) => {
              return item?.RacingParticipantId == itemData?.id ? item : [];
            })
            ?.filter((x) => {
              return x?.data?.length > 0;
            });
          setOddsData(filteredList);
        }
      }
    } catch (error) {}
  };

  const renderPieChartItem = () => {
    let itemJsondata =
      itemData?.RunnerInfos.length > 0 &&
      JSON.parse(itemData?.RunnerInfos?.[0]?.info);
    return (
      <View style={styles.runnerHeaderStyle}>
        <RunnerHeader width={"100%"} height={Metrics.rfv(11)} />
        <View style={styles.horizontalView}>
          <Text style={styles.runnerCommentsText}>
            {translate("RunnerComments")}
          </Text>
          <Text style={styles.runnerInfo}>
            {itemJsondata?.entrant_comment
              ? itemJsondata?.entrant_comment
              : translate("NoComment")}
          </Text>

          <View style={styles.fullFormMainView}>
            <View style={CommonStyle.commonFlex}>
              {/* <View style={styles.fullFormSubStyle}>
                <Text style={styles.fullFormText}>{translate("FullForm")}</Text>
              </View> */}
              <View style={styles.sireStyle}>
                <Text style={styles.shortFromListTitle}>
                  {translate("Sire")}
                </Text>
                <Text style={styles.shortFromListSubText}>
                  {itemJsondata?.sire?.name ? itemJsondata?.sire?.name : "-"}
                </Text>
              </View>
            </View>
            {/* <View style={styles.chartViewStyle}>
              <PieChart
                donut
                showText
                innerRadius={55}
                radius={70}
                labelsPosition="onBorder"
                innerCircleColor={Colors.darkGray}
                // showTextBackground

                data={pieData}
                centerLabelComponent={() => {
                  return (
                    <View style={styles.centerView}>
                      <Text style={styles.winText}>{translate("Win")}</Text>
                      <Text style={styles.percentegeStyle}>
                        {translate("Percentage")}
                      </Text>
                      <Text style={styles.placeText}>{translate("Place")}</Text>
                      <Text style={styles.percentegeStyle}>
                        {translate("ThirtySixPercentage")}
                      </Text>
                    </View>
                  );
                }}
              />
              </View> */}
          </View>
          <View style={styles.shortFromList}>
            <View style={CommonStyle.commonFlex}>
              <Text style={styles.shortFromListTitle}>
                {translate("PrizeMoney")}
              </Text>
              <Text style={styles.shortFromListSubText}>
                {itemJsondata?.runner_info?.prize_money
                  ? "$" + itemJsondata?.runner_info?.prize_money
                  : "-"}
              </Text>

              <Text style={styles.shortFromListTitle}>
                {translate("PrizeType")}
              </Text>
              <Text style={styles.shortFromListSubText}>
                {itemJsondata?.runner_info?.colour
                  ? itemJsondata?.runner_info?.colour?.split(",")[0]
                  : "-"}
              </Text>

              <Text style={styles.shortFromListTitle}>
                {translate("Overall")}
              </Text>
              <Text style={styles.OverallCost}>
                {" "}
                {itemJsondata?.past_runner_performances?.overall?.starts
                  ? itemJsondata?.past_runner_performances?.overall?.starts
                  : "0"}{" "}
                {itemJsondata?.past_runner_performances?.overall?.wins
                  ? itemJsondata?.past_runner_performances?.overall?.wins
                  : "0"}
                -
                {itemJsondata?.past_runner_performances?.overall?.second
                  ? itemJsondata?.past_runner_performances?.overall?.second
                  : "0"}
                -
                {itemJsondata?.past_runner_performances?.overall?.thirds
                  ? itemJsondata?.past_runner_performances?.overall?.thirds
                  : "0"}
              </Text>
            </View>

            <View style={styles.rightView}>
              <Text style={styles.shortFromListTitle}>{translate("Dam")}</Text>
              <Text style={styles.shortFromListSubText}>
                {itemJsondata?.dam?.name ? itemJsondata?.dam?.name : "-"}
              </Text>

              <Text style={styles.shortFromListTitle}>{translate("Age")}</Text>
              <Text style={styles.shortFromListSubText}>
                {itemJsondata?.runner_info?.age
                  ? itemJsondata?.runner_info?.age + " yo"
                  : "-"}
              </Text>

              <Text style={styles.shortFromListTitle}>
                {translate("LastSix")}
              </Text>
              <Text style={styles.shortFromListSubText}>
                {itemJsondata?.runner_info?.last_starts
                  ? itemJsondata?.runner_info?.last_starts?.slice(
                      itemJsondata?.runner_info?.last_starts?.length - 6
                    )
                  : "-"}
              </Text>
            </View>
          </View>

          <View style={styles.separatorLine} />

          <View style={styles.rowButton}>
            <View style={styles.width}>
              <Button
                disabled={false}
                height={Metrics.rfv(40)}
                title={translate("ShortForm")}
                borderRadius={Metrics.rfv(5)}
                color={Colors.white}
                fontSize={Metrics.rfv(14)}
                marginTop={0}
                borderColor={Colors.OddsPopBackground}
                backgroundColor={Colors.OddsPopBackground}
              />
            </View>
          </View>
          <View style={styles.shortFormViewStyle}>
            <OddsShortFrom data={itemJsondata} />
          </View>
        </View>
      </View>
    );
  };

  const getCurrentBestValue = (data) => {
    // let newOdds = data?.filter((odds) => {
    //   return odds.ApiProviderId > 5;
    // });
    let newOdds = data;
    let maxno = newOdds?.reduce((max, obj) => {
      obj?.RaceOdds?.[0]?.intValue > max
        ? (max = obj?.RaceOdds?.[0]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        // return maxno;
        let providerid = data
          ?.map((obj) => {
            if (obj?.RaceOdds?.[0]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          .filter((x) => x !== undefined);
        return fetchClickableOdds(maxno, providerid?.[0], "header");
      } else {
        return (
          <View style={styles.currentBestContainerStyle}>
            <View style={styles.spContainer}>
              <Text style={styles.noaText}>{translate("SP")}</Text>
            </View>
          </View>
        );
      }
    } else {
      return (
        <View style={styles.currentBestContainerStyle}>
          <View style={styles.spContainer}>
            <Text style={styles.noaText}>{translate("SP")}</Text>
          </View>
        </View>
      );
    }
  };
  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.centerView}
      >
        <Text style={styles.bestValueTextStyle}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };
  const getSponsoredOdds = (data) => {
    let newOdds = data
      ?.filter((odds) => {
        return sponsoredData?.includes(odds?.BookKeeperId);
      })
      ?.slice(0, 2);
    let firstSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === sponsoredData?.[0]
    );
    let secondSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === sponsoredData?.[1]
    );
    let SponsoredOdds =
      sponsoredData?.length > 0 ? (
        <>
          <View style={styles.sponsoredContainerView}>
            <View style={CommonStyle.centerFlex}>
              {firstSponsored?.length > 0 ? (
                <>
                  <View>
                    {fetchClickableOdds(
                      firstSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0
                        ? firstSponsored?.[0]?.RaceOdds?.[0]?.intValue
                        : "SP",
                      firstSponsored?.[0]?.BookKeeperId,
                      "sponsored"
                    )}
                  </View>
                  {/* {firstSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0 ? (
                    <Text style={styles.sponsoredTextStyle}>
                      {firstSponsored?.[0]?.RaceOdds?.[0]?.intValue}
                    </Text>
                  ) : (
                    <View style={styles.currentBestContainerStyle}>
                      <View style={styles.spContainer}>
                        <Text style={styles.noaText}>{translate("SP")}</Text>
                      </View>
                    </View>
                  )} */}
                </>
              ) : (
                <>
                  <Text>{""}</Text>
                </>
              )}
              {oddsIcon(sponsoredData?.[0], "sponsored")}
            </View>

            {sponsoredData?.[1] && (
              <View style={CommonStyle.centerFlex}>
                {secondSponsored?.length > 0 ? (
                  <>
                    {/* {secondSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0 ? (
                      <Text style={styles.sponsoredTextStyle}>
                        {secondSponsored?.[0]?.RaceOdds?.[0]?.intValue}
                      </Text>
                    ) : (
                      <View style={styles.currentBestContainerStyle}>
                        <View style={styles.spContainer}>
                          <Text style={styles.noaText}>{translate("SP")}</Text>
                        </View>
                      </View>
                    )} */}
                    <View>
                      {fetchClickableOdds(
                        secondSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0
                          ? secondSponsored?.[0]?.RaceOdds?.[0]?.intValue
                          : "SP",
                        secondSponsored?.[0]?.BookKeeperId,
                        "sponsored"
                      )}
                    </View>
                  </>
                ) : (
                  <Text style={styles.sponsoredTextStyle}>{""}</Text>
                )}
                {oddsIcon(sponsoredData?.[1], "sponsored")}
              </View>
            )}
          </View>
        </>
      ) : (
        // sponsoredData?.map((obj, index) => {
        //     return (
        //       <View key={index}>
        //         {obj?.RaceOdds?.[0]?.intValue ? (
        //           <>
        //             <View style={styles.centerSponsorText}>
        //               <Text style={styles.sponsoredTextStyle}>
        //                 {obj?.RaceOdds?.[0]?.intValue !== 0
        //                   ? obj?.RaceOdds?.[0]?.intValue
        //                   : translate("SP")}
        //               </Text>
        //               {getOddsIcon(obj?.ApiProviderId)}
        //             </View>
        //           </>
        //         ) : (
        //           <Text style={styles.bestValueTextStyle}>{translate("SP")}</Text>
        //         )}
        //       </View>
        //     );
        //   })
        <View style={styles.noaContainerView}>
          <Text style={styles.noaText}>{translate("NoaText")}</Text>
        </View>
        // <View style={styles.noaCenterView}>
        //   <Text style={styles.bestValueTextStyle}>{translate("NoaText")}</Text>
        // </View>
      );
    return SponsoredOdds;
  };

  // const fetchSponsoredOdds = (data) => {
  //   let newOdds = data?.filter((odds) => { return sponsoredId?.includes(odds.ApiProviderId) })?.slice(0, 2)
  //   let firstSponsored = newOdds?.filter((item) => item?.ApiProviderId === sponsoredId?.[0])
  //   let secondSponsored = newOdds?.filter((item) => item?.ApiProviderId === sponsoredId?.[1])
  //   console.log("sponsoredodds", newOdds, data, sponsoredId, firstSponsored, secondSponsored)
  //   let SponsoredOdds = sponsoredId?.length > 0 ?
  //     <>
  //       <Box>
  //         {firstSponsored?.length > 0 ? (
  //           <>
  //             <Box>
  //               {firstSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0 ? firstSponsored?.[0]?.RaceOdds?.[0]?.intValue : "SP"}
  //             </Box>
  //           </>
  //         ) : (<Tooltip title="No odds available" className="odds-tooltip" placement="top">
  //           <span className="no-odds">NOA</span>
  //         </Tooltip>)}
  //         {oddsicon(sponsoredId?.[0])}
  //       </Box>
  //       {sponsoredId?.[1] ?
  //         <Box>
  //           {secondSponsored?.length > 0 ? (
  //             <>
  //               <Box>
  //                 {secondSponsored?.[0]?.RaceOdds?.[0]?.intValue !== 0 ? secondSponsored?.[0]?.RaceOdds?.[0]?.intValue : "SP"}
  //               </Box>
  //             </>
  //           ) : (<Tooltip title="No odds available" className="odds-tooltip" placement="top">
  //             <span className="no-odds">NOA</span>
  //           </Tooltip>)}
  //           {oddsicon(sponsoredId?.[1])}
  //         </Box>
  //         : <></>}

  //     </>
  //     : (<TableCell colSpan={2}> <Tooltip title="No odds available" className="odds-tooltip" placement="top">
  //       <span className="no-odds">NOA</span>
  //     </Tooltip></TableCell>)
  //   return SponsoredOdds;
  // }

  const getCurrentBestIcon = (data) => {
    // let newOdds = data?.filter((odds) => {
    //   return odds.ApiProviderId > 5;
    // });
    let newOdds = data;
    let maxno = newOdds?.reduce((max, obj) => {
      obj?.RaceOdds?.[0]?.intValue > max
        ? (max = obj?.RaceOdds?.[0]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = newOdds
          ?.map((obj) => {
            if (obj?.RaceOdds?.[0]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          .filter((x) => x !== undefined);
        return oddsIcon(providerid?.[0], "header");
        // return getOddsIcon(providerid?.[0]);
        // return oddsIcon(providerid?.[0]);
      } else {
        return "";
      }
    } else {
      return "";
    }
  };

  const getBestOpenValue = (data) => {
    // let newOdds = data?.filter((odds) => {
    //   return odds.ApiProviderId > 5;
    // });
    let maxno = data?.reduce((max, obj) => {
      obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue > max
        ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno == 0) {
        let newmaxno = data?.reduce((max, obj) => {
          obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue > max
            ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue)
            : (max = max);
          return max;
        }, -1);
        if (newmaxno !== -1) {
          // return newmaxno;
          let providerid = data
            ?.map((obj) => {
              if (obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue === maxno) {
                return obj?.BookKeeperId;
              }
            })
            ?.filter((x) => x !== undefined);
          return fetchClickableOdds(maxno, providerid?.[0], "header");
        } else {
          return "-";
        }
      } else {
        let providerid = data
          ?.map((obj) => {
            if (obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          ?.filter((x) => x !== undefined);
        return fetchClickableOdds(maxno, providerid?.[0], "header");
      }
    } else {
      return (
        <View style={styles.noaContainerView}>
          <Text style={styles.noaText}>{translate("NoaText")}</Text>
        </View>
      );
    }
  };

  const getBestOpenIcon = (data) => {
    let newOdds = data;
    let maxno = newOdds?.reduce((max, obj) => {
      obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue > max
        ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue)
        : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = newOdds
          ?.map((obj) => {
            if (obj?.RaceOdds?.[0]?.RaceOddFlucs?.[0]?.intValue === maxno) {
              return obj?.BookKeeperId;
            }
          })
          .filter((x) => x !== undefined);
        return oddsIcon(providerid?.[0], "header");
      } else {
        let newmaxno = newOdds?.reduce((max, obj) => {
          obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue > max
            ? (max = obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue)
            : (max = max);
          return max;
        }, -1);
        if (newmaxno !== -1) {
          let providerid = newOdds
            ?.map((obj) => {
              if (
                obj?.RaceOdds?.[0]?.RaceOddFlucs?.[1]?.intValue === newmaxno
              ) {
                return obj?.BookKeeperId;
              }
            })
            .filter((x) => x !== undefined);
          return oddsIcon(providerid?.[0], "header");
        } else {
          return "";
        }
      }
    } else {
      return "";
    }
  };

  return (
    <View style={styles.horizontalView}>
      <Pressable
        style={styles.touchViewStyle}
        onPress={() => onRacingPress(itemData, itemIndex)}
      >
        <View style={styles.commonRowWithArrow}>
          <Text
            style={
              itemData?.isScratched === "false" ||
              itemData?.isScratched === null ||
              itemData?.isScratched === "0"
                ? styles.todayNumberTextStyle
                : styles.todayScratchNumberTextStyle
            }
          >
            {itemData.runnerNumber + ". "}
            {itemData?.animal?.name}
            {" ("}
            {itemData?.barrierNumber}
            {") "}
          </Text>
          <View style={styles.iconArrowContainerStyle}>
            {itemData?.isExpanded ? (
              <UpBlueArrow
                style={styles.arrowIconStyle}
                color={
                  itemData?.isScratched === "false" ||
                  itemData?.isScratched === null ||
                  itemData?.isScratched === "0"
                    ? Colors.linearColor1
                    : Colors.gray
                }
              />
            ) : (
              <DownBlueArrow
                style={styles.arrowIconStyle}
                color={
                  itemData?.isScratched === "false" ||
                  itemData?.isScratched === null ||
                  itemData?.isScratched === "0"
                    ? Colors.linearColor1
                    : Colors.gray
                }
              />
            )}
          </View>
        </View>

        {itemData?.isScratched === "false" ||
        itemData?.isScratched === null ||
        itemData?.isScratched === "0" ? (
          <View style={styles.fixedTextView}>
            <View style={styles.fixedTextView1}>
              {sportId == "1" && (
                <View style={styles.commonRowOnly}>
                  <Text style={styles.fixedCommonStyle}>
                    {translate("OddWeight")}
                  </Text>
                  <Text style={styles.valueTextStyle}>
                    {Number(itemData?.JockeyWeight).toFixed(2) +
                      translate("WeightKg")}
                  </Text>
                </View>
              )}
              {itemData?.Jockey ? (
                <View
                  style={
                    sportId == "2"
                      ? styles.commonRowOnly
                      : styles.commonRowEndAlign
                  }
                >
                  <Text style={styles.fixedCommonStyle}>
                    {sportId == "2"
                      ? translate("DriverTxt")
                      : translate("Jockey")}
                  </Text>
                  <Text style={styles.valueTextStyle}>
                    {itemData?.Jockey?.name}
                  </Text>
                </View>
              ) : itemData?.Trainer ? (
                <View style={styles.commonRowOnly}>
                  <Text style={styles.fixedCommonStyle}>
                    {translate("Trainer")}
                  </Text>
                  <Text style={styles.valueTextStyle}>
                    {itemData?.Trainer?.name}
                  </Text>
                </View>
              ) : null}
            </View>
            {sportId == "1" || sportId == "2" ? (
              <>
                {itemData?.Trainer && (
                  <View style={styles.commonRowOnly}>
                    <Text style={styles.fixedCommonStyle}>
                      {translate("Trainer")}
                    </Text>
                    <Text style={styles.valueTextStyle}>
                      {itemData?.Trainer?.name}
                    </Text>
                  </View>
                )}
              </>
            ) : null}
          </View>
        ) : (
          <Text style={styles.scratchTitleTextStyle}>
            {translate("ScratchedTxt")}
            {moment(itemData?.updatedAt).format("hh:mm A DD/MM/YYYY")}
          </Text>
        )}
      </Pressable>

      {itemData.isExpanded && renderPieChartItem()}

      {(itemData?.isScratched === "false" ||
        itemData?.isScratched === null ||
        itemData?.isScratched === "0") && (
        <>
          {!props?.seeAllOdds && (
            <View style={styles.bestMainContainer}>
              <View style={styles.openContainer}>
                <View style={styles.bestTextContiner}>
                  <Text style={styles.bestTitleTextStyle}>
                    {translate("BestAtOpen")}
                  </Text>
                </View>
                <View style={styles.rightWidth}>
                  {oddsData?.[0]?.data ? (
                    <View style={styles.iconContainerStyle}>
                      <Text style={styles.bestValueTextStyle}>
                        {getBestOpenValue(oddsData?.[0]?.data)}
                      </Text>
                      {getBestOpenIcon(oddsData?.[0]?.data)}
                    </View>
                  ) : (
                    <View style={styles.currentBestContainerStyle}>
                      <View style={styles.noaContainer}>
                        <Text style={styles.noaText}>
                          {translate("NoaText")}
                        </Text>
                      </View>
                    </View>
                  )}
                </View>
              </View>

              <View style={styles.separatorStyle} />
              <View style={styles.openContainer}>
                <View style={styles.currentBestContiner}>
                  <Text style={styles.currentBestTitleTextStyle}>
                    {translate("CurrentBest")}
                  </Text>
                </View>
                <View style={styles.currentBestContainer}>
                  {oddsData?.[0]?.data ? (
                    <View style={styles.currentBestContainerStyle}>
                      <Text style={styles.bestValueTextStyle}>
                        {getCurrentBestValue(oddsData?.[0]?.data)}
                      </Text>
                      {getCurrentBestIcon(oddsData?.[0]?.data)}
                    </View>
                  ) : (
                    <View style={styles.currentBestContainerStyle}>
                      <View style={styles.noaContainer}>
                        <Text style={styles.noaText}>
                          {translate("NoaText")}
                        </Text>
                      </View>
                    </View>
                  )}
                </View>
              </View>

              {sponsoredData?.length > 0 && (
                <>
                  <View style={styles.separatorStyle} />

                  <View style={styles.sponsoredCotainerView}>
                    <View style={styles.sponsoredContiner}>
                      <Text style={styles.currentBestTitleTextStyle}>
                        {translate("Sponsored")}
                      </Text>
                      {/* <Image
      source={Images.sponsored}
      style={styles.sponsoredImage}
    /> */}
                    </View>
                    <View style={styles.leftWidth}>
                      <View style={styles.currentBestContainerStyle}>
                        {/* <View style={styles.iconContainer}> */}
                        {getSponsoredOdds(oddsData?.[0]?.data)}
                        {/* </View> */}
                      </View>
                    </View>
                  </View>
                </>
              )}
            </View>
          )}
          <OddsTypeNextList
            pageHeadingData={pageHeadingData}
            oddsData={oddsData?.[0]?.data}
            seeAllOdds={props?.seeAllOdds}
            bookkeeperData={bookkeeperData}
            sportId={props?.sportId}
          />
        </>
      )}
      <View style={styles.itemSeparatorComponent} />
    </View>
  );
}
