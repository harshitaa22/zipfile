import { StyleSheet, Dimensions } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  emptyView: {
    width: "100%",
    height: Metrics.rfv(40),
    backgroundColor: Colors.drownDownBackground,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyText: {
    color: Colors.lineBreak,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
  },
});
