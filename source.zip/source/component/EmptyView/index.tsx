import { Text, View } from "react-native";
import styles from "./style";
export default function EmptyViewRace(props: any) {
  return (
    <View style={styles.emptyView}>
      <Text style={styles.emptyText}>{props?.name}</Text>
    </View>
  );
}
