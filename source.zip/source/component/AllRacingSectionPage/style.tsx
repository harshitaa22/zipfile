import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  itemSeparatorComponentTrue: {},
  itemSeparatorComponentFalse: {
    backgroundColor: Colors.black,
    height: Metrics.rfv(25),
    width: Metrics.rfv(1),
    marginHorizontal: Metrics.rfv(15),
  },

  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  raceTabTextSelectedTrue: {
    marginRight: Metrics.rfv(10),
    height: Metrics.rfv(35),
    width: Metrics.rfv(70),
    backgroundColor: Colors.orange,
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
  },
  raceTabTextSelectedFalse: {
    height: Metrics.rfv(35),
    width: Metrics.rfv(70),
    backgroundColor: Colors.white,
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
  },
  contentContainerStyle: {
    height: Metrics.rfv(38),
  },
  racingTabTextTrue: {
    color: Colors.white,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    textAlign: "center",
  },
  racingTabTextFalse: {
    color: Colors.black,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    paddingVertical: Metrics.rfv(10),
    textAlign: "center",
  },
  commonRow: {
    alignItems: "center",
    flexDirection: "row",
  },
});
