import React, { useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import styles from "./style";

export default function AllRacingSectionList(props) {
  const [isSelectIndex, setSelectIndex] = useState(0);
  const onTabClick = (item, index) => {
    if (index === item.id && item.isBG === true) {
      if(props.onItemClick){
        props.onItemClick(item)
      }
      setSelectIndex(index);
    
    } 
  };

  const renderItem = (item, index) => {
    return (
      <Pressable
        onPress={() => onTabClick(item, index)}
        style={
          index === isSelectIndex && item.isBG
            ? styles.raceTabTextSelectedTrue
            : styles.raceTabTextSelectedFalse
        }
      >
        <View style={styles.commonRow}>
          <Text
            style={
              index === isSelectIndex && item.isBG
                ? styles.racingTabTextTrue
                : styles.racingTabTextFalse
            }
          >
            {item.textRaceTab}
          </Text>
          <View
            style={
              index === isSelectIndex && item.isBG
                ? styles.itemSeparatorComponentTrue
                : styles.itemSeparatorComponentFalse
            }
          />
        </View>
      </Pressable>
    );
  };

  return (
    <FlatList
      data={props.data}
      horizontal={true}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.contentContainerStyle}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
    />
  );
}
