import React, { useState, useEffect } from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { Colors, Images } from "../../theme/index";
import styles from "./style";
import _ from "underscore";
import { translate } from "../../utils/Localize";

export default function FilterList(props: any) {
  let raceFilterDataConst = [
    {
      id: 1,
      selectionText: "",
      selectionImage: Images.racingIcon,
      selected: props.sportId.includes(1) ? true : false,
      isDefault: true,
    },
    {
      id: 3,
      selectionText: "",
      selectionImage: Images.houndsIcon,
      selected: props.sportId.includes(3) ? true : false,
      isDefault: true,
    },
    {
      id: 2,
      selectionText: "",
      selectionImage: Images.harnessIcon,
      selected: props.sportId.includes(2) ? true : false,
      isDefault: true,
    },
  ];

  const countryFilterDataConst = [
    {
      id: 1,
      selectionText: translate("SelectionFour"),
      selectionImage: "",
      selected: true,
      isDefault: false,
      apiData: "Aus/NZ",
    },
    {
      id: 2,
      selectionText: translate("SelectionFive"),
      selectionImage: "",
      selected: true,
      isDefault: false,
      apiData: "Intl",
    },
  ];

  const [raceFilterData, setRaceData] = useState(raceFilterDataConst);
  const [countryFilterData, setCountryFilterData] = useState(
    countryFilterDataConst
  );

  useEffect(() => {
    if (
      JSON.stringify(props.sportId) == JSON.stringify(props.selectedRaceType)
    ) {
    } else {
      if (JSON.stringify(props.sportId) != JSON.stringify(props.prevSportId)) {
        setRaceData(raceFilterDataConst);
      }
    }
  }, [props.sportId]);

  const onValueChange = (item, index, itemType) => {
    if (itemType == 1) {
      let temp = [...raceFilterData];
      var filteredData = _.filter(temp, {
        selected: true,
      });
      if (filteredData?.length - 1 != 0 && item?.selected) {
        temp[index].selected = false;
      } else {
        temp[index].selected = true;
      }
      setRaceData(temp);
      let idArray = [];
      temp.forEach((item) => {
        if (item.selected) {
          idArray.push(item?.id);
        }
      });
      if (JSON.stringify(props.selectedRaceType) == JSON.stringify(idArray)) {
      } else {
        props.onRaceTypeFilterChange(idArray);
      }
    } else {
      let temp = [...countryFilterData];
      var filteredData = _.filter(temp, {
        selected: true,
      });
      if (filteredData?.length - 1 != 0 && item?.selected) {
        temp[index].selected = false;
      } else {
        temp[index].selected = true;
      }
      setCountryFilterData(temp);
      let countryIDArray = [];
      temp.forEach((item) => {
        if (item.selected) {
          countryIDArray.push(item?.apiData);
        }
      });

      if (JSON.stringify(props.prevAusId) == JSON.stringify(countryIDArray)) {
      } else {
        props.onCountryTypeFilterChange(countryIDArray);
      }
    }
  };

  const renderItem = (
    item: {
      id?: number;
      selectionText: any;
      selectionImage?: string;
      selected: any;
      isDefault?: boolean;
    },
    index: number,
    itemtype: number
  ) => {
    return (
      <Pressable
        key={index + ""}
        onPress={() => onValueChange(item, index, itemtype)}
      >
        <View style={styles.rowView}>
          <View style={styles.radioViewStyle}>
            <View
              style={[
                styles.radioSelectionStyle,
                {
                  borderColor: item.selected
                    ? Colors.appColorSelection
                    : Colors.white,
                  backgroundColor: item.selected
                    ? Colors.appColorSelection
                    : Colors.white,
                },
              ]}
            />
          </View>

          {!item.isDefault ? (
            <Text style={styles.selectionText} numberOfLines={1}>
              {item.selectionText}
            </Text>
          ) : (
            <Image
              style={styles.selectionImage}
              resizeMode="contain"
              source={item?.selectionImage}
            />
          )}
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.scrollContainerStyle}>
      <ScrollView overScrollMode="never">
        <View style={styles.filterViewStyle}>
          {raceFilterData?.length > 0 &&
            raceFilterData?.map((filter, i) => renderItem(filter, i, 1))}
          {countryFilterData?.length > 0 &&
            countryFilterData?.map((filter, i) => renderItem(filter, i, 2))}
        </View>
      </ScrollView>
    </View>
  );
}
