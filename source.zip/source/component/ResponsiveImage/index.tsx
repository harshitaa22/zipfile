import { Dimensions, Text, View } from "react-native";
import React, { useState } from "react";

import FastImage from "react-native-fast-image";

import { Images } from "../../theme";
import { SvgCssUri } from "react-native-svg";

const ResponsiveImage = (props: any) => {
  const width = Dimensions.get("window").width;

  const [loaded, setLoaded] = useState(false);
  const [isError, setIsError] = useState(false);
  const [aspectRatio, setAspectRatio] = useState(0.6);

  const onLoadError = () => {
    setIsError(true);
  };
  const onLoadMethod = (e) => {
    setLoaded(true);
    if (e) {
      setAspectRatio(
        parseInt(e?.nativeEvent?.height) / parseInt(e?.nativeEvent?.width)
      );
    }
  };

  return (
    <View style={props.style}>
      {props.source != null && props.source.length != 0 ? (
        <>
          {props?.source?.substr(props?.source?.length - 3) == "svg" ? (
            <>
              <SvgCssUri
                width={props.style.width}
                height={props.style.height}
                uri={props.source}
              />
            </>
          ) : !loaded && isError ? (
            <FastImage
              source={Images.noImage}
              style={props.style}
              resizeMode={props.resizeMode}
            />
          ) : (
            <>
              <FastImage
                source={{
                  uri: props?.source,
                }}
                style={[
                  props?.bannerStyle,
                  {
                    // width: width,
                    height: width * aspectRatio,
                    marginBottom: 10,
                  },
                ]}
                onLoad={(e) => onLoadMethod(e)}
                onError={onLoadError.bind()}
                resizeMode={"contain"}
              />
            </>
          )}
        </>
      ) : (
        <FastImage
          // source={Images.SouthernCrossBet}
          source={Images.noImage}
          style={props.style}
          resizeMode={props.resizeMode}
        />
      )}
    </View>
  );
};

export default ResponsiveImage;
