import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({

  bookMarkList: {
    width:'100%'
  },
  horizontalContainerStyle:{
    width:'100%',
    flexDirection:'row',
    marginTop:Metrics.rfv(10)
  },
  dummySpaceStyle:{
width:Metrics.rfv(5)
  },
  leftContainerStyle:{
    flex:1,
    flexDirection:'row',
    backgroundColor:Colors.darkGrayBackground,
    paddingVertical:Metrics.rfv(7),
    paddingHorizontal:Metrics.rfv(10),
borderRadius:Metrics.rfv(15)
  },
  titleTextStyle:{
    flex:1,
    color: Colors.white,
    fontSize: Metrics.rfv(10),
    lineHeight: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
  },
  valueTextStyle:{
    color: Colors.white,
    fontSize: Metrics.rfv(10),
    lineHeight: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
  }
  
});
