import React from "react";
import { Text, View } from "react-native";
import { translate } from "../../utils/Localize";
import styles from "./style";

type OddsShortFromListProps = {
  data?: [];
};

export default function OddsShortFrom(props: OddsShortFromListProps) {
  const { data } = props;

  return (
    <View style={styles.bookMarkList}>
      <View style={styles.horizontalContainerStyle}>
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("Track")}</Text>

          <Text style={styles.valueTextStyle}>
            {data?.past_runner_performances?.track?.starts
              ? data?.past_runner_performances?.track?.starts
              : "0"}
            {data?.past_runner_performances?.track?.wins
              ? data?.past_runner_performances?.track?.wins
              : "0"}
            -
            {data?.past_runner_performances?.track?.second
              ? data?.past_runner_performances?.track?.second
              : "0"}
            -
            {data?.past_runner_performances?.track?.thirds
              ? data?.past_runner_performances?.track?.thirds
              : "0"}
          </Text>
        </View>
        <View style={styles.dummySpaceStyle} />
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("Distance")}</Text>
          <Text style={styles.valueTextStyle}>
            {data?.past_runner_performances?.distance?.starts
              ? data?.past_runner_performances?.distance?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.distance?.wins
              ? data?.past_runner_performances?.distance?.wins
              : "0"}
            -
            {data?.past_runner_performances?.distance?.second
              ? data?.past_runner_performances?.distance?.second
              : "0"}
            -
            {data?.past_runner_performances?.distance?.thirds
              ? data?.past_runner_performances?.distance?.thirds
              : "0"}
          </Text>
        </View>
      </View>

      <View style={styles.horizontalContainerStyle}>
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("StartTrkDst")}</Text>
          <Text style={styles.valueTextStyle}>
            {data?.past_runner_performances?.track_distance?.starts
              ? data?.past_runner_performances?.track_distance?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.track_distance?.wins
              ? data?.past_runner_performances?.track_distance?.wins
              : "0"}
            -
            {data?.past_runner_performances?.track_distance?.second
              ? data?.past_runner_performances?.track_distance?.second
              : "0"}
            -
            {data?.past_runner_performances?.track_distance?.thirds
              ? data?.past_runner_performances?.track_distance?.thirds
              : "0"}
          </Text>
        </View>
        <View style={styles.dummySpaceStyle} />
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("StartFirstUp")}</Text>
          <Text style={styles.valueTextStyle}>
            {" "}
            {data?.past_runner_performances?.first_up?.starts
              ? data?.past_runner_performances?.first_up?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.first_up?.wins
              ? data?.past_runner_performances?.first_up?.wins
              : "0"}
            -
            {data?.past_runner_performances?.first_up?.second
              ? data?.past_runner_performances?.first_up?.second
              : "0"}
            -
            {data?.past_runner_performances?.first_up?.thirds
              ? data?.past_runner_performances?.first_up?.thirds
              : "0"}
          </Text>
        </View>
      </View>

      <View style={styles.horizontalContainerStyle}>
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>
            {translate("StartSecondUp")}
          </Text>
          <Text style={styles.valueTextStyle}>
            {" "}
            {data?.past_runner_performances?.second_up?.starts
              ? data?.past_runner_performances?.second_up?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.second_up?.wins
              ? data?.past_runner_performances?.second_up?.wins
              : "0"}
            -
            {data?.past_runner_performances?.second_up?.second
              ? data?.past_runner_performances?.second_up?.second
              : "0"}
            -
            {data?.past_runner_performances?.second_up?.thirds
              ? data?.past_runner_performances?.second_up?.thirds
              : "0"}
          </Text>
        </View>
        <View style={styles.dummySpaceStyle} />
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("Firm")}</Text>
          <Text style={styles.valueTextStyle}>
            {" "}
            {data?.past_runner_performances?.firm?.starts
              ? data?.past_runner_performances?.firm?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.firm?.wins
              ? data?.past_runner_performances?.firm?.wins
              : "0"}
            -
            {data?.past_runner_performances?.firm?.second
              ? data?.past_runner_performances?.firm?.second
              : "0"}
            -
            {data?.past_runner_performances?.firm?.thirds
              ? data?.past_runner_performances?.firm?.thirds
              : "0"}
          </Text>
        </View>
      </View>

      <View style={styles.horizontalContainerStyle}>
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("StarGood")}</Text>
          <Text style={styles.valueTextStyle}>
            {data?.past_runner_performances?.good?.starts
              ? data?.past_runner_performances?.good?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.good?.wins
              ? data?.past_runner_performances?.good?.wins
              : "0"}
            -
            {data?.past_runner_performances?.good?.second
              ? data?.past_runner_performances?.good?.second
              : "0"}
            -
            {data?.past_runner_performances?.good?.thirds
              ? data?.past_runner_performances?.good?.thirds
              : "0"}
          </Text>
        </View>
        <View style={styles.dummySpaceStyle} />
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("StarSoft")}</Text>
          <Text style={styles.valueTextStyle}>
            {data?.past_runner_performances?.soft?.starts
              ? data?.past_runner_performances?.soft?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.soft?.wins
              ? data?.past_runner_performances?.soft?.wins
              : "0"}
            -
            {data?.past_runner_performances?.soft?.second
              ? data?.past_runner_performances?.soft?.second
              : "0"}
            -
            {data?.past_runner_performances?.soft?.thirds
              ? data?.past_runner_performances?.soft?.thirds
              : "0"}
          </Text>
        </View>
      </View>

      <View style={styles.horizontalContainerStyle}>
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>{translate("StartHeavy")}</Text>
          <Text style={styles.valueTextStyle}>
            {data?.past_runner_performances?.heavy?.starts
              ? data?.past_runner_performances?.heavy?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.heavy?.wins
              ? data?.past_runner_performances?.heavy?.wins
              : "0"}
            -
            {data?.past_runner_performances?.heavy?.second
              ? data?.past_runner_performances?.heavy?.second
              : "0"}
            -
            {data?.past_runner_performances?.heavy?.thirds
              ? data?.past_runner_performances?.heavy?.thirds
              : "0"}
          </Text>
        </View>
        <View style={styles.dummySpaceStyle} />
        <View style={styles.leftContainerStyle}>
          <Text style={styles.titleTextStyle}>
            {translate("StartSynthetic")}
          </Text>
          <Text style={styles.valueTextStyle}>
            {data?.past_runner_performances?.synthetic?.starts
              ? data?.past_runner_performances?.synthetic?.starts
              : "0"}{" "}
            {data?.past_runner_performances?.synthetic?.wins
              ? data?.past_runner_performances?.synthetic?.wins
              : "0"}
            -
            {data?.past_runner_performances?.synthetic?.second
              ? data?.past_runner_performances?.synthetic?.second
              : "0"}
            -
            {data?.past_runner_performances?.synthetic?.thirds
              ? data?.past_runner_performances?.synthetic?.thirds
              : "0"}
          </Text>
        </View>
      </View>
    </View>
  );
}
