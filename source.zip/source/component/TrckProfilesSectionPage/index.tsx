import React, { useEffect, useRef, useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import { CommonStyle, Metrics } from "../../theme";
import { LeftUpArrow, RightUpArrow } from "../../theme/svg";
import { print_data } from "../../utils/Logs";
import styles from "./style";

export default function TrackProfileSectionPage(props: any) {
  const listViewRef = useRef(null);
  const [index, setIndex] = useState(0);
  const [screenWidth, setScreenWidth] = useState(0);
  const [arrowWidth, setarrowWidth] = useState(0);
  const width = screenWidth - arrowWidth * 2 - 10;

  useEffect(() => {
    if (props?.selectedItemIndex < props?.data?.length) {
      print_data(props?.selectedItemIndex);
      listViewRef?.current?.scrollToIndex({
        index: props?.selectedItemIndex,
        Animated: true,
      });
    }
  }, [props?.selectedItemIndex, props?.data]);

  useEffect(() => {
    if (index < props?.data?.length) {
      listViewRef?.current?.scrollToIndex({
        index,
        Animated: true,
      });
    }
  }, [index]);

  const onTabClick = (item, index) => {
    if (props.onItemClick) {
      props.onItemClick(item, index);
    }
  };

  const renderItem = (item, index) => {
    return (
      <>
        <Pressable
          onPress={() => onTabClick(item?.id, index)}
          style={[
            styles.raceTabTextSelectedTrue(item?.id === props.isSelectIndex),
            { width: width / 2 },
          ]}
        >
          <View style={styles.commonRow}>
            <Text
              numberOfLines={1}
              style={styles.racingTabTextTrue(item?.id === props.isSelectIndex)}
            >
              {item?.initialTitle}
            </Text>
          </View>
        </Pressable>
        {index !== props?.data?.length - 1 && (
          <View style={{ width: 10 }}></View>
        )}
      </>
    );
  };

  return (
    <View
      style={CommonStyle.alignCenterView}
      onLayout={(event) => {
        const { width } = event.nativeEvent.layout;
        setScreenWidth(width);
      }}
    >
      <Pressable
        onPress={() => {
          if (index == 0) {
            return;
          }
          setIndex(index - 2);
        }}
        style={styles.arrow}
        onLayout={(event) => {
          const { width } = event.nativeEvent.layout;
          setarrowWidth(width);
        }}
      >
        <LeftUpArrow width={Metrics.rfv(9)} height={Metrics.rfv(15)} />
      </Pressable>
      <View style={CommonStyle.commonFlex}>
        <FlatList
          ref={listViewRef}
          data={props?.data}
          horizontal={true}
          onScrollToIndexFailed={(info) => {
            const wait = new Promise((resolve) => setTimeout(resolve, 500));
            wait.then(() => {
              listViewRef?.current?.scrollToIndex({
                index: info.index,
                animated: true,
              });
            });
          }}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.contentContainerStyle}
          renderItem={({ item, index }) => renderItem(item, index)}
          keyExtractor={(item, index) => index.toString()}
          extraData={props?.isSelectIndex}
        />
      </View>
      <Pressable
        style={styles.arrowRight}
        onPress={() => {
          if (index == props?.data?.length - 1) {
            return;
          }
          setIndex(index + 2);
        }}
      >
        <RightUpArrow width={Metrics.rfv(9)} height={Metrics.rfv(15)} />
      </Pressable>
    </View>
  );
}
