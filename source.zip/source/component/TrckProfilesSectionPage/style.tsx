import { Dimensions, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";
const windowWidth = Dimensions.get("window").width;

export default StyleSheet.create({
  itemSeparatorComponentTrue: {},
  itemSeparatorComponentFalse: {
    backgroundColor: Colors.black,
    height: Metrics.rfv(25),
    width: Metrics.rfv(1),
    marginHorizontal: Metrics.rfv(15),
  },

  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  raceTabTextSelectedTrue: (visible) => ({
    height: Metrics.rfv(32),
    flex: 1,
    paddingHorizontal: Metrics.rfv(5),
    // width: windowWidth / 2 - 41,
    backgroundColor: visible ? Colors.linearColor1 : Colors.white,
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
    borderWidth: Metrics.rfv(2),
    borderColor: Colors.linearColor1,
    alignSelf: "center",
    // marginRight: Metrics.rfv(10),
  }),

  raceTabTextSelectedFalse: {
    height: Metrics.rfv(32),
    flex: 1,

    width: windowWidth / 2 - 41,
    paddingHorizontal: Metrics.rfv(5),
    backgroundColor: Colors.white,
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
    borderWidth: Metrics.rfv(2),
    borderColor: Colors.linearColor1,
    alignSelf: "center",
    // marginRight: Metrics.rfv(10),
  },
  contentContainerStyle: {
    height: Metrics.rfv(38),
    // flex: 1,
  },
  racingTabTextTrue: (visible) => ({
    color: visible ? Colors.white : Colors.black,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    textAlign: "center",
  }),
  racingTabTextFalse: {
    color: Colors.black,
    fontSize: Metrics.rfv(13),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    textAlign: "center",
  },
  commonRow: {
    alignItems: "center",
    flexDirection: "row",
  },
  arrowRight: {
    paddingLeft: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
  },
  arrow: {
    paddingRight: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(10),
  },
});
