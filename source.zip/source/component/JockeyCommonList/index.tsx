import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import CardView from "react-native-cardview";
import { NAVIGATION } from "../../navigation";
import { Colors, Metrics } from "../../theme";
import { DownBlueArrow, UpBlueArrow } from "../../theme/svg";
import { translate } from "../../utils/Localize";
import { print_data } from "../../utils/Logs";
import styles from "./style";

export default function JockeyCommonList(props: any) {
  const navigation = useNavigation();
  const [jockeyStatesData, setJockeyStatesData] = useState([]);
  const [dataUpdated, setDataUpdated] = useState(false);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    let jockeyData = [...props.data];
    setJockeyStatesData(jockeyData);
  }, []);

  const onItemPress = (item, index) => {
    print_data("press");
    print_data(item);
    if (item.isExpanded) {
      item.isExpanded = false;
    } else {
      jockeyStatesData.forEach((item, _index) => {
        let obj = { ...item }; //Remember to copy Object
        if (_index === index) {
          obj.isExpanded = true;
        } else {
          obj.isExpanded = false;
        }
        jockeyStatesData[_index] = obj;
      });
    }
    setDataUpdated(!dataUpdated);
    print_data(jockeyStatesData);
    setJockeyStatesData(jockeyStatesData);
  };

  const renderListItem = (item: any, index: any, listTitle: any) => {
    print_data(listTitle);
    return (
      <View key={index}>
        <CardView
          style={styles.SeeAllwinView}
          cardElevation={6}
          cardMaxElevation={3}
        >
          <Pressable style={styles.commonRow} onPress={props.onClick}>
            <Text style={styles.startsText}>{translate("Starts")}</Text>
            <Text style={styles.startsPoints}>{item?.starts}</Text>
          </Pressable>
          <View style={styles.bootomWidth} />
          <View style={styles.commonRow}>
            <Text style={styles.startsText}>{translate("1st")}</Text>
            <Text style={styles.startsPoints}>{item?.first}</Text>
          </View>
          <View style={styles.bootomWidth} />
          <View style={styles.commonRow}>
            <Text style={styles.startsText}>{translate("2nd")}</Text>
            <Text style={styles.startsPoints}>{item?.second}</Text>
          </View>
          <View style={styles.bootomWidth} />
          <View style={styles.commonRow}>
            <Text style={styles.startsText}>{translate("3rd")}</Text>
            <Text style={styles.startsPoints}>{item?.third}</Text>
          </View>
          <View style={styles.bootomWidth} />
          <View style={styles.commonRow}>
            <Text style={styles.startsText}>{translate("winText")}</Text>
            <Text style={styles.startsPoints}>{item?.win}</Text>
          </View>
          <View style={styles.bootomWidth} />
          <View style={styles.commonRow}>
            <Text style={styles.startsText}>{translate("AvgWinText")}</Text>
            <Text style={styles.startsPoints}>{item?.place}</Text>
          </View>
          <View style={styles.bootomWidth} />
          <View style={styles.commonRow}>
            <Text style={styles.startsText}>{translate("placeText")}</Text>
            <Text style={styles.startsPoints}>{item?.avgWinOdds}</Text>
          </View>
          <View style={styles.bootomWidth} />
          <View style={styles.commonRow}>
            <Text style={styles.startsText}>{translate("RoiText")}</Text>
            <Text style={styles.startsPoints}>{item?.roi}</Text>
          </View>
        </CardView>
        <Pressable
          style={styles.viewProfileContainer}
          onPress={() => {
            print_data(listTitle);
            navigation.navigate(NAVIGATION.TAINER_STATS_PROFILETAB, {
              listTitleData: listTitle,
            });
          }}
        >
          <Text style={styles.viewProfileText}>{translate("ViewProfile")}</Text>
        </Pressable>
      </View>
    );
  };

  const renderItem = (itemData: any, index: any) => {
    return (
      <>
        <Pressable onPress={() => onItemPress(itemData, index)}>
          {index == 0 ? null : <View style={styles.bottomWidth} />}
          <View style={styles.container}>
            <Text
              style={itemData?.isExpanded ? styles.listText : styles.listTitle}
            >
              {itemData?.listTitle}
            </Text>
            {itemData?.id == 0 ? null : (
              <>
                <View style={{}}>
                  {itemData?.isExpanded ? (
                    <UpBlueArrow
                      width={Metrics.rfv(15)}
                      height={Metrics.rfv(10)}
                      color={Colors.orange}
                    />
                  ) : (
                    <DownBlueArrow
                      width={Metrics.rfv(15)}
                      height={Metrics.rfv(10)}
                      color={Colors.orange}
                    />
                  )}
                </View>
              </>
            )}
          </View>
          {itemData?.date && index == 0 ? (
            <Text style={styles.dateText}>{itemData?.date}</Text>
          ) : null}
        </Pressable>

        <View>
          {itemData?.isExpanded && itemData?.id != 0 && (
            <FlatList
              data={props.listItem}
              scrollEnabled={true}
              contentContainerStyle={styles.containerStyle}
              renderItem={({ item, index }) => {
                return renderListItem(item, index, itemData?.listTitle);
              }}
              keyExtractor={(item, index) => index.toString()}
              showsHorizontalScrollIndicator={false}
              showsVerticalScrollIndicator={false}
              extraData={dataUpdated}
            />
          )}
        </View>
      </>
    );
  };

  return (
    <FlatList
      data={jockeyStatesData}
      scrollEnabled={false}
      contentContainerStyle={styles.containerStyle}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
      extraData={dataUpdated}
    />
  );
}
