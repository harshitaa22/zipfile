import React, { useState, useEffect } from "react";
import {  Text, View } from "react-native";
import styles from "./style";
import { useTimer } from "react-timer-hook";
import { translate } from "../../utils/Localize";
type Props = {
  expiryTimestamp?: number;
};
export default function RaceCountDown(props:Props) {

    const { days, seconds, minutes, hours, restart } = useTimer({
        expiryTimestamp: props.expiryTimestamp,
      });
      const refreshTime = (time) => {
        restart(time);
      };
    
      useEffect(() => {
        refreshTime(props.expiryTimestamp);
      }, [props.expiryTimestamp]);
    
  return (
       <Text style={styles.timerStyle}>{days > 0 ? String(days).padStart(2,'0') + "d" : ""} {hours > 0 ? String(hours).padStart(2, '0') + "h" : "0h"}{" "}
             {minutes > 0 ? String(minutes).padStart(2,"0") + "m" : "0m"}{" "}
             {days > 0 ? "" : seconds > 0 ? String(seconds).padStart(2,'0') + "s" : "0s"}</Text>
  );
}
