import { Dimensions, StyleSheet } from "react-native";
import { Colors, Metrics } from "../../theme/index";
import { print_data } from "../../utils/Logs";
print_data(Dimensions.get("window").width);
export default StyleSheet.create({
  partnerContainer: {
    height: (Dimensions.get("window").width - 180) / 3,
    width: Dimensions.get("window").width / 3,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    paddingHorizontal: Metrics.rfv(15),
  },

  playUpIconStyle: {
    width: "100%",
    height: "100%",
  },
  listContainer: {
    width: "100%",
    marginBottom: Metrics.rfv(20),
  },
  dotContainers: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    bottom: -20,
    width: "100%",
  },
  dotWrapper: {
    marginHorizontal: 5,
  },
  dot: {
    width: Metrics.rfv(8),
    height: Metrics.rfv(8),
    borderRadius: Metrics.rfv(6),
    borderWidth: Metrics.rfv(1),
    borderColor: Colors.linearColor1,
  },
  activeDot: {
    backgroundColor: Colors.linearColor2,
    borderColor: Colors.linearColor2,
    borderWidth: 2,
  },
});
