import React, { useEffect, useState } from "react";
import { Dimensions, FlatList, Linking, Pressable, View } from "react-native";
//style
import styles from "./style";
//api
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
//component
import { CommonStyle } from "../../theme";
import { print_data } from "../../utils/Logs";
import ImageLoad from "../ImageLoad";

export default function PartnersList() {
  const [bookkeeperData, setBookKeeperData] = useState([]);
  const [indicatorData, setIndicatorData] = useState(0);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    fetchBookKeeper();
  }, []);
  // useEffect(() => {
  //   if (bookkeeperData) {
  //     const actualData = [...bookkeeperData];
  //     setIndicatorData(actualData.splice(14));
  //   }
  // }, []);

  const fetchBookKeeper = async () => {
    try {
      const response = await callApi(
        API_CONFIG.GET_OUR_PARTNERS,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body?.status === 200) {
        let data = response?.body?.data?.result;
        let b = [
          {
            id: 399,
          },
          {
            id: 400,
          },
        ];
        let a = [
          {
            id: 399,
          },
        ];
        if (data?.length % 3 == 0) {
          setBookKeeperData(response?.body?.data?.result);
          const actualData = response?.body?.data?.result;
          setIndicatorData(
            // actualData.splice(response?.body?.data?.result?.length / 3)
            actualData?.length / 3
          );
        } else {
          if ((data?.length + 2) % 3 == 0) {
            data?.push(...b);
            setBookKeeperData(data);
            setIndicatorData(data?.length / 3);
          } else {
            data?.push(...a);
            setBookKeeperData(data);
            setIndicatorData(data?.length / 3);
          }
        }
      }
    } catch (error) {}
  };
  const renderDot = (index) => {
    return (
      <View style={[styles.dot, index === activeIndex && styles.activeDot]} />
    );
  };
  const onSlideChange = (event: any) => {
    const slideOffset = event.nativeEvent.contentOffset.x;
    const currentIndex = Math.round(
      slideOffset / Dimensions.get("window").width
    );
    setActiveIndex(currentIndex);
  };
  const handleBookkeeperCounter = async (BookKeeperId) => {
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: "ourpartner",
    };

    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const renderItem = (item: any, index: any) => {
    return (
      <Pressable
        key={index}
        style={styles.partnerContainer}
        onPress={() => {
          Linking.openURL(item?.affiliate_link),
            handleBookkeeperCounter(item?.id);
        }}
      >
        {item?.logo ? (
          <ImageLoad
            style={styles.playUpIconStyle}
            source={
              item?.logo?.includes("uploads")
                ? API_URL + "/" + item?.logo
                : item?.logo
            }
            resizeMode={"contain"}
          />
        ) : (
          <View style={styles.playUpIconStyle} />
        )}
      </Pressable>
    );
  };

  var ourpartnerIndicatorData = [];

  for (let i = 0; i < indicatorData; i++) {
    ourpartnerIndicatorData.push(
      <View key={i} style={styles.dotWrapper}>
        {renderDot(i)}
      </View>
    );
  }

  return (
    <View style={styles.listContainer}>
      <FlatList
        scrollEnabled={true}
        data={bookkeeperData}
        horizontal
        pagingEnabled
        onScroll={(event) => onSlideChange(event)}
        decelerationRate={"normal"}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => renderItem(item, index)}
        keyExtractor={(item, index) => index.toString()}
      />
      <View style={styles.dotContainers}>
        <>
          <View style={CommonStyle.commonRow}>{ourpartnerIndicatorData}</View>
        </>
      </View>
    </View>
  );
}
