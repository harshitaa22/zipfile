import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { ErrorTextImage } from "../../theme/svg";
import { Colors, Fonts, Metrics } from "../../theme";

export default function ErrorText(props: any) {
  return (
    <View>
      {props.is_visible ? (
        <View style={styles.containerView}>
          <View>
            <ErrorTextImage style={styles.errorImageStyle} />
          </View>
          <Text style={styles.errorTextStyle}>{props.errorText}</Text>
        </View>
      ) : null}
    </View>
  );
}
const styles = StyleSheet.create({
  errorTextStyle: {
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    color: Colors.red,
    marginLeft: Metrics.rfv(3),
  },
  errorImageStyle: {
    width: Metrics.rfv(12),
    height: Metrics.rfv(12),
  },
  containerView: {
    flexDirection: "row",
    marginTop: Metrics.rfv(5),
  },
});
