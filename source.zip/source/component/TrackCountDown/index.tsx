import React, { useState, useEffect } from "react";
import { Text, View } from "react-native";
import styles from "./style";
import { useTimer } from "react-timer-hook";
import { translate } from "../../utils/Localize";
type Props = {
  expiryTimestamp?: number;
};
export default function TrackCountDown(props: Props) {
  const { days, seconds, minutes, hours, restart } = useTimer({
    expiryTimestamp: props.expiryTimestamp,
    onExpire: () => {},
  });
  useEffect(() => {
    restart(props.expiryTimestamp);
  }, [props.expiryTimestamp]);

  return (
    <View style={styles.containerStyle}>
      {props.raceData?.startTimeDate !== null ? (
        <View>
          {hours === 0 && minutes === 0 && seconds === 0 ? (
            <Text style={styles.closeTextStyle}>{translate("ClosedTxt")}</Text>
          ) : (
            <Text style={styles.timerStyle}>
              {" "}
              {days > 0 ? days + "d" : ""}{" "}
              {days > 0 ? hours + "h" : hours > 0 ? hours + "h" : ""}{" "}
              {days === 0 ? (minutes > 0 ? minutes + "m" : "0m") : ""}{" "}
              {days === 0 && hours === 0 && minutes <= 5
                ? seconds > 0
                  ? seconds + "s"
                  : "0s"
                : ""}
            </Text>
          )}
        </View>
      ) : (
        <Text style={styles.timerStyle}>-</Text>
      )}
    </View>
  );
}
