import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
    containerStyle:{
paddingHorizontal:Metrics.rfv(5)
    },
    closeTextStyle: {
    color: Colors.red,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
  },
  timerStyle:{
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
  }
});
