import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";
import Modal from "react-native-modal";

import { translate } from "../../utils/Localize";
import styles from "./style";
import { Colors, Metrics } from "../../theme";
import Button from "../Button";

export default function DeleteModal(props: any) {
    const [isModalVisible, setIsModalVisible] = useState(props.isVisible);

    useEffect(() => {
        setIsModalVisible(props.isVisible);
    }, [props.isVisible]);

    // const onCloseModal = () => {
    //     if (props.showModel !== null) {
    //         props.showModel(false);
    //     } else {
    //         setIsModalVisible(false);
    //     }
    // };
    return (
        <Modal
            isVisible={isModalVisible}
            style={styles.modal}
            transparent={false}
            backdropColor={Colors.black}
        >
            <View style={styles.dialogStyle}>
                <View style={styles.modalView}>
                    <Text style={styles.deleteText}>{translate('Deletetext')}</Text>
                    <View style={styles.commonRow}>
                        <View style={styles.modalView}>
                            <Button
                                marginTop={0}
                                disabled={false}
                                onPress={props.onNextPress}
                                title={translate("Yes")}
                                borderColor={Colors.linearColor2}
                                color={Colors.linearColor2}
                                fontSize={Metrics.rfv(14)}
                                backgroundColor={Colors.white}
                                height={Metrics.rfv(40)}
                            />
                        </View>
                        <View style={styles.gapViewStyle} />
                        <View style={styles.modalView}>
                            <Button
                                marginTop={0}
                                disabled={false}
                                onPress={props.onPressBack}
                                title={translate("No")}
                                borderColor={Colors.white}
                                color={Colors.white}
                                fontSize={Metrics.rfv(14)}
                                backgroundColor={Colors.linearColor2}
                                height={Metrics.rfv(40)}
                            />
                        </View>
                    </View>
                </View>
            </View>
        </Modal>
    );
}
