import { StyleSheet } from "react-native";
import { Colors, Metrics, Fonts } from "../../theme";

export default StyleSheet.create({
  modal: {
    justifyContent: "center",
    alignItems: "center",
    margin: Metrics.rfv(0),
    paddingHorizontal: Metrics.rfv(15),
  },
  commonFlex: {
    flex: 1,
  },
  commonRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  dialogStyle: {
    flexDirection: "row",
    width: "100%",
    height: Metrics.rfv(180),
    paddingHorizontal: Metrics.rfv(15),
    justifyContent: "center",
    borderRadius: Metrics.rfv(5),
    backgroundColor: Colors.white,
  },
  deleteText: {
    textAlign: "center",
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(22),
    marginBottom: Metrics.rfv(8),
  },
  modalView: {
    flex: 1,
    marginTop: Metrics.rfv(30),
  },
});
