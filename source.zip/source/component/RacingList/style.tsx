import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  mainHomePageView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  signUpButton: {
    marginLeft: Metrics.rfv(12),
  },
  loginButton: {
    marginLeft: Metrics.rfv(150),
  },
  headerStyle: {
    justifyContent: "space-between",
    flexDirection: "row",
    margin: Metrics.rfv(15),
  },
  AdStyle: {
    margin: Metrics.rfv(15),
  },
  listTitle: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: Metrics.rfv(10),
    alignItems: "center",
  },
  renderListStyle: {
    flexDirection: "row",
    marginHorizontal: Metrics.rfv(5),
    alignItems: "center",
  },
  imageStyle: {
    width: Metrics.rfv(27),
    height: Metrics.rfv(27),
    tintColor: Colors.linearColor1,
    resizeMode: "contain",
  },
  textStyle: {
    color: Colors.black,
    flex: 1,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(18),
    marginLeft: Metrics.rfv(10),
  },
  timeStyle: {
    borderRadius: Metrics.rfv(3),
    height: Metrics.rfv(22),
    width: Metrics.rfv(50),
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.orange,
  },
  timeTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    textAlign: "center",
    fontFamily: Fonts.IN_SemiBold,
  },
  nextTopicTextStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(14),
    fontSize: Metrics.rfv(12),
  },
  seeAllStyle: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    textDecorationLine: "underline",
    fontFamily: Fonts.IN_Regular,
    textDecorationColor: Colors.linearColor2,
  },
  itemSeparatorComponent: {
    height: Metrics.rfv(1),
    backgroundColor: Colors.borderLightGrey,
    marginHorizontal: Metrics.rfv(15),
  },
  noDataFoundMainStyle: {
    alignSelf: "center",
  },
  noDataFoundText: {
    color: Colors.black,
    fontSize: Metrics.rfv(18),
    margin: Metrics.rfv(50),
    textAlign: "center",
  },
  outerBoxStyle: {
    padding: 20,

    borderRadius: Metrics.rfv(8),
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.5),
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(8),
    marginBottom: Metrics.rfv(8),
  },
  boxWithShadow: {
    width: "100%",
    borderRadius: Metrics.rfv(10),
    backgroundColor: Colors.white,
    padding: Metrics.rfv(15),
    marginTop: Metrics.rfv(8),
    marginBottom: Metrics.rfv(20),
  },
});
