import React from "react";
import {
  FlatList,
  GestureResponderEvent,
  Image,
  Pressable,
  Text,
  View,
} from "react-native";
import styles from "./style";
import CardView from "react-native-cardview";
import { translate } from "../../utils/Localize";

type RacingListProps = {
  data?: [];
  topicTitle?: string;
  onPress?: (event: GestureResponderEvent) => void;
};

export default function RacingList(props: RacingListProps) {
  const { data = [], onPress, topicTitle = "" } = props;

  const renderItem = (item, index) => {
    return (
      <View>
        {index == 0 ? null : <View style={styles.bottomWidth} />}
        <View style={styles.renderListStyle}>
          <Image style={styles.imageStyle} source={item.imageRacing} />
          <Text style={styles.textStyle}>{item.textRacing}</Text>
          <View style={styles.timeStyle}>
            <Text style={styles.timeTextStyle}>{item.timeRacing}</Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View>
      <View style={styles.listTitle}>
        <Text style={styles.nextTopicTextStyle}>{topicTitle}</Text>
        <Pressable onPress={props.onPress}>
          <Text style={styles.seeAllStyle}>{translate("SeeAll")}</Text>
        </Pressable>
      </View>
      <CardView
        style={styles.boxWithShadow}
        cardElevation={5}
        cardMaxElevation={4}
        cornerRadius={7}
      >
        <FlatList
          data={data}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => renderItem(item, index)}
          ListEmptyComponent={() => {
            return (
              <View style={styles.noDataFoundMainStyle}>
                <Text style={styles.noDataFoundText}>
                  {translate("NoDataFound")}
                </Text>
              </View>
            );
          }}
        />
      </CardView>
    </View>
  );
}
