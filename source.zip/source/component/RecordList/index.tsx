import React, { useState } from "react";
import { FlatList, Text, View } from "react-native";
import styles from "./style";

export default function RecordList(props: any) {
  const [data] = useState(props?.data);

  const renderItem = (item: any, index1: any) => {
    return (
      <View style={styles.container} key={index1}>
        <Text style={styles.listTitle}>{item?.listTitle}</Text>
        <View style={styles.bottomWidth} />
        <Text style={styles.detailsTitle}>{item?.distance}</Text>
        <View style={styles.bottomWidth} />
        <Text style={styles.detailsTitle}>{item?.recordTime}</Text>
        <View style={styles.bottomWidth} />
        <Text style={styles.detailsTitle}>{item?.avgSpeed}</Text>
        <View style={styles.bottomWidth} />
        <Text style={styles.detailsTitle}>{item?.date}</Text>
        <View style={styles.bottomWidth} />
        <Text style={styles.detailsTitle}>{item?.horse}</Text>
      </View>
    );
  };

  return (
    <FlatList
      data={data}
      scrollEnabled={true}
      horizontal
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    />
  );
}
