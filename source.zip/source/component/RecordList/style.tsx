import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  detailsText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    marginBottom: Metrics.rfv(5),
  },
  subTitleText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
  emptyImage: {
    height: Metrics.rfv(80),
    width: "100%",
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(1),
    borderBottomColor: Colors.lineBreak,
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(10),
    width: "100%",
    opacity: Metrics.rfv(0.5),
  },

  raceText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  raceMeterText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    marginTop: Metrics.rfv(10),
  },
  mainLoginView: {
    paddingVertical: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    marginTop: Metrics.rfv(7),
  },
  listTitle: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    marginRight: Metrics.rfv(20),
  },
  descriptionText: {
    color: Colors.LoremText,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  topText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    textAlign: "center",
  },
  topToteContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
  },
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
    justifyContent: "space-between",
  },
  container: {
    flex: 1,
    alignItems: "center",
  },
  indexView: {
    flexDirection: "row",
    alignItems: "center",
  },
  indexText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  indexContainer: {
    backgroundColor: Colors.linearColor2,
    height: Metrics.rfv(25),
    width: Metrics.rfv(25),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
    marginRight: Metrics.rfv(5),
  },
  indexLowText: {
    color: Colors.gray,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  indexLowContainer: {
    backgroundColor: Colors.drownDownBackground,
    height: Metrics.rfv(25),
    width: Metrics.rfv(25),
    borderRadius: Metrics.rfv(5),
    alignItems: "center",
    justifyContent: "center",
    marginRight: Metrics.rfv(5),
  },
  sepraterLine: {
    borderWidth: Metrics.rfv(0.3),
    height: Metrics.rfv(40),
    opacity: Metrics.rfv(0.5),
    color: Colors.borderLightGrey,
  },
  detailsTitle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    marginRight: Metrics.rfv(20),
  },
});
