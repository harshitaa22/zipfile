import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";
import { translate } from "../../utils/Localize";
import styles from "./style";
import Modal from "react-native-modal";
import { Platform } from "react-native";
import { WheelPicker } from "react-native-wheel-picker-android";
import { Metrics } from "../../theme";
import { Picker } from "@react-native-picker/picker";

export default function RaceTrackPicker(props) {
  const { eventData, isVisible, selectedEventId, eventDataAndroid } = props;

  const getEventIndex = () => {
    const eventIndex = eventData?.findIndex((item) => {
      return item?.value == selectedEventId;
    });
    return eventIndex;
  };

  const [isModalVisible, setIsModalVisible] = useState(isVisible);
  const [selectedIndex, setIsSelectedIndex] = useState(getEventIndex());
  const [isSelectedEventId, setIsSelectedEventId] = useState(selectedEventId);

  useEffect(() => {
    setIsModalVisible(isVisible);
  }, [isVisible]);

  const onCloseModal = (buttonType: number) => {
    if (props.showModel !== null) {
      props.showModel(false);
    } else {
      setIsModalVisible(false);
    }
    if (buttonType == 1) {
      const selectedData = {
        id: isSelectedEventId,
        title: eventData[selectedIndex]?.label,
      };
      props.onItemSelect(selectedData);
    }
  };
  return (
    <Modal
      isVisible={isModalVisible}
      onBackButtonPress={() => onCloseModal(0)}
      testID={"modal"}
      style={styles.modal}
      onBackdropPress={() => {
        onCloseModal(0);
      }}
    >
      <View style={styles.pickerDoneTextStyle}>
        <Text
          style={styles.dialogCancelTextStyle}
          onPress={() => onCloseModal(1)}
        >
          {translate("ModalDonePicker")}
        </Text>
      </View>

      <View style={styles.dateDialogStyle}>
        <View style={styles.commonFlex}>
          {Platform.OS === "android" ? (
            <WheelPicker
              style={styles.wheelPickerStyle}
              initPosition={selectedIndex}
              data={eventDataAndroid}
              onItemSelected={(item) => {
                setIsSelectedIndex(item);
                setIsSelectedEventId(eventData[item]?.value);
              }}
              selectedItemTextSize={Metrics.rfv(22)}
              itemTextSize={Metrics.rfv(22)}
            />
          ) : (
            <Picker
              selectedValue={isSelectedEventId}
              style={styles.background}
              onValueChange={(item, index) => {
                setIsSelectedEventId(item);
                setIsSelectedIndex(index);
              }}
            >
              {eventData.map((item) => (
                <Picker.Item
                  label={item?.label}
                  value={item?.value}
                  key={item?.value}
                />
              ))}
            </Picker>
          )}
        </View>

        <View />
      </View>
    </Modal>
  );
}
