import { Dimensions, StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  paginationContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: Metrics.rfv(25),
    marginBottom: Metrics.rfv(15),
  },
  paginationButton: {
    paddingHorizontal: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(5),
    marginRight: Metrics.rfv(10),
  },
  disabledButton: {
    backgroundColor: "gray",
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
  pageNumbersContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  pageNumberText: {
    // marginRight: 5,
    height: 20,
    width: 20,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    margin: 5,
  },
  totalPagesText: {},
  selectedPageContainer: (currentPageVisible) => ({
    backgroundColor: currentPageVisible ? Colors.borderDropDown : Colors.white,
    alignItems: "center",
    justifyContent: "center",
    height: Metrics.rfv(30),
    width: Metrics.rfv(30),
    borderRadius: Metrics.rfv(30) / 2,
    marginHorizontal: Metrics.rfv(5),
  }),
  currentPageText: {
    color: Colors.black,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    fontFamily: Fonts.IN_Regular,
    textAlign: "center",
  },
  rightArraow: {
    marginLeft: Metrics.rfv(15),
    paddingHorizontal: Metrics.rfv(5),
    paddingVertical: Metrics.rfv(5),
  },
  dotStyle: {
    marginHorizontal: Metrics.rfv(15),
  },
});
