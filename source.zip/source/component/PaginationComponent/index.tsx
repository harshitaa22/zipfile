import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Pressable,
} from "react-native";
import { Colors, Fonts, Metrics } from "../../theme";
import { LeftUpArrow, RightUpArrow } from "../../theme/svg";
import { print_data } from "../../utils/Logs";
import styles from "./style";

const SweetPagination = ({
  currentPage,
  totalPages,
  onPageChange,
  index,
  page,
}) => {
  const [currentPageVisible, setCurrentPageVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  print_data("page===" + page);
  return (
    <View style={styles.paginationContainer}>
      <Pressable
        style={[styles.paginationButton]}
        onPress={() => {
          if (currentPage != 0) {
            onPageChange(currentPage - 5);
          }
        }}
      >
        <LeftUpArrow
          width={Metrics.rfv(9)}
          height={Metrics.rfv(15)}
          strokeColor={currentPage === 0 ? Colors.borderDropDown : Colors.black}
        />
      </Pressable>
      <View style={styles.pageNumbersContainer}>
        {/* {index !== 1 && (
          <Pressable
            // style={styles.selectedPageContainer(currentPageVisible)}
            onPress={() => {
              print_data("helo==");
              //   onPageChange(1);
              setCurrentPageVisible(true);
            }}
          >
            <Text style={styles.pageNumberText}>{1}</Text>
          </Pressable>
        )} */}

        {/* <Text>{currentPage >= 5 && "....."}</Text> */}
        <Pressable
          style={styles.selectedPageContainer(index == selectedItem)}
          onPress={() => {
            onPageChange(index - 1);
            setSelectedItem(index);
          }}
        >
          <Text style={styles.currentPageText}>{index}</Text>
        </Pressable>
        <Pressable
          style={styles.selectedPageContainer(index + 1 == selectedItem)}
          onPress={() => {
            onPageChange(index + 4);
            setSelectedItem(index + 1);
          }}
        >
          <Text style={styles.currentPageText}>{index + 1}</Text>
        </Pressable>
        <Pressable
          style={styles.selectedPageContainer(index + 2 == selectedItem)}
          onPress={() => {
            print_data("helo=3=" + index + 5);

            onPageChange(index + 5);
            setSelectedItem(index + 2);
          }}
        >
          <Text style={styles.currentPageText}>{index + 2}</Text>
        </Pressable>
        <Text style={styles.dotStyle}> ... </Text>
        <Pressable
          style={styles.selectedPageContainer(totalPages == selectedItem)}
          onPress={() => {
            onPageChange(
              totalPages * 5 - 5 >= currentPage + 5
                ? currentPage + 5
                : totalPages * 5 - 5
            );

            setSelectedItem(totalPages);
          }}
        >
          <Text style={styles.totalPagesText}>{totalPages}</Text>
        </Pressable>
      </View>
      <Pressable
        style={[
          styles.rightArraow,
          currentPage === totalPages && styles.disabledButton,
        ]}
        onPress={() => onPageChange(currentPage + 5)}
      >
        <RightUpArrow
          width={Metrics.rfv(9)}
          height={Metrics.rfv(15)}
          strokeColor={Colors.black}
        />
      </Pressable>
    </View>
  );
};

export default SweetPagination;

// import React, { useState } from "react";
// import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

// const SweetPagination = ({ currentPage, totalPages, onPageChange }) => {
//   const [visiblePages, setVisiblePages] = useState(getInitialVisiblePages());

//   const handlePagePress = (pageNumber) => {
//     onPageChange(pageNumber);
//   };

//   function getInitialVisiblePages() {
//     const maxVisiblePages = 5;
//     const totalPagesToShow = Math.min(totalPages, maxVisiblePages);
//     return Array.from({ length: totalPagesToShow }, (_, index) => index + 1);
//   }

//   const handleNextPress = () => {
//     if (visiblePages[visiblePages.length - 1] < totalPages) {
//       const nextPage = visiblePages[visiblePages.length - 1] + 1;
//       const updatedVisiblePages = visiblePages.map((page) => page + 1);
//       setVisiblePages(updatedVisiblePages);
//       onPageChange(nextPage);
//     }
//   };

//   const handlePrevPress = () => {
//     if (visiblePages[0] > 1) {
//       const prevPage = visiblePages[0] - 1;
//       const updatedVisiblePages = visiblePages.map((page) => page - 1);
//       setVisiblePages(updatedVisiblePages);
//       onPageChange(prevPage);
//     }
//   };

//   return (
//     <View style={styles.paginationContainer}>
//       <TouchableOpacity
//         style={[
//           styles.paginationButton,
//           currentPage === 1 && styles.disabledButton,
//         ]}
//         onPress={handlePrevPress}
//         disabled={currentPage === 1}
//       >
//         <Text style={styles.buttonText}>Previous</Text>
//       </TouchableOpacity>

//       <View style={styles.pageNumbersContainer}>
//         {visiblePages.map((pageNumber) => (
//           <TouchableOpacity
//             key={pageNumber}
//             onPress={() => handlePagePress(pageNumber)}
//             style={[
//               styles.paginationButton,
//               pageNumber === currentPage && styles.activeButton,
//             ]}
//           >
//             <Text
//               style={[
//                 styles.buttonText,
//                 pageNumber === currentPage && styles.activeButtonText,
//               ]}
//             >
//               {pageNumber}
//             </Text>
//           </TouchableOpacity>
//         ))}
//       </View>

//       <TouchableOpacity
//         style={[
//           styles.paginationButton,
//           currentPage === totalPages && styles.disabledButton,
//         ]}
//         onPress={handleNextPress}
//         disabled={currentPage === totalPages}
//       >
//         <Text style={styles.buttonText}>Next</Text>
//       </TouchableOpacity>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   paginationContainer: {
//     flexDirection: "row",
//     justifyContent: "center",
//     alignItems: "center",
//     marginTop: 10,
//   },
//   paginationButton: {
//     padding: 10,
//     borderRadius: 5,
//     marginHorizontal: 5,
//     backgroundColor: "lightgray",
//   },
//   disabledButton: {
//     backgroundColor: "gray",
//   },
//   activeButton: {
//     backgroundColor: "blue",
//   },
//   buttonText: {
//     color: "white",
//     fontWeight: "bold",
//   },
//   activeButtonText: {
//     color: "white",
//   },
//   pageNumbersContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//   },
// });

// export default SweetPagination;
