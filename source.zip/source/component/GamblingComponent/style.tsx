import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  siteText: {
    color: Colors.linearColor2,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
  },
  sensitiveView: {
    marginLeft: Metrics.rfv(15),
  },
  boldText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Bold,
    lineHeight: Metrics.rfv(20),
  },
  boldTitle: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(20),
  },
  ModifiedText: {
    color: Colors.black,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  topView: {
    marginBottom: Metrics.rfv(15),
  },
});
