import { Linking, Pressable, StyleSheet, Text, View } from "react-native";
import React from "react";
import styles from "./style";

export default function GamblingComponent(props: any) {
  return (
    <View style={styles.topView}>
      <Text style={styles.boldText}>{props.boldTitleText}</Text>
      <Text style={styles.ModifiedText}>{props.simpleText}</Text>
      <Pressable onPress={() => Linking.openURL(props.url)}>
        <Text style={styles.siteText}>{props.siteText}</Text>
      </Pressable>
      <Text style={styles.siteText}>{props.numberText}</Text>
    </View>
  );
}
