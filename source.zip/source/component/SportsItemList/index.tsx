import { useNavigation } from "@react-navigation/native";
import moment from "moment";
import React, { useEffect, useRef, useState } from "react";
import {
  FlatList,
  Image,
  Linking,
  Pressable,
  RefreshControl,
  Text,
  View,
} from "react-native";
import { Tabs } from "react-native-collapsible-tab-view";
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import { NAVIGATION } from "../../navigation";
import commonStyles from "../../theme/commonStyle";
import { Colors, CommonStyle, Images } from "../../theme/index";
import {
  BetFairIcon,
  BlackDropDownArrow,
  BookMakerIcon,
} from "../../theme/svg";
import { Constant } from "../../utils";
import { translate } from "../../utils/Localize";
import { print_data } from "../../utils/Logs";
import { SPORTS } from "../../utils/constant";
import AddsCommonList from "../AddsCommonApi";
import ImageLoad from "../ImageLoad";
import Loader from "../ProgressBar";
import SportOdds from "../SportOdds";
import SportModel from "../SportsModelComponent";
import styles from "./style";

export default function SportsItemList(props: any) {
  const navigation = useNavigation();
  const scrollRef = useRef(null);
  const [isSeeAll, setSeeAll] = useState(props?.isSeeAll);
  const [sportId, setSportId] = useState([]);
  const [isLeaugeModalVisible, setLeagueModalVisible] = useState(false);
  const [isLoadMore, setIsLoadMoreVisible] = useState(false);
  const [selectedOddsText, setSelectedOddsText] = useState("");
  const [teamsData, setTeamsData] = useState([]);
  const [pageHeadingData, setPageHeadingData] = useState([]);
  const [itemID, setItemID] = useState();
  const [marketName, setMarketName] = useState("");

  useEffect(() => {
    setIsLoadMoreVisible(true);
    props?.data?.filter((item) => {
      setItemID(item?.id);
      setIsLoadMoreVisible(false);
    });
    if (props?.isSeeAll) {
      getSeeAllData(itemID, 1);
      getOddsApi(itemID);
      fetchLatestOdds(itemID);
    }
  });
  useEffect(() => {
    setIsLoadMoreVisible(true);
    setMarketName(props?.marketAllName);
    setIsLoadMoreVisible(false);
  }, [props?.marketAllName]);

  const fetchDayName = (date: any) => {
    var days = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    var d = new Date(date);
    var dayName = days[d.getDay()];
    return dayName;
  };

  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    const sportId =
      props?.sportId === SPORTS.CRICKET
        ? 4
        : props?.sportId === SPORTS.RUBGY_LEAGUE
        ? 12
        : props?.sportId === SPORTS.RUBGY_UNION
        ? 13
        : props?.sportId === SPORTS.BASKETBALL
        ? 10
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? 15
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? 9
        : props?.sportId === SPORTS.GOLF
        ? 16
        : props?.sportId === SPORTS.TENNIS
        ? 7
        : props?.sportId === SPORTS.BASEBALL
        ? 11
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? 17
        : props?.sportId === SPORTS.BOXING
        ? 6
        : props?.sportId === SPORTS.MMA
        ? 5
        : props?.sportId === SPORTS.SOCCER
        ? 8
        : 14;
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      print_data("====datacounter===");
      print_data(response);
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  function capitalizeWords(arr) {
    return arr.map((word) => {
      const firstLetter = word.charAt(0).toUpperCase();
      const rest = word.slice(1).toLowerCase();

      return firstLetter + rest;
    });
  }

  const onMarketPressBack = () => {
    setLeagueModalVisible(false);
  };

  const oddsIcon = (BookKeeperId: number, type: any) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsImageContainer}
      >
        {BookKeeperId === 11 ? (
          <Image style={styles.oddsImageIcon} source={Images.topSportOdds} />
        ) : (
          <ImageLoad
            style={styles.oddsImageIcon}
            resizeMode={"contain"}
            source={
              iconData?.small_logo?.includes("uploads")
                ? API_URL + "/" + iconData?.small_logo
                : iconData?.small_logo
            }
          />
        )}
      </Pressable>
    );
  };
  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsCurrentBestContainer}
      >
        <Text style={styles.subLeftImageRight1}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };

  const getOddsSponsoredIcon = (BookKeeperId: number) => {
    if (BookKeeperId === 1 || BookKeeperId === 7) {
      return null;
    } else if (BookKeeperId === 3) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.NEDS_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.nedImageIcon} />
        </Pressable>
      );
    } else if (BookKeeperId === 4) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.LADBROKES_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.landBrokes} />
        </Pressable>
      );
    } else if (BookKeeperId === 5) {
      return <BookMakerIcon style={styles.betfairIcon} />;
    } else if (BookKeeperId === 6) {
      return (
        // <Pressable onPress={() => Linking.openURL(Constant.BET_365_URL)}>
        <Image style={styles.sponsoredIcon} source={Images.beStartIcon} />
        // </Pressable>
      );
    } else if (BookKeeperId === 8) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BET_365_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.bet365} />
        </Pressable>
      );
    } else if (BookKeeperId === 10) {
      //Need to change
      return (
        <Pressable onPress={() => Linking.openURL(Constant.UNIBET_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.uniBetIcon} />
        </Pressable>
      );
    } else if (BookKeeperId === 11) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.TOP_SPORT_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.topSport} />
        </Pressable>
      );
    } else if (BookKeeperId === 12) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.PLAY_UP_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.greenArrowIcon} />
        </Pressable>
      );
    } else if (BookKeeperId === 13) {
      return (
        <Pressable
          onPress={() => Linking.openURL(Constant.BET_FAIR_URL)}
          style={styles.sponsoredContainer}
        >
          <BetFairIcon style={styles.betFairIcon} />
        </Pressable>
      );
    } else if (BookKeeperId === 14) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.DRAFT_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.draftStars} />
        </Pressable>
      );
    } else if (BookKeeperId === 15) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.PLAY_UP_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.playUpIcon} />
        </Pressable>
      );
    } else if (BookKeeperId === 16) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BLUE_BET_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.blueBetImg} />
        </Pressable>
      );
    } else if (BookKeeperId === 17) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BOOM_BET_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.boomBetOdds} />
        </Pressable>
      );
    } else if (BookKeeperId === 18) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.SOUTHREN_BET)}>
          <Image
            style={styles.sponsoredIcon}
            source={Images.southerncrossBetOdds}
          />
        </Pressable>
      );
    } else if (BookKeeperId === 20) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.SPORT_BET)}>
          <Image style={styles.sponsoredIcon} source={Images.sportBetImage} />
        </Pressable>
      );
    } else if (BookKeeperId === 21) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.TAB_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.tabwebImage} />
        </Pressable>
      );
    } else if (BookKeeperId === 22) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BET_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.betRImage} />
        </Pressable>
      );
    } else if (BookKeeperId === 23) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.POINT_BET)}>
          <Image style={styles.sponsoredIcon} source={Images.pointBetImage} />
        </Pressable>
      );
    } else if (BookKeeperId === 25) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BT_RIGHT_URL)}>
          <Image style={styles.betRightLogo} source={Images.betRightLogo} />
        </Pressable>
      );
    } else if (BookKeeperId === 26) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.ELITE_BET_URL)}>
          <Image style={styles.sponsoredIcon} source={Images.eliteBetOdds} />
        </Pressable>
      );
    } else if (BookKeeperId === 27) {
      return (
        // <Pressable onPress={() => Linking.openURL(Constant.POINT_BET)}>
        <Image style={styles.sponsoredIcon} source={Images.gsbOdds} />
        // </Pressable>
      );
    } else {
      return null;
    }
  };

  const neweventListData = props?.data?.sort(
    (a, b) => new Date(a?.startTime) - new Date(b?.startTime)
  );

  const fetchLatestOdds = async (item) => {
    try {
      const sportName =
        props?.sportId === SPORTS.CRICKET
          ? "crickets"
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportId === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportId === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportId === SPORTS.TENNIS
          ? "tennis"
          : props?.sportId === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportId === SPORTS.BOXING
          ? "boxing"
          : props?.sportId === SPORTS.MMA
          ? "mma"
          : props?.sportId === SPORTS.SOCCER
          ? "soccer"
          : props?.sportId === SPORTS.GOLF
          ? "golf"
          : "rls";
      const sportId =
        props?.sportId === SPORTS.CRICKET
          ? 4
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? 12
          : props?.sportId === SPORTS.RUBGY_UNION
          ? 13
          : props?.sportId === SPORTS.BASKETBALL
          ? 10
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? 15
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? 9
          : props?.sportId === SPORTS.GOLF
          ? 16
          : props?.sportId === SPORTS.TENNIS
          ? 7
          : props?.sportId === SPORTS.BASEBALL
          ? 11
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? 17
          : props?.sportId === SPORTS.BOXING
          ? 6
          : props?.sportId === SPORTS.MMA
          ? 5
          : props?.sportId === SPORTS.SOCCER
          ? 8
          : 14;
      const response = await callApi(
        `sync/${sportName}/oddOnDemand/${item}?SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
        }
      }
    } catch (error) {}
  };

  const fetchSeeAllOutRightsOdds = (data, providerId, teamId) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let odds = outrightsTeamOdds
      ?.map((obj) => {
        if (obj?.BookKeeperId === providerId) {
          return obj?.odd;
        }
      })
      ?.filter((x) => x !== undefined);
    if (odds?.length > 0) {
      return odds?.[0];
    } else {
      return (
        <Text style={styles.bestValueTextStyle}>{translate("NoaText")}</Text>
      );
    }
  };

  const fetchCureentBestOdds = (
    data: any,
    type: any,
    team: any,
    teamId: any
  ) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });
    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;

    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max: any, obj: any) => {
      let oddsType = obj?.odd ? obj?.odd : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (type === "odds") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let bookkeeperid = teamData
            ?.map((obj) => {
              if (obj?.odd === maxno) {
                return obj?.BookKeeperId;
              }
            })
            ?.filter((x) => x !== undefined);
          return fetchClickableOdds(maxno, bookkeeperid?.[0], "header");
          // return maxno;
        } else {
          return (
            <View style={styles.oddsCurrentBestContainer}>
              <Text style={styles.subLeftImageRight1}>-</Text>
            </View>
          );
        }
      } else {
        return (
          <View style={styles.oddsCurrentBestContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else if (type === "points") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let point = teamData
            ?.map((obj) => {
              if (obj?.odd === maxno) {
                return marketName === "totals"
                  ? obj?.label + " " + obj?.point
                  : obj?.point;
              }
            })
            ?.filter((x) => x !== undefined);

          return point?.[0];
        } else {
          return "";
        }
      } else {
        return "";
      }
    }
  };

  const fetchBestAtOpenOdds = (
    data: any,
    type: any,
    team: any,
    teamId: any
  ) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });
    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max, obj) => {
      let oddsType = obj?.bestOpen ? obj?.bestOpen : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (type === "odds") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let bookkeeperid = teamData
            ?.map((obj) => {
              if (obj?.bestOpen === maxno) {
                return obj?.BookKeeperId;
              }
            })
            ?.filter((x) => x !== undefined);
          return fetchClickableOdds(maxno, bookkeeperid?.[0], "header");
          // return maxno;
        } else {
          return (
            <View style={styles.oddsCurrentBestContainer}>
              <Text style={styles.subLeftImageRight1}>-</Text>
            </View>
          );
        }
      } else {
        return (
          <View style={styles.oddsCurrentBestContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else if (type === "points") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let point = teamData
            ?.map((obj) => {
              if (obj?.bestOpen === maxno) {
                return marketName === "totals"
                  ? obj?.label + " " + obj?.point
                  : obj?.point;
              }
            })
            ?.filter((x) => x !== undefined);

          return point?.[0];
        } else {
          return "";
        }
      } else {
        return "";
      }
    }
  };

  const fetchOutrightTeamlogo = (item) => {
    let teamLogo = item?.flag?.includes("uploads") ? (
      <ImageLoad
        style={styles.imageCommonLeftStyle}
        source={API_URL + "/" + item?.homeTeam?.flag}
        resizeMode={"contain"}
      />
    ) : (
      <Image
        style={styles.imageCommonLeftStyle}
        source={Images.brisbaneLionsIcon}
      />
    );
    return teamLogo;
  };
  const fetchTeamlogo = (item: any, type: any) => {
    if (type === "hometeam") {
      if (item?.homeTeam) {
        let TeamLogo = item?.homeTeam?.flag?.includes("uploads") ? (
          <ImageLoad
            style={styles.imageCommonLeftStyle}
            source={API_URL + "/" + item?.homeTeam?.flag}
            resizeMode={"contain"}
          />
        ) : (
          // : item?.homeTeam?.flag == !null ? (
          //   <ImageLoad
          //     style={styles.imageCommonLeftStyle}
          //     source={API_URL + "/" + item?.homeTeam?.flag}
          //     resizeMode={"contain"}
          //   />
          // )
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.brisbaneLionsIcon}
          />
        );
        return TeamLogo;
      } else {
        return (
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.brisbaneLionsIcon}
          />
        );
      }
    } else {
      if (item?.awayTeam) {
        let TeamLogo = item?.awayTeam?.flag?.includes("uploads") ? (
          <ImageLoad
            style={styles.imageCommonLeftStyle}
            source={API_URL + "/" + item?.awayTeam?.flag}
            resizeMode={"contain"}
          />
        ) : (
          // : item?.awayTeam?.flag == !null ? (
          //   <ImageLoad
          //     style={styles.imageCommonLeftStyle}
          //     source={API_URL + "/" + item?.awayTeam?.flag}
          //     resizeMode={"contain"}
          //   />
          // )
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.melbourne}
          />
        );
        return TeamLogo;
      } else {
        return (
          <Image
            style={styles.imageCommonLeftStyle}
            source={Images.melbourne}
          />
        );
      }
    }
  };

  const fetchCureentBestOddsIcon = (data, type, team, teamId) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max, obj) => {
      let oddsType = obj?.odd ? obj?.odd : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = teamData
          ?.map((obj) => {
            let oddsType = type === "odds" ? obj?.odd : obj?.line;
            if (oddsType === maxno) {
              return obj?.BookKeeperId;
            }
          })
          ?.filter((x) => x !== undefined);

        return oddsIcon(providerid?.[0], "header");
      } else {
        return (
          <View style={styles.emptyContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.subLeftImageRight1}>-</Text>
        </View>
      );
    }
  };

  const fetchBestAtOpenOddsIcon = (
    data: any,
    type: any,
    team: any,
    teamId: any
  ) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max, obj) => {
      let oddsType = obj?.bestOpen ? obj?.bestOpen : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = teamData
          ?.map((obj) => {
            let oddsType = obj?.bestOpen;
            if (oddsType === maxno) {
              return obj?.BookKeeperId;
            }
          })
          ?.filter((x) => x !== undefined);
        return oddsIcon(providerid?.[0], "header");
      } else {
        return (
          <View style={styles.bestEmptyContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else {
      return (
        <View style={styles.bestEmptyContainer}>
          <Text style={styles.subLeftImageRight1}>-</Text>
        </View>
      );
    }
  };

  const fetchBestSportOddsIcon = (
    data: any,
    type: any,
    team: any,
    teamId: any
  ) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = data?.reduce((max, obj) => {
      let oddsType = obj?.odd ? obj?.odd : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno == 0) {
        let providerid = teamData
          ?.map((obj) => {
            let oddsType = obj?.odd;
            if (oddsType === maxno) {
              return obj?.BookKeeperId;
            }
          })
          ?.filter((x) => x !== undefined);

        return oddsIcon(providerid?.[0], "header");
      } else {
        return (
          <View style={styles.numberSecondContainer}>
            <Text style={styles.emptyView}> - </Text>
          </View>
        );
      }
    } else {
      return (
        <View style={styles.numberSecondContainer}>
          <Text style={styles.emptyView}> - </Text>
        </View>
      );
    }
  };

  const listHeader = () => {
    return (
      !isLoadMore && (
        <Text style={styles.noRaceText}>{translate("NoDataAvailable")}</Text>
      )
    );
  };

  const renderTennisSetItem = (item: any, index: any) => {
    return (
      <View key={index} style={commonStyles.commonRow}>
        {/* <View style={commonStyles.commonCeterView}>
          <Text style={styles.numberText}>{item?.eventId}</Text>
        </View>
        <View style={commonStyles.commonCeterView}>
          <Text style={styles.numberText}>{item?.teamId}</Text>
        </View> */}
        <View style={commonStyles.commonFlex} />
        <View
          style={{
            // flex: ,
            flex: 1,
            alignItems: "center",
          }}
        >
          <Text style={styles.numberText}>{item?.score}</Text>
        </View>
      </View>
    );
  };

  const renderTennisItem = (item: any, index: any) => {
    return (
      <View style={CommonStyle.commonFlex} key={index}>
        <View style={styles.dateItem}>
          <Text style={styles.dateItemText}>
            {fetchDayName(new Date())}{" "}
            {moment.utc(new Date()).local().format("DD/MM/YYYY")}
          </Text>
          {/* <View style={styles.rowView}>
            <Text style={styles.currentBest}>{translate("CurrentBest")}</Text>
            <Text style={styles.seeAllText}>{item?.seeAll}</Text>
          </View> */}
          <View style={styles.rowView}>
            <Pressable
              onPress={() => {
                setSeeAll(false);
                scrollRef?.current?.scrollToIndex({
                  animated: true,
                  index: 0,
                  // viewPosition: 1,
                  // viewOffset: props?.tournamentsHeight,
                });
              }}
            >
              <Text
                style={
                  isSeeAll ? styles.heighLightCurrentBest : styles.currentBest
                }
              >
                {translate("CurrentBest")}
              </Text>
            </Pressable>
            <Text
              style={isSeeAll ? styles.seeAllHeighLightText : styles.seeAllText}
            >
              {translate("SeeAll")}
            </Text>
          </View>
        </View>
        <View style={styles.width} />
        <View style={styles.leftRightCenterText}>
          <View style={styles.nameContainer}>
            <Text style={styles.nameText}>[Competitions]</Text>
          </View>

          <Text style={styles.rightText}>
            {" "}
            {moment.utc(item?.startTime).local().format("hh:mm A")} |{" "}
            {`${item?.MarketNumber ? item?.MarketNumber : 0} Markets`}
          </Text>
        </View>
        <View style={styles.sportContainer}>
          <View style={styles.centerView}>
            <Text style={styles.sportTitle}>Jessica Pegula</Text>
          </View>
          <Text style={styles.vsBlueText}>{translate("Vs")}</Text>

          <View style={styles.centerView}>
            <Text style={styles.sportTitle}>Anastasia Potapova</Text>
          </View>
        </View>
        <View style={styles.bestHeadContainer}>
          <Text style={styles.bestHeadTitle}>{translate("TitleOne")}</Text>
        </View>
        <View style={CommonStyle.commonRow}>
          <View style={styles.centerOddsView}>
            <Text style={styles.subLeftTitle1}>
              {translate("SubRightTitleOne")}
            </Text>
            <View style={CommonStyle.alignCenterView}>
              <View style={styles.numberTennisContainer}>
                <Text style={styles.oddsText}>2.00</Text>
              </View>

              {/* <View style={styles.numberSecondContainer}>
                      <Text style={styles.emptyView}> - </Text>
                    </View> */}
              <View style={styles.oddsContainer}>
                <Image source={Images.uniBetIcon} style={styles.oddsIcon} />
              </View>
            </View>
          </View>
          <View style={styles.widthStyle} />
          <View style={styles.centerOddsView}>
            <Text style={styles.subLeftTitle1}>
              {translate("SubRightTitleOne")}
            </Text>
            <View style={CommonStyle.alignCenterView}>
              <View style={styles.numberTennisContainer}>
                <Text style={styles.oddsText}>2.00</Text>
              </View>
              <View style={styles.oddsContainer}>
                <Image source={Images.uniBetIcon} style={styles.oddsIcon} />
              </View>
            </View>
          </View>
        </View>
        <View style={styles.sponsoredView}>
          <Image source={Images.sponsoredImage} style={styles.sponsoredImage} />
        </View>
        <View style={styles.commonTitleView}>
          <View style={styles.centerOddsView}>
            <Text style={styles.subLeftTitle1}>Christopher Eubanks</Text>
            <View style={CommonStyle.alignCenterView}>
              <View style={styles.numberTennisContainer}>
                <Text style={styles.oddsText}>2.00</Text>
              </View>

              {/* <View style={styles.numberSecondContainer}>
                      <Text style={styles.emptyView}> - </Text>
                    </View> */}
              <View style={styles.oddsContainer}>
                <Image source={Images.uniBetIcon} style={styles.oddsIcon} />
              </View>
            </View>
          </View>
          <View style={styles.widthStyle} />
          <View style={styles.centerOddsView}>
            <Text style={styles.subLeftTitle1}>Christopher Eubanks</Text>
            <View style={CommonStyle.alignCenterView}>
              <View style={styles.numberTennisContainer}>
                <Text style={styles.oddsText}>2.00</Text>
              </View>
              <View style={styles.oddsContainer}>
                <Image source={Images.uniBetIcon} style={styles.oddsIcon} />
              </View>
            </View>
          </View>
        </View>
        <View style={styles.bottomWidth} />
        <View style={styles.commonTitleView}>
          <View style={styles.centerView}>
            <View style={styles.centerOddsView}>
              <Text style={styles.subLeftTitle1}>Christopher Eubanks</Text>
              <View style={CommonStyle.alignCenterView}>
                <View style={styles.numberTennisContainer}>
                  <Text style={styles.oddsText}>2.00</Text>
                </View>
                {/* <View style={styles.numberSecondContainer}>
                      <Text style={styles.emptyView}> - </Text>
                    </View> */}
                <View style={styles.oddsContainer}>
                  <Image source={Images.betIcon} style={styles.oddsIcon} />
                </View>
              </View>
            </View>
          </View>
          <View style={styles.widthStyle} />
          <View style={styles.centerOddsView}>
            <Text style={styles.subLeftTitle1}>Christopher Eubanks</Text>
            <View style={CommonStyle.alignCenterView}>
              <View style={styles.numberTennisContainer}>
                <Text style={styles.oddsText}>2.00</Text>
              </View>

              {/* <View style={styles.numberSecondContainer}>
                      <Text style={styles.emptyView}> - </Text>
                    </View> */}
              <View style={styles.oddsContainer}>
                <Image source={Images.betIcon} style={styles.oddsIcon} />
              </View>
            </View>
          </View>
        </View>
        <View style={styles.bottomWidth} />
      </View>
    );
  };

  // const fetchSeeAllOutRightsData = (item) => {
  //   let outRightTeams =
  //     props?.sportId == "Cricket"
  //       ? item?.CricketOutRightTeams
  //       : props?.sportId == "Basketball"
  //       ? item?.NBAOutRightTeams
  //       : props?.sportId == "American Football"
  //       ? item?.AFLOutRightTeams
  //       : props?.sportId == "Australian Rules"
  //       ? item?.AROutRightTeams
  //       : props?.sportId == "Tennis"
  //       ? item?.TennisOutRightTeams
  //       : props?.sportId == "Baseball"
  //       ? item?.BaseballOutRightTeams
  //       : props?.sportId == "Ice Hockey"
  //       ? item?.IceHockeyOutRightTeams
  //       : props?.sportId == "Boxing"
  //       ? item?.BoxingOutRightTeams
  //       : props?.sportId == "Mixed Martial Arts"
  //       ? item?.MMAOutRightTeams
  //       : props?.sportId == "Soccer"
  //       ? item?.SoccerOutRightTeams
  //       : props?.sportId == "Golf"
  //       ? item?.GolfOutRightTeams
  //       : item?.RLOutRightTeams;
  //   let outrightsTeamdata = outRightTeams?.map((obj) => {
  //     return props?.sportId == "Cricket"
  //       ? obj?.CricketTeam
  //       : props?.sportId == "Basketball"
  //       ? obj?.NBATeam
  //       : props?.sportId == "American Football"
  //       ? obj?.AFLTeam
  //       : props?.sportId == "Australian Rules"
  //       ? obj?.ARTeam
  //       : props?.sportId == "Tennis"
  //       ? obj?.TennisTeam
  //       : props?.sportId == "Baseball"
  //       ? obj?.BaseballTeam
  //       : props?.sportId == "Ice Hockey"
  //       ? obj?.IceHockeyTeam
  //       : props?.sportId == "Boxing"
  //       ? obj?.BoxingTeam
  //       : props?.sportId == "Mixed Martial Arts"
  //       ? obj?.MMATeam
  //       : props?.sportId == "Soccer"
  //       ? obj?.SoccerTeam
  //       : props?.sportId == "Golf"
  //       ? obj?.GolfTeam
  //       : obj?.RLTeam;
  //   });
  //   return outrightsTeamdata?.map((teamdata, index) => {
  //     return (
  //       <View key={index}>
  //         <View style={styles.sportContainerView}>
  //           <View>{fetchTeamlogo(item, "hometeam")}</View>
  //           <Text style={styles.sportRightTitle}>{teamdata?.name}</Text>
  //         </View>
  //         <OutRightOdds
  //           fetchSeeAllHomeTeamOddsvalue={fetchSeeAllOutRightsOdds}
  //           item={item}
  //           teamId={teamdata?.id}
  //         />
  //         <View style={styles.sportBottomWidth} />

  //         <View style={styles.topHeight} />
  //       </View>
  //     );
  //   });
  // };

  // const fetchOutrightsTable = (item) => {
  //   let outRightTeams =
  //     props?.sportId == "Cricket"
  //       ? item?.CricketOutRightTeams
  //       : props?.sportId == "Basketball"
  //       ? item?.NBAOutRightTeams
  //       : props?.sportId == "American Football"
  //       ? item?.AFLOutRightTeams
  //       : props?.sportId == "Australian Rules"
  //       ? item?.AROutRightTeams
  //       : props?.sportId == "Tennis"
  //       ? item?.TennisOutRightTeams
  //       : props?.sportId == "Baseball"
  //       ? item?.BaseballOutRightTeams
  //       : props?.sportId == "Ice Hockey"
  //       ? item?.IceHockeyOutRightTeams
  //       : props?.sportId == "Boxing"
  //       ? item?.BoxingOutRightTeams
  //       : props?.sportId == "Mixed Martial Arts"
  //       ? item?.MMAOutRightTeams
  //       : props?.sportId == "Soccer"
  //       ? item?.SoccerOutRightTeams
  //       : props?.sportId == "Golf"
  //       ? item?.GolfOutRightTeams
  //       : item?.RLOutRightTeams;
  //   let outrightsTeamdata = outRightTeams?.map((obj) => {
  //     return props?.sportId == "Cricket"
  //       ? obj?.CricketTeam
  //       : props?.sportId == "Basketball"
  //       ? obj?.NBATeam
  //       : props?.sportId == "American Football"
  //       ? obj?.AFLTeam
  //       : props?.sportId == "Australian Rules"
  //       ? obj?.ARTeam
  //       : props?.sportId == "Tennis"
  //       ? obj?.TennisTeam
  //       : props?.sportId == "Baseball"
  //       ? obj?.BaseballTeam
  //       : props?.sportId == "Ice Hockey"
  //       ? obj?.IceHockeyTeam
  //       : props?.sportId == "Boxing"
  //       ? obj?.BoxingTeam
  //       : props?.sportId == "Mixed Martial Arts"
  //       ? obj?.MMATeam
  //       : props?.sportId == "Soccer"
  //       ? obj?.SoccerTeam
  //       : props?.sportId == "Golf"
  //       ? obj?.GolfTeam
  //       : obj?.RLTeam;
  //   });

  //   return (
  //     <>
  //       {outrightsTeamdata?.map((teamData, index) => {
  //         return (
  //           <View key={index}>
  //             <View style={styles.outrightsContainer}>
  //               <View>{fetchOutrightTeamlogo(teamData)}</View>
  //               <Text style={styles.outRightText}>{teamData?.name}</Text>
  //             </View>
  //             {/* <View style={styles.leftCenterText}>
  //               <View style={styles.centerView}>
  //                 <View>{fetchOutrightTeamlogo(item)}</View>
  //                 <Text style={styles.textLeft}>{item?.homeTeam?.name}</Text>
  //               </View>
  //               <View>
  //                 <View style={styles.halfFlex} />
  //                 <Text style={styles.vsText}>{translate("Vs")}</Text>
  //               </View>

  //               <View style={styles.centerView}>
  //                 <View>{fetchTeamlogo(item, "awayteam")}</View>
  //                 <Text style={styles.textLeft}>{item?.awayTeam?.name}</Text>
  //               </View>
  //             </View> */}

  //             <>
  //               <View style={styles.bestAtOpenContainer}>
  //                 <Text style={styles.bestHeadTitle}>
  //                   {translate("Outrights")}
  //                 </Text>
  //               </View>
  //               <View style={styles.commonTitleView}>
  //                 <View style={commonStyles.alignCenter}>
  //                   {/* <Text style={styles.subRightTitle1}>
  //           {translate("SubRightTitleOne")}
  //         </Text> */}
  //                   <View style={styles.subRightImageRight}>
  //                     <View style={styles.numberContainer}>
  //                       <Text style={styles.subLeftImageRight1}>
  //                         {fetchCureentBestOdds(
  //                           item,
  //                           "odds",
  //                           "outrightsteam",
  //                           teamData?.id
  //                         )}
  //                       </Text>
  //                     </View>
  //                     <View>
  //                       {fetchCureentBestOddsIcon(
  //                         item,
  //                         "odds",
  //                         "outrightsteam",
  //                         teamData?.id
  //                       )}
  //                     </View>
  //                   </View>
  //                 </View>
  //                 {/* <View style={styles.widhStyle} /> */}
  //               </View>
  //             </>

  //             {props?.sponsoredId?.length > 0 && (
  //               <>
  //                 <View style={styles.sponsoredView}>
  //                   <Text style={styles.currentBestTitle}>
  //                     {translate("SponsoredHeadToHead")}
  //                   </Text>
  //                 </View>
  //                 <View style={styles.commonTitleView}>
  //                   {props?.sponsoredId?.length > 0 &&
  //                     fetchSponsoredOddsHome(
  //                       item,
  //                       "outRights",
  //                       3,
  //                       teamData?.id
  //                     )}
  //                 </View>
  //                 <View style={styles.bottomWidth} />
  //               </>
  //             )}
  //             <View style={styles.bottomWidth} />
  //           </View>
  //         );
  //       })}
  //     </>
  //   );
  // };

  const fetchSponsoredOddsHome = (data, team, type, teamId) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });
    let teamInfo = team === "homeTeam" ? homeTeamOdds : awayTeamOdds;
    let teamOdds = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamOdds = team === "homeTeam" ? OverData : UnderData;
    }

    let newOdds = teamOdds
      ?.filter((odds) => {
        return props?.sponsoredId?.includes(odds.BookKeeperId);
      })
      ?.slice(0, 2);
    // let newOdds =
    //   team === "homeTeam"
    //     ? homeTeamOdds
    //     : team === "awayTeam"
    //     ? awayTeamOdds
    //     : outRightsTeamOdds
    //         ?.filter((odds) => {
    //           return props?.sponsoredId?.includes(odds?.BookKeeperId);
    //         })
    //         ?.slice(0, 2);
    let firstSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[0]
    );
    let secondSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[1]
    );
    let SponsoredOdds = props?.sponsoredId?.length > 0 && (
      <>
        {/* <View style={styles.commonTitleView}> */}
        {type == 1 && (
          // <View style={styles.centerOddsView}>
          <View style={styles.sponsoreCenterView}>
            <View style={commonStyles.commonRow}>
              {firstSponsored?.[0]?.odd ? (
                <View>
                  {firstSponsored?.[0]?.point && (
                    <Text style={styles.sponsorePointsText}>
                      {marketName === "totals"
                        ? firstSponsored?.[0]?.label +
                          " " +
                          firstSponsored?.[0]?.point
                        : firstSponsored?.[0]?.point}
                    </Text>
                  )}
                  <>
                    {fetchClickableOdds(
                      firstSponsored?.[0]?.odd
                        ? firstSponsored?.[0]?.odd
                        : "NOA",
                      firstSponsored?.[0]?.BookKeeperId,
                      "sponsored"
                    )}
                  </>
                </View>
              ) : null}
              <View style={commonStyles.flexEnd}>
                {oddsIcon(props?.sponsoredId?.[0], "sponsored")}
              </View>
            </View>
          </View>
          // </View>
        )}
        {type == 2 && (
          <>
            {props?.sponsoredId?.[1] ? (
              <>
                {/* <View style={styles.centerOddsView}>
                  <View style={CommonStyle.alignCenterView}>
                    {secondSponsored?.[0]?.odd ? (
                      <View>
                        <Text>
                          {marketName === "totals"
                            ? secondSponsored?.[0]?.label +
                              " " +
                              secondSponsored?.[0]?.point
                            : secondSponsored?.[0]?.point}
                        </Text>
                        <Text>
                          {fetchClickableOdds(
                            secondSponsored?.[0]?.odd
                              ? secondSponsored?.[0]?.odd
                              : "NOA",
                            secondSponsored?.[0]?.BookKeeperId
                          )}
                        </Text>
                      </View>
                    ) : null}

                    <View style={styles.bottomView}>
                      {oddsIcon(props?.sponsoredId?.[1], "sponsored")}
                    </View>
                  </View>
                </View> */}
                {/* <View style={styles.centerOddsView}> */}
                <View style={styles.sponsoreCenterView}>
                  <View style={commonStyles.commonRow}>
                    {secondSponsored?.[0]?.odd ? (
                      <View>
                        {secondSponsored?.[0]?.point && (
                          <Text style={styles.sponsorePointsText}>
                            {marketName === "totals"
                              ? secondSponsored?.[0]?.label +
                                " " +
                                secondSponsored?.[0]?.point
                              : secondSponsored?.[0]?.point}
                          </Text>
                        )}

                        {fetchClickableOdds(
                          secondSponsored?.[0]?.odd
                            ? secondSponsored?.[0]?.odd
                            : "NOA",
                          secondSponsored?.[0]?.BookKeeperId,
                          "sponsored"
                        )}
                      </View>
                    ) : (
                      <></>
                    )}
                    <View style={commonStyles.flexEnd}>
                      {oddsIcon(props?.sponsoredId?.[1], "sponsored")}
                    </View>
                  </View>
                </View>
                {/* </View> */}
              </>
            ) : (
              <></>
            )}
          </>
        )}

        {type == 3 && (
          <>
            <View style={styles.centerOddsView}>
              <View style={CommonStyle.alignCenterView}>
                {firstSponsored?.[0]?.odd ? (
                  <View style={styles.numberOddsContainer}>
                    <Text style={styles.oddsText}>
                      {firstSponsored?.[0]?.odd ? firstSponsored?.[0]?.odd : ""}
                    </Text>
                  </View>
                ) : null}

                <View>{getOddsSponsoredIcon(props?.sponsoredId?.[0])}</View>
              </View>
            </View>
            {props?.sponsoredId?.[1] ? (
              <>
                <View style={styles.sponsoredWidthStyle} />
                <View style={styles.centerOddsView}>
                  <View style={CommonStyle.alignCenterView}>
                    {secondSponsored?.[0]?.odd ? (
                      <View style={styles.numberOddsContainer}>
                        <Text style={styles.oddsText}>
                          {secondSponsored?.[0]?.odd
                            ? secondSponsored?.[0]?.odd
                            : "NOA"}
                        </Text>
                      </View>
                    ) : null}

                    <View>{getOddsSponsoredIcon(props?.sponsoredId?.[1])}</View>
                  </View>
                </View>
              </>
            ) : (
              <></>
            )}
          </>
        )}

        {/* <View style={styles.widthStyle} /> */}
        {/* <View style={styles.centerOddsView}>
            <Text style={styles.subLeftTitle1}>
              {data?.awayTeam?.name ? data?.awayTeam?.name : ""}
            </Text>
            <View style={CommonStyle.alignCenterView}>
              <View style={styles.numberOddsContainer}>
                <Text style={styles.oddsText}>
                  {secondSponsored?.[0]?.odd
                    ? secondSponsored?.[0]?.odd
                    : "NOA"}
                </Text>
              </View>
              <View>{getOddsIcon(props?.sponsoredId?.[1])}</View>
            </View>
          </View> */}
        {/* </View> */}
        {/* {props?.sponsoredId?.[1] && (
          <View style={styles.commonTitleView}>
            <View style={styles.centerOddsView}>
              <Text style={styles.subLeftTitle1}>
                {data?.awayTeam?.name ? data?.awayTeam?.name : ""}
              </Text>
              <View style={CommonStyle.alignCenterView}>
                <View style={styles.numberOddsContainer}>
                  <Text style={styles.oddsText}>
                    {secondSponsored?.[0]?.odd
                      ? secondSponsored?.[0]?.odd
                      : "NOA"}
                  </Text>
                </View>
                <View>{getOddsIcon(props?.sponsoredId?.[1])}</View>
              </View>
            </View>
          </View>
        )} */}
      </>
    );

    return SponsoredOdds;
  };

  const fetchSponsoredOddsAway = (data) => {
    let newOdds = data?.awayTeamOdds
      ?.filter((odds) => {
        return props?.sponsoredId?.includes(odds.BookKeeperId);
      })
      ?.slice(0, 2);
    let firstSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[0]
    );
    let secondSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[1]
    );

    let SponsoredOdds = props?.sponsoredId?.length > 0 && (
      <>
        <View style={styles.centerOddsView}>
          <Text style={styles.subLeftTitle1} numberOfLines={1}>
            {data?.awayTeam?.name ? data?.awayTeam?.name : ""}
          </Text>
          <View
            style={{
              flexDirection: "row",
            }}
          >
            <View style={styles.numberOddsContainer}>
              <Text style={styles.oddsText}>
                {firstSponsored?.[0]?.odd ? firstSponsored?.[0]?.odd : "NOA"}
              </Text>
            </View>
            <View>{getOddsSponsoredIcon(props?.sponsoredId?.[0])}</View>
          </View>
        </View>
      </>
    );

    return SponsoredOdds;
  };

  const renderTennisOddsItem = (item: any, index: any) => {
    return (
      <View key={index}>
        <View style={CommonStyle.commonRow}>
          <Text style={styles.listTitle} numberOfLines={1}>
            {item?.homeTeam?.name}
          </Text>
          <View style={CommonStyle.commonFlex} />
        </View>
        <View style={CommonStyle.alignCenterView}>
          <View style={styles.oddsView}>
            <Text style={styles.tennisTitleText} numberOfLines={1}>
              {item?.odds}
            </Text>
          </View>
          <Image source={item?.imageIcon} style={styles.iconStyle} />
        </View>
      </View>
    );
  };

  const onMarketNextPress = () => {
    const marketData = props?.marketItem;
    marketData?.forEach((item, _index) => {
      if (item?.displayName == selectedOddsText) {
        setIsLoadMoreVisible(true);

        getSeeAllSelectedItem([sportId]?.[0]?.id, item?.id);
      }
      setSelectedOddsText(selectedOddsText);
      setLeagueModalVisible(false);
    });
  };

  const onMarketPress = (item, index) => {
    setSelectedOddsText(item);
  };

  const marketRenderItem = (item, index) => {
    return (
      <Pressable onPress={() => onMarketPress(item, index)} key={index}>
        <Text
          style={
            selectedOddsText == item ? styles.selectedItem : styles.labelText
          }
        >
          {capitalize(item)}
        </Text>
      </Pressable>
    );
  };

  const fetchTableHeading = async (bookkeeper) => {
    try {
      const sportId =
        props?.sportId === SPORTS.CRICKET
          ? 4
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? 12
          : props?.sportId === SPORTS.RUBGY_UNION
          ? 13
          : props?.sportId === SPORTS.BASKETBALL
          ? 10
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? 15
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? 9
          : props?.sportId === SPORTS.GOLF
          ? 16
          : props?.sportId === SPORTS.TENNIS
          ? 7
          : props?.sportId === SPORTS.BASEBALL
          ? 11
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? 17
          : props?.sportId === SPORTS.BOXING
          ? 6
          : props?.sportId === SPORTS.MMA
          ? 5
          : props?.sportId === SPORTS.SOCCER
          ? 8
          : 14;
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders?SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          let filteredHeading = response?.body?.data?.result?.filter((item) =>
            bookkeeper?.includes(item?.BookKeeperId)
          );
          setPageHeadingData(filteredHeading);
        }
      }
    } catch (error) {}
  };

  function capitalize(str) {
    return str?.charAt(0)?.toUpperCase() + str?.slice(1);
  }

  const getOddsApi = async (oddsId) => {
    try {
      let sportName =
        props?.sportId === SPORTS.CRICKET
          ? "crickets"
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportId === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportId === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportId === SPORTS.TENNIS
          ? "tennis"
          : props?.sportId === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportId === SPORTS.BOXING
          ? "boxing"
          : props?.sportId === SPORTS.MMA
          ? "mma"
          : props?.sportId === SPORTS.SOCCER
          ? "soccer"
          : props?.sportId === SPORTS.GOLF
          ? "golf"
          : "rls";
      const response = await callApi(
        `public/${sportName}/event/${oddsId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          print_data(response);

          setIsLoadMoreVisible(false);
        }
      }
    } catch (error) {
      print_data("error======");
    }
  };

  const getSeeAllData = async (oddsId, id) => {
    try {
      let sportName =
        props?.sportId === SPORTS.CRICKET
          ? "crickets"
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportId === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportId === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportId === SPORTS.TENNIS
          ? "tennis"
          : props?.sportId === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportId === SPORTS.BOXING
          ? "boxing"
          : props?.sportId === SPORTS.MMA
          ? "mma"
          : props?.sportId === SPORTS.SOCCER
          ? "soccer"
          : props?.sportId === SPORTS.GOLF
          ? "golf"
          : "rls";
      const response = await callApi(
        `public/${sportName}/event/${oddsId}?marketId=${id}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let data = response.body?.data?.result;
          setTeamsData([data]);

          let teamdata = [data];
          let newData =
            teamdata?.length > 0
              ? props?.sportId === SPORTS.CRICKET
                ? teamdata?.[0]?.CricketBetOffers
                : props?.sportId === SPORTS.BASKETBALL
                ? teamdata?.[0]?.NBABetOffers
                : props?.sportId === SPORTS.AMERICAN_FOOTBALL
                ? teamdata?.[0]?.AFLBetOffers
                : props?.sportId === SPORTS.AUSTRALIAN_RULES
                ? teamdata?.[0]?.ARBetOffers
                : props?.sportId === SPORTS.TENNIS
                ? teamdata?.[0]?.TennisBetOffers
                : props?.sportId === SPORTS.BASEBALL
                ? teamdata?.[0]?.BaseballBetOffers
                : props?.sportId === SPORTS.ICE_HOCKEY
                ? teamdata?.[0]?.IceHockeyBetOffers
                : props?.sportId === SPORTS.BOXING
                ? teamdata?.[0]?.BoxingBetOffers
                : props?.sportId === SPORTS.MMA
                ? teamdata?.[0]?.MMABetOffers
                : props?.sportId === SPORTS.SOCCER
                ? teamdata?.[0]?.SoccerBetOffers
                : props?.sportId === SPORTS.GOLF
                ? teamdata?.[0]?.GolfBetOffers
                : teamdata?.[0]?.RLBetOffers
              : [];

          let sportsOdds =
            props?.sportId === SPORTS.CRICKET
              ? newData?.[0]?.CricketOdds
              : props?.sportId === SPORTS.BASKETBALL
              ? newData?.[0]?.NBAOdds
              : props?.sportId === SPORTS.AMERICAN_FOOTBALL
              ? newData?.[0]?.AFLOdds
              : props?.sportId === SPORTS.AUSTRALIAN_RULES
              ? newData?.[0]?.AROdds
              : props?.sportId === SPORTS.TENNIS
              ? newData?.[0]?.TennisOdds
              : props?.sportId === SPORTS.BASEBALL
              ? newData?.[0]?.BaseballOdds
              : props?.sportId === SPORTS.ICE_HOCKEY
              ? newData?.[0]?.IceHockeyOdds
              : props?.sportId === SPORTS.BOXING
              ? newData?.[0]?.BoxingOdds
              : props?.sportId === SPORTS.MMA
              ? newData?.[0]?.MMAOdds
              : props?.sportId === SPORTS.SOCCER
              ? newData?.[0]?.SoccerOdds
              : props?.sportId === SPORTS.GOLF
              ? newData?.[0]?.GolfOdds
              : newData?.[0]?.RLOdds;

          let sportMarket =
            props?.sportId === SPORTS.CRICKET
              ? newData?.[0]?.CricketMarket?.name
              : props?.sportId === SPORTS.BASKETBALL
              ? newData?.[0]?.NBAMarket?.name
              : props?.sportId === SPORTS.AMERICAN_FOOTBALL
              ? newData?.[0]?.AFLMarket?.name
              : props?.sportId === SPORTS.AUSTRALIAN_RULES
              ? newData?.[0]?.ARMarket?.name
              : props?.sportId === SPORTS.TENNIS
              ? newData?.[0]?.TennisMarket?.name
              : props?.sportId === SPORTS.BASEBALL
              ? newData?.[0]?.BaseballMarket?.name
              : props?.sportId === SPORTS.ICE_HOCKEY
              ? newData?.[0]?.IceHockeyMarket?.name
              : props?.sportId === SPORTS.BOXING
              ? newData?.[0]?.BoxingMarket?.name
              : props?.sportId === SPORTS.MMA
              ? newData?.[0]?.MMAMarket?.name
              : props?.sportId === SPORTS.SOCCER
              ? newData?.[0]?.SoccerMarket?.name
              : props?.sportId === SPORTS.GOLF
              ? newData?.[0]?.GolfMarket?.name
              : newData?.[0]?.RLMarket?.name;

          setMarketName(sportMarket);
          let bookkeeper = [];
          let BookkeeperList = sportsOdds?.map((element) => {
            return bookkeeper?.push(element?.BookKeeperId);
          });
          fetchTableHeading([...new Set(bookkeeper)]);
          let displayName = data?.CricketBetOffers
            ? data?.CricketBetOffers[0]?.CricketMarket?.displayName
            : data?.NBABetOffers
            ? data?.NBABetOffers[0]?.NBAMarket?.displayName
            : data?.AFLBetOffers
            ? data?.AFLBetOffers[0]?.AFLMarket?.displayName
            : data?.ARBetOffers
            ? data?.ARBetOffers[0]?.ARMarket?.displayName
            : data?.TennisBetOffers
            ? data?.TennisBetOffers[0]?.TennisMarket?.displayName
            : data?.BaseballBetOffers
            ? data?.BaseballBetOffers[0]?.BaseballMarket?.displayName
            : data?.IceHockeyBetOffers
            ? data?.IceHockeyBetOffers[0]?.IceHockeyMarket?.displayName
            : data?.BoxingBetOffers
            ? data?.BoxingBetOffers[0]?.BoxingMarket?.displayName
            : data?.MMABetOffers
            ? data?.MMABetOffers[0]?.MMAMarket?.displayName
            : data?.SoccerBetOffers
            ? data?.SoccerBetOffers[0]?.SoccerMarket?.displayName
            : data?.RLBetOffers[0]?.RLMarket?.displayName;

          setSelectedOddsText(displayName);

          setIsLoadMoreVisible(false);
        }
      }
    } catch (error) {
      print_data("error======");
    }
  };

  const getSeeAllSelectedItem = async (oddsId, id) => {
    try {
      let sportName =
        props?.sportId === SPORTS.CRICKET
          ? "crickets"
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportId === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportId === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportId === SPORTS.TENNIS
          ? "tennis"
          : props?.sportId === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportId === SPORTS.BOXING
          ? "boxing"
          : props?.sportId === SPORTS.MMA
          ? "mma"
          : props?.sportId === SPORTS.SOCCER
          ? "soccer"
          : props?.sportId === SPORTS.GOLF
          ? "golf"
          : "rls";
      const response = await callApi(
        `public/${sportName}/event/${oddsId}?marketId=${id}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let data = response.body?.data?.result;
          setTeamsData([data]);
          let teamdata = [data];
          let newData =
            teamdata?.length > 0
              ? props?.sportId === SPORTS.CRICKET
                ? teamdata?.[0]?.CricketBetOffers
                : props?.sportId === SPORTS.BASKETBALL
                ? teamdata?.[0]?.NBABetOffers
                : props?.sportId === SPORTS.AMERICAN_FOOTBALL
                ? teamdata?.[0]?.AFLBetOffers
                : props?.sportId === SPORTS.AUSTRALIAN_RULES
                ? teamdata?.[0]?.ARBetOffers
                : props?.sportId === SPORTS.TENNIS
                ? teamdata?.[0]?.TennisBetOffers
                : props?.sportId === SPORTS.BASEBALL
                ? teamdata?.[0]?.BaseballBetOffers
                : props?.sportId === SPORTS.ICE_HOCKEY
                ? teamdata?.[0]?.IceHockeyBetOffers
                : props?.sportId === SPORTS.BOXING
                ? teamdata?.[0]?.BoxingBetOffers
                : props?.sportId === SPORTS.MMA
                ? teamdata?.[0]?.MMABetOffers
                : props?.sportId === SPORTS.SOCCER
                ? teamdata?.[0]?.SoccerBetOffers
                : props?.sportId === SPORTS.GOLF
                ? teamdata?.[0]?.GolfBetOffers
                : teamdata?.[0]?.RLBetOffers
              : [];

          let sportsOdds =
            props?.sportId === SPORTS.CRICKET
              ? newData?.[0]?.CricketOdds
              : props?.sportId === SPORTS.BASKETBALL
              ? newData?.[0]?.NBAOdds
              : props?.sportId === SPORTS.AMERICAN_FOOTBALL
              ? newData?.[0]?.AFLOdds
              : props?.sportId === SPORTS.AUSTRALIAN_RULES
              ? newData?.[0]?.AROdds
              : props?.sportId === SPORTS.TENNIS
              ? newData?.[0]?.TennisOdds
              : props?.sportId === SPORTS.BASEBALL
              ? newData?.[0]?.BaseballOdds
              : props?.sportId === SPORTS.ICE_HOCKEY
              ? newData?.[0]?.IceHockeyOdds
              : props?.sportId === SPORTS.BOXING
              ? newData?.[0]?.BoxingOdds
              : props?.sportId === SPORTS.MMA
              ? newData?.[0]?.MMAOdds
              : props?.sportId === SPORTS.SOCCER
              ? newData?.[0]?.SoccerOdds
              : props?.sportId === SPORTS.GOLF
              ? newData?.[0]?.GolfOdds
              : newData?.[0]?.RLOdds;

          let sportMarket =
            props?.sportId === SPORTS.CRICKET
              ? newData?.[0]?.CricketMarket?.name
              : props?.sportId === SPORTS.BASKETBALL
              ? newData?.[0]?.NBAMarket?.name
              : props?.sportId === SPORTS.AMERICAN_FOOTBALL
              ? newData?.[0]?.AFLMarket?.name
              : props?.sportId === SPORTS.AUSTRALIAN_RULES
              ? newData?.[0]?.ARMarket?.name
              : props?.sportId === SPORTS.TENNIS
              ? newData?.[0]?.TennisMarket?.name
              : props?.sportId === SPORTS.BASEBALL
              ? newData?.[0]?.BaseballMarket?.name
              : props?.sportId === SPORTS.ICE_HOCKEY
              ? newData?.[0]?.IceHockeyMarket?.name
              : props?.sportId === SPORTS.BOXING
              ? newData?.[0]?.BoxingMarket?.name
              : props?.sportId === SPORTS.MMA
              ? newData?.[0]?.MMAMarket?.name
              : props?.sportId === SPORTS.SOCCER
              ? newData?.[0]?.SoccerMarket?.name
              : props?.sportId === SPORTS.GOLF
              ? newData?.[0]?.GolfMarket?.name
              : newData?.[0]?.RLMarket?.name;

          setMarketName(sportMarket);
          let bookkeeper = [];
          let BookkeeperList = sportsOdds?.map((element) => {
            return bookkeeper?.push(element?.BookKeeperId);
          });
          fetchTableHeading([...new Set(bookkeeper)]);
          // setSelectedOddsText(
          //   data?.CricketBetOffers
          //     ? data?.CricketBetOffers[0]?.CricketMarket?.displayName
          //     : data?.NBABetOffers
          //     ? data?.NBABetOffers[0]?.NBAMarket?.displayName
          //     : data?.AFLBetOffers
          //     ? data?.AFLBetOffers[0]?.AFLMarket?.displayName
          //     : data?.ARBetOffers
          //     ? data?.ARBetOffers[0]?.ARMarket?.displayName
          //     : data?.TennisBetOffers
          //     ? data?.TennisBetOffers[0]?.TennisMarket?.displayName
          //     : data?.BaseballBetOffers
          //     ? data?.BaseballBetOffers[0]?.BaseballMarket?.displayName
          //     : data?.IceHockeyBetOffers
          //     ? data?.IceHockeyBetOffers[0]?.IceHockeyMarket?.displayName
          //     : data?.BoxingBetOffers
          //     ? data?.BoxingBetOffers[0]?.BoxingMarket?.displayName
          //     : data?.MMABetOffers
          //     ? data?.MMABetOffers[0]?.MMAMarket?.displayName
          //     : data?.SoccerBetOffers
          //     ? data?.SoccerBetOffers[0]?.SoccerMarket?.displayName
          //     : data?.RLMarket?.displayName
          // );
          setIsLoadMoreVisible(false);
        }
      }
    } catch (error) {
      print_data("error======");
    }
  };

  const renderSeeAllItem = (item: any, index: any) => {
    return (
      <>
        <View style={styles.topView} key={index}>
          <View style={styles.horizontalSeeAllView}>
            <Pressable
              onPress={() => setLeagueModalVisible(true)}
              style={styles.oddsViewContainer}
            >
              <Text style={styles.textInputStyle} numberOfLines={1}>
                {capitalize(selectedOddsText)}
              </Text>
              <BlackDropDownArrow style={styles.dropdownIcon} />
            </Pressable>
          </View>
          {isLoadMore && (
            <View style={styles.loader}>
              <Loader color={Colors.black} />
            </View>
          )}
          <SportModel
            isSearchVisible={false}
            isVisible={isLeaugeModalVisible}
            showModel={setLeagueModalVisible}
            data={props?.marketAllData}
            onPressBack={() => onMarketPressBack()}
            onNextPress={() => onMarketNextPress()}
            renderItem={(item, index) => marketRenderItem(item, index)}
          />
          {/* <LeaguePicker
            isVisible={isLeaugeModalVisible}
            showModel={setLeagueModalVisible}
            // data={oddsDataOption}
            data={props?.marketAllData}
            onItemSelect={(selectedData) => {
              const marketData = props?.marketItem;
              marketData?.forEach((item, _index) => {
                if (item?.displayName == selectedData?.title) {
                  setIsLoadMoreVisible(true);

                  getSeeAllSelectedItem([sportId]?.[0]?.id, item?.id);
                }
                setSelectedOddsText(selectedData);
              });

              // oddsTypeChange(selectedData);
              // setSelectedOddsText(selectedData?.title);
            }}
          /> */}
          {/* <View style={styles.dateItem}> */}
          {/* <Pressable
              style={styles.oddTypeWidth}
              onPress={() => setLeagueModalVisible(true)}
            >
              <CustomTextInput
                editable={false}
                pointerEvents="none"
                textInputStyle={styles.textModelInputStyle}
                // dropDown={true}
                racingDropDown={true}
                dropDownStyle={styles.dropDownArrow}
                dropDownIconStyle={styles.dropDownContainer}
                placeholderText={""}
                inputTextStyle={styles.inputTextStyle}
                placeholderTextColor={Colors.red}
                onPressWheelPicker={() => setLeagueModalVisible(true)}
                value={
                  selectedOddsText?.title?.length > 0
                    ? selectedOddsText?.title
                    : 
                      selectedOddsText
                }
                activeOpacity={1}
              />
            </Pressable> */}
          <View style={styles.seeAllEndView}>
            <Pressable
              onPress={() => {
                setSeeAll(false);
                scrollRef?.current?.scrollToIndex({
                  animated: true,
                  index: 0,
                  // viewPosition: 1,
                  // viewOffset: props?.tournamentsHeight,
                });
              }}
            >
              <Text
                style={
                  isSeeAll ? styles.heighLightCurrentBest : styles.currentBest
                }
              >
                {translate("CurrentBest")}
              </Text>
            </Pressable>
            <Text
              style={isSeeAll ? styles.seeAllHeighLightText : styles.seeAllText}
            >
              {translate("SeeAll")}
            </Text>
          </View>
          {/* </View> */}
          <View style={styles.width} />

          <>
            {item == null ? (
              <Text style={styles.noRaceText}>
                {translate("NoDataAvailable")}
              </Text>
            ) : (
              <>
                <Text style={styles.dateView}>
                  {fetchDayName(item?.startTime)}
                  {"  "}
                  {moment
                    .utc(item?.startTime)
                    .local()
                    .format("DD/MM/YYYY")}{" "}
                  {"  "}|{"   "}
                  {moment.utc(item?.startTime).local().format("hh:mm A")}
                  {"  "} |{"   "}
                  {`${item?.marketLength ? item?.marketLength : 0} Markets`}
                </Text>
                <View style={styles.bottomWidth} />
                {/* {(
      item?.NBAOutRightTeams ||
      item?.CricketOutRightTeams ||
      item?.AFLOutRightTeams ||
      item?.AROutRightTeams ||
      item?.TennisOutRightTeams ||
      item?.BaseballOutRightTeams ||
      item?.IceHockeyOutRightTeams ||
      item?.BoxingOutRightTeams ||
      item?.MMAOutRightTeams ||
      item?.SoccerOutRightTeams ||
      item?.RLOutRightTeams
    ).length > 0 ? (
      <View>{fetchSeeAllOutRightsData(item)}</View>
    ) : ( */}
                <>
                  <View style={styles.sportContainerView}>
                    <View>{fetchTeamlogo(item, "hometeam")}</View>
                    <Text style={styles.sportRightTitle}>
                      {item?.homeTeam?.name}
                    </Text>
                  </View>
                  <SportOdds
                    // fetchSeeAllHomeTeamOddsvalue={fetchSeeAllHomeTeamOddsvalue}
                    // fetchClickableOddsIcon={oddsSeeAllIcon}
                    homeTeamName={item?.homeTeam?.name}
                    marketName={marketName}
                    bookkeeperData={props?.bookkeeperData}
                    item={item}
                    team={marketName === "totals" ? "over" : "hometeam"}
                    sportItem={pageHeadingData}
                    sportId={props?.sportId}
                    type={"odds"}
                  />
                  <View style={styles.sportBottomWidth} />
                  <View style={styles.sportContainerView}>
                    <View>{fetchTeamlogo(item, "awayteam")}</View>
                    <Text style={styles.sportRightTitle}>
                      {item?.awayTeam?.name}
                    </Text>
                  </View>

                  <View>
                    {/* <SportOdds
                    // fetchSeeAllHomeTeamOddsvalue={fetchSeeAllawayTeamOddsvalue}
                    // pageHeadingData={item}
                    homeTeamName={item?.awayTeam?.name}
                    bookkeeperData={props?.bookkeeperData}
                    fetchClickableOddsIcon={oddsSeeAllIcon}
                    marketName={marketName}
                    item={item}
                    sportItem={pageHeadingData}
                    team={marketName === "totals" ? "under" : "awayteam"}
                    type={"spreadpoints"}
                    sportId={props?.sportId}
                  /> */}
                    <SportOdds
                      // fetchSeeAllHomeTeamOddsvalue={fetchSeeAllawayTeamOddsvalue}
                      // pageHeadingData={item}
                      homeTeamName={item?.awayTeam?.name}
                      bookkeeperData={props?.bookkeeperData}
                      marketName={marketName}
                      item={item}
                      sportItem={pageHeadingData}
                      team={marketName === "totals" ? "under" : "awayteam"}
                      type={"odds"}
                      sportId={props?.sportId}
                    />
                  </View>
                </>
                {/* <SportOdds
                  fetchSeeAllHomeTeamOddsvalue={fetchSeeAllawayTeamOddsvalue(
                    item,
                    item?.BookKeeperId,
                    marketName === "totals" ? "under" : "awayteam",
                    "spreadpoints"
                  )}
                  homeTeamName={item?.awayTeam?.name}
                  fetchClickableOddsIcon={oddsSeeAllIcon}
                  marketName={marketName}
                  item={item}
                  sportId={props?.sportId}
                /> */}
                {/* <View>
                  {fetchSeeAllawayTeamOddsvalue(
                    item,
                    item?.BookKeeperId,
                    marketName === "totals" ? "under" : "awayteam",
                    "spreadpoints"
                  )}
                </View> */}
                <View style={styles.topHeight} />
              </>
            )}
          </>
          {/* )} */}
        </View>
      </>
    );
  };

  const renderItem = (item: any, index: any) => {
    // setItemID(item?.id);
    return (
      <>
        {!isSeeAll ? (
          <>
            {item?.ARScores?.length > 0 ? (
              <View style={styles.bannerBottomContainer}>
                <View style={styles.horizontalView}>
                  <View style={styles.dateItem}>
                    <Text style={styles.dateItemText}>
                      {fetchDayName(item?.startTime)}{" "}
                      {moment.utc(item?.startTime).local().format("DD/MM/YYYY")}
                    </Text>
                    {/* <View style={styles.rowView}>
        <Text style={styles.currentBest}>
          {translate("CurrentBest")}
        </Text>
        <Text style={styles.seeAllText}>{item?.seeAll}</Text>
      </View> */}
                    <View style={styles.rowView}>
                      <Pressable
                        onPress={() => {
                          setSeeAll(false);
                          scrollRef?.current?.scrollToIndex({
                            animated: true,
                            index: 0,
                            viewPosition: 1,
                            // viewOffset: props?.tournamentsHeight,
                          });
                        }}
                      >
                        <Text
                          style={
                            isSeeAll
                              ? styles.heighLightCurrentBest
                              : styles.currentBest
                          }
                        >
                          {translate("CurrentBest")}
                        </Text>
                      </Pressable>
                      <Text
                        style={
                          isSeeAll
                            ? styles.seeAllHeighLightText
                            : styles.seeAllText
                        }
                      >
                        {translate("SeeAll")}
                      </Text>
                    </View>
                  </View>
                  <View style={styles.width} />

                  <View style={styles.liveView}>
                    {/* <View style={styles.liveContainer}>
                      <Text style={styles.liveText}>
                        {translate("LiveText")}
                      </Text>
                    </View> */}
                    <View style={styles.centerContainerView}>
                      <View style={styles.flex} />
                      <Text style={styles.rightText}>
                        {" "}
                        {moment
                          .utc(item?.startTime)
                          .local()
                          .format("hh:mm A")}{" "}
                        |{" "}
                        {`${
                          item?.MarketNumber ? item?.MarketNumber : 0
                        } Markets`}
                      </Text>
                      <View style={styles.tennisWidth} />
                      <View style={styles.nameBlueContainer}>
                        <Text style={styles.nameBlueText} numberOfLines={1}>
                          {(item?.CricketTournament &&
                            item?.CricketTournament?.name) ||
                            (item?.RLTournament && item?.RLTournament?.name) ||
                            (item?.NBATournament &&
                              item?.NBATournament?.name +
                                " " +
                                item?.NBATournament?.NBACategory?.name) ||
                            (item?.AFLTournament &&
                              item?.AFLTournament?.name) ||
                            (item?.ARTournament && item?.ARTournament?.name) ||
                            (item?.GolfTournament &&
                              item?.GolfTournament?.name) ||
                            (item?.TennisTournament &&
                              item?.TennisTournament?.name) ||
                            (item?.BaseballTournament &&
                              item?.BaseballTournament?.name) ||
                            (item?.IceHockeyTournament &&
                              item?.IceHockeyTournament?.name) ||
                            (item?.BoxingTournament &&
                              item?.BoxingTournament?.name) ||
                            (item?.MMATournament &&
                              item?.MMATournament?.name) ||
                            (item?.SoccerTournament &&
                              item?.SoccerTournament?.name)}
                        </Text>
                      </View>
                      <View style={styles.flex} />
                    </View>
                  </View>
                  <View>
                    <View style={styles.setTopView}>
                      <View style={styles.thirdFlex} />
                      <View style={CommonStyle.commonCeterView}>
                        <Text style={styles.setTitleText}>
                          {translate("Score")}
                        </Text>
                      </View>
                      {/* <View style={CommonStyle.commonCeterView}>
                        <Text style={styles.setTitleText}>
                          {translate("Sets")}
                        </Text>
                      </View>
                      <View style={CommonStyle.commonCeterView}>
                        <Text style={styles.setTitleText}>
                          {translate("Games")}
                        </Text>
                      </View>
                      <View style={CommonStyle.commonCeterView}>
                        <Text style={styles.setTitleText}>
                          {translate("Points")}
                        </Text>
                      </View> */}
                    </View>
                    <View style={styles.tennisContainerView}>
                      <View style={commonStyles.commonFlex}>
                        <Pressable
                          onPress={() =>
                            navigation.navigate(NAVIGATION.TENNIS_MARKET)
                          }
                          style={commonStyles.commonFlex}
                        >
                          <Text style={styles.titleText} numberOfLines={1}>
                            {item?.homeTeam?.name}
                          </Text>
                        </Pressable>
                        <View style={commonStyles.commonFlex}>
                          <Text style={styles.titleText} numberOfLines={1}>
                            {item?.awayTeam?.name}
                          </Text>
                        </View>
                      </View>
                      <View style={commonStyles.commonFlex}>
                        <FlatList
                          data={item?.ARScores}
                          scrollEnabled={false}
                          showsVerticalScrollIndicator={false}
                          renderItem={({ item, index }) =>
                            renderTennisSetItem(item, index)
                          }
                          ListEmptyComponent={() => listHeader()}
                          keyExtractor={(item, index) => index.toString()}
                        />
                      </View>
                    </View>
                    {/* <FlatList
                      data={[item]}
                      scrollEnabled={false}
                      showsVerticalScrollIndicator={false}
                      renderItem={({ item, index }) =>
                        renderTennisOddsItem(item, index)
                      }
                      ListEmptyComponent={() => listHeader()}
                      keyExtractor={(item, index) => index.toString()}
                    /> */}
                    <View style={CommonStyle.commonRow}>
                      <Text style={styles.sportTitleText} numberOfLines={1}>
                        {item?.homeTeam?.name}
                      </Text>
                      <View style={CommonStyle.commonFlex} />
                    </View>
                    <View style={CommonStyle.alignCenterView}>
                      <Text style={styles.pointsText}>
                        {fetchCureentBestOdds(
                          item,
                          "points",
                          marketName === "totals" ? "over" : "homeTeam"
                        )}
                      </Text>
                      <View style={styles.oddsView}>
                        <Text style={styles.tennisTitleText} numberOfLines={1}>
                          {fetchCureentBestOdds(
                            item,
                            "odds",
                            marketName === "totals" ? "over" : "homeTeam"
                          )}
                        </Text>
                      </View>
                      {/* <Image
                        source={item?.imageIcon}
                        style={styles.iconStyle}
                      /> */}

                      {fetchBestSportOddsIcon(
                        item,
                        "odds",
                        marketName === "totals" ? "over" : "homeTeam"
                      )}
                    </View>
                    <View style={CommonStyle.commonRow}>
                      <Text style={styles.sportTitleText} numberOfLines={1}>
                        {item?.awayTeam?.name}
                      </Text>
                      <View style={CommonStyle.commonFlex} />
                    </View>
                    <View style={CommonStyle.alignCenterView}>
                      <Text style={styles.pointsText}>
                        {fetchCureentBestOdds(
                          item,
                          "points",
                          marketName === "totals" ? "over" : "homeTeam"
                        )}
                      </Text>
                      <View style={styles.oddsView}>
                        <Text style={styles.tennisTitleText} numberOfLines={1}>
                          {item?.homeTeamOdds
                            ? fetchCureentBestOdds(
                                item,
                                "odds",
                                marketName === "totals" ? "over" : "homeTeam"
                              )
                            : " - "}
                        </Text>
                      </View>

                      {fetchBestSportOddsIcon(
                        item,
                        "odds",
                        marketName === "totals" ? "over" : "homeTeam"
                      )}
                    </View>
                    <View style={styles.sponsoredHeight} />
                  </View>
                </View>
                {/* {props?.sponsoredId?.length > 0 && (
                  <>
                    <View style={styles.sponsoredView}>
                      <Text style={styles.currentBestTitle}>
                        {translate("SponsoredHeadToHead")}
                      </Text>
                    </View>
                    <View style={styles.commonTitleView}>
                      {props?.sponsoredId?.length > 0 &&
                        fetchSponsoredOddsHome(item, "homeTeam")}
                      <View style={styles.widthStyle} />
                      {props?.sponsoredId?.length > 0 &&
                        // fetchSponsoredOddsAway(item)}
                        fetchSponsoredOddsHome(item, "awayTeam")}
                    </View>
                  </>
                )} */}
                <View style={styles.bottomWidth} />
                {/* <AddsCommonList
                  AboveEventList={"AboveEventList"}
                  page={
                    props?.sportId == "Cricket"
                      ? 6
                      : props?.sportId == "Rugby League"
                      ? 7
                      : props?.sportId == "Rugby Union"
                      ? 8
                      : props?.sportId == "Basketball"
                      ? 12
                      : props?.sportId == "American Football"
                      ? 16
                      : props?.sportId == "Australian Rules"
                      ? 17
                      : // : props?.sportId == "Golf"
                      // ? 16
                      props?.sportId == "Tennis"
                      ? 23
                      : props?.sportId == "Baseball"
                      ? 18
                      : props?.sportId == "Ice Hockey"
                      ? 20
                      : props?.sportId == "Boxing"
                      ? 19
                      : props?.sportId == "Mixed Martial Arts"
                      ? 21
                      : props?.sportId == "Soccer"
                      ? 22
                      : ""
                  }
                  placeholder={Images.sportFirstImg}
                  bannerStyle={styles.secondBannerStyle}
                /> */}
              </View>
            ) : (
              <>
                <View style={styles.topView} key={index}>
                  {/* {index == 0 && (
                    <AddsCommonList
                      AboveEventList={"AboveEventList"}
                      page={
                        props?.sportId == "Cricket"
                          ? 6
                          : props?.sportId == "Rugby League"
                          ? 7
                          : props?.sportId == "Rugby Union"
                          ? 8
                          : props?.sportId == "Basketball"
                          ? 12
                          : props?.sportId == "American Football"
                          ? 16
                          : props?.sportId == "Australian Rules"
                          ? 17
                          : props?.sportId == "Golf"
                          ? 16
                          : props?.sportId == "Tennis"
                          ? 23
                          : props?.sportId == "Baseball"
                          ? 18
                          : props?.sportId == "Ice Hockey"
                          ? 20
                          : props?.sportId == "Boxing"
                          ? 19
                          : props?.sportId == "Mixed Martial Arts"
                          ? 21
                          : props?.sportId == "Soccer"
                          ? 22
                          : ""
                      }
                      placeholder={Images.sportFirstImg}
                      bannerStyle={styles.secondBannerStyle}
                    />
                  )} */}
                  {index == 1 && item?.outrights === false && (
                    <AddsCommonList
                      AboveEventFirstList={"AboveEventFirstList"}
                      page={
                        props?.sportId == "Cricket"
                          ? 6
                          : props?.sportId == "Rugby League"
                          ? 7
                          : props?.sportId == "Rugby Union"
                          ? 8
                          : props?.sportId == "Basketball"
                          ? 12
                          : props?.sportId == "American Football"
                          ? 16
                          : props?.sportId == "Australian Rules"
                          ? 17
                          : props?.sportId == "Golf"
                          ? 16
                          : props?.sportId == "Tennis"
                          ? 23
                          : props?.sportId == "Baseball"
                          ? 18
                          : props?.sportId == "Ice Hockey"
                          ? 20
                          : props?.sportId == "Boxing"
                          ? 19
                          : props?.sportId == "Mixed Martial Arts"
                          ? 21
                          : props?.sportId == "Soccer"
                          ? 22
                          : ""
                      }
                      placeholder={Images.sportFirstImg}
                      bannerStyle={styles.secondBannerStyle}
                    />
                  )}

                  {item?.outrights === false ? (
                    <>
                      <View style={styles.dateItem}>
                        <Text style={styles.dateItemText}>
                          {fetchDayName(item?.startTime)}{" "}
                          {moment
                            .utc(item?.startTime)
                            .local()
                            .format("DD/MM/YYYY")}
                        </Text>
                        <View style={styles.rowView}>
                          <Text style={styles.currentBest}>
                            {translate("CurrentBest")}
                          </Text>
                          <Pressable
                            onPress={() => {
                              setSeeAll(true), setSportId(item);
                              scrollRef?.current?.scrollToIndex({
                                animated: true,
                                index: 0,
                                viewPosition: 1,
                                // viewOffset: props?.tournamentsHeight,
                              });
                              setIsLoadMoreVisible(true);
                              getSeeAllData(item?.id, 1);
                              getOddsApi(item?.id);
                              fetchLatestOdds(item?.id);
                            }}
                          >
                            <Text style={styles.seeAllText}>
                              {translate("SeeAll")}
                            </Text>
                          </Pressable>
                        </View>
                      </View>
                      <View style={styles.width} />
                      <View style={styles.leftRightCenterText}>
                        <View style={styles.nameContainer}>
                          <Text style={styles.nameText}>
                            {(item?.CricketTournament &&
                              item?.CricketTournament?.name) ||
                              (item?.RLTournament &&
                                item?.RLTournament?.name) ||
                              (item?.NBATournament &&
                                item?.NBATournament?.name +
                                  " " +
                                  item?.NBATournament?.NBACategory?.name) ||
                              (item?.AFLTournament &&
                                item?.AFLTournament?.name) ||
                              (item?.ARTournament &&
                                item?.ARTournament?.name) ||
                              (item?.GolfTournament &&
                                item?.GolfTournament?.name) ||
                              (item?.TennisTournament &&
                                item?.TennisTournament?.name) ||
                              (item?.BaseballTournament &&
                                item?.BaseballTournament?.name) ||
                              (item?.IceHockeyTournament &&
                                item?.IceHockeyTournament?.name) ||
                              (item?.BoxingTournament &&
                                item?.BoxingTournament?.name) ||
                              (item?.MMATournament &&
                                item?.MMATournament?.name) ||
                              (item?.SoccerTournament &&
                                item?.SoccerTournament?.name)}
                          </Text>
                        </View>
                        <Text style={styles.rightText}>
                          {" "}
                          {moment
                            .utc(item?.startTime)
                            .local()
                            .format("hh:mm A")}{" "}
                          |{" "}
                          {`${
                            item?.marketLength ? item?.marketLength : 0
                          } Markets`}
                        </Text>
                      </View>
                      <View style={styles.leftCenterText}>
                        <View style={styles.centerView}>
                          <View>{fetchTeamlogo(item, "hometeam")}</View>
                          <Text style={styles.textLeft}>
                            {item?.homeTeam?.name}
                          </Text>
                        </View>
                        <View>
                          <View style={styles.halfFlex} />
                          <Text style={styles.vsText}>{translate("Vs")}</Text>
                        </View>

                        <View style={styles.centerView}>
                          <View>{fetchTeamlogo(item, "awayteam")}</View>
                          <Text style={styles.textLeft}>
                            {item?.awayTeam?.name}
                          </Text>
                        </View>
                      </View>
                      <>
                        <View style={styles.bestAtOpenContainer}>
                          <Text style={styles.bestHeadTitle}>
                            {translate("BestAtOpen")}
                          </Text>
                        </View>
                        <View style={styles.commonTitleView}>
                          <View style={styles.commonCenterView}>
                            <View style={commonStyles.commonRow}>
                              <View>
                                <Text style={styles.pointsText}>
                                  {fetchBestAtOpenOdds(
                                    item,
                                    "points",
                                    marketName === "totals"
                                      ? "over"
                                      : "homeTeam"
                                  )}
                                </Text>
                                {fetchBestAtOpenOdds(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "over" : "homeTeam"
                                )}
                              </View>
                              <View style={commonStyles.flexEnd}>
                                {fetchBestAtOpenOddsIcon(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "over" : "homeTeam"
                                )}
                              </View>
                            </View>
                          </View>

                          <View style={styles.widhStyle} />

                          {/* <View style={commonStyles.commonCeterView}>
                            <View style={styles.topCurrentBestView}>
                              <Text style={styles.pointsText}>
                                {fetchBestAtOpenOdds(
                                  item,
                                  "points",
                                  marketName === "totals" ? "under" : "awayTeam"
                                )}
                              </Text>
                              <View style={styles.leftStyle}>
                                {fetchBestAtOpenOdds(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "under" : "awayTeam"
                                )}

                                {fetchBestAtOpenOddsIcon(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "under" : "awayTeam"
                                )}
                              </View>
                            </View>
                          </View> */}

                          <View style={styles.commonCenterView}>
                            <View style={commonStyles.commonRow}>
                              <View>
                                <Text style={styles.pointsText}>
                                  {fetchBestAtOpenOdds(
                                    item,
                                    "points",
                                    marketName === "totals"
                                      ? "under"
                                      : "awayTeam"
                                  )}
                                </Text>
                                {fetchBestAtOpenOdds(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "under" : "awayTeam"
                                )}
                              </View>
                              <View style={commonStyles.flexEnd}>
                                {fetchBestAtOpenOddsIcon(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "under" : "awayTeam"
                                )}
                              </View>
                            </View>
                          </View>
                        </View>
                      </>
                      <>
                        <View style={styles.currentBestHeadView}>
                          <Text style={styles.currentBestTitle}>
                            {translate("CurrentBest")}
                          </Text>
                        </View>

                        {/* <View style={styles.commonTitleView}> */}
                        <View style={styles.currentBestOddsView}>
                          <View style={styles.commonCenterView}>
                            <View style={commonStyles.commonRow}>
                              <View>
                                <Text style={styles.pointsText}>
                                  {fetchCureentBestOdds(
                                    item,
                                    "points",
                                    marketName === "totals"
                                      ? "over"
                                      : "homeTeam"
                                  )}
                                </Text>
                                {fetchCureentBestOdds(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "over" : "homeTeam"
                                )}
                              </View>
                              <View style={commonStyles.flexEnd}>
                                {fetchCureentBestOddsIcon(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "over" : "homeTeam"
                                )}
                              </View>
                            </View>
                          </View>
                          <View style={styles.widhStyle} />

                          <View style={styles.commonCenterView}>
                            <View style={commonStyles.commonRow}>
                              <View>
                                <Text style={styles.pointsText}>
                                  {fetchCureentBestOdds(
                                    item,
                                    "points",
                                    marketName === "totals"
                                      ? "under"
                                      : "awayTeam"
                                  )}
                                </Text>
                                {fetchCureentBestOdds(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "under" : "awayTeam"
                                )}
                              </View>
                              <View style={commonStyles.flexEnd}>
                                {fetchCureentBestOddsIcon(
                                  item,
                                  "odds",
                                  marketName === "totals" ? "under" : "awayTeam"
                                )}
                              </View>
                            </View>
                          </View>
                        </View>
                      </>

                      {/* {props?.sponsoredId?.length > 0 && (
                  <>
                    <View style={styles.sponsoredView}>
                      <Text style={styles.currentBestTitle}>
                        {translate("SponsoredHeadToHead")}
                      </Text>
                    </View>
                    <View style={styles.commonTitleView}>
                      {props?.sponsoredId?.length > 0 &&
                        fetchSponsoredOddsHome(item)}
                      <View style={styles.widthStyle} />
                      {props?.sponsoredId?.length > 0 &&
                        fetchSponsoredOddsAway(item)}
                    </View>
                  </>
                )} */}
                      {props?.sponsoredId?.length > 0 && (
                        <>
                          <View style={styles.sponsoredView}>
                            <Text style={styles.currentBestTitle}>
                              {translate("SponsoredHeadToHead")}
                            </Text>
                          </View>
                          <View style={styles.commonTitleView}>
                            {fetchSponsoredOddsHome(item, "homeTeam", 1)}
                            <View style={styles.sponsoredWidth} />

                            {fetchSponsoredOddsHome(item, "awayTeam", 1)}
                          </View>
                          <View style={styles.bottomWidth} />
                          {props?.sponsoredId?.[1] && (
                            <>
                              <View style={styles.commonTitleView}>
                                {fetchSponsoredOddsHome(item, "homeTeam", 2)}
                                <View style={styles.sponsoredWidth} />

                                {fetchSponsoredOddsHome(item, "awayTeam", 2)}
                              </View>
                            </>
                          )}
                        </>
                      )}
                      <View style={styles.bottomWidth} />

                      <View style={styles.topHeight} />
                    </>
                  ) : // <View>{fetchOutrightsTable(item)}</View>
                  null}
                </View>
              </>
            )}
          </>
        ) : null}
      </>
    );
  };

  return (
    <>
      <Tabs.FlatList
        ref={scrollRef}
        data={isSeeAll ? teamsData : props?.data}
        // data={seeAllData.length > 0 ? seeAllData[0]?.BaseballOdds : props?.data}
        nestedScrollEnabled={false}
        showsVerticalScrollIndicator={false}
        // keyExtractor={(item) => item?.id}
        contentContainerStyle={styles.contentContainerStyle}
        renderItem={
          isSeeAll
            ? ({ item, index }) => renderSeeAllItem(item, index)
            : ({ item, index }) => renderItem(item, index)
        }
        ListHeaderComponent={
          isSeeAll ? props?.headerSeeAllCompnent : props.headerComponent
        }
        ListFooterComponent={
          isSeeAll ? props.seeAllfooterComponent : props.footerComponent
        }
        ListEmptyComponent={() => listHeader()}
        keyExtractor={(item, index) => index.toString()}
        refreshControl={
          <RefreshControl
            refreshing={props.refreshing}
            onRefresh={props.onRefresh}
          />
        }
      />
    </>
  );
}

export const oddsDataOption = [translate("WinFixed")];

// <View style={styles.topView} key={index}>
//   <AddsCommonList
//     AboveEventList={"AboveEventList"}
//     page={
//       props?.sportId == "Cricket"
//         ? 6
//         : props?.sportId == "Rugby League"
//         ? 7
//         : props?.sportId == "Rugby Union"
//         ? 8
//         : props?.sportId == "Basketball"
//         ? 12
//         : ""
//     }
//     placeholder={Images.sportFirstImg}
//     bannerStyle={styles.secondBannerStyle}
//   />
//   <View style={styles.dateItem}>
//     <Text style={styles.dateItemText}>
//       {fetchDayName(item?.startTime)}{" "}
//       {moment.utc(item?.startTime).local().format("DD/MM/YYYY")}
//     </Text>
//     <View style={styles.rowView}>
//       <Text style={styles.currentBest}>
//         {translate("CurrentBest")}
//       </Text>
//       <Text style={styles.seeAllText}>{item?.seeAll}</Text>
//     </View>
//   </View>
//   <View style={styles.width} />
//   <View style={styles.leftRightCenterText}>
//     <View style={styles.nameContainer}>
//       <Text style={styles.nameText}>
//         {(item?.CricketTournament && item?.CricketTournament?.name) ||
//           (item?.RLTournament && item?.RLTournament?.name) ||
//           (item?.NBATournament &&
//             item?.NBATournament?.name +
//               " " +
//               item?.NBATournament?.NBACategory?.name)}
//       </Text>
//     </View>

//     <Text style={styles.rightText}>
//       {" "}
//       {moment.utc(item?.startTime).local().format("hh:mm A")} |{" "}
//       {`${item?.MarketNumber ? item?.MarketNumber : 0} Markets`}
//     </Text>
//   </View>
//   <View style={styles.leftCenterText}>
//     <View style={styles.centerView}>
//       <View>{fetchTeamlogo(item, "hometeam")}</View>
//       <Text style={styles.textLeft}>{item?.homeTeam?.name}</Text>
//     </View>
//     <View style={{}}>
//       <Text style={styles.vsText}>{translate("Vs")}</Text>
//     </View>

//     <View style={styles.centerView}>
//       <View>{fetchTeamlogo(item, "awayteam")}</View>
//       <Text style={styles.textLeft}>{item?.awayTeam?.name}</Text>
//     </View>
//   </View>

//   <Text style={styles.title1}>{translate("TitleOne")}</Text>
//   <View style={styles.commonTitleView}>
//     <View style={styles.centerView}>
//       <Text style={styles.subRightTitle1}>
//         {translate("SubRightTitleOne")}
//       </Text>
//       <View style={styles.subRightImageRight}>
//         <View style={styles.numberContainer}>
//           <Text style={styles.subLeftImageRight1}>
//             {item?.homeTeamOdds
//               ? fetchBestOdds(item?.homeTeamOdds, "odds")
//               : " - "}
//           </Text>
//         </View>
//         {item?.homeTeamOdds ? (
//           fetchBestOddsIcon(item?.homeTeamOdds, "odds")
//         ) : (
//           <View style={styles.numberSecondContainer}>
//             <Text style={styles.emptyView}> - </Text>
//           </View>
//         )}
//       </View>
//     </View>
//     <View style={styles.centerView}>
//       <Text style={styles.subLeftTitle1}>
//         {translate("SubRightTitleOne")}
//       </Text>
//       <View style={styles.leftStyle}>
//         <View style={styles.numberContainer}>
//           <Text style={styles.subImageCommonStyle}>
//             {item?.homeTeamOdds
//               ? fetchBestOdds(item?.awayTeamOdds, "odds")
//               : " - "}
//           </Text>
//         </View>
//         {item?.awayTeamOdds ? (
//           fetchBestOddsIcon(item?.awayTeamOdds, "odds")
//         ) : (
//           <View style={styles.numberSecondContainer}>
//             <Text style={styles.emptyView}> - </Text>
//           </View>
//         )}
//       </View>
//     </View>
//   </View>
//   <SportOdds
//     fetchSeeAllHomeTeamOddsvalue={fetchSeeAllHomeTeamOddsvalue}
//     homeTeamName={item?.homeTeam?.name}
//     item={item}
//   />
//   <SportOdds
//     fetchSeeAllHomeTeamOddsvalue={fetchSeeAllawayTeamOddsvalue}
//     homeTeamName={item?.awayTeam?.name}
//     item={item}
//   />
//   <View style={styles.topHeight} />
// </View>

// let seeAllItem = (item, index) => {
//   print_data("helo=====");
//   print_data(item);
//   return (
//     <View style={{ backgroundColor: "red" }}>
//       <Text style={styles.dateItemText}>Odds Type</Text>
//       <View style={styles.rowView}>
//         <Pressable onPress={() => setSeeAll(false)}>
//           <Text style={styles.currentBest}>{translate("CurrentBest")}</Text>
//         </Pressable>
//         <Pressable onPress={() => setSeeAll(true)}>
//           <Text style={styles.seeAllText}>{translate("SeeAll")}</Text>
//         </Pressable>
//       </View>
//     </View>
//   );
// };

//Tennis
// props?.sportId == "Tennis" ? (
//   <View style={styles.horizontalView}>
//     <View style={styles.dateItem}>
//       <Text style={styles.dateItemText}>
//         {fetchDayName(new Date())}{" "}
//         {moment.utc(new Date()).local().format("DD/MM/YYYY")}
//       </Text>
//       {/* <View style={styles.rowView}>
//         <Text style={styles.currentBest}>
//           {translate("CurrentBest")}
//         </Text>
//         <Text style={styles.seeAllText}>{item?.seeAll}</Text>
//       </View> */}
//       <View style={styles.rowView}>
//         <Pressable
//           onPress={() => {
//             setSeeAll(false);
//             scrollRef?.current?.scrollToIndex({
//               animated: true,
//               index: 0,
//               viewPosition: 1,
//               viewOffset: props?.tournamentsHeight,
//             });
//           }}
//         >
//           <Text
//             style={
//               isSeeAll
//                 ? styles.heighLightCurrentBest
//                 : styles.currentBest
//             }
//           >
//             {translate("CurrentBest")}
//           </Text>
//         </Pressable>
//         <Text
//           style={
//             isSeeAll ? styles.seeAllHeighLightText : styles.seeAllText
//           }
//         >
//           {translate("SeeAll")}
//         </Text>
//       </View>
//     </View>
//     <View style={styles.width} />

//     <View style={styles.liveView}>
//       <View style={styles.liveContainer}>
//         <Text style={styles.liveText}>{translate("LiveText")}</Text>
//       </View>
//       <View style={styles.centerContainerView}>
//         <View style={styles.flex} />
//         <Text style={styles.rightText}>1st Set | 159 Markets</Text>
//         <View style={styles.tennisWidth} />
//         <View style={styles.nameBlueContainer}>
//           <Text style={styles.nameBlueText} numberOfLines={1}>
//             NFL Divisions sdfsdfsdfsdf
//           </Text>
//         </View>
//         <View style={styles.flex} />
//       </View>
//     </View>
//     <View>
//       <View style={styles.setTopView}>
//         <View style={styles.thirdFlex} />
//         <View style={CommonStyle.commonCeterView}>
//           <Text style={styles.setTitleText}>Sets</Text>
//         </View>
//         <View style={CommonStyle.commonCeterView}>
//           <Text style={styles.setTitleText}>Games</Text>
//         </View>
//         <View style={CommonStyle.commonCeterView}>
//           <Text style={styles.setTitleText}>Points</Text>
//         </View>
//       </View>
//       <FlatList
//         data={TennisSetList}
//         scrollEnabled={false}
//         showsVerticalScrollIndicator={false}
//         renderItem={({ item, index }) =>
//           renderTennisSetItem(item, index)
//         }
//         style={styles.bottomView}
//         ListEmptyComponent={() => listHeader()}
//         keyExtractor={(item, index) => index.toString()}
//       />
//       <FlatList
//         data={TennisSetList}
//         scrollEnabled={false}
//         showsVerticalScrollIndicator={false}
//         renderItem={({ item, index }) =>
//           renderTennisOddsItem(item, index)
//         }
//         ListEmptyComponent={() => listHeader()}
//         keyExtractor={(item, index) => index.toString()}
//       />
//       <View style={styles.sponsoredHeight} />
//       <View style={styles.sponsoredView}>
//         <Image
//           source={Images.sponsoredImage}
//           style={styles.sponsoredImage}
//         />
//       </View>
//       <View style={styles.commonTitleView}>
//         <View style={styles.centerOddsView}>
//           <Text style={styles.subLeftTitle1}>Christopher Eubanks</Text>
//           <View style={CommonStyle.alignCenterView}>
//             <View style={styles.numberTennisContainer}>
//               <Text style={styles.oddsText}>2.00</Text>
//             </View>

//             {/* <View style={styles.numberSecondContainer}>
//               <Text style={styles.emptyView}> - </Text>
//             </View> */}
//             <View style={styles.oddsContainer}>
//               <Image
//                 source={Images.uniBetIcon}
//                 style={styles.oddsIcon}
//               />
//             </View>
//           </View>
//         </View>
//         <View style={styles.widthStyle} />
//         <View style={styles.centerOddsView}>
//           <Text style={styles.subLeftTitle1}>Christopher Eubanks</Text>
//           <View style={CommonStyle.alignCenterView}>
//             <View style={styles.numberTennisContainer}>
//               <Text style={styles.oddsText}>2.00</Text>
//             </View>
//             <View style={styles.oddsContainer}>
//               <Image
//                 source={Images.uniBetIcon}
//                 style={styles.oddsIcon}
//               />
//             </View>
//           </View>
//         </View>
//       </View>
//       <View style={styles.bottomWidth} />
//       <View style={styles.commonTitleView}>
//         <View style={styles.centerView}>
//           <View style={styles.centerOddsView}>
//             <Text style={styles.subLeftTitle1}>
//               Christopher Eubanks
//             </Text>
//             <View style={CommonStyle.alignCenterView}>
//               <View style={styles.numberTennisContainer}>
//                 <Text style={styles.oddsText}>2.00</Text>
//               </View>
//               {/* <View style={styles.numberSecondContainer}>
//               <Text style={styles.emptyView}> - </Text>
//             </View> */}
//               <View style={styles.oddsContainer}>
//                 <Image
//                   source={Images.betIcon}
//                   style={styles.oddsIcon}
//                 />
//               </View>
//             </View>
//           </View>
//         </View>
//         <View style={styles.widthStyle} />
//         <View style={styles.centerOddsView}>
//           <Text style={styles.subLeftTitle1}>Christopher Eubanks</Text>
//           <View style={CommonStyle.alignCenterView}>
//             <View style={styles.numberTennisContainer}>
//               <Text style={styles.oddsText}>2.00</Text>
//             </View>

//             {/* <View style={styles.numberSecondContainer}>
//               <Text style={styles.emptyView}> - </Text>
//             </View> */}
//             {/* <View style={styles.oddsContainer}> */}
//             <Image source={Images.betIcon} style={styles.oddsIcon} />
//             {/* </View> */}
//           </View>
//         </View>
//       </View>
//       <View style={styles.bottomWidth} />
//     </View>
//     <FlatList
//       data={TENNIS_ARAAY}
//       scrollEnabled={false}
//       showsVerticalScrollIndicator={false}
//       contentContainerStyle={styles.contentContainerStyle}
//       renderItem={({ item, index }) => renderTennisItem(item, index)}
//       ListEmptyComponent={() => listHeader()}
//       keyExtractor={(item, index) => index.toString()}
//     />
//   </View>

//currentBest
{
  /* <View style={styles.currentBestHeadView}>
<Text style={styles.currentBestTitle}>
  {translate("CurrentBest")}
</Text>
</View>
<View style={styles.currentBestOddsView}>

<View style={commonStyles.alignCenter}>

  <View style={styles.s<View style={styles.widhStyle} />
<View style={commonStyles.alignCenter}>

  <View style={styles.leftStyle}>
    <View style={styles.numberContainer}>
      <Text style={styles.subImageCommonStyle}>
        {item?.homeTeamOdds
          ? fetchBestOdds(item?.awayTeamOdds, "odds")
          : " - "}
      </Text>
    </View>
    {item?.awayTeamOdds ? (
      fetchBestOddsIcon(item?.awayTeamOdds, "odds")
    ) : (
      <View style={styles.numberSecondContainer}>
        <Text style={styles.emptyView}> - </Text>
      </View>
    )}
  </View>
</View>
</View> ubRightImageRight}>
    <View style={styles.numberContainer}>
      <Text style={styles.subLeftImageRight1}>
        {item?.homeTeamOdds
          ? fetchBestOdds(item?.homeTeamOdds, "odds")
          : " - "}
      </Text>
    </View>
    {item?.homeTeamOdds ? (
      fetchBestOddsIcon(item?.homeTeamOdds, "odds")
    ) : (
      <View style={styles.numberSecondContainer}>
        <Text style={styles.emptyView}> - </Text>
      </View>
    )}
  </View>
</View>
*/
}
