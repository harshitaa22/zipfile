import React, { useEffect, useRef, useState } from "react";
import {
  Image,
  Linking,
  Pressable,
  RefreshControl,
  Text,
  View,
} from "react-native";
import CardView from "react-native-cardview";
import { Colors, Images } from "../../theme/index";
import { translate } from "../../utils/Localize";
import styles from "./style";

import { DownWhiteArrow, UpWhiteArrow } from "../../theme/svg";

import { format, parse } from "date-fns";
import _ from "lodash";
import moment from "moment";
import { Tabs } from "react-native-collapsible-tab-view";
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import commonStyles from "../../theme/commonStyle";
import { print_data } from "../../utils/Logs";
import { showToast } from "../../utils/commonFunction";
import ImageLoad from "../ImageLoad";
import LeaguePicker from "../LeaguePicker";
import Loader from "../ProgressBar";
import OutRightOdds from "../SportOdds/outRightOdds";
import CustomTextInput from "../TextInput";
import { SPORTS } from "../../utils/constant";

export default function GolfOutRightList(props: any) {
  const scrollRef = useRef(null);
  const [isSeeAll, setSeeAll] = useState(false);
  const [sportId, setSportId] = useState([]);
  const [isLeaugeModalVisible, setLeagueModalVisible] = useState(false);
  const [isLoadMore, setIsLoadMoreVisible] = useState(false);
  const [pageHeadingData, setPageHeadingData] = useState([]);
  const [isResults, setIsResults] = useState([]);
  const [isSelected, setIsSelected] = useState(true);
  const [teamsData, setTeamsData] = useState([]);
  const [marketName, setMarketName] = useState("");
  const [bookkeeperData, setBookKeeperData] = useState([]);
  const [individualTeamData, setIndividualTeamData] = useState({});
  const [selectedOddsText, setSelectedOddsText] = useState(
    translate("OddsType")
  );

  const groupedData = _.groupBy(props?.eventList, (item) =>
    moment.utc(item?.startTime).local().format("DD/MM/YYYY")
  );
  const result = _.map(groupedData, (objects, date) => ({ date, objects }));

  useEffect(() => {
    setIsResults(result);
    fetchBookKeeper();
  }, []);

  const fetchDayName = (date: any) => {
    var days = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    var d = new Date(date);
    var dayName = days[d.getDay()];
    return dayName;
  };

  const fetchFormatedDayname = (date) => {
    const parseddate = parse(date, "dd/MM/yyyy", new Date());
    const dayName = format(parseddate, "EEEE");
    return dayName;
  };

  const listHeader = () => {
    return (
      <Text style={styles.noRaceText}>{translate("NoDataAvailable")}</Text>
    );
  };
  // const onMarketNextPress = () => {
  //   const marketData = props?.marketItem;
  //   marketData?.forEach((item, _index) => {
  //     if (item?.displayName == selectedOddsText) {
  //       setIsLoadMoreVisible(true);

  //       getSeeAllSelectedItem([sportId]?.[0]?.id, item?.id);
  //     }
  //     setSelectedOddsText(selectedOddsText);
  //     setLeagueModalVisible(false);
  //   });
  // };
  const fetchBookKeeper = async () => {
    try {
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          setBookKeeperData(response?.body?.data?.result);
        }
      }
    } catch (error) {}
  };

  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    const sportId =
      props?.sportId === SPORTS.CRICKET
        ? 4
        : props?.sportId === SPORTS.RUBGY_LEAGUE
        ? 12
        : props?.sportId === SPORTS.RUBGY_UNION
        ? 13
        : props?.sportId === SPORTS.BASKETBALL
        ? 10
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? 15
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? 9
        : props?.sportId === SPORTS.GOLF
        ? 16
        : props?.sportId === SPORTS.TENNIS
        ? 7
        : props?.sportId === SPORTS.BASEBALL
        ? 11
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? 17
        : props?.sportId === SPORTS.BOXING
        ? 6
        : props?.sportId === SPORTS.MMA
        ? 5
        : props?.sportId === SPORTS.SOCCER
        ? 8
        : 14;
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      print_data("====datacounter===");
      print_data(response);
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsCurrentBestContainer}
      >
        <Text style={styles.subLeftImageRight1}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };

  const oddsIcon = (BookKeeperId: number, type: any) => {
    let icon = bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsImageContainer}
      >
        {BookKeeperId === 11 ? (
          <Image style={styles.oddsImageIcon} source={Images.topSportOdds} />
        ) : (
          <ImageLoad
            style={styles.oddsImageIcon}
            resizeMode={"contain"}
            source={
              iconData?.small_logo?.includes("uploads")
                ? API_URL + "/" + iconData?.small_logo
                : iconData?.small_logo
            }
          />
        )}
      </Pressable>
    );
  };
  const fetchTableHeading = async (bookkeeper) => {
    try {
      const sportId =
        props?.sportId === SPORTS.CRICKET
          ? 4
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? 12
          : props?.sportId === SPORTS.RUBGY_UNION
          ? 13
          : props?.sportId === SPORTS.BASKETBALL
          ? 10
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? 15
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? 9
          : props?.sportId === SPORTS.GOLF
          ? 16
          : props?.sportId === SPORTS.TENNIS
          ? 7
          : props?.sportId === SPORTS.BASEBALL
          ? 11
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? 17
          : props?.sportId === SPORTS.BOXING
          ? 6
          : props?.sportId === SPORTS.MMA
          ? 5
          : props?.sportId === SPORTS.SOCCER
          ? 8
          : 14;
      const response = await callApi(
        `public/apiProviders/bookkeeperproviders?SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
          let filteredHeading = response?.body?.data?.result?.filter((item) =>
            bookkeeper?.includes(item?.BookKeeperId)
          );
          setPageHeadingData(filteredHeading);
        }
      }
    } catch (error) {}
  };
  const fetchIndividualTeamdata = async (item) => {
    try {
      const passApi =
        props?.sportId === SPORTS.CRICKET
          ? `public/crickets/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? `public/rls/event/${item}?SportId=12&isOuright=true`
          : props?.sportId === SPORTS.RUBGY_UNION
          ? `public/rls/event/${item}?SportId=13&isOuright=true`
          : props?.sportId === SPORTS.BASKETBALL
          ? `public/nba/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? `public/afl/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? `public/ar/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.GOLF
          ? `public/golf/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.TENNIS
          ? `public/tennis/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.BASEBALL
          ? `public/baseball/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? `public/icehockey/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.BOXING
          ? `public/boxing/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.MMA
          ? `public/mma/event/${item}?isOuright=true`
          : props?.sportId === SPORTS.SOCCER
          ? `public/soccer/event/${item}?isOuright=true`
          : `public/rls/event/${item}?SportId=14&isOuright=true`;

      const response = await callApi(passApi, null, API_CONFIG.GET, null);

      if (response.body != null) {
        if (response.body?.status === 200) {
          let fullData = [];
          let teamdata = [response?.body?.data?.result];
          let datas = teamdata?.map((item) => {
            let newData =
              teamdata?.length > 0
                ? props?.sportId === SPORTS.CRICKET
                  ? teamdata?.[0]?.CricketBetOffers
                  : props?.sportId === SPORTS.BASKETBALL
                  ? teamdata?.[0]?.NBABetOffers
                  : props?.sportId === SPORTS.AMERICAN_FOOTBALL
                  ? teamdata?.[0]?.AFLBetOffers
                  : props?.sportId === SPORTS.AUSTRALIAN_RULES
                  ? teamdata?.[0]?.ARBetOffers
                  : props?.sportId === SPORTS.TENNIS
                  ? teamdata?.[0]?.TennisBetOffers
                  : props?.sportId === SPORTS.BASEBALL
                  ? teamdata?.[0]?.BaseballBetOffers
                  : props?.sportId === SPORTS.ICE_HOCKEY
                  ? teamdata?.[0]?.IceHockeyBetOffers
                  : props?.sportId === SPORTS.BOXING
                  ? teamdata?.[0]?.BoxingBetOffers
                  : props?.sportId === SPORTS.MMA
                  ? teamdata?.[0]?.MMABetOffers
                  : props?.sportId === SPORTS.SOCCER
                  ? teamdata?.[0]?.SoccerBetOffers
                  : props?.sportId === SPORTS.GOLF
                  ? teamdata?.[0]?.GolfBetOffers
                  : teamdata?.[0]?.RLBetOffers
                : [];

            let SportsOdds =
              props?.sportId === SPORTS.CRICKET
                ? newData?.[0]?.CricketOdds
                : props?.sportId === SPORTS.BASKETBALL
                ? newData?.[0]?.NBAOdds
                : props?.sportId === SPORTS.AMERICAN_FOOTBALL
                ? newData?.[0]?.AFLOdds
                : props?.sportId === SPORTS.AUSTRALIAN_RULES
                ? newData?.[0]?.AROdds
                : props?.sportId === SPORTS.TENNIS
                ? newData?.[0]?.TennisOdds
                : props?.sportId === SPORTS.BASEBALL
                ? newData?.[0]?.BaseballOdds
                : props?.sportId === SPORTS.ICE_HOCKEY
                ? newData?.[0]?.IceHockeyOdds
                : props?.sportId === SPORTS.BOXING
                ? newData?.[0]?.BoxingOdds
                : props?.sportId === SPORTS.MMA
                ? newData?.[0]?.MMAOdds
                : props?.sportId === SPORTS.SOCCER
                ? newData?.[0]?.SoccerOdds
                : props?.sportId === SPORTS.GOLF
                ? newData?.[0]?.GolfOdds
                : newData?.[0]?.RLOdds;
            let bookkeeper = [];
            let BookkeeperList = SportsOdds?.map((element) => {
              return bookkeeper?.push(element?.BookKeeperId);
            });
            fetchTableHeading([...new Set(bookkeeper)]);

            setIndividualTeamData(item);
            fullData.push(item);
            setTimeout(() => {
              setIsLoadMoreVisible(false);
            }, 2000);
          });
        }
      }
    } catch {
      setIsLoadMoreVisible(false);
      setTimeout(() => {
        showToast(translate("SomethingWrong"));
      }, 10);
    }
  };

  const fetchSeeAllOutRightsData = (item) => {
    let outRightTeams =
      props?.sportId === SPORTS.CRICKET
        ? item?.CricketOutRightTeams
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBAOutRightTeams
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLOutRightTeams
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.AROutRightTeams
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisOutRightTeams
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballOutRightTeams
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyOutRightTeams
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingOutRightTeams
        : props?.sportId === SPORTS.MMA
        ? item?.MMAOutRightTeams
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerOutRightTeams
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfOutRightTeams
        : item?.RLOutRightTeams;
    let outrightsTeamdata = outRightTeams?.map((obj) => {
      return props?.sportId === SPORTS.CRICKET
        ? obj?.CricketTeam
        : props?.sportId === SPORTS.BASKETBALL
        ? obj?.NBATeam
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? obj?.AFLTeam
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? obj?.ARTeam
        : props?.sportId === SPORTS.TENNIS
        ? obj?.TennisTeam
        : props?.sportId === SPORTS.BASEBALL
        ? obj?.BaseballTeam
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? obj?.IceHockeyTeam
        : props?.sportId === SPORTS.BOXING
        ? obj?.BoxingTeam
        : props?.sportId === SPORTS.MMA
        ? obj?.MMATeam
        : props?.sportId === SPORTS.SOCCER
        ? obj?.SoccerTeam
        : props?.sportId === SPORTS.GOLF
        ? obj?.GolfTeam
        : obj?.RLTeam;
    });
    return outrightsTeamdata?.map((teamdata, index) => {
      return (
        <>
          <View key={index}>
            <View style={styles.sportContainerView}>
              <Text style={styles.sportRightTitle}>{teamdata?.name}</Text>
            </View>
            <OutRightOdds
              item={item}
              teamId={teamdata?.id}
              sportId={props?.sportId}
              bookkeeperData={bookkeeperData}
              pageHeadingData={pageHeadingData}
              sportItem={pageHeadingData}
            />
            <View style={styles.sportBottomWidth} />
          </View>
        </>
      );
    });
  };
  const fetchCureentBestOdds = (
    data: any,
    type: any,
    team: any,
    teamId: any
  ) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });
    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max: any, obj: any) => {
      let oddsType = obj?.odd ? obj?.odd : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (type === "odds") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let bookkeeperid = teamData
            ?.map((obj) => {
              if (obj?.odd === maxno) {
                return obj?.BookKeeperId;
              }
            })
            ?.filter((x) => x !== undefined);
          return fetchClickableOdds(maxno, bookkeeperid?.[0], "header");
          // return maxno;
        } else {
          return (
            <View style={styles.oddsCurrentBestContainer}>
              <Text style={styles.subLeftImageRight1}>-</Text>
            </View>
          );
        }
      } else {
        return (
          <View style={styles.oddsCurrentBestContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else if (type === "points") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let point = teamData
            ?.map((obj) => {
              if (obj?.odd === maxno) {
                return marketName === "totals"
                  ? obj?.label + " " + obj?.point
                  : obj?.point;
              }
            })
            ?.filter((x) => x !== undefined);

          return point?.[0];
        } else {
          return "";
        }
      } else {
        return "";
      }
    }
  };

  const fetchBestAtOpenOdds = (
    data: any,
    type: any,
    team: any,
    teamId: any
  ) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });
    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max, obj) => {
      let oddsType = obj?.bestOpen ? obj?.bestOpen : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (type === "odds") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let bookkeeperid = teamData
            ?.map((obj) => {
              if (obj?.bestOpen === maxno) {
                return obj?.BookKeeperId;
              }
            })
            ?.filter((x) => x !== undefined);
          return fetchClickableOdds(maxno, bookkeeperid?.[0], "header");
          // return maxno;
        } else {
          return (
            <View style={styles.oddsCurrentBestContainer}>
              <Text style={styles.subLeftImageRight1}>-</Text>
            </View>
          );
        }
      } else {
        return (
          <View style={styles.oddsCurrentBestContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else if (type === "points") {
      if (maxno !== -1) {
        if (maxno !== 0) {
          let point = teamData
            ?.map((obj) => {
              if (obj?.bestOpen === maxno) {
                return marketName === "totals"
                  ? obj?.label + " " + obj?.point
                  : obj?.point;
              }
            })
            ?.filter((x) => x !== undefined);

          return point?.[0];
        } else {
          return "";
        }
      } else {
        return "";
      }
    }
  };
  const fetchLatestOdds = async (item) => {
    try {
      const sportName =
        props?.sportId === SPORTS.CRICKET
          ? "crickets"
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportId === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportId === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportId === SPORTS.TENNIS
          ? "tennis"
          : props?.sportId === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportId === SPORTS.BOXING
          ? "boxing"
          : props?.sportId === SPORTS.MMA
          ? "mma"
          : props?.sportId === SPORTS.SOCCER
          ? "soccer"
          : props?.sportId === SPORTS.GOLF
          ? "golf"
          : "rls";
      const sportId =
        props?.sportId === SPORTS.CRICKET
          ? 4
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? 12
          : props?.sportId === SPORTS.RUBGY_UNION
          ? 13
          : props?.sportId === SPORTS.BASKETBALL
          ? 10
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? 15
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? 9
          : props?.sportId === SPORTS.GOLF
          ? 16
          : props?.sportId === SPORTS.TENNIS
          ? 7
          : props?.sportId === SPORTS.BASEBALL
          ? 11
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? 17
          : props?.sportId === SPORTS.BOXING
          ? 6
          : props?.sportId === SPORTS.MMA
          ? 5
          : props?.sportId === SPORTS.SOCCER
          ? 8
          : 14;
      const response = await callApi(
        `sync/${sportName}/oddOnDemand/${item}?SportId=${sportId}`,
        null,
        API_CONFIG.GET,
        null
      );

      if (response.body != null) {
        if (response.body?.status === 200) {
        }
      }
    } catch (error) {}
  };

  const fetchCureentBestOddsIcon = (data, type, team, teamId) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max, obj) => {
      let oddsType = obj?.odd ? obj?.odd : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);
    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = teamData
          ?.map((obj) => {
            let oddsType = type === "odds" ? obj?.odd : obj?.line;
            if (oddsType === maxno) {
              return obj?.BookKeeperId;
            }
          })
          ?.filter((x) => x !== undefined);

        return oddsIcon(providerid?.[0], "header");
      } else {
        return (
          <View style={styles.emptyContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.subLeftImageRight1}>-</Text>
        </View>
      );
    }
  };

  const fetchBestAtOpenOddsIcon = (
    data: any,
    type: any,
    team: any,
    teamId: any
  ) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let teamInfo =
      team === "homeTeam"
        ? homeTeamOdds
        : team === "awayTeam"
        ? awayTeamOdds
        : outrightsTeamOdds;
    let teamData = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let UnderData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? OverData : UnderData;
    }
    let maxno = teamData?.reduce((max, obj) => {
      let oddsType = obj?.bestOpen ? obj?.bestOpen : 0;
      oddsType > max ? (max = oddsType) : (max = max);
      return max;
    }, -1);

    if (maxno !== -1) {
      if (maxno !== 0) {
        let providerid = teamData
          ?.map((obj) => {
            let oddsType = obj?.bestOpen;
            if (oddsType === maxno) {
              return obj?.BookKeeperId;
            }
          })
          ?.filter((x) => x !== undefined);
        return oddsIcon(providerid?.[0], "header");
      } else {
        return (
          <View style={styles.bestEmptyContainer}>
            <Text style={styles.subLeftImageRight1}>-</Text>
          </View>
        );
      }
    } else {
      return (
        <View style={styles.bestEmptyContainer}>
          <Text style={styles.subLeftImageRight1}>-</Text>
        </View>
      );
    }
  };

  const fetchOutrightsTable = (item) => {
    let outRightTeams =
      props?.sportId === SPORTS.CRICKET
        ? item?.CricketOutRightTeams
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBAOutRightTeams
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLOutRightTeams
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.AROutRightTeams
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisOutRightTeams
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballOutRightTeams
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyOutRightTeams
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingOutRightTeams
        : props?.sportId === SPORTS.MMA
        ? item?.MMAOutRightTeams
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerOutRightTeams
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfOutRightTeams
        : item?.RLOutRightTeams;
    let outrightsTeamdata = outRightTeams?.map((obj) => {
      return props?.sportId === SPORTS.CRICKET
        ? obj?.CricketTeam
        : props?.sportId === SPORTS.BASKETBALL
        ? obj?.NBATeam
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? obj?.AFLTeam
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? obj?.ARTeam
        : props?.sportId === SPORTS.TENNIS
        ? obj?.TennisTeam
        : props?.sportId === SPORTS.BASEBALL
        ? obj?.BaseballTeam
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? obj?.IceHockeyTeam
        : props?.sportId === SPORTS.BOXING
        ? obj?.BoxingTeam
        : props?.sportId === SPORTS.MMA
        ? obj?.MMATeam
        : props?.sportId === SPORTS.SOCCER
        ? obj?.SoccerTeam
        : props?.sportId === SPORTS.GOLF
        ? obj?.GolfTeam
        : obj?.RLTeam;
    });
    return (
      <>
        {outrightsTeamdata?.map((teamData, index) => {
          return (
            <View key={index}>
              <Text style={styles.teamTitleTextStyle}>{teamData?.name}</Text>
              <View style={commonStyles.alignCenterView}>
                <View style={styles.bestView}>
                  <View style={styles.bestAtOpenContainerGolf}>
                    <Text style={styles.bestHeadTitle}>
                      {translate("BestAtOpen")}
                    </Text>
                  </View>

                  {fetchBestAtOpenOdds(
                    item,
                    "odds",
                    "outrightsteam",
                    teamData?.id
                  )}

                  {fetchBestAtOpenOddsIcon(
                    item,
                    "odds",
                    "outrightsteam",
                    teamData?.id
                  )}
                </View>

                <View style={styles.separatorBestStyle} />
                <View style={styles.bestView}>
                  <View style={styles.currentBestHeadViewGolf}>
                    <Text style={styles.currentBestTitle}>
                      {translate("CurrentBest")}
                    </Text>
                  </View>

                  {fetchCureentBestOdds(
                    item,
                    "odds",
                    "outrightsteam",
                    teamData?.id
                  )}
                  {fetchCureentBestOddsIcon(
                    item,
                    "odds",
                    "outrightsteam",
                    teamData?.id
                  )}
                </View>
                {props?.sponsoredId?.length > 0 && (
                  <>
                    <View style={styles.separatorBestStyle} />
                    <View style={styles.bestViewSponsore}>
                      <View style={styles.sponsoredViewGolf}>
                        <Text style={styles.currentBestTitle}>
                          {translate("Sponsored")}
                        </Text>
                      </View>
                      <View style={styles.commonTitleView}>
                        {props?.sponsoredId?.length > 0 &&
                          fetchSponsoredOddsHome(item, teamData?.id)}
                      </View>
                    </View>
                  </>
                )}
              </View>
              <View style={styles.separatorStyle} />
            </View>
          );
        })}
      </>
    );
  };

  const fetchSponsoredOddsHome = (data, teamId) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let outRightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let teamInfo = teamId ? outRightsTeamOdds : homeTeamOdds;
    let teamOdds = marketName === "totals" ? allTeamOdds : teamInfo;
    if (marketName === "totals") {
      let OverData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });

      teamOdds = OverData;
    }
    let newOdds = teamOdds
      ?.filter((odds) => {
        return props?.sponsoredId?.includes(odds.BookKeeperId);
      })
      ?.slice(0, 2);
    let firstSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[0]
    );
    let secondSponsored = newOdds?.filter(
      (item) => item?.BookKeeperId === props?.sponsoredId?.[1]
    );

    let SponsoredOdds = props?.sponsoredId?.length > 0 && (
      <>
        <View style={styles.centerOddsView}>
          <View style={styles.sponsoreCenterView}>
            {firstSponsored?.[0]?.odd ? (
              <View>
                {firstSponsored?.[0]?.point && (
                  <Text style={styles.sponsorePointsText}>
                    {marketName === "totals"
                      ? firstSponsored?.[0]?.label +
                        " " +
                        firstSponsored?.[0]?.point
                      : firstSponsored?.[0]?.point}
                  </Text>
                )}
                <>
                  {fetchClickableOdds(
                    firstSponsored?.[0]?.odd ? firstSponsored?.[0]?.odd : "NOA",
                    firstSponsored?.[0]?.BookKeeperId,
                    "sponsored"
                  )}
                </>
              </View>
            ) : (
              <View style={styles.bestEmptyContainer}>
                <Text style={styles.subLeftImageRight1}>-</Text>
              </View>
            )}
            <View style={commonStyles.flexEnd}>
              {oddsIcon(props?.sponsoredId?.[0], "sponsored")}
            </View>
          </View>
        </View>
        <>
          {props?.sponsoredId?.[1] ? (
            <>
              <View style={styles.sponsoreCenterView}>
                {secondSponsored?.[0]?.odd ? (
                  <View>
                    {secondSponsored?.[0]?.point && (
                      <Text style={styles.sponsorePointsText}>
                        {marketName === "totals"
                          ? secondSponsored?.[0]?.label +
                            " " +
                            secondSponsored?.[0]?.point
                          : secondSponsored?.[0]?.point}
                      </Text>
                    )}

                    {fetchClickableOdds(
                      secondSponsored?.[0]?.odd
                        ? secondSponsored?.[0]?.odd
                        : "NOA",
                      secondSponsored?.[0]?.BookKeeperId,
                      "sponsored"
                    )}
                  </View>
                ) : (
                  <View style={styles.bestEmptyContainer}>
                    <Text style={styles.subLeftImageRight1}>-</Text>
                  </View>
                )}
                <View style={commonStyles.flexEnd}>
                  {oddsIcon(props?.sponsoredId?.[1], "sponsored")}
                </View>
              </View>
            </>
          ) : (
            <></>
          )}
        </>
        {/* {type == 3 && (
          <>
            <View style={styles.centerOddsView}>
              <View style={CommonStyle.alignCenterView}>
                {firstSponsored?.[0]?.odd ? (
                  <View style={styles.numberOddsContainer}>
                    <Text style={styles.oddsText}>
                      {firstSponsored?.[0]?.odd ? firstSponsored?.[0]?.odd : ""}
                    </Text>
                  </View>
                ) : null}

                <View>{getOddsSponsoredIcon(props?.sponsoredId?.[0])}</View>
              </View>
            </View>
            {props?.sponsoredId?.[1] ? (
              <>
                <View style={styles.sponsoredWidthStyle} />
                <View style={styles.centerOddsView}>
                  <View style={CommonStyle.alignCenterView}>
                    {secondSponsored?.[0]?.odd ? (
                      <View style={styles.numberOddsContainer}>
                        <Text style={styles.oddsText}>
                          {secondSponsored?.[0]?.odd
                            ? secondSponsored?.[0]?.odd
                            : "NOA"}
                        </Text>
                      </View>
                    ) : null}

                    <View>{getOddsSponsoredIcon(props?.sponsoredId?.[1])}</View>
                  </View>
                </View>
              </>
            ) : (
              <></>
            )}
          </>
        )} */}
        {/* <View style={styles.widthStyle} /> */}
        {/* <View style={styles.centerOddsView}>
            <Text style={styles.subLeftTitle1}>
              {data?.awayTeam?.name ? data?.awayTeam?.name : ""}
            </Text>
            <View style={CommonStyle.alignCenterView}>
              <View style={styles.numberOddsContainer}>
                <Text style={styles.oddsText}>
                  {secondSponsored?.[0]?.odd
                    ? secondSponsored?.[0]?.odd
                    : "NOA"}
                </Text>
              </View>
              <View>{getOddsIcon(props?.sponsoredId?.[1])}</View>
            </View>
          </View> */}
        {/* </View> */}
        {/* {props?.sponsoredId?.[1] && (
          <View style={styles.commonTitleView}>
            <View style={styles.centerOddsView}>
              <Text style={styles.subLeftTitle1}>
                {data?.awayTeam?.name ? data?.awayTeam?.name : ""}
              </Text>
              <View style={CommonStyle.alignCenterView}>
                <View style={styles.numberOddsContainer}>
                  <Text style={styles.oddsText}>
                    {secondSponsored?.[0]?.odd
                      ? secondSponsored?.[0]?.odd
                      : "NOA"}
                  </Text>
                </View>
                <View>{getOddsIcon(props?.sponsoredId?.[1])}</View>
              </View>
            </View>
          </View>
        )} */}
      </>
    );

    return SponsoredOdds;
  };

  const getSeeAllData = async (oddsId, id) => {
    try {
      let sportName =
        props?.sportId === SPORTS.CRICKET
          ? "crickets"
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportId === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportId === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportId === SPORTS.TENNIS
          ? "tennis"
          : props?.sportId === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportId === SPORTS.BOXING
          ? "boxing"
          : props?.sportId === SPORTS.MMA
          ? "mma"
          : props?.sportId === SPORTS.SOCCER
          ? "soccer"
          : props?.sportId === SPORTS.GOLF
          ? "golf"
          : "rls";
      const response = await callApi(
        `public/${sportName}/event/${oddsId}?marketId=${id}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          let data = response.body?.data?.result;
          setTeamsData([data]);

          let teamdata = [data];
          let newData =
            teamdata?.length > 0
              ? props?.sportId === SPORTS.CRICKET
                ? teamdata?.[0]?.CricketBetOffers
                : props?.sportId === SPORTS.BASKETBALL
                ? teamdata?.[0]?.NBABetOffers
                : props?.sportId === SPORTS.AMERICAN_FOOTBALL
                ? teamdata?.[0]?.AFLBetOffers
                : props?.sportId === SPORTS.AUSTRALIAN_RULES
                ? teamdata?.[0]?.ARBetOffers
                : props?.sportId === SPORTS.TENNIS
                ? teamdata?.[0]?.TennisBetOffers
                : props?.sportId === SPORTS.BASEBALL
                ? teamdata?.[0]?.BaseballBetOffers
                : props?.sportId === SPORTS.ICE_HOCKEY
                ? teamdata?.[0]?.IceHockeyBetOffers
                : props?.sportId === SPORTS.BOXING
                ? teamdata?.[0]?.BoxingBetOffers
                : props?.sportId === SPORTS.MMA
                ? teamdata?.[0]?.MMABetOffers
                : props?.sportId === SPORTS.SOCCER
                ? teamdata?.[0]?.SoccerBetOffers
                : props?.sportId === SPORTS.GOLF
                ? teamdata?.[0]?.GolfBetOffers
                : teamdata?.[0]?.RLBetOffers
              : [];

          let sportsOdds =
            props?.sportId === SPORTS.CRICKET
              ? newData?.[0]?.CricketOdds
              : props?.sportId === SPORTS.BASKETBALL
              ? newData?.[0]?.NBAOdds
              : props?.sportId === SPORTS.AMERICAN_FOOTBALL
              ? newData?.[0]?.AFLOdds
              : props?.sportId === SPORTS.AUSTRALIAN_RULES
              ? newData?.[0]?.AROdds
              : props?.sportId === SPORTS.TENNIS
              ? newData?.[0]?.TennisOdds
              : props?.sportId === SPORTS.BASEBALL
              ? newData?.[0]?.BaseballOdds
              : props?.sportId === SPORTS.ICE_HOCKEY
              ? newData?.[0]?.IceHockeyOdds
              : props?.sportId === SPORTS.BOXING
              ? newData?.[0]?.BoxingOdds
              : props?.sportId === SPORTS.MMA
              ? newData?.[0]?.MMAOdds
              : props?.sportId === SPORTS.SOCCER
              ? newData?.[0]?.SoccerOdds
              : props?.sportId === SPORTS.GOLF
              ? newData?.[0]?.GolfOdds
              : newData?.[0]?.RLOdds;
          let sportMarket =
            props?.sportId === SPORTS.CRICKET
              ? newData?.[0]?.CricketMarket?.name
              : props?.sportId === SPORTS.BASKETBALL
              ? newData?.[0]?.NBAMarket?.name
              : props?.sportId === SPORTS.AMERICAN_FOOTBALL
              ? newData?.[0]?.AFLMarket?.name
              : props?.sportId === SPORTS.AUSTRALIAN_RULES
              ? newData?.[0]?.ARMarket?.name
              : props?.sportId === SPORTS.TENNIS
              ? newData?.[0]?.TennisMarket?.name
              : props?.sportId === SPORTS.BASEBALL
              ? newData?.[0]?.BaseballMarket?.name
              : props?.sportId === SPORTS.ICE_HOCKEY
              ? newData?.[0]?.IceHockeyMarket?.name
              : props?.sportId === SPORTS.BOXING
              ? newData?.[0]?.BoxingMarket?.name
              : props?.sportId === SPORTS.MMA
              ? newData?.[0]?.MMAMarket?.name
              : props?.sportId === SPORTS.SOCCER
              ? newData?.[0]?.SoccerMarket?.name
              : props?.sportId === SPORTS.GOLF
              ? newData?.[0]?.GolfMarket?.name
              : newData?.[0]?.RLMarket?.name;

          setMarketName(sportMarket);
          let bookkeeper = [];
          let BookkeeperList = sportsOdds?.map((element) => {
            return bookkeeper?.push(element?.BookKeeperId);
          });
          fetchTableHeading([...new Set(bookkeeper)]);
          let displayName = data?.CricketBetOffers
            ? data?.CricketBetOffers[0]?.CricketMarket?.displayName
            : data?.NBABetOffers
            ? data?.NBABetOffers[0]?.NBAMarket?.displayName
            : data?.AFLBetOffers
            ? data?.AFLBetOffers[0]?.AFLMarket?.displayName
            : data?.ARBetOffers
            ? data?.ARBetOffers[0]?.ARMarket?.displayName
            : data?.TennisBetOffers
            ? data?.TennisBetOffers[0]?.TennisMarket?.displayName
            : data?.BaseballBetOffers
            ? data?.BaseballBetOffers[0]?.BaseballMarket?.displayName
            : data?.IceHockeyBetOffers
            ? data?.IceHockeyBetOffers[0]?.IceHockeyMarket?.displayName
            : data?.BoxingBetOffers
            ? data?.BoxingBetOffers[0]?.BoxingMarket?.displayName
            : data?.MMABetOffers
            ? data?.MMABetOffers[0]?.MMAMarket?.displayName
            : data?.SoccerBetOffers
            ? data?.SoccerBetOffers[0]?.SoccerMarket?.displayName
            : data?.RLBetOffers[0]?.RLMarket?.displayName;

          setSelectedOddsText(displayName);

          setIsLoadMoreVisible(false);
        }
      }
    } catch (error) {
      print_data("error======");
    }
  };
  const getOddsApi = async (oddsId) => {
    try {
      let sportName =
        props?.sportId === SPORTS.CRICKET
          ? "crickets"
          : props?.sportId === SPORTS.RUBGY_LEAGUE
          ? "rls"
          : props?.sportId === SPORTS.RUBGY_UNION
          ? "rls"
          : props?.sportId === SPORTS.BASKETBALL
          ? "nba"
          : props?.sportId === SPORTS.AMERICAN_FOOTBALL
          ? "afl"
          : props?.sportId === SPORTS.AUSTRALIAN_RULES
          ? "ar"
          : props?.sportId === SPORTS.TENNIS
          ? "tennis"
          : props?.sportId === SPORTS.BASEBALL
          ? "baseball"
          : props?.sportId === SPORTS.ICE_HOCKEY
          ? "icehockey"
          : props?.sportId === SPORTS.BOXING
          ? "boxing"
          : props?.sportId === SPORTS.MMA
          ? "mma"
          : props?.sportId === SPORTS.SOCCER
          ? "soccer"
          : props?.sportId === SPORTS.GOLF
          ? "golf"
          : "rls";
      const response = await callApi(
        `public/${sportName}/event/${oddsId}`,
        null,
        API_CONFIG.GET,
        null
      );
      if (response.body != null) {
        if (response.body?.status === 200) {
          setIsLoadMoreVisible(false);
        }
      }
    } catch (error) {
      print_data("error======");
    }
  };

  const renderSeeAllItem = (item: any, index: any) => {
    return (
      <>
        {isLoadMore && (
          <View style={styles.loader}>
            <Loader color={Colors.black} />
          </View>
        )}
        {!isLoadMore && (
          <CardView
            style={styles.SeeAllwinView}
            cardElevation={5}
            cardMaxElevation={4}
          >
            <View style={styles.topView} key={index}>
              <LeaguePicker
                isVisible={isLeaugeModalVisible}
                showModel={setLeagueModalVisible}
                data={oddsDataOption}
                onItemSelect={(selectedData) => {
                  setSelectedOddsText(selectedData?.title);
                  // oddsTypeChange(selectedData);
                  // setSelectedOddsText(selectedData?.title);
                }}
              />
              <View style={styles.dateItem}>
                <Pressable
                  style={styles.oddTypeWidth}
                  onPress={() => setLeagueModalVisible(true)}
                >
                  <CustomTextInput
                    editable={false}
                    pointerEvents="none"
                    textInputStyle={styles.textModelInputStyle(
                      selectedOddsText == translate("OddsType")
                    )}
                    // dropDown={true}
                    racingDropDown={true}
                    dropDownStyle={styles.dropDownArrow}
                    dropDownIconStyle={styles.dropDownContainer}
                    placeholderText={""}
                    inputTextStyle={styles.inputTextStyle}
                    placeholderTextColor={Colors.red}
                    onPressWheelPicker={() => setLeagueModalVisible(true)}
                    value={selectedOddsText}
                    activeOpacity={1}
                  />
                </Pressable>
                <View style={styles.rowView}>
                  <Pressable
                    onPress={() => {
                      setSeeAll(false);
                      scrollRef?.current?.scrollToIndex({
                        animated: true,
                        index: 0,
                      });
                    }}
                  >
                    <Text
                      style={
                        isSeeAll
                          ? styles.heighLightCurrentBest
                          : styles.currentBest
                      }
                    >
                      {translate("CurrentBest")}
                    </Text>
                  </Pressable>
                  <Text
                    style={
                      isSeeAll ? styles.seeAllHeighLightText : styles.seeAllText
                    }
                  >
                    {translate("SeeAll")}
                  </Text>
                </View>
              </View>
              <View style={styles.width} />

              <View style={styles.alignCenterView}>
                <Text style={styles.dateTimeTextStyle}>
                  {fetchDayName(individualTeamData?.startTime)}{" "}
                  {moment
                    .utc(individualTeamData?.startTime)
                    .local()
                    .format("DD/MM/YYYY")}
                  {"  "}|{"   "}
                  {moment
                    .utc(individualTeamData?.startTime)
                    .local()
                    .format("hh:mm A")}
                  {"   "}|{"   "}
                  {`${
                    individualTeamData?.marketLength
                      ? individualTeamData?.marketLength
                      : 0
                  } Markets`}
                </Text>
              </View>
              <View style={styles.sponsoredWidth} />

              {fetchSeeAllOutRightsData(individualTeamData)}
            </View>
          </CardView>
        )}
      </>
    );
  };

  const renderItem = (item: any, index: any) => {
    return (
      <>
        {!isSeeAll && isResults?.length > 0 && (
          <>
            {}
            <CardView
              style={styles.winView}
              cardElevation={5}
              cardMaxElevation={4}
            >
              <View style={styles.topView}>
                {item?.objects?.map((obj, index) => {
                  return (
                    <>
                      <View style={styles.dateItem}>
                        <Text style={styles.dateItemText}>
                          {fetchFormatedDayname(item?.date)} {item?.date}
                        </Text>
                        <View style={styles.rowView}>
                          <Text style={styles.currentBestGofl}>
                            {translate("CurrentBest")}
                          </Text>
                          <Pressable
                            onPress={() => {
                              setSeeAll(true), setSportId(item);
                              scrollRef?.current?.scrollToIndex({
                                animated: true,
                                index: 0,
                                viewPosition: 1,
                              });
                              setIsLoadMoreVisible(true);
                              getOddsApi(obj?.id);
                              getSeeAllData(item?.id, 1);
                              fetchLatestOdds(obj?.id);
                              fetchIndividualTeamdata(obj?.id);
                            }}
                          >
                            <Text style={styles.seeAllTextGolf}>
                              {translate("SeeAll")}
                            </Text>
                          </Pressable>
                        </View>
                      </View>
                      <View style={styles.width} />
                      <View style={styles.alignCenterViewGolf}>
                        <Text style={styles.golfItemTitleTextStyle}>
                          {moment.utc(obj?.startTime).local().format("hh:mm A")}
                          {"   "}|{"   "}
                          {`${
                            obj?.marketLength ? obj?.marketLength : 0
                          } Markets`}
                        </Text>
                        <View style={styles.tournamentNameContainer}>
                          <Text style={styles.tournamentTextStyle}>
                            {props?.sportId === SPORTS.CRICKET
                              ? obj?.CricketTournament?.name
                              : props?.sportId === SPORTS.RUBGY_LEAGUE ||
                                props?.sportId === SPORTS.RUBGY_UNION
                              ? obj?.RLTournament?.name
                              : props?.sportId === SPORTS.AMERICAN_FOOTBALL
                              ? obj?.AFLTournament?.name
                              : props?.sportId === SPORTS.AUSTRALIAN_RULES
                              ? obj?.ARTournament?.name
                              : props?.sportId === SPORTS.GOLF
                              ? obj?.GolfTournament?.name
                              : props?.sportId === SPORTS.TENNIS
                              ? obj?.TennisTournament?.name
                              : props?.sportId === SPORTS.BASEBALL
                              ? obj?.BaseballTournament?.name
                              : props?.sportId === SPORTS.ICE_HOCKEY
                              ? obj?.IceHockeyTournament?.name
                              : props?.sportId === SPORTS.BOXING
                              ? obj?.BoxingTournament?.name
                              : props?.sportId === SPORTS.MMA
                              ? obj?.MMATournament?.name
                              : props?.sportId === SPORTS.SOCCER
                              ? obj?.SoccerTournament?.name
                              : props?.sportId === SPORTS.BASKETBALL
                              ? obj?.NBATournament?.NBACategory === null
                                ? obj?.NBATournament?.name
                                : obj?.NBATournament?.name +
                                  " " +
                                  obj?.NBATournament?.NBACategory?.name
                              : ""}
                          </Text>
                        </View>
                      </View>
                      <Pressable
                        style={styles.golfItemExpandContainer}
                        onPress={() => setIsSelected(!isSelected)}
                      >
                        <View style={styles.alignCenterViewGolf}>
                          <Text style={styles.topFinishText}>
                            {translate("OutrightBetting")}
                          </Text>
                        </View>
                        {isSelected ? (
                          <UpWhiteArrow
                            style={styles.arrowIconGof}
                            stroke={Colors.black}
                          />
                        ) : (
                          <DownWhiteArrow
                            style={styles.arrowIconGof}
                            stroke={Colors.black}
                          />
                        )}
                      </Pressable>
                      {isSelected && <>{fetchOutrightsTable(obj)}</>}
                    </>
                  );
                })}
              </View>
            </CardView>
          </>
        )}
      </>
    );
  };

  return (
    <>
      <Tabs.FlatList
        ref={scrollRef}
        data={isResults}
        nestedScrollEnabled={false}
        showsVerticalScrollIndicator={false}
        // keyExtractor={(item) => item?.id}
        contentContainerStyle={styles.contentContainerStyle}
        renderItem={
          isSeeAll
            ? ({ item, index }) => renderSeeAllItem(item, index)
            : ({ item, index }) => renderItem(item, index)
        }
        ListHeaderComponent={props.headerComponent}
        ListFooterComponent={props.footerComponent}
        ListEmptyComponent={() => listHeader()}
        keyExtractor={(item, index) => index.toString()}
        refreshControl={
          <RefreshControl
            refreshing={props.refreshing}
            onRefresh={props.onRefresh}
          />
        }
      />
    </>
  );
}

export const oddsDataOption = [translate("WinFixed")];
