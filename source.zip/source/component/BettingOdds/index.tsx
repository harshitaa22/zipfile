import React, { useState } from "react";
import {
  Image,
  Linking,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { CommonStyle, Images, Metrics } from "../../theme/index";
import { BetFairIcon, DownOrangeArrow, UpOrangeArrow } from "../../theme/svg";
import { Constant } from "../../utils";
import styles from "./style";

export default function BettingOdds(props: any) {
  const [isExpanded, setIsExpanded] = useState(false);

  const renderOddsItem = (item, providerId) => {
    return (
      <View style={styles.iconContainerStyle}>
        {/* <View style={styles.iconContainer}> */}

        {getOddsSportIcon(providerId)}

        <View style={styles.jazzContainer}>
          <Text style={styles.bestValueTextStyle}>
            {item?.plusPrice}
            {/* {props.fetchSeeAllHomeTeamOddsvalue(item, providerId)} */}
          </Text>
          <Text style={styles.priceText}>{item?.minusPrice}</Text>
        </View>
        <View
          style={{
            backgroundColor: "red",
            paddingBottom: 10,
            paddingTop: Metrics.rfv(20),
          }}
        >
          <View style={styles.lastContainer}>
            <Text style={styles.bestValueTextStyle}>
              {item?.plusSecondPrice}
            </Text>
            <Text style={styles.priceText}>{item?.minusSecondPrice}</Text>
          </View>
        </View>
        {/* </View> */}
      </View>
    );
  };

  const getOddsSportIcon = (apiProviderId: number) => {
    if (apiProviderId === 1 || apiProviderId === 7) {
      return null;
    } else if (apiProviderId === 2) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.NEDS_URL)}>
          <Image style={styles.oddsIcon} source={Images.nedImageIcon} />
        </Pressable>
      );
    } else if (apiProviderId === 3) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.LADBROKES_URL)}>
          <Image style={styles.oddsIcon} source={Images.redIcon} />
        </Pressable>
      );
    } else if (apiProviderId === 4) {
      return (
        // <Pressable onPress={() => Linking.openURL(Constant.BET_URL)}>
        <Image style={styles.oddsIcon} source={Images.betIcon} />
        // </Pressable>
      );
    } else if (apiProviderId === 5) {
      return (
        // <Pressable onPress={() => Linking.openURL(Constant.BLUE_BET_URL)}>
        <Image style={styles.oddsIcon} source={Images.beStartIcon} />
        // </Pressable>
      );
    } else if (apiProviderId === 6) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BET_365_URL)}>
          <Image style={styles.oddsIcon} source={Images.bet365} />
        </Pressable>
      );
    } else if (apiProviderId === 8) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.UNIBET_URL)}>
          <Image style={styles.oddsIcon} source={Images.uniBetIcon} />
        </Pressable>
      );
    } else if (apiProviderId === 10) {
      //Need to change
      return (
        <Pressable
          onPress={() => Linking.openURL(Constant.BET_FAIR_URL)}
          style={styles.betFairContainer}
        >
          <BetFairIcon style={styles.betFairIcon} />
        </Pressable>
      );
    } else if (apiProviderId === 11) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.TOP_SPORT_URL)}>
          <Image style={styles.oddsIcon} source={Images.topSportOdds} />
        </Pressable>
      );
    } else if (apiProviderId === 12) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.PLAY_UP_URL)}>
          <Image style={styles.oddsIcon} source={Images.greenArrowIcon} />
        </Pressable>
      );
    } else if (apiProviderId === 13) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BLUE_BET_URL)}>
          {/* <Image style={styles.oddsIcon} source={Images.blueBet} /> */}
          <Image style={styles.oddsIconStyle} source={Images.blueBetImg} />
        </Pressable>
      );
    } else if (apiProviderId === 14) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.BOOM_BET_URL)}>
          <Image style={styles.oddsIcon} source={Images.boomBetOdds} />
        </Pressable>
      );
    } else if (apiProviderId === 15) {
      return (
        <Pressable onPress={() => Linking.openURL(Constant.SOUTHREN_BET)}>
          <Image style={styles.oddsIcon} source={Images.SouthernCrossBet} />
        </Pressable>
      );
    } else {
      return null;
    }
  };

  return (
    <View style={styles.containerStyle}>
      <Pressable
        style={styles.OddsTypeNExtList}
        onPress={() => setIsExpanded(!isExpanded)}
      >
        <Text style={styles.todayTitleTextStyle}>
          {/* {translate("NextFiveBestOdds")} */}

          <Text style={styles.boldSportText}> {props.tredName} </Text>
        </Text>
        {isExpanded ? (
          <UpOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
        ) : (
          <DownOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
        )}
      </Pressable>
      {isExpanded && (
        <View style={styles.listContainerStyle}>
          <ScrollView
            style={styles.contentContainerStyle}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            nestedScrollEnabled={true}
          >
            <View style={CommonStyle.center}>
              <View>
                <View style={styles.centerView}>
                  <Image
                    source={props?.item?.seconImage}
                    style={styles.iconImage}
                  />
                  <Text style={styles.titleText}>{props?.item?.Jazz}</Text>
                </View>
                <View style={styles.secondList}>
                  <Image source={props?.item?.image} style={styles.iconImage} />
                  <Text style={styles.titleText}>{props?.item?.Spurs}</Text>
                </View>
              </View>
              {renderOddsItem(props.item, 2)}
              {renderOddsItem(props.item, 3)}
              {/* {renderOddsItem(props.item, 4)} */}
              {/* {renderOddsItem(props.item, 5)} */}
              {renderOddsItem(props.item, 6)}
              {renderOddsItem(props.item, 8)}
              {renderOddsItem(props.item, 10)}
              {renderOddsItem(props.item, 11)}
              {renderOddsItem(props.item, 12)}
              {renderOddsItem(props.item, 13)}
              {renderOddsItem(props.item, 14)}
              {renderOddsItem(props.item, 15)}
            </View>
          </ScrollView>
        </View>
      )}
    </View>
    // <View style={styles.containerStyle}>
    //   <Pressable
    //     style={styles.OddsTypeNExtList}
    //     onPress={() => setIsExpanded(!isExpanded)}
    //   >
    //     <Text style={styles.todayTitleTextStyle}>
    //       {translate("NextFiveBestOdds")}
    //     </Text>
    //     {isExpanded ? (
    //       <UpOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
    //     ) : (
    //       <DownOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
    //     )}
    //   </Pressable>
    //   {isExpanded && (
    //     <View style={styles.listContainerStyle}>
    //       <ScrollView
    //         style={styles.contentContainerStyle}
    //         horizontal={true}
    //         showsHorizontalScrollIndicator={false}
    //         nestedScrollEnabled={true}
    //       >
    //         {renderOddsItem(2)}
    //         {renderOddsItem(3)}
    //         {renderOddsItem(4)}
    //         {renderOddsItem(5)}
    //         {renderOddsItem(6)}
    //         {renderOddsItem(8)}
    //         {renderOddsItem(10)}
    //         {renderOddsItem(11)}
    //         {renderOddsItem(12)}
    //         {renderOddsItem(13)}
    //         {renderOddsItem(14)}
    //         {renderOddsItem(15)}
    //       </ScrollView>
    //     </View>
    //   )}
    // </View>
  );
}
