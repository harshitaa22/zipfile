import { Dimensions } from "react-native";
import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  todayTitleTextStyle: {
    flex: 1,
    color: Colors.orange,
    fontSize: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
  },
  OddsTypeNExtList: {
    flexDirection: "row",
    borderColor: Colors.orange,
    borderWidth: Metrics.rfv(1),
    borderRadius: Metrics.rfv(7),
    marginTop: Metrics.rfv(15),
    paddingHorizontal: Metrics.rfv(10),
    paddingVertical: Metrics.rfv(8),
    alignItems: "center",
  },
  betFairIcon: {
    height: Metrics.rfv(32),
    width: Metrics.rfv(48),
  },
  betFairContainer: {
    borderRadius: Metrics.rfv(10),
    height: Metrics.rfv(32),
    width: Metrics.rfv(48),
    marginTop: Metrics.rfv(5),
    overflow: "hidden",
  },
  containerStyle: {
    width: "100%",
  },
  listContainerStyle: {
    width: "100%",
    marginTop: Metrics.rfv(5),
  },
  iconContainerStyle: {
    width: (Dimensions.get("window").width - 30) / 5,
    marginTop: Metrics.rfv(2),
  },
  bestValueTextStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
  },
  priceText: {
    color: Colors.gray,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    fontFamily: Fonts.IN_Regular,
    marginTop: Metrics.rfv(2),
  },
  contentContainerStyle: {
    width: "100%",
  },
  oddsIconStyle: {
    height: Metrics.rfv(30),
    width: Metrics.rfv(45),
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(5),
  },
  boldSportText: {
    flex: 1,
    color: Colors.orange,
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
  },
  oddsIcon: {
    height: Metrics.rfv(30),
    width: Metrics.rfv(45),
    borderRadius: Metrics.rfv(5),
    marginTop: Metrics.rfv(5),
  },
  iconContainer: {
    width: (Dimensions.get("window").width - 30) / 5,
    marginTop: Metrics.rfv(2),
    alignItems: "center",
    justifyContent: "center",
  },
  titleText: {
    color: Colors.black,
    fontSize: Metrics.rfv(16),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(20),
    marginLeft: Metrics.rfv(10),
  },
  iconImage: {
    width: Metrics.rfv(40),
    height: Metrics.rfv(40),
  },
  jazzContainer: {
    borderWidth: Metrics.rfv(1),
    borderColor: Colors.grayColor,
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(9),
    alignItems: "center",
    marginTop: Metrics.rfv(20),
  },
  secondContainer: {
    borderWidth: Metrics.rfv(1),
    borderColor: Colors.grayColor,
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(12),
    paddingVertical: Metrics.rfv(4),
    alignItems: "center",
    marginTop: Metrics.rfv(5),
  },
  centerView: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    // marginTop: Metrics.rfv(30),
    top: Metrics.rfv(20),
  },
  secondList: {
    flexDirection: "row",
    backgroundColor: "red",
    paddingTop: 20,
    paddingBottom: Metrics.rfv(22),
  },
  lastContainer: {
    borderWidth: Metrics.rfv(1),
    borderColor: Colors.grayColor,
    borderRadius: Metrics.rfv(5),
    paddingHorizontal: Metrics.rfv(15),
    paddingVertical: Metrics.rfv(9),
    alignItems: "center",

    backgroundColor: "pink",
  },
});
