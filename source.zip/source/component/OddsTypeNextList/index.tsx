import React, { useRef, useState } from "react";
import {
  Animated,
  FlatList,
  Image,
  Linking,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import { Images, Metrics } from "../../theme/index";
import { BetFairIcon, DownOrangeArrow, UpOrangeArrow } from "../../theme/svg";
import { Constant } from "../../utils";
import { translate } from "../../utils/Localize";
import { print_data } from "../../utils/Logs";
import ImageLoad from "../ImageLoad";
import styles from "./style";

export default function OddsTypeNextList(props: any) {
  const { oddsData, oddsIconData } = props;
  const [isExpanded, setIsExpanded] = useState(false);
  const [isBestOddsExpanded, setIsBestOddsExpanded] = useState(false);
  const scrollViewRef = useRef(null);
  const [visibleScrollBarWidth, setVisibleScrollBarWidth] = useState(0);
  const scrollIndicatorSize = visibleScrollBarWidth / 2.7;
  const difference = visibleScrollBarWidth - scrollIndicatorSize;
  const scrollIndicator = useRef(new Animated.Value(0)).current;

  const scrollIndicatorPosition = scrollIndicator.interpolate({
    extrapolate: "clamp",
    inputRange: [0, visibleScrollBarWidth / 6],
    outputRange: [0, difference],
  });
  const onLayout = (event: { nativeEvent: { layout: { width: any } } }) => {
    const { width } = event.nativeEvent.layout;
    setVisibleScrollBarWidth(width);
  };
  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(props?.sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      print_data("=====Counter=====");
      print_data(response);
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const oddsIcon = (BookKeeperId: number, type: any) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;
    print_data("helo====");
    print_data(BookKeeperId);
    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsImageContainer}
      >
        {BookKeeperId === 15 ? (
          <Image
            style={styles.oddsImageIcon}
            // resizeMode={"stretch"}
            source={Images.playUpIcon}
            // source={
            //   iconData?.small_logo?.includes("uploads")
            //     ? API_URL + "/" + iconData?.small_logo
            //     : iconData?.small_logo
            // }
          />
        ) : (
          <ImageLoad
            style={styles.oddsImageIcon}
            resizeMode={"stretch"}
            source={
              iconData?.small_logo?.includes("uploads")
                ? API_URL + "/" + iconData?.small_logo
                : iconData?.small_logo
            }
          />
        )}
      </Pressable>
    );
  };

  const renderOddsItem = (providerId: number) => {
    let datas = oddsData
      ?.map((obj) => {
        if (obj?.ApiProviderId === providerId) {
          return obj?.RaceOdds?.[0]?.intValue !== 0
            ? obj?.RaceOdds?.[0]?.intValue
            : translate("SP");
        }
      })
      .filter((x) => x !== undefined);
    if (datas?.length > 0) {
      // return props?.fetchClickableOdds(datas?.[0]?.odds, datas?.[0]?.provider);
      return (
        <Pressable onPress={() => onClickOpne(providerId)}>
          <View style={styles.iconContainerStyle}>
            {/* <Text style={styles.bestValueTextStyle}>
            {getOddsTextValue(providerId)}
          </Text> */}

            <View>{getOddsTextValue(providerId)}</View>
            {/* {getOddsIcon(providerId)} */}
            {oddsIconData}
          </View>
        </Pressable>
      );
    }
  };

  const renderPageHeadingDataItem = (item, index) => {
    var type = "header";
    return (
      <View style={styles.iconContainerStyle}>
        {getOddsTextValue(item, item?.BookKeeperId)}
        {oddsIcon(item?.BookKeeperId, type)}
      </View>
    );
  };
  const onClickOpne = (providerId: any) => {
    if (providerId === 1 || providerId === 7) {
      return null;
    } else if (providerId === 2) {
      return Linking.openURL(Constant.NEDS_URL);
    } else if (providerId === 3) {
      return Linking.openURL(Constant.LADBROKES_URL);
    } else if (providerId === 4) {
      return null;
    } else if (providerId === 5) {
      return null;
    } else if (providerId === 6) {
      return Linking.openURL(Constant.BET_365_URL);
    } else if (providerId === 8) {
      return Linking.openURL(Constant.UNIBET_URL);
    } else if (providerId === 9) {
      return Linking.openURL(Constant.DRAFT_STAR_URL);
    } else if (providerId === 10) {
      return Linking.openURL(Constant.BET_FAIR_URL);
    } else if (providerId === 11) {
      return Linking.openURL(Constant.TOP_SPORT_URL);
    } else if (providerId === 12) {
      return Linking.openURL(Constant.PLAY_UP_URL);
    } else if (providerId === 13) {
      return Linking.openURL(Constant.BLUE_BET_URL);
    } else if (providerId === 14) {
      return Linking.openURL(Constant.BOOM_BET_URL);
    } else if (providerId === 15) {
      return Linking.openURL(Constant.SOUTHREN_BET);
    } else if (providerId === 18) {
      return Linking.openURL(Constant.PUT_ON_DOGS);
    } else if (providerId === 19) {
      return Linking.openURL(Constant.BT_RIGHT_URL);
    } else if (providerId === 20) {
      return Linking.openURL(Constant.ELITE_BET_URL);
    } else if (providerId === 21) {
      return null;
    } else {
      return null;
    }
  };

  // const fetchTop5Odds = (data) => {
  //   let filledOdds = data
  //     ?.filter((item) => {
  //       return item?.RaceOdds?.length > 0;
  //     })
  //     .sort((a, b) => b?.RaceOdds?.[0]?.intValue - a?.RaceOdds?.[0]?.intValue);
  //   let BlankOdds = data?.filter((item) => {
  //     return item?.RaceOdds?.length == 0;
  //   });
  //   let oddsSort =
  //     filledOdds || BlankOdds ? [...filledOdds, ...BlankOdds].slice(0, 3) : [];
  //   let finalOdds = oddsSort?.length > 0 ? oddsSort : [];
  //   let Top5Odds =
  //     finalOdds?.length > 0 ? (
  //       finalOdds?.map((obj, index) => {
  //         return (
  //           <View style={styles.iconContainerStyle} key={index}>
  //             {obj?.RaceOdds?.[0]?.intValue ? (
  //               <>
  //                 <Text>
  //                   {obj?.RaceOdds?.[0]?.intValue !== 0
  //                     ? obj?.RaceOdds?.[0]?.intValue
  //                     : "SP"}
  //                 </Text>
  //                 {getOddsIcon(obj?.ApiProviderId)}
  //               </>
  //             ) : (
  //               <View style={styles.noaContainer}>
  //                 <Text style={styles.noaText}>{translate("NoaText")}</Text>
  //               </View>
  //             )}
  //           </View>
  //         );
  //       })
  //     ) : (
  //       <View style={styles.noaContainer}>
  //         <Text style={styles.noaText}>{translate("NoaText")}</Text>
  //       </View>
  //     );

  //   return Top5Odds;
  // };

  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.topView}
      >
        <Text style={styles.bestValueTextStyle}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };

  const getOddsTextValue = (item: any, providerId: any) => {
    let datas = props?.oddsData
      ?.map((obj) => {
        if (obj?.BookKeeperId === providerId) {
          return {
            odds:
              obj?.RaceOdds?.[0]?.intValue !== 0
                ? obj?.RaceOdds?.[0]?.intValue
                : "SP",
            provider: obj?.BookKeeperId,
          };
        }
      })
      .filter((x) => x !== undefined);
    if (datas?.length > 0) {
      return fetchClickableOdds(
        datas?.[0]?.odds,
        datas?.[0]?.provider,
        "header"
      );
    } else {
      // return "-";
      return (
        <View style={styles.noaContainer}>
          <Text style={styles.noaText}>{translate("NoaText")}</Text>
        </View>
      );
    }
  };

  const getOddsIcon = (apiProviderId: number) => {
    if (apiProviderId === 1 || apiProviderId === 7) {
      return null;
    } else if (apiProviderId === 2) {
      return (
        <Image style={styles.oddsIconStyle} source={Images.nedImageIcon} />
      );
    } else if (apiProviderId === 3) {
      return <Image style={styles.oddsIconStyle} source={Images.redIcon} />;
    } else if (apiProviderId === 4) {
      return <Image style={styles.oddsIconStyle} source={Images.betIcon} />;
    } else if (apiProviderId === 5) {
      return <Image style={styles.oddsIconStyle} source={Images.beStartIcon} />;
    } else if (apiProviderId === 6) {
      return (
        <Image style={styles.bet365IconStyle} source={Images.bet365Odds} />
      );
    } else if (apiProviderId === 8) {
      return <Image style={styles.oddsIconStyle} source={Images.uniBetIcon} />;
    } else if (apiProviderId === 9) {
      //Need to change
      return <View style={styles.oddsIconStyle} />;
    } else if (apiProviderId === 10) {
      //Need to change
      return (
        <View style={styles.betFairContainer}>
          <BetFairIcon style={styles.betFairIcon} />
        </View>
      );
    } else if (apiProviderId === 11) {
      return (
        <Image style={styles.oddsIconStyle} source={Images.topSportOdds} />
      );
    } else if (apiProviderId === 12) {
      return (
        <Image style={styles.oddsIconStyle} source={Images.greenArrowIcon} />
      );
    } else if (apiProviderId === 13) {
      return <Image style={styles.oddsIconStyle} source={Images.blueBetImg} />;
    } else if (apiProviderId === 14) {
      return <Image style={styles.oddsIconStyle} source={Images.boomBetOdds} />;
    } else if (apiProviderId === 15) {
      return (
        <Image
          style={styles.oddsIconStyle}
          source={Images.southerncrossBetOdds}
        />
      );
    } else if (apiProviderId === 18) {
      return (
        <Image style={styles.oddsIconStyle} source={Images.putOnDogsLogo} />
      );
    } else if (apiProviderId === 19) {
      return <Image style={styles.betRightIcon} source={Images.betRightOdds} />;
    } else if (apiProviderId === 20) {
      return (
        <Image style={styles.oddsIconStyle} source={Images.eliteBetOdds} />
      );
    } else if (apiProviderId === 21) {
      return (
        // <Pressable onPress={() => Linking.openURL(Constant.PUT_ON_DOGS)}>
        <Image style={styles.oddsIconStyle} source={Images.gsbOdds} />
        // </Pressable>
      );
    } else {
      return null;
    }
  };

  return (
    <View style={styles.containerStyle}>
      {props?.seeAllOdds && (
        <>
          <Pressable
            style={styles.OddsTypeNExtList}
            onPress={() => setIsExpanded(!isExpanded)}
          >
            <Text style={styles.todayTitleTextStyle}>
              {translate("SeeAllRunner")}
            </Text>
            {isExpanded ? (
              <UpOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
            ) : (
              <DownOrangeArrow
                width={Metrics.rfv(15)}
                height={Metrics.rfv(15)}
              />
            )}
          </Pressable>
          {isExpanded && (
            <View style={styles.listContainerStyle}>
              <ScrollView
                ref={scrollViewRef}
                style={styles.contentContainerStyle}
                horizontal={true}
                showsHorizontalScrollIndicator={false}
                nestedScrollEnabled={true}
                onLayout={onLayout}
                onScroll={Animated.event(
                  [{ nativeEvent: { contentOffset: { x: scrollIndicator } } }],
                  { useNativeDriver: false }
                )}
                scrollEventThrottle={16}
                scrollEnabled={true}
              >
                <FlatList
                  data={props?.pageHeadingData}
                  scrollEnabled={false}
                  horizontal
                  showsVerticalScrollIndicator={false}
                  contentContainerStyle={styles.contentContainerStyle}
                  renderItem={({ item, index }) =>
                    renderPageHeadingDataItem(item, index)
                  }
                  keyExtractor={(item, index) => index.toString()}
                />
              </ScrollView>
              {props?.pageHeadingData?.length > 5 && (
                <View style={styles.itemSeparatorComponent}>
                  <Animated.View
                    style={[
                      styles.indicatorstyle,
                      {
                        width: scrollIndicatorSize,
                        transform: [{ translateX: scrollIndicatorPosition }],
                      },
                    ]}
                  ></Animated.View>
                </View>
              )}
            </View>
          )}
        </>
      )}
      {/* ) : ( */}
      <>
        {/* <Pressable
            style={styles.OddsTypeNExtList}
            onPress={() => setIsBestOddsExpanded(!isBestOddsExpanded)}
          >
            <Text style={styles.todayTitleTextStyle}>
              {translate("NextFiveBestOdds")}
            </Text>
            {isBestOddsExpanded ? (
              <UpOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
            ) : (
              <DownOrangeArrow
                width={Metrics.rfv(15)}
                height={Metrics.rfv(15)}
              />
            )}
          </Pressable> */}
        {/* {isBestOddsExpanded && (
            <View style={styles.oddsContainer}>{fetchTop5Odds(oddsData)}</View>
          )} */}
      </>
      {/* )} */}
    </View>
  );
}

// {renderOddsItem(2)}
// {renderOddsItem(3)}
// {/* {renderOddsItem(4)} */}
// {/* {renderOddsItem(5)} */}
// {renderOddsItem(6)}
// {renderOddsItem(8)}
// {renderOddsItem(10)}
// {renderOddsItem(11)}
// {renderOddsItem(12)}
// {renderOddsItem(13)}
// {renderOddsItem(14)}
// {renderOddsItem(15)}
// {renderOddsItem(18)}
// {renderOddsItem(19)}
// {renderOddsItem(20)}
// {renderOddsItem(21)}
