import React from "react";
import { Text, View } from "react-native";
import { useSelector } from "react-redux";
import { CommonStyle, Metrics } from "../../theme/index";
import { translate } from "../../utils/Localize";
import Button from "../Button/index";
import styles from "./style";
import Images from "../../theme/images";
import AddsCommonList from "../AddsCommonApi";
import { Image } from "react-native-svg";
import { CommonAppIcon } from "../../theme/svg";

export default function Header(props: any) {
  let userToken = useSelector(
    (state: any) => state.UserDataReducer.is_token_saved
  );
  let saveToken = JSON.parse(userToken);
  return (
    <View>
      <AddsCommonList
        topLongBanner={"topLongBanner"}
        page={10}
        placeholder={Images.topBannerImg}
        bannerStyle={styles.secondBannerStyle}
      />
      <View style={styles.horizontalView}>
        {saveToken ? null : (
          <View style={styles.commonRow}>
            <View style={CommonStyle.commonFlex}>
              <Button
                marginTop={Metrics.rfv(0)}
                disabled={false}
                height={Metrics.rfv(40)}
                onPress={props.onPressSignUp}
                title={translate("SignUp")}
                color={props.colorUp}
                fontSize={Metrics.rfv(12)}
                backgroundColor={props.isBackgroundSignUp}
              />
            </View>
            <View style={styles.gapViewStyle} />
            <View style={CommonStyle.commonFlex}>
              <Button
                height={Metrics.rfv(40)}
                marginTop={Metrics.rfv(0)}
                disabled={false}
                onPress={props.onPressSignIn}
                title={translate("LogIn")}
                color={props.colorIn}
                fontSize={Metrics.rfv(12)}
                backgroundColor={props.isBackgroundSignIn}
              />
            </View>
          </View>
        )}
      </View>
      <AddsCommonList
        headerTopImage={"headerTopImage"}
        page={11}
        placeholder={Images.adBannerIcon}
        bannerStyle={styles.smartbIcon}
      />
      {props?.isshowSmartBitle && (
        <View style={styles.headerLogoConatiner}>
          <View style={CommonStyle.commonFlex}>
            <CommonAppIcon style={styles.iconStyle} />
          </View>
          <Text style={styles.headerTitle}>
            {translate("SmartBGetLatestTitle")}
          </Text>
        </View>
      )}
    </View>
  );
}
