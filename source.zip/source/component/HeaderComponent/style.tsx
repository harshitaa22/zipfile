import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  mainHomePageView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  signUpButton: {
    width: Metrics.rfv(168),
  },
  loginButton: {
    width: "100%",
    flex: 1,
  },
  headerStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Metrics.rfv(8),
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
  },
  searchIcon: {
    width: Metrics.rfv(20),
    height: Metrics.rfv(20),
  },
  backIconStyle: {
    width: Metrics.rfv(18),
    height: Metrics.rfv(18),
  },
  iconStyle: {
    width: Metrics.rfv(70),
    height: Metrics.rfv(27),
  },
  gapViewStyle: {
    width: Metrics.rfv(10),
  },
  smartbIcon: {
    width: "100%",
    height: Metrics.rfv(80),
  },
  commonRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Metrics.rfv(10),
  },
  iconContainerStyle: {
    flex: 1,
  },
  backContainerStyle: {
    paddingVertical: Metrics.rfv(10),
    paddingRight: Metrics.rfv(15),
  },
  secondBannerStyle: {
    marginBottom: Metrics.rfv(10),
    width: "100%",
    height: Metrics.rfv(150),
    resizeMode: "contain",
  },
  signupButton: {
    flex: 1,
  },
  headerTitle: {
    color: Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
    textTransform: "uppercase",
    marginTop: Metrics.rfv(5),
  },
  homeText: {
    color: Colors.linearColor2,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(14),
    textTransform: "uppercase",
    marginTop: Metrics.rfv(14),
  },
  headerLogoConatiner: {
    marginTop: Metrics.rfv(10),
    marginHorizontal: Metrics.rfv(15),
  },
});
