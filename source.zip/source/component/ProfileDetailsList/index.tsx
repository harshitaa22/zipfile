import { useNavigation } from "@react-navigation/native";
import React from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import { NAVIGATION } from "../../navigation";

import styles from "./style";

export default function ProfileDetailist(props: any) {
  const navigation = useNavigation();

  const renderItem = (item, index) => {
    return (
      <Pressable
        onPress={() =>
          navigation.navigate(
            index == 0 ? NAVIGATION.TRACK_NEWS : NAVIGATION.TRAINER_TAB
          )
        }
      >
        <View style={styles.commonRow}>
          <Text style={styles.detailsText}>{item?.name}</Text>
        </View>
      </Pressable>
    );
  };

  return (
    <FlatList
      data={props.data}
      scrollEnabled={false}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index) => index.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    />
  );
}
