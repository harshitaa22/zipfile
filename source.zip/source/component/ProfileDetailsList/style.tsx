import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  commonRow: {
    marginTop: Metrics.rfv(10),
  },
  detailsText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
});
