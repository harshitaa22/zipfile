import { View, Text } from "react-native";
import React from "react";
import styles from "./style";
import {
  BlueInfo,
  GreenInfo,
  InterimInfo,
  MinsInfo,
  PayingInfo,
} from "../../theme/svg";
import { Metrics } from "../../theme";
import { translate } from "../../utils/Localize";

export const FixedOffred = () => {
  return (
    <View>
      <View style={styles.containerView}>
        <View style={styles.containerView}>
          <BlueInfo width={Metrics.rfv(9)} height={Metrics.rfv(9)} />
          <Text style={styles.symbolStyle}>{translate("SymbolOne")}</Text>
        </View>
        <View style={styles.containerView}>
          <GreenInfo width={Metrics.rfv(9)} height={Metrics.rfv(9)} />
          <Text style={styles.symbolStyle}>{translate("SymbolTwo")}</Text>
        </View>
        <View style={styles.containerView}>
          <InterimInfo width={Metrics.rfv(9)} height={Metrics.rfv(9)} />
          <Text style={styles.symbolStyle}>{translate("SymbolThree")}</Text>
        </View>
      </View>

      <View style={styles.information}>
        <View style={styles.containerView}>
          <MinsInfo width={Metrics.rfv(9)} height={Metrics.rfv(9)} />
          <Text style={styles.symbolStyle}>{translate("SymbolFour")}</Text>
        </View>
        <View style={styles.containerView}>
          <PayingInfo width={Metrics.rfv(9)} height={Metrics.rfv(9)} />
          <Text style={styles.symbolStyle}>{translate("SymbolFive")}</Text>
        </View>
      </View>
    </View>
  );
};
