import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  containerView: {
    flexDirection: "row",
    alignItems: "center",
  },
  symbolStyle: {
    color: Colors.black,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(14),
    marginLeft: Metrics.rfv(10),
    marginRight: Metrics.rfv(15),
  },
  information: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
    justifyContent: "flex-start",
  },
});
