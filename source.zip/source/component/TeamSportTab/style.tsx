import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  tabViewStyle: {
    width: Metrics.rfp(180),
    height: Metrics.rfv(2),
    marginTop: Metrics.rfv(45),
    backgroundColor: Colors.grayColor,
  },
  indicatorStyle: {
    backgroundColor: Colors.linearColor1,
    width: Metrics.rfv(180),
    height: Metrics.rfv(4),
  },
  tabBarMainStyle: {
    backgroundColor: Colors.white,
    shadowOffset: { height: Metrics.rfv(0), width: Metrics.rfv(0) },
    shadowColor: "transparent",
    shadowOpacity: Metrics.rfv(0),
    elevation: Metrics.rfv(0),
    // marginBottom: Metrics.rfv(8),
  },
  contentContainerStyle: {
    // justifyContent: "center",

    justifyContent: "space-around",
  },
  renderTabStyle: {
    elevation: Metrics.rfv(0),
    width: Metrics.rfv(180),
  },
  labelStyle: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    color: Colors.black,
    textTransform: "capitalize",
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(22),
    lineHeight: Metrics.rfv(26),
  },
  safeAreaViewStyle: {
    color: Colors.white,
    backgroundColor: Colors.white,
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(15),
    marginTop: Metrics.rfv(18),
  },
  betsContainerView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
  },
  button: {
    width: Metrics.rfv(160),
    alignItems: "center",
    height: Metrics.rfv(45),
    justifyContent: "center",
  },
  betsText: (tabVisible: any) => ({
    fontSize: Metrics.rfv(16),
    color: tabVisible ? Colors.linearColor2 : Colors.black,
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    lineHeight: Metrics.rfv(20),
  }),
  viewstyle: {
    backgroundColor: Colors.linearColor1,
    alignSelf: "flex-end",
    marginHorizontal: Metrics.rfv(15),
    width: Metrics.rfv(170),
    height: Metrics.rfv(4),
  },
  activeStyle: (tabVisible: any) => ({
    backgroundColor: Colors.linearColor1,
    alignSelf: tabVisible ? "flex-end" : "flex-start",
    marginHorizontal: Metrics.rfv(15),
    width: Metrics.rfv(170),
    height: Metrics.rfv(4),
  }),
  widthStyle: {
    borderWidth: Metrics.rfv(1),
    backgroundColor: Colors.grayColor,
    borderColor: Colors.grayColor,
    width: "100%",
    height: Metrics.rfv(1),
  },
});
