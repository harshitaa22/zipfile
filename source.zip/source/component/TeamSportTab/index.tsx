import React, { useState } from "react";
import BetsTab from "../../screens/Dashboard/TabStack/TabScreen/Sports/SportsMatchups/SportTeam/BetsTab";
import MoneyTab from "../../screens/Dashboard/TabStack/TabScreen/Sports/SportsMatchups/SportTeam/MoneyTab";
import styles from "./style";
import { Pressable, ScrollView, Text, View } from "react-native";
import commonStyles from "../../theme/commonStyle";
import { translate } from "../../utils/Localize";
import { print_data } from "../../utils/Logs";

const TeamSportTab = (props: any) => {
  const [tabVisible, setTabVisible] = useState(false);

  return (
    <ScrollView
      contentContainerStyle={commonStyles.scrollViewStyle}
      overScrollMode={"never"}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      nestedScrollEnabled={true}
    >
      <View style={styles.betsContainerView}>
        <Pressable style={styles.button} onPress={() => setTabVisible(false)}>
          <Text style={styles.betsText(!tabVisible)}>{translate("Bets")}</Text>
        </Pressable>
        <Pressable style={styles.button} onPress={() => setTabVisible(true)}>
          <Text style={styles.betsText(tabVisible)}>{translate("Money")}</Text>
        </Pressable>
      </View>

      <View style={styles.activeStyle(tabVisible)} />
      <View style={styles.widthStyle} />
      {tabVisible ? (
        <MoneyTab
          sportData={props?.sportData}
          sportMoneyDetails={props?.sportDetailsList}
          visible={props.visible}
        />
      ) : (
        <BetsTab
          sportData={props?.sportData}
          sportBetsDetails={props?.sportDetailsList}
          visible={props.visible}
        />
      )}
    </ScrollView>
  );
};

export default TeamSportTab;
