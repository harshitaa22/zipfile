import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme";

export default StyleSheet.create({
  dropDownContainerStyle: {
    // backgroundColor: Colors.lightblue,
    width: "100%",
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    top: Metrics.rfv(-7),
    textAlign: "center",
    position: "relative", // It was absolute
  },
  contryContainer: {
    zIndex: Metrics.rfv(2000),
  },
  dropDownStyleRed: {
    width: "100%",
    // backgroundColor: Colors.lightblue,
  },
  dropDownStyleWhite: {
    height: Metrics.rfv(44),
    borderColor: Colors.gray,
    borderWidth: Metrics.rfv(0.6),
    borderRadius: Metrics.rfv(7),
    marginTop: Metrics.rfv(5),
    // backgroundColor: Colors.lightblue,
    width: "100%",
    marginBottom: Metrics.rfv(5),
    padding: 0,
  },
  labelSelectStyle: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    color: Colors.linearColor2,
  },
  dropDownArrow: {
    width: Metrics.rfv(14),
    height: Metrics.rfv(8),
    resizeMode: "contain",
    marginLeft: Metrics.rfv(8),
  },
  selectedItemContainerStyle: {
    backgroundColor: Colors.gray,
    color: Colors.black,
  },
  dropDownPlaceholder: {
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.VENEER_CLEAN_SOFT,
    color: Colors.linearColor2,
  },
});
