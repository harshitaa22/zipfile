import React from "react";
import DropDownPicker from "react-native-dropdown-picker";
import { DownBlueArrow, UpBlueArrow } from "../../theme/svg";
import styles from "./style";

const DropDownPickerComponent = (props) => {
  return (
    <DropDownPicker
      zIndex={props?.zIndex}
      textStyle={styles.labelSelectStyle}
      open={props?.open}
      value={props?.value}
      labelExtractor={({ label }) => label}
      valueExtractor={({ selectedTitle }) => selectedTitle}
      items={props?.items}
      scrollViewProps={props?.scrollViewProps}
      setOpen={props?.setOpen}
      listMode="SCROLLVIEW"
      containerStyle={props.containerStyle}
      dropDownContainerStyle={styles.dropDownContainerStyle}
      setValue={props?.setValue}
      onChangeValue={props?.onChangeValue}
      setItems={props?.setItems}
      dropDownDirection="BOTTOM"
      autoScroll={true}
      style={props?.style}
      placeholder={props?.placeHolder}
      ArrowUpIconComponent={({}) => (
        <UpBlueArrow style={styles.dropDownArrow} />
      )}
      ArrowDownIconComponent={({}) => (
        <DownBlueArrow style={styles.dropDownArrow} />
      )}
      selectedItemContainerStyle={styles.selectedItemContainerStyle}
      placeholderStyle={styles.dropDownPlaceholder}
      selectedItemLabelStyle={styles.selectedItemStyle}
    />
  );
};

export default DropDownPickerComponent;
