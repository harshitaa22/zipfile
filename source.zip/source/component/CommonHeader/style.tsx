import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  svgIconStyle: {
    alignItems: "center",
    marginTop: Metrics.rfv(25),
    width: Metrics.rfv(71),
    height: Metrics.rfv(22),
    resizeMode: "contain",
  },
  signInText: {
    marginTop: Metrics.rfv(30),
    alignItems: "center",
  },
  height: {
    height: Metrics.rfv(60),
  },
  bottomHeight: {
    height: Metrics.rfv(25),
  },
  signInTextStyle: {
    color: Colors.white,
    fontSize: Metrics.rfv(22),
    fontFamily: Fonts.IN_SemiBold,
    lineHeight: Metrics.rfv(24),
  },
  aleredyAccountContainer: {
    flexDirection: "row",
    marginTop: Metrics.rfv(5),
  },
  signUpTextStyle: {
    color: Colors.white,
    marginLeft: Metrics.rfv(8),
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(16),
    fontFamily: Fonts.IN_Bold,
    textDecorationLine: "underline",
    textDecorationColor: Colors.white,
  },
  notHaveAccountTextStyle: {
    color: Colors.lightGrayBoxGray,
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
    lineHeight: Metrics.rfv(16),
  },
  horizontalContainerView: {
    marginHorizontal: Metrics.rfv(20),
    alignItems: "center",
  },
  step1Style: {
    color: Colors.stepColor,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(18),
    marginTop: Metrics.rfv(25),
  },
  horizontalView: {
    marginHorizontal: Metrics.rfv(20),
  },
  signUpInfo: {
    color: Colors.white,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    marginTop: Metrics.rfv(10),
  },
});
