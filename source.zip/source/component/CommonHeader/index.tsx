import { View, Text, Pressable, Image } from "react-native";
import React from "react";
import { SmartBAppSmallIcon } from "../../theme/svg";
import styles from "./style";
import { useNavigation } from "@react-navigation/native";
import { NAVIGATION } from "../../navigation";
import { translate } from "../../utils/Localize";

import { Images } from "../../theme";

const CommonHeader = (props: any) => {
  const navigation = useNavigation();
  return (
    <View>
      <View style={styles.horizontalContainerView}>
        {/* <SmartBAppSmallIcon
          style={props.iconStyle ? props.iconStyle : styles.svgIconStyle}
        /> */}
        <Image
          source={Images.registerLogo}
          style={props.iconStyle ? props.iconStyle : styles.svgIconStyle}
        />
        <View style={styles.signInText}>
          <Text style={styles.signInTextStyle}>{translate("SignUp")}</Text>
          <View style={styles.aleredyAccountContainer}>
            <Text style={styles.notHaveAccountTextStyle}>
              {translate("AlreadyHaveAnAccount")}
            </Text>
            <Pressable onPress={() => navigation.navigate(NAVIGATION.LOGIN)}>
              <Text style={styles.signUpTextStyle}>{translate("SignIn")}</Text>
            </Pressable>
          </View>
        </View>
      </View>
      <View style={styles.horizontalView}>
        <Text style={styles.step1Style}>{props.title}</Text>
        <Text style={styles.signUpInfo}>{props.subTitle}</Text>
        <View style={styles.bottomHeight} />
      </View>
    </View>
  );
};

export default CommonHeader;
