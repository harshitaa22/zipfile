import { View, Text, ActivityIndicator, Modal } from "react-native";
import React from "react";
import { Colors } from "../../theme";

const Loader = (props: any) => {
  return (
    <View style={props.style}>
      <ActivityIndicator
        size={props.size ? props.size : "large"}
        color={props.color ? props.color : Colors.black}
      />
    </View>
  );
};

export default Loader;
