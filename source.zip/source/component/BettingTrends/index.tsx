import React from "react";

import styles from "./style";
import { FlatList, Image, Text, View } from "react-native";
import { BetingList } from "../../theme/dummyArray";
import { translate } from "../../utils/Localize";
import BettingOdds from "../BettingOdds";

const BettingTrend = () => {
  const renderItem = (item, index) => {
    return (
      <View style={styles.containerView} key={index}>
        <Text style={styles.titleText}>{item?.title}</Text>
        <View style={styles.bottomWidth} />
        <Text style={styles.metchUpText}>{item?.metchupText}</Text>
        <Text style={styles.spursText}>{item?.spursText}</Text>
        <View style={styles.bottomlightGrayWidth} />

        <Text style={styles.spursText}>{item?.total}</Text>
        <Text style={styles.betTypeText}>{item?.betType}</Text>
        <View style={styles.bottomGrayWidth} />

        <View style={styles.leftCenterText}>
          <View style={styles.centerView}>
            <Image
              style={styles.imageCommonLeftStyle}
              source={item?.seconImage}
            />
            <Text style={styles.jazzText}>{item?.Jazz}</Text>
          </View>
          <View>
            <Text style={styles.vsText}>{translate("Vs")}</Text>
          </View>
          <View style={styles.centerView}>
            <Image style={styles.imageCommonLeftStyle} source={item?.image} />
            <Text style={styles.jazzText}>{item?.Spurs}</Text>
          </View>
        </View>
        <BettingOdds
          //   fetchSeeAllHomeTeamOddsvalue={fetchSeeAllHomeTeamOddsvalue}
          tredName={item?.OuTrend}
          item={item}
        />
      </View>
    );
  };
  return (
    <View>
      <FlatList
        data={BetingList}
        scrollEnabled={true}
        contentContainerStyle={styles.containerStyle}
        renderItem={({ item, index }) => renderItem(item, index)}
        keyExtractor={(item, index) => index.toString()}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

export default BettingTrend;
