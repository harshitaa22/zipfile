import { View } from "react-native";
import React, { useState } from "react";
import FastImage from "react-native-fast-image";
import { Images } from "../../theme";
import { SvgCssUri } from "react-native-svg";

const ImageLoad = (props: any) => {
  const [loaded, setLoaded] = useState(false);
  const [isError, setIsError] = useState(false);

  const onLoadEnd = () => {
    setLoaded(true);
  };
  const onLoadError = () => {
    setIsError(true);
  };
  return (
    <View style={props.style}>
      {props.source != null && props.source.length != 0 ? (
        <>
          {props?.source?.substr(props?.source?.length - 3) == "svg" ? (
            <>
              <SvgCssUri
                width={props.style.width}
                height={props.style.height}
                uri={props.source}
              />
            </>
          ) : !loaded && isError ? (
            <FastImage
              source={Images.noImage}
              style={props.style}
              resizeMode={props.resizeMode}
            />
          ) : (
            <>
              <FastImage
                source={{
                  uri: props.source,
                }}
                style={props.style}
                onLoad={onLoadEnd.bind()}
                onError={onLoadError.bind()}
                resizeMode={props.resizeMode}
              />
            </>
          )}
        </>
      ) : (
        <FastImage
          // source={Images.SouthernCrossBet}
          source={Images.noImage}
          style={props.style}
          resizeMode={props.resizeMode}
        />
      )}
    </View>
  );
};

export default ImageLoad;
