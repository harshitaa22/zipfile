// import { View, Text, Pressable, Platform } from "react-native";
// import React from "react";
// import styles from "../../screens/Dashboard/TopStack/MatchesSports/style";
// import { Colors, CommonStyle, Metrics } from "../../theme";
// import { translate } from "../../utils/Localize";
// import { BlackDropDownArrow, LeftUpArrow, RightUpArrow } from "../../theme/svg";
// import moment from "moment";

// const SportHeaderComponent = (props: any) => {
//   return (
//     <>
//       <View style={styles.horizontalView}>
//         <Pressable
//           onPress={props?.ontournamentPress}
//           style={styles.commonContainerView}
//         >
//           <Text style={styles.textInputStyle} numberOfLines={1}>
//             {props?.tournamentsValue}
//           </Text>

//           <BlackDropDownArrow style={styles.dropdownIcon} />
//         </Pressable>
//         <View style={styles.containerView}>
//           <Pressable
//             // style={CommonStyle.commonFlex}
//             style={styles.commonContainerView}
//             onPress={props?.onRoundPress}
//           >
//             <Text style={styles.textInputStyle} numberOfLines={1}>
//               {props.selectedDateValue
//                 ? moment(props.selectedDateValue).format("DD/MM/YYYY")
//                 : translate("RoundThree")}
//             </Text>
//             <BlackDropDownArrow style={styles.dropdownIcon} />
//             {/* <CustomTextInput
//               editable={false}
//               textInputStyle={styles.dateTextInputStyle}
//               backgroundColor={Colors.white}
//               placeholderText={translate("RoundThree")}
//               width={Metrics.rfp(45)}
//               borderColor={Colors.validationBorder}
//               inputTextStyle={styles.inputTextStyle}
//               dropDown={true}
//               dropDownIconStyle={styles.dropDownStyle}
//               onChangeText={(text: string) => {
//                 props.selectedDate(text);
//               }}
//               placeholderTextColor={Colors.black}
//               onPressWheelPicker={props?.showModel}
//               value={props.selectedDateValue}
//               returnKeyType="next"
//               placeholder={translate("DatePickerPlaceHolder")}
//               activeOpacity={1}
//             /> */}
//           </Pressable>
//           <View style={styles.commonWidth} />
//           <Pressable
//             onPress={props?.onTeamPress}
//             style={styles.commonContainerView}
//           >
//             <Text style={styles.textInputStyle} numberOfLines={1}>
//               {props?.teamValue}
//             </Text>

//             <BlackDropDownArrow style={styles.dropdownIcon} />
//           </Pressable>
//         </View>
//         {(props?.sportDataTitle === "Cricket" ||
//           props?.homeData === "Cricket" ||
//           props?.homeData == "Basketball" ||
//           props?.sportDataTitle === "Basketball") && (
//           <View style={styles.bottom} />
//         )}

//         {!(
//           props?.sportDataTitle === "Cricket" ||
//           props?.homeData === "Cricket" ||
//           props?.homeData == "Basketball" ||
//           props?.sportDataTitle === "Basketball"
//         ) && (
//           <>
//             <View style={styles.renderStyle}>
//               <Pressable
//                 onPress={() => props?.handleStepper("left")}
//                 style={CommonStyle.commonRow}
//               >
//                 <View style={styles.leftUpArrow}>
//                   <LeftUpArrow
//                     width={Metrics.rfv(9)}
//                     height={Metrics.rfv(15)}
//                   />
//                 </View>

//                 <View style={styles.rightVertical}></View>
//               </Pressable>
//               <Text style={styles.routeName}>
//                 {props?.stepperCount === 0
//                   ? translate("RoundOne")
//                   : translate("RoundOne") + " " + `${props?.stepperCount}`}
//               </Text>
//               <Pressable
//                 style={CommonStyle.commonRow}
//                 onPress={() => props?.handleStepper("right")}
//               >
//                 <View style={styles.leftVertical}></View>
//                 <View style={styles.leftUpArrow}>
//                   <RightUpArrow
//                     width={Metrics.rfv(9)}
//                     height={Metrics.rfv(15)}
//                   />
//                 </View>
//               </Pressable>
//             </View>
//           </>
//         )}
//       </View>
//     </>
//   );
// };

// export default SportHeaderComponent;

import { View, Text, Pressable, Platform } from "react-native";
import React from "react";
import styles from "../../screens/Dashboard/TopStack/MatchesSports/style";
import { Colors, CommonStyle, Metrics } from "../../theme";
import { translate } from "../../utils/Localize";
import { BlackDropDownArrow, LeftUpArrow, RightUpArrow } from "../../theme/svg";
import moment from "moment";
import { SPORTS } from "../../utils/constant";

const SportHeaderComponent = (props: any) => {
  return (
    <>
      <View style={styles.horizontalView}>
        <Pressable
          onPress={props?.ontournamentPress}
          style={styles.commonContainerView}
        >
          <Text style={styles.textInputStyle} numberOfLines={1}>
            {props?.tournamentsValue}
          </Text>
          <BlackDropDownArrow style={styles.dropdownIcon} />
        </Pressable>
        <View style={styles.containerView}>
          <Pressable
            // style={CommonStyle.commonFlex}
            style={styles.commonContainerView}
            onPress={props?.onRoundPress}
          >
            <Text style={styles.textInputStyle} numberOfLines={1}>
              {props.selectedDateValue
                ? moment(props.selectedDateValue).format("DD/MM/YYYY")
                : translate("RoundThree")}
            </Text>
            <BlackDropDownArrow style={styles.dropdownIcon} />
            {/* <CustomTextInput
              editable={false}
              textInputStyle={styles.dateTextInputStyle}
              backgroundColor={Colors.white}
              placeholderText={translate("RoundThree")}
              width={Metrics.rfp(45)}
              borderColor={Colors.validationBorder}
              inputTextStyle={styles.inputTextStyle}
              dropDown={true}
              dropDownIconStyle={styles.dropDownStyle}
              onChangeText={(text: string) => {
                props.selectedDate(text);
              }}
              placeholderTextColor={Colors.black}
              onPressWheelPicker={props?.showModel}
              value={props.selectedDateValue}
              returnKeyType="next"
              placeholder={translate("DatePickerPlaceHolder")}
              activeOpacity={1}
            /> */}
          </Pressable>
          <View style={styles.commonWidth} />
          <Pressable
            onPress={props?.onTeamPress}
            style={styles.commonContainerView}
          >
            <Text style={styles.textInputStyle} numberOfLines={1}>
              {props?.teamValue}
            </Text>

            <BlackDropDownArrow style={styles.dropdownIcon} />
          </Pressable>
        </View>
        {(props?.sportDataTitle === SPORTS.CRICKET ||
          props?.homeData === SPORTS.CRICKET ||
          props?.homeData === SPORTS.BASKETBALL ||
          props?.sportDataTitle === SPORTS.BASKETBALL ||
          props?.homeData === SPORTS.AMERICAN_FOOTBALL ||
          props?.sportDataTitle === SPORTS.AMERICAN_FOOTBALL ||
          props?.homeData === SPORTS.AUSTRALIAN_RULES ||
          props?.sportDataTitle === SPORTS.AUSTRALIAN_RULES ||
          props?.homeData === SPORTS.BASEBALL ||
          props?.sportDataTitle === SPORTS.BASEBALL ||
          props?.homeData === SPORTS.ICE_HOCKEY ||
          props?.sportDataTitle === SPORTS.ICE_HOCKEY ||
          props?.homeData === SPORTS.TENNIS ||
          props?.sportDataTitle === SPORTS.TENNIS ||
          props?.homeData === SPORTS.BOXING ||
          props?.sportDataTitle === SPORTS.BOXING ||
          props?.homeData === SPORTS.MMA ||
          props?.sportDataTitle === SPORTS.MMA ||
          props?.homeData == SPORTS.SOCCER ||
          props?.sportDataTitle === SPORTS.SOCCER) && (
          <View style={styles.bottom} />
        )}
        {!(
          props?.sportDataTitle === SPORTS.CRICKET ||
          props?.homeData === SPORTS.CRICKET ||
          props?.homeData === SPORTS.BASKETBALL ||
          props?.sportDataTitle === SPORTS.BASKETBALL ||
          props?.homeData === SPORTS.AMERICAN_FOOTBALL ||
          props?.sportDataTitle === SPORTS.AMERICAN_FOOTBALL ||
          props?.homeData === SPORTS.AUSTRALIAN_RULES ||
          props?.sportDataTitle === SPORTS.AUSTRALIAN_RULES ||
          props?.homeData === SPORTS.BASEBALL ||
          props?.sportDataTitle === SPORTS.BASEBALL ||
          props?.homeData === SPORTS.ICE_HOCKEY ||
          props?.sportDataTitle === SPORTS.ICE_HOCKEY ||
          props?.homeData === SPORTS.TENNIS ||
          props?.sportDataTitle === SPORTS.TENNIS ||
          props?.homeData === SPORTS.BOXING ||
          props?.sportDataTitle === SPORTS.BOXING ||
          props?.homeData === SPORTS.MMA ||
          props?.sportDataTitle === SPORTS.MMA ||
          props?.homeData == SPORTS.SOCCER ||
          props?.sportDataTitle === SPORTS.SOCCER
        ) && (
          <>
            <View style={styles.renderStyle}>
              <View style={styles.leftUpArrow}>
                <Pressable
                  onPress={() => props?.handleStepper("left")}
                  style={styles.arrowButtonStyle}
                >
                  <LeftUpArrow
                    width={Metrics.rfv(9)}
                    height={Metrics.rfv(15)}
                  />
                </Pressable>
              </View>
              <View style={styles.rightVertical}></View>
              <Text style={styles.routeName}>
                {props?.stepperCount === 0
                  ? translate("RoundOne")
                  : translate("RoundOne") + " " + `${props?.stepperCount}`}
              </Text>
              <View style={styles.leftVertical}></View>
              <View style={styles.rightArrow}>
                <Pressable
                  style={styles.arrowButtonStyle}
                  onPress={() => props?.handleStepper("right")}
                >
                  <RightUpArrow
                    width={Metrics.rfv(9)}
                    height={Metrics.rfv(15)}
                  />
                </Pressable>
              </View>
            </View>
          </>
        )}
        {props?.isMarketVisible && (
          <Pressable onPress={props?.onMarketPress} style={styles.oddsView}>
            <Text style={styles.textInputStyle} numberOfLines={1}>
              {props?.marketValue}
            </Text>
            <BlackDropDownArrow style={styles.dropdownIcon} />
          </Pressable>
        )}
      </View>
    </>
  );
};

export default SportHeaderComponent;
