import React from "react";
import { StatusBar } from "react-native";

export default function AppStatusBar(props: any) {
  return (
    <StatusBar
      translucent={props.isTransperent}
      barStyle={props.barStyle}
      backgroundColor={props.backgroundColor}
    />
  );
}
