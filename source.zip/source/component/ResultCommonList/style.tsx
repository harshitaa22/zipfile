import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  detailsText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
    marginBottom: Metrics.rfv(5),
  },
  subTitleText: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
  emptyImage: {
    height: Metrics.rfv(80),
    width: "100%",
  },
  bottomWidth: {
    borderBottomWidth: Metrics.rfv(0.7),
    borderBottomColor: Colors.lightGray,
    marginTop: Metrics.rfv(10),
    marginBottom: Metrics.rfv(10),
  },
  containerStyle: {
    marginTop: Metrics.rfv(4),
  },
  raceText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  raceMeterText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(20),
    marginTop: Metrics.rfv(10),
  },
  mainLoginView: {
    paddingVertical: Metrics.rfv(10),
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
    marginTop: Metrics.rfv(7),
  },
  listTitle: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(16),
    lineHeight: Metrics.rfv(20),
  },
  descriptionText: {
    color: Colors.LoremText,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(14),
    lineHeight: Metrics.rfv(16),
  },
  topText: {
    color: Colors.black,
    fontFamily: Fonts.IN_SemiBold,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(18),
    textAlign: "center",
  },
  topTextPrice: {
    color: Colors.black,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(12),
    lineHeight: Metrics.rfv(18),
    textAlign: "center",
  },
  topToteContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
  },
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Metrics.rfv(10),
    justifyContent: "space-between",
  },
  container: {
    flex: 1,
    marginHorizontal: Metrics.rfv(15),
  },
  indexView: {
    flexDirection: "row",
    alignItems: "center",
  },
  indexText: {
    color: Colors.white,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
  indexContainer: {
    backgroundColor: Colors.linearColor2,
    height: Metrics.rfv(20),
    width: Metrics.rfv(20),
    borderRadius: Metrics.rfv(3),
    alignItems: "center",
    justifyContent: "center",
    marginRight: Metrics.rfv(5),
  },
  indexLowText: {
    color: Colors.gray,
    fontFamily: Fonts.IN_Regular,
    fontSize: Metrics.rfv(15),
    lineHeight: Metrics.rfv(20),
  },
  indexLowContainer: {
    backgroundColor: Colors.drownDownBackground,
    height: Metrics.rfv(20),
    width: Metrics.rfv(20),
    borderRadius: Metrics.rfv(3),
    alignItems: "center",
    justifyContent: "center",
    marginRight: Metrics.rfv(5),
  },
  sepraterLine: {
    height: Metrics.rfv(25),
    borderWidth: Metrics.rfv(0.4),
    color: Colors.lineBreak,
    opacity: Metrics.rfv(0.4),
  },
});
