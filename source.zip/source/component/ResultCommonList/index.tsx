import React, { useState } from "react";
import { FlatList, Text, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Colors, Fonts } from "../../theme";
import styles from "./style";

export default function ResultCommonList(props: any) {
  const [data] = useState(props.data);
  const [listData] = useState(props.listData);

  const renderListItem = (item: any, index: any) => {
    return (
      <View style={styles.container} key={index}>
        <View style={styles.titleContainer}>
          <View style={styles.indexView}>
            {item.id > 1 ? (
              <View style={styles.indexLowContainer}>
                <Text style={styles.indexLowText}>{index + 1}</Text>
              </View>
            ) : (
              <View style={styles.indexContainer}>
                <Text style={styles.indexText}>{index + 1}</Text>
              </View>
            )}
            <Text style={styles.listTitle}>{item?.listTitle}</Text>
          </View>
          <Text style={styles.descriptionText}>{item?.jTitle}</Text>
        </View>
        <View style={styles.topToteContainer}>
          <View>
            <Text style={styles.topText}>{item?.topTote}</Text>
            <Text style={styles.topTextPrice}>{item?.topTotePrice}</Text>
          </View>
          <View style={styles.sepraterLine} />
          <View>
            <Text style={styles.topText}>{item?.spText}</Text>
            <Text style={styles.topTextPrice}>{item?.spPrice}</Text>
          </View>
          <View style={styles.sepraterLine} />
          <View>
            <Text style={styles.topText}>{item?.marginText}</Text>
            <Text style={styles.topTextPrice}>{item?.marginPrice}</Text>
          </View>
        </View>
        <View style={styles.bottomWidth} />
      </View>
    );
  };

  const BoldText = (props) => {
    return (
      <Text
        style={{
          fontFamily: Fonts.IN_SemiBold,
        }}
      >
        {props.children}
      </Text>
    );
  };

  const renderItem = (item: any, index1: any) => {
    return (
      <View key={index1}>
        <LinearGradient
          colors={[Colors.linearColor1, Colors.linearColor2]}
          style={styles.mainLoginView}
        >
          <Text style={styles.raceText}>
            <BoldText>Race {index1 + 1} </BoldText>
            {item?.title}
          </Text>
          <Text style={styles.raceMeterText}>{item?.subTitle}</Text>
        </LinearGradient>
        <FlatList
          data={listData}
          scrollEnabled={false}
          contentContainerStyle={styles.containerStyle}
          renderItem={({ item, index }) => renderListItem(item, index)}
          keyExtractor={(item, index) => index.toString()}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}
        />
      </View>
    );
  };

  return (
    <FlatList
      data={data}
      scrollEnabled={false}
      contentContainerStyle={styles.containerStyle}
      renderItem={({ item, index }) => renderItem(item, index)}
      keyExtractor={(item, index1) => index1.toString()}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    />
  );
}
