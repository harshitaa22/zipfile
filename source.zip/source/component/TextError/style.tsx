import {StyleSheet} from 'react-native';
import {Colors, Fonts, Metrics} from '../../theme/index';

export default StyleSheet.create({
  textInput: {
    borderWidth: Metrics.rfv(2),
    height: Metrics.rfv(45),
    borderRadius: Metrics.rfv(8),
    paddingHorizontal: Metrics.rfv(12),
    color: Colors.white,
    fontSize: Metrics.rfv(16),
    backgroundColor: Colors.lightblue,
    borderColor: Colors.white,
    opacity: 0.8,
    placeholderTextColor: Colors.white,
  },
  textMsg: {
    marginTop: Metrics.rfv(3),
    fontSize: Metrics.rfv(12),
    fontFamily: Fonts.IN_Regular,
  },
  commonMargin30: {
    margin: Metrics.rfv(30),
  },
  container: {
    backgroundColor: Colors.linearColor2,
    flex: 1,
  },
});
