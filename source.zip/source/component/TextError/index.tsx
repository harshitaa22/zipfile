import React from 'react';
import {Text, View} from 'react-native';
import styles from './style';

type TextProps = {
  textError?: string;
  color?: string;
};

export default function TextInputError(props: TextProps) {
  return (
    <View>
      <Text style={[styles.textMsg, {color: props.color}]}>
        {props?.textError}
      </Text>
    </View>
  );
}
