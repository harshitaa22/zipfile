import { StyleSheet } from "react-native";
import { Colors, Fonts, Metrics } from "../../theme/index";

export default StyleSheet.create({
  headerStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Metrics.rfv(10),
    marginTop: Metrics.rfv(5),
  },
  horizontalView: {
    paddingHorizontal: Metrics.rfv(15),
    backgroundColor: Colors.white,
  },
  searchIcon: {
    width: Metrics.rfv(20),
    height: Metrics.rfv(20),
  },
  backIconStyle: {
    width: Metrics.rfv(18),
    height: Metrics.rfv(18),
  },
  iconStyle: {
    width: Metrics.rfv(84),
    height: Metrics.rfv(27),
  },
  smartbIcon: {
    width: "100%",
    height: Metrics.rfv(80),
  },
  backContainerStyle: {
    paddingVertical: Metrics.rfv(10),
    paddingRight: Metrics.rfv(10),
    flex: 1,
  },
  backNewsStyle: {
    paddingVertical: Metrics.rfv(10),
    paddingRight: Metrics.rfv(10),
  },
});
