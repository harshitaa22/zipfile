import { View, Text, Pressable, BackHandler } from "react-native";
import React, { useEffect } from "react";
import { BackArrow, CommonAppIcon, SearchIcon } from "../../theme/svg";
import styles from "./style";

import { CommonStyle } from "../../theme";

const CommonHeaderComponent = (props: any) => {
  return (
    <View style={styles.horizontalView}>
      <View style={styles.headerStyle}>
        {props.isShowBack && (
          <Pressable
            style={styles.backContainerStyle}
            onPress={props.onBackPress}
          >
            <BackArrow style={styles.backIconStyle} />
          </Pressable>
        )}
        {props.isShowNewsBack && (
          <Pressable style={styles.backNewsStyle} onPress={props.onBackPress}>
            <BackArrow style={styles.backIconStyle} />
          </Pressable>
        )}
        {props.isShowSmartBIcon && (
          <View style={CommonStyle.commonFlex}>
            <CommonAppIcon style={styles.iconStyle} />
          </View>
        )}
        {/* {props?.showSearchIcon ? null : (
          <SearchIcon style={styles.searchIcon} onPress={props.onPress} />
        )} */}
      </View>
    </View>
  );
};

export default CommonHeaderComponent;
