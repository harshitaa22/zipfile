import React, { useState } from "react";
import { FlatList, Image, RefreshControl, Text, View } from "react-native";
import styles from "./style";
import CardView from "react-native-cardview";
import { translate } from "../../utils/Localize";

type SportListProps = {
  data?: [];
  topicTitle?: string;
};

export default function SportList(props: SportListProps) {
  const { data = [], topicTitle = "" } = props;

  const [refreshing, setRefreshing] = useState(false);
  const ItemSeparatorComponent = () => {
    return <View style={styles.itemSeparatorComponent} />;
  };
  const onRefresh = () => {};

  const renderItem = (item, index) => {
    return (
      <View>
        {index == 0 ? null : <View style={styles.bottomWidth} />}
        <View style={styles.renderListStyle}>
          <View style={styles.vsStyle}>
            <Image style={styles.imageStyle} source={item.imageRacing} />
            <Text style={styles.textStyle}>{item.vs}</Text>
            <Image style={styles.imageStyle} source={item.imageRacing} />
          </View>
          <View>
            <Text style={styles.dateTimeTextStyle}>{item.textDateSport}</Text>
            <Text style={styles.dateOfTimeTextStyle}>{item.timeSport}</Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View>
      <View style={styles.listTitle}>
        <Text style={styles.nextTopicTextStyle}>{topicTitle}</Text>
        <Text style={styles.seeAllStyle}>{translate("SeeAll")}</Text>
      </View>
      <CardView
        style={styles.boxWithShadow}
        cardElevation={5}
        cardMaxElevation={4}
        cornerRadius={7}
      >
        <FlatList
          data={data}
          renderItem={({ item, index }) => renderItem(item, index)}
          ListEmptyComponent={() => {
            return (
              <View style={styles.noDataFoundMainStyle}>
                <Text style={styles.noDataFoundText}>
                  {translate("NoDataFound")}
                </Text>
              </View>
            );
          }}
          // ItemSeparatorComponent={() => ItemSeparatorComponent()}
          keyExtractor={(item, index) => index.toString()}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => onRefresh()}
            />
          }
        />
      </CardView>
    </View>
  );
}
