import React, { useRef, useState } from "react";
import { Animated, FlatList, Linking, ScrollView } from "react-native";
import { Image, Pressable, Text, View } from "react-native";
import { Images, Metrics } from "../../theme/index";
import { DownOrangeArrow, UpOrangeArrow } from "../../theme/svg";
import { translate } from "../../utils/Localize";
import styles from "./style";
import { print_data } from "../../utils/Logs";
import ImageLoad from "../ImageLoad";
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import { SPORTS } from "../../utils/constant";

export default function OutRightOdds(props: any) {
  const scrollViewRef = useRef(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const scrollIndicator = useRef(new Animated.Value(0)).current;
  const [visibleScrollBarWidth, setVisibleScrollBarWidth] = useState(0);
  const scrollIndicatorSize = visibleScrollBarWidth / 2.5;
  const difference = visibleScrollBarWidth - scrollIndicatorSize;

  const scrollIndicatorPosition = scrollIndicator.interpolate({
    extrapolate: "clamp",
    inputRange: [0, visibleScrollBarWidth / 6],
    outputRange: [0, difference],
  });

  const onLayout = (event) => {
    const { width } = event.nativeEvent.layout;
    setVisibleScrollBarWidth(width);
  };

  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    const sportId =
      props?.sportId === SPORTS.CRICKET
        ? 4
        : props?.sportId === SPORTS.RUBGY_LEAGUE
        ? 12
        : props?.sportId === SPORTS.RUBGY_UNION
        ? 13
        : props?.sportId === SPORTS.BASKETBALL
        ? 10
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? 15
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? 9
        : props?.sportId === SPORTS.GOLF
        ? 16
        : props?.sportId === SPORTS.TENNIS
        ? 7
        : props?.sportId === SPORTS.BASEBALL
        ? 11
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? 17
        : props?.sportId === SPORTS.BOXING
        ? 6
        : props?.sportId === SPORTS.MMA
        ? 5
        : props?.sportId === SPORTS.SOCCER
        ? 8
        : 14;
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      print_data("====counter=====");
      print_data(response);
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const fetchSeeAllOutRightsOdds = (data, providerId, teamId) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;
    let outrightsTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == teamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == teamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == teamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == teamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == teamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == teamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == teamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == teamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == teamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == teamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == teamId
        : item?.RLTeamId == teamId;
    });

    let odds = outrightsTeamOdds
      ?.map((obj) => {
        print_data(obj?.odd);
        if (obj?.BookKeeperId === providerId) {
          return { odds: obj?.odd, bookkeeper: obj?.BookKeeperId };
        }
      })
      ?.filter((x) => x !== undefined);
    if (odds?.length > 0) {
      return fetchClickableOdds(
        odds?.[0]?.odds,
        odds?.[0]?.bookkeeper,
        "header"
      );
      // return odds?.[0];
    } else {
      return (
        <View style={styles.oddsCurrentBestContainer}>
          <Text style={styles.subLeftImageRight1}>{translate("NoaText")}</Text>
        </View>
      );
    }
  };
  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;
    print_data("===od=====");
    print_data(odds);
    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsCurrentBestContainer}
      >
        <Text style={styles.subLeftImageRight1}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };

  const oddsSeeAllIcon = (BookKeeperId: number, type: any) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsSeeAllImageContainer}
      >
        {BookKeeperId === 11 ? (
          <Image style={styles.oddsImageIcon} source={Images.topSportOdds} />
        ) : (
          <ImageLoad
            style={styles.oddsImageIcon}
            resizeMode={"stretch"}
            source={
              iconData?.small_logo?.includes("uploads")
                ? API_URL + "/" + iconData?.small_logo
                : iconData?.small_logo
            }
          />
        )}
      </Pressable>
    );
  };

  const renderPageHeadingDataItem = (item, index) => {
    print_data(item?.BookKeeperId);
    var type = "header";
    return (
      <View style={styles.iconContainerStyle} key={index}>
        {fetchSeeAllOutRightsOdds(
          props?.item,
          item?.BookKeeperId,
          props?.teamId
        )}
        {oddsSeeAllIcon(item?.BookKeeperId, "header")}
      </View>
    );
  };

  return (
    <View style={styles.containerStyle}>
      <Pressable
        style={styles.OddsTypeNExtList}
        onPress={() => setIsExpanded(!isExpanded)}
      >
        <Text style={styles.todayTitleTextStyle}>
          {translate("SeeAll")} {translate("OddsText")}
        </Text>
        {isExpanded ? (
          <UpOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
        ) : (
          <DownOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
        )}
      </Pressable>
      {isExpanded && (
        <View style={styles.listContainerStyle}>
          <ScrollView
            ref={scrollViewRef}
            style={styles.contentContainerStyle}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            nestedScrollEnabled={true}
            onLayout={onLayout}
            onScroll={Animated.event(
              [{ nativeEvent: { contentOffset: { x: scrollIndicator } } }],
              { useNativeDriver: false }
            )}
            scrollEventThrottle={16}
            scrollEnabled={true}
          >
            <FlatList
              data={props?.sportItem}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.contentContainerStyle}
              renderItem={({ item, index }) =>
                renderPageHeadingDataItem(item, index)
              }
              keyExtractor={(item, index) => index.toString()}
            />
          </ScrollView>
          {props?.sportItem?.length > 5 && (
            <View style={styles.itemSeparatorComponent}>
              <Animated.View
                style={[
                  styles.indicatorstyle,
                  {
                    width: scrollIndicatorSize,
                    transform: [{ translateX: scrollIndicatorPosition }],
                  },
                ]}
              ></Animated.View>
            </View>
          )}
        </View>
      )}
    </View>
  );
}
