import React, { useRef, useState } from "react";
import { Animated, FlatList, Linking, ScrollView } from "react-native";
import { Image, Pressable, Text, View } from "react-native";

import { Images, Metrics } from "../../theme/index";
import {
  BetFairIcon,
  BookMakerIcon,
  DownOrangeArrow,
  UpOrangeArrow,
} from "../../theme/svg";
import { Constant } from "../../utils";
import { translate } from "../../utils/Localize";
import styles from "./style";
import { print_data } from "../../utils/Logs";
import ImageLoad from "../ImageLoad";
import { API_URL } from "../../../env.json";
import { callApi } from "../../api";
import API_CONFIG from "../../api/api_url";
import { SPORTS } from "../../utils/constant";

export default function SportOdds(props: any) {
  const scrollViewRef = useRef(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const scrollIndicator = useRef(new Animated.Value(0)).current;
  const [visibleScrollBarWidth, setVisibleScrollBarWidth] = useState(0);
  const scrollIndicatorSize = visibleScrollBarWidth / 2.5;
  const difference = visibleScrollBarWidth - scrollIndicatorSize;

  const scrollIndicatorPosition = scrollIndicator.interpolate({
    extrapolate: "clamp",
    inputRange: [0, visibleScrollBarWidth / 6],
    outputRange: [0, difference],
  });

  const onLayout = (event) => {
    const { width } = event.nativeEvent.layout;
    setVisibleScrollBarWidth(width);
  };

  const handleBookkeeperCounter = async (BookKeeperId, type) => {
    const sportId =
      props?.sportId === SPORTS.CRICKET
        ? 4
        : props?.sportId === SPORTS.RUBGY_LEAGUE
        ? 12
        : props?.sportId === SPORTS.RUBGY_UNION
        ? 13
        : props?.sportId === SPORTS.BASKETBALL
        ? 10
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? 15
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? 9
        : props?.sportId === SPORTS.GOLF
        ? 16
        : props?.sportId === SPORTS.TENNIS
        ? 7
        : props?.sportId === SPORTS.BASEBALL
        ? 11
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? 17
        : props?.sportId === SPORTS.BOXING
        ? 6
        : props?.sportId === SPORTS.MMA
        ? 5
        : props?.sportId === SPORTS.SOCCER
        ? 8
        : 14;
    var param_data = {
      BookKeeperId: BookKeeperId,
      type: type,
      SportId: Number(sportId),
    };
    try {
      const response = await callApi(
        API_CONFIG.COUNTER_CLICK,
        param_data,
        API_CONFIG.POST,
        null
      );
      print_data("====counter=====");
      print_data(response);
      if (response.body?.status === 200) {
      }
    } catch (error) {
      print_data("=====handleAdsImression=====" + error);
    }
  };

  const fetchClickableOdds = (odds, BookKeeperId, type) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsCurrentBestContainer}
      >
        <Text style={styles.subLeftImageRight1}>{Number(odds).toFixed(2)}</Text>
      </Pressable>
    );
  };

  const oddsSeeAllIcon = (BookKeeperId: number, type: any) => {
    let icon = props?.bookkeeperData?.filter(
      (obj) => obj?.BookKeeperId === BookKeeperId
    );
    let iconData = icon?.[0]?.BookKeeper;

    return (
      <Pressable
        onPress={() => {
          Linking.openURL(iconData?.affiliate_link);
          handleBookkeeperCounter(BookKeeperId, type);
        }}
        style={styles.oddsSeeAllImageContainer}
      >
        {BookKeeperId === 11 ? (
          <Image style={styles.oddsImageIcon} source={Images.topSportOdds} />
        ) : (
          <ImageLoad
            style={styles.oddsImageIcon}
            resizeMode={"stretch"}
            source={
              iconData?.small_logo?.includes("uploads")
                ? API_URL + "/" + iconData?.small_logo
                : iconData?.small_logo
            }
          />
        )}
      </Pressable>
    );
  };

  const fetchSeeAllawayTeamOddsvalue = (data, providerId, team, type) => {
    let allTeamOdds =
      props?.sportId === SPORTS.CRICKET
        ? data?.CricketBetOffers?.[0]?.CricketOdds
        : props?.sportId === SPORTS.BASKETBALL
        ? data?.NBABetOffers?.[0]?.NBAOdds
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? data?.AFLBetOffers?.[0]?.AFLOdds
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? data?.ARBetOffers?.[0]?.AROdds
        : props?.sportId === SPORTS.TENNIS
        ? data?.TennisBetOffers?.[0]?.TennisOdds
        : props?.sportId === SPORTS.BASEBALL
        ? data?.BaseballBetOffers?.[0]?.BaseballOdds
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? data?.IceHockeyBetOffers?.[0]?.IceHockeyOdds
        : props?.sportId === SPORTS.BOXING
        ? data?.BoxingBetOffers?.[0]?.BoxingOdds
        : props?.sportId === SPORTS.MMA
        ? data?.MMABetOffers?.[0]?.MMAOdds
        : props?.sportId === SPORTS.SOCCER
        ? data?.SoccerBetOffers?.[0]?.SoccerOdds
        : props?.sportId === SPORTS.GOLF
        ? data?.GolfBetOffers?.[0]?.GolfOdds
        : data?.RLBetOffers?.[0]?.RLOdds;

    let awayTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.awayTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.awayTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.awayTeamId
        : item?.RLTeamId == data?.awayTeamId;
    });
    let homeTeamOdds = allTeamOdds?.filter((item) => {
      return props?.sportId === SPORTS.CRICKET
        ? item?.CricketTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASKETBALL
        ? item?.NBATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AMERICAN_FOOTBALL
        ? item?.AFLTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.AUSTRALIAN_RULES
        ? item?.ARTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.TENNIS
        ? item?.TennisTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BASEBALL
        ? item?.BaseballTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.ICE_HOCKEY
        ? item?.IceHockeyTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.BOXING
        ? item?.BoxingTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.MMA
        ? item?.MMATeamId == data?.homeTeamId
        : props?.sportId === SPORTS.SOCCER
        ? item?.SoccerTeamId == data?.homeTeamId
        : props?.sportId === SPORTS.GOLF
        ? item?.GolfTeamId == data?.homeTeamId
        : item?.RLTeamId == data?.homeTeamId;
    });
    let teamInfo = team === "hometeam" ? homeTeamOdds : awayTeamOdds;
    let teamData = props?.marketName === "totals" ? allTeamOdds : teamInfo;

    if (props?.marketName === "totals") {
      let overData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Over";
      });
      let underData = allTeamOdds?.filter((ele) => {
        return ele?.label === "Under";
      });
      teamData = team === "over" ? overData : underData;
    }

    if (type === "odds") {
      if (teamData) {
        let odds = teamData
          ?.map((obj) => {
            if (obj?.BookKeeperId === providerId) {
              return { odds: obj?.odd, bookkeeper: obj?.BookKeeperId };
            }
          })
          ?.filter((x) => x !== undefined);
        if (odds?.length > 0) {
          return fetchClickableOdds(
            odds?.[0]?.odds,
            odds?.[0]?.bookkeeper,
            "header"
          );
        } else {
          return (
            <Text style={styles.bestValueTextStyle}>
              {translate("NoaText")}
            </Text>
          );
        }
      } else {
        return (
          <Text style={styles.bestValueTextStyle}>{translate("NoaText")}</Text>
        );
      }
    } else if (type === "spreadpoints") {
      if (teamData) {
        let odds = teamData
          ?.map((obj) => {
            if (obj?.BookKeeperId === providerId) {
              return props?.marketName === "totals"
                ? obj?.label + " " + obj?.point
                : obj?.point;
            }
          })
          ?.filter((x) => x !== undefined);
        if (odds?.length > 0) {
          return odds?.[0];
        } else {
        }
      } else {
      }
    }
  };

  const renderPageHeadingDataItem = (item, index) => {
    print_data(item);
    var type = "header";
    return (
      // <View style={styles.iconContainerStyle}>
      //   {getOddsTextValue(item, item?.BookKeeperId)}
      //   {oddsIcon(item?.BookKeeperId, type)}
      // </View>
      <View style={styles.iconContainerStyle} key={index}>
        {}
        <Text style={styles.overText}>
          {fetchSeeAllawayTeamOddsvalue(
            props?.item,
            item?.BookKeeperId,
            props?.team,
            "spreadpoints"
          )}
        </Text>

        {fetchSeeAllawayTeamOddsvalue(
          props?.item,
          item?.BookKeeperId,
          props?.team,
          props?.type
        )}
        {oddsSeeAllIcon(item?.BookKeeperId, "header")}
      </View>
    );
  };

  return (
    <View style={styles.containerStyle}>
      <Pressable
        style={styles.OddsTypeNExtList}
        onPress={() => setIsExpanded(!isExpanded)}
      >
        <Text style={styles.todayTitleTextStyle}>
          {translate("SeeAll")} {translate("OddsText")}
        </Text>
        {isExpanded ? (
          <UpOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
        ) : (
          <DownOrangeArrow width={Metrics.rfv(15)} height={Metrics.rfv(15)} />
        )}
      </Pressable>
      {isExpanded && (
        <View style={styles.listContainerStyle}>
          <ScrollView
            ref={scrollViewRef}
            style={styles.contentContainerStyle}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            nestedScrollEnabled={true}
            onLayout={onLayout}
            onScroll={Animated.event(
              [{ nativeEvent: { contentOffset: { x: scrollIndicator } } }],
              { useNativeDriver: false }
            )}
            scrollEventThrottle={16}
            scrollEnabled={true}
          >
            <FlatList
              data={props?.sportItem}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.contentContainerStyle}
              renderItem={({ item, index }) =>
                renderPageHeadingDataItem(item, index)
              }
              keyExtractor={(item, index) => index.toString()}
            />
            {/* <FlatList
              data={props?.item}
              scrollEnabled={false}
              horizontal
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.contentContainerStyle}
              renderItem={({ item, index }) => print_data("helo======")}
              keyExtractor={(item, index) => index.toString()}
            /> */}
          </ScrollView>
          {props?.sportItem?.length > 5 && (
            <View style={styles.itemSeparatorComponent}>
              <Animated.View
                style={[
                  styles.indicatorstyle,
                  {
                    width: scrollIndicatorSize,
                    transform: [{ translateX: scrollIndicatorPosition }],
                  },
                ]}
              ></Animated.View>
            </View>
          )}
        </View>
      )}
    </View>
  );
}
